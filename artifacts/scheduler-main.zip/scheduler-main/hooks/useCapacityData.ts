import { useMemo } from 'react';
import { GameState, ScheduledJob, Team, Shift, Role } from '../types';
import { TOTAL_DAYS } from '../constants';

// --- Type Definitions ---

export interface DailyCapacityData {
  dayIndex: number;
  capacity: number;
  load: number;
  utilization: number;
  isHoliday: boolean;
  isOverloaded: boolean;
}

export interface JobCapacityStatus {
  jobId: string;
  hasWarning: boolean;
  overloadedDays: number;
  maxUtilization: number;
  worstDayIndex: number;
  severity: 'none' | 'warning' | 'critical';
}

export interface CapacityDataOptions {
  baseId?: string;
  hangarIds?: string[];
}

export interface CapacityDataResult {
  dailyCapacities: Float32Array;
  dailyLoads: Float32Array;
  getDayData: (dayIndex: number) => DailyCapacityData;
  getJobCapacityStatus: (job: ScheduledJob) => JobCapacityStatus;
  getOverloadedDays: () => number[];
  getRangeData: (startDay: number, endDay: number) => DailyCapacityData[];
}

// --- Helper Functions ---

/**
 * Calculate hours for a specific day of a job based on dailyEffort/nonWorkDays
 */
const calculateJobHoursForDay = (job: ScheduledJob, dayOffset: number): number => {
  if (job.nonWorkDays?.includes(dayOffset)) return 0;

  const totalWeight = Array.from({ length: job.deadlineDays }).reduce((sum, _, d) => {
    if (job.nonWorkDays?.includes(d)) return sum;
    return sum + (job.dailyEffort?.[d] ?? 1.0);
  }, 0);

  if (totalWeight === 0) return 0;

  const dayWeight = job.dailyEffort?.[dayOffset] ?? 1.0;
  return (dayWeight / totalWeight) * job.estimatedHours;
};

// --- Main Hook ---

export function useCapacityData(
  gameState: GameState,
  options: CapacityDataOptions = {}
): CapacityDataResult {
  const { baseId, hangarIds } = options;
  const bufferPercent = gameState.capacityBufferPercent ?? 15;

  // Build lookup maps for performance
  const { teamMap, shiftMap, roleMap } = useMemo(() => {
    const teamMap = new Map<string, Team>();
    const shiftMap = new Map<string, Shift>();
    const roleMap = new Map<string, Role>();

    gameState.teams.forEach(t => teamMap.set(t.id, t));
    gameState.shifts.forEach(s => shiftMap.set(s.id, s));
    gameState.roles.forEach(r => roleMap.set(r.id, r));

    return { teamMap, shiftMap, roleMap };
  }, [gameState.teams, gameState.shifts, gameState.roles]);

  // Calculate daily capacities based on personnel/shifts/roles
  const dailyCapacities = useMemo(() => {
    const capacities = new Float32Array(TOTAL_DAYS);
    const isGlobal = !baseId || baseId === 'ALL';
    const relevantPersonnel = isGlobal
      ? gameState.personnel
      : gameState.personnel.filter(p => p.baseId === baseId);

    // Build weekly labor profile (indexed by day of week 0-6)
    const dailyLaborProfile = new Float32Array(7);

    relevantPersonnel.forEach(p => {
      const team = teamMap.get(p.teamId || '');
      const role = roleMap.get(p.roleId);

      if (team && role) {
        const shift = shiftMap.get(team.shiftId);
        if (shift) {
          const totalBreakMins = ((shift.breakCount || 0) * (shift.breakDuration || 0)) + (shift.meetingDuration || 0);
          const effectiveDuration = Math.max(0, shift.duration - (totalBreakMins / 60));
          const efficiency = p.efficiencyOverride ?? role.baseEfficiency ?? 1.0;
          const dailyOutput = effectiveDuration * efficiency;

          for (const dayIndex of shift.days) {
            dailyLaborProfile[dayIndex] += dailyOutput;
          }
        }
      }
    });

    // Apply to all days, accounting for holidays
    for (let i = 0; i < TOTAL_DAYS; i++) {
      const isHoliday = gameState.holidays.some(h => h.dayIndex === i && h.enabled);
      if (!isHoliday) {
        const dayOfWeek = (i + 1) % 7;
        capacities[i] = dailyLaborProfile[dayOfWeek];
      }
    }

    return capacities;
  }, [gameState.personnel, gameState.holidays, baseId, teamMap, shiftMap, roleMap]);

  // Calculate daily loads from scheduled jobs
  const dailyLoads = useMemo(() => {
    const loads = new Float32Array(TOTAL_DAYS);
    const isGlobal = !baseId || baseId === 'ALL';

    // Determine which hangars to include
    let relevantHangarIds: string[];
    if (hangarIds) {
      relevantHangarIds = hangarIds;
    } else if (isGlobal) {
      relevantHangarIds = gameState.hangars.map(h => h.id);
    } else {
      relevantHangarIds = gameState.hangars.filter(h => h.baseId === baseId).map(h => h.id);
    }

    gameState.schedule.forEach(job => {
      if (!relevantHangarIds.includes(job.hangarId)) return;

      for (let d = 0; d < job.deadlineDays; d++) {
        const currentDayIndex = job.startDate + d;
        if (currentDayIndex >= 0 && currentDayIndex < TOTAL_DAYS) {
          const hours = calculateJobHoursForDay(job, d);
          if (hours > 0) {
            loads[currentDayIndex] += hours;
          }
        }
      }
    });

    return loads;
  }, [gameState.schedule, gameState.hangars, baseId, hangarIds]);

  // Get detailed data for a specific day
  const getDayData = useMemo(() => {
    return (dayIndex: number): DailyCapacityData => {
      if (dayIndex < 0 || dayIndex >= TOTAL_DAYS) {
        return {
          dayIndex,
          capacity: 0,
          load: 0,
          utilization: 0,
          isHoliday: false,
          isOverloaded: false
        };
      }

      const capacity = dailyCapacities[dayIndex];
      const load = dailyLoads[dayIndex];
      const utilization = capacity > 0 ? (load / capacity) * 100 : 0;
      const isHoliday = gameState.holidays.some(h => h.dayIndex === dayIndex && h.enabled);
      const bufferMultiplier = 1 - (bufferPercent / 100);
      const effectiveCapacity = capacity * bufferMultiplier;
      const isOverloaded = effectiveCapacity > 0 && load > effectiveCapacity;

      return {
        dayIndex,
        capacity,
        load,
        utilization,
        isHoliday,
        isOverloaded
      };
    };
  }, [dailyCapacities, dailyLoads, gameState.holidays, bufferPercent]);

  // Get capacity status for a job (for warnings)
  const getJobCapacityStatus = useMemo(() => {
    return (job: ScheduledJob): JobCapacityStatus => {
      const bufferMultiplier = 1 - (bufferPercent / 100);
      let overloadedDays = 0;
      let maxUtilization = 0;
      let worstDayIndex = -1;

      for (let d = 0; d < job.deadlineDays; d++) {
        const dayIdx = job.startDate + d;
        if (dayIdx >= 0 && dayIdx < TOTAL_DAYS) {
          const load = dailyLoads[dayIdx] || 0;
          const cap = dailyCapacities[dayIdx] || 0;
          const effectiveCap = cap * bufferMultiplier;

          if (effectiveCap > 0 && load > effectiveCap) {
            overloadedDays++;
            const util = cap > 0 ? (load / cap) * 100 : 0;
            if (util > maxUtilization) {
              maxUtilization = util;
              worstDayIndex = dayIdx;
            }
          }
        }
      }

      let severity: 'none' | 'warning' | 'critical' = 'none';
      if (overloadedDays > 0) {
        severity = maxUtilization > 100 ? 'critical' : 'warning';
      }

      return {
        jobId: job.id,
        hasWarning: overloadedDays > 0,
        overloadedDays,
        maxUtilization,
        worstDayIndex,
        severity
      };
    };
  }, [dailyLoads, dailyCapacities, bufferPercent]);

  // Get list of overloaded day indices
  const getOverloadedDays = useMemo(() => {
    return (): number[] => {
      const bufferMultiplier = 1 - (bufferPercent / 100);
      const overloaded: number[] = [];

      for (let i = 0; i < TOTAL_DAYS; i++) {
        const cap = dailyCapacities[i];
        const load = dailyLoads[i];
        const effectiveCap = cap * bufferMultiplier;

        if (effectiveCap > 0 && load > effectiveCap) {
          overloaded.push(i);
        }
      }

      return overloaded;
    };
  }, [dailyCapacities, dailyLoads, bufferPercent]);

  // Get data for a range of days
  const getRangeData = useMemo(() => {
    return (startDay: number, endDay: number): DailyCapacityData[] => {
      const data: DailyCapacityData[] = [];
      const clampedStart = Math.max(0, startDay);
      const clampedEnd = Math.min(TOTAL_DAYS, endDay);

      for (let i = clampedStart; i < clampedEnd; i++) {
        data.push(getDayData(i));
      }

      return data;
    };
  }, [getDayData]);

  return {
    dailyCapacities,
    dailyLoads,
    getDayData,
    getJobCapacityStatus,
    getOverloadedDays,
    getRangeData
  };
}

export default useCapacityData;
