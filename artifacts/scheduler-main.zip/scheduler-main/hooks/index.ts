// Custom Hooks - Linear-inspired utilities
// Barrel export for all custom hooks

export {
  useScrollReveal,
  useStaggeredReveal,
  useScrollProgress,
  getRevealClasses,
} from './useScrollReveal';

export type {
  UseScrollRevealOptions,
  UseScrollRevealReturn,
  UseStaggeredRevealOptions,
} from './useScrollReveal';

export {
  useCapacityData,
} from './useCapacityData';

export type {
  DailyCapacityData,
  JobCapacityStatus,
  CapacityDataOptions,
  CapacityDataResult,
} from './useCapacityData';

export {
  useDebounce,
  useDebouncedCallback,
} from './useDebounce';
