import { useEffect, useRef, useState, useCallback } from 'react';

export interface UseScrollRevealOptions {
  threshold?: number;
  rootMargin?: string;
  triggerOnce?: boolean;
  delay?: number;
}

export interface UseScrollRevealReturn {
  ref: React.RefObject<HTMLDivElement>;
  isVisible: boolean;
  hasTriggered: boolean;
}

/**
 * Hook for scroll-triggered reveal animations
 * Uses IntersectionObserver for efficient visibility detection
 */
export function useScrollReveal(
  options: UseScrollRevealOptions = {}
): UseScrollRevealReturn {
  const {
    threshold = 0.1,
    rootMargin = '0px 0px -50px 0px',
    triggerOnce = true,
    delay = 0,
  } = options;

  const ref = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);
  const [hasTriggered, setHasTriggered] = useState(false);

  useEffect(() => {
    const element = ref.current;
    if (!element) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          // Apply delay if specified
          if (delay > 0) {
            setTimeout(() => {
              setIsVisible(true);
              setHasTriggered(true);
            }, delay);
          } else {
            setIsVisible(true);
            setHasTriggered(true);
          }

          // Disconnect if triggerOnce is true
          if (triggerOnce) {
            observer.disconnect();
          }
        } else if (!triggerOnce) {
          setIsVisible(false);
        }
      },
      {
        threshold,
        rootMargin,
      }
    );

    observer.observe(element);

    return () => {
      observer.disconnect();
    };
  }, [threshold, rootMargin, triggerOnce, delay]);

  return { ref, isVisible, hasTriggered };
}

/**
 * Hook for staggered reveal animations
 * Returns an array of refs and visibility states for each child
 */
export interface UseStaggeredRevealOptions extends UseScrollRevealOptions {
  itemCount: number;
  staggerDelay?: number;
}

export function useStaggeredReveal(options: UseStaggeredRevealOptions) {
  const { itemCount, staggerDelay = 80, ...revealOptions } = options;
  const containerRef = useRef<HTMLDivElement>(null);
  const [visibleItems, setVisibleItems] = useState<boolean[]>(
    new Array(itemCount).fill(false)
  );

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          // Stagger the reveal of each item
          for (let i = 0; i < itemCount; i++) {
            setTimeout(() => {
              setVisibleItems((prev) => {
                const newState = [...prev];
                newState[i] = true;
                return newState;
              });
            }, i * staggerDelay);
          }

          if (revealOptions.triggerOnce !== false) {
            observer.disconnect();
          }
        } else if (revealOptions.triggerOnce === false) {
          setVisibleItems(new Array(itemCount).fill(false));
        }
      },
      {
        threshold: revealOptions.threshold ?? 0.1,
        rootMargin: revealOptions.rootMargin ?? '0px 0px -50px 0px',
      }
    );

    observer.observe(container);

    return () => {
      observer.disconnect();
    };
  }, [itemCount, staggerDelay, revealOptions.threshold, revealOptions.rootMargin, revealOptions.triggerOnce]);

  return { containerRef, visibleItems };
}

/**
 * Hook for scroll progress tracking
 * Returns a value from 0 to 1 based on element's scroll position
 */
export function useScrollProgress() {
  const ref = useRef<HTMLDivElement>(null);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const element = ref.current;
    if (!element) return;

    const handleScroll = () => {
      const rect = element.getBoundingClientRect();
      const windowHeight = window.innerHeight;

      // Calculate progress: 0 when element enters viewport, 1 when it leaves
      const elementTop = rect.top;
      const elementHeight = rect.height;

      // Start measuring when element top enters viewport
      // End when element bottom leaves viewport
      const totalScrollDistance = windowHeight + elementHeight;
      const scrolled = windowHeight - elementTop;

      const newProgress = Math.max(0, Math.min(1, scrolled / totalScrollDistance));
      setProgress(newProgress);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll(); // Initial calculation

    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  return { ref, progress };
}

/**
 * Utility function to get animation class names based on visibility
 */
export function getRevealClasses(
  isVisible: boolean,
  animation: 'fade-up' | 'fade-in' | 'scale' | 'slide-left' | 'slide-right' = 'fade-up'
): string {
  const baseTransition = 'transition-all duration-reveal ease-linear-smooth';

  const animations = {
    'fade-up': {
      hidden: 'opacity-0 translate-y-6',
      visible: 'opacity-100 translate-y-0',
    },
    'fade-in': {
      hidden: 'opacity-0',
      visible: 'opacity-100',
    },
    scale: {
      hidden: 'opacity-0 scale-95',
      visible: 'opacity-100 scale-100',
    },
    'slide-left': {
      hidden: 'opacity-0 translate-x-6',
      visible: 'opacity-100 translate-x-0',
    },
    'slide-right': {
      hidden: 'opacity-0 -translate-x-6',
      visible: 'opacity-100 translate-x-0',
    },
  };

  const animationClasses = animations[animation];
  return `${baseTransition} ${isVisible ? animationClasses.visible : animationClasses.hidden}`;
}

export default useScrollReveal;
