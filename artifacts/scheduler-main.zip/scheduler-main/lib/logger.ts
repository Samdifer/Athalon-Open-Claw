/**
 * Simple logging utility that respects environment
 * - In development: logs to console
 * - In production: suppresses log/warn, keeps error for critical issues
 */

const isDev = import.meta.env.DEV;

export const logger = {
  log: (...args: unknown[]) => {
    if (isDev) console.log(...args);
  },
  warn: (...args: unknown[]) => {
    if (isDev) console.warn(...args);
  },
  error: (...args: unknown[]) => {
    // Always log errors - they indicate actual problems
    console.error(...args);
  },
  // Debug level - only in development with DEBUG flag
  debug: (...args: unknown[]) => {
    if (isDev && import.meta.env.VITE_DEBUG) console.log('[DEBUG]', ...args);
  },
};

export default logger;
