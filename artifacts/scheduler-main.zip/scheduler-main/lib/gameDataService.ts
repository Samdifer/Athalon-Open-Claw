/**
 * Game Data Service - Supabase Integration
 * Handles loading and saving game state to/from Supabase database
 */

import { supabase } from './supabase';
import type {
  GameState, Job, ScheduledJob, Hangar, AircraftModel, Personnel,
  Team, Role, Shift, Base, Holiday, ExpenseItem, CapexItem,
  MarkupTier, ProjectStage, StandardService, ProgressCursor,
  FinancialLogEntry, UIState, QuoteLineItem
} from '../types';
import type { Database } from './database.types';
import { logger } from './logger';

// Database row types - extracted from Supabase generated types
type DbJob = Database['public']['Tables']['jobs']['Row'];
type DbScheduledJob = Database['public']['Tables']['scheduled_jobs']['Row'];
type DbHangar = Database['public']['Tables']['hangars']['Row'];
type DbAircraftModel = Database['public']['Tables']['aircraft_models']['Row'];
type DbPersonnel = Database['public']['Tables']['personnel']['Row'];
type DbTeam = Database['public']['Tables']['teams']['Row'];
type DbRole = Database['public']['Tables']['roles']['Row'];
type DbShift = Database['public']['Tables']['shifts']['Row'];
type DbBase = Database['public']['Tables']['bases']['Row'];
type DbHoliday = Database['public']['Tables']['holidays']['Row'];
type DbExpenseItem = Database['public']['Tables']['expense_items']['Row'];
type DbCapexItem = Database['public']['Tables']['capex_items']['Row'];
type DbMarkupTier = Database['public']['Tables']['markup_tiers']['Row'];
type DbProjectStage = Database['public']['Tables']['project_stages']['Row'];
type DbStandardService = Database['public']['Tables']['standard_services']['Row'];
type DbCursor = Database['public']['Tables']['progress_cursors']['Row'];
type DbFinancialEntry = Database['public']['Tables']['financial_log_entries']['Row'];
type DbQuoteLineItem = Database['public']['Tables']['quote_line_items']['Row'];
type DbNonWorkDay = Database['public']['Tables']['scheduled_job_non_work_days']['Row'];
type DbDailyEffort = Database['public']['Tables']['scheduled_job_daily_efforts']['Row'];

// Get the current user's organization ID
async function getOrganizationId(): Promise<string | null> {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) {
    logger.warn('No authenticated user found');
    return null;
  }

  const { data: profile, error } = await supabase
    .from('profiles')
    .select('organization_id')
    .eq('id', user.id)
    .single();

  if (error) {
    logger.error('Error fetching user profile:', error);
    return null;
  }

  if (!profile?.organization_id) {
    logger.warn('User profile exists but has no organization_id - this may be a newly registered user waiting for trigger to complete');
    return null;
  }

  return profile.organization_id;
}

// ============================================
// LOAD FUNCTIONS - Fetch data from Supabase
// ============================================

export async function loadGameState(): Promise<GameState | null> {
  const orgId = await getOrganizationId();
  if (!orgId) {
    logger.log('No organization ID available - user may need organization initialization');
    return null;
  }

  try {
    // Load all data in parallel for performance
    const [
      settingsResult,
      jobsResult,
      scheduledJobsResult,
      hangarsResult,
      aircraftModelsResult,
      personnelResult,
      teamsResult,
      rolesResult,
      shiftsResult,
      basesResult,
      holidaysResult,
      expenseItemsResult,
      capexItemsResult,
      partMarkupsResult,
      serviceMarkupsResult,
      projectStagesResult,
      standardServicesResult,
      cursorsResult,
      financialHistoryResult,
      quoteLineItemsResult,
    ] = await Promise.all([
      supabase.from('organization_settings').select('*').eq('organization_id', orgId).maybeSingle(),
      supabase.from('jobs').select('*').eq('organization_id', orgId).eq('is_deleted', false),
      supabase.from('scheduled_jobs').select('*').eq('organization_id', orgId),
      supabase.from('hangars').select('*').eq('organization_id', orgId),
      supabase.from('aircraft_models').select('*').eq('organization_id', orgId),
      supabase.from('personnel').select('*').eq('organization_id', orgId),
      supabase.from('teams').select('*').eq('organization_id', orgId),
      supabase.from('roles').select('*').eq('organization_id', orgId),
      supabase.from('shifts').select('*').eq('organization_id', orgId),
      supabase.from('bases').select('*').eq('organization_id', orgId),
      supabase.from('holidays').select('*').eq('organization_id', orgId),
      supabase.from('expense_items').select('*').eq('organization_id', orgId),
      supabase.from('capex_items').select('*').eq('organization_id', orgId),
      supabase.from('markup_tiers').select('*').eq('organization_id', orgId).eq('tier_type', 'parts'),
      supabase.from('markup_tiers').select('*').eq('organization_id', orgId).eq('tier_type', 'services'),
      supabase.from('project_stages').select('*').eq('organization_id', orgId),
      supabase.from('standard_services').select('*').eq('organization_id', orgId),
      supabase.from('progress_cursors').select('*').eq('organization_id', orgId),
      supabase.from('financial_log_entries').select('*').eq('organization_id', orgId),
      supabase.from('quote_line_items').select('*').eq('organization_id', orgId),
    ]);

    // Optional tables - fetch separately and handle errors gracefully
    let nonWorkDaysResult = { data: [], error: null };
    let dailyEffortsResult = { data: [], error: null };

    // Try to fetch optional tables, but don't fail if they don't exist
    // Note: These join tables don't have organization_id - they're filtered by scheduled_job_id in transform
    const nonWorkDaysAttempt = await supabase.from('scheduled_job_non_work_days').select('*');
    if (!nonWorkDaysAttempt.error) {
      nonWorkDaysResult = nonWorkDaysAttempt;
    } else {
      logger.warn('scheduled_job_non_work_days table not available (this is OK)');
    }

    const dailyEffortsAttempt = await supabase.from('scheduled_job_daily_efforts').select('*');
    if (!dailyEffortsAttempt.error) {
      dailyEffortsResult = dailyEffortsAttempt;
    } else {
      logger.warn('scheduled_job_daily_efforts table not available (this is OK)');
    }

    // If no settings exist, return null (new org needs initialization)
    if (!settingsResult.data) {
      logger.log('No organization settings found - new organization');
      return null;
    }

    const settings = settingsResult.data;

    // Transform database records to frontend format
    const jobs = transformJobs(jobsResult.data || [], quoteLineItemsResult.data || []);
    const scheduledJobs = transformScheduledJobs(
      scheduledJobsResult.data || [],
      jobs,
      nonWorkDaysResult.data || [],
      dailyEffortsResult.data || []
    );

    // Separate backlog (unscheduled) from graveyard (deleted)
    const backlog = jobs.filter(j => !scheduledJobs.some(sj => sj.id === j.id));

    // Load deleted jobs for graveyard
    const { data: deletedJobs } = await supabase
      .from('jobs')
      .select('*')
      .eq('organization_id', orgId)
      .eq('is_deleted', true);
    const graveyard = transformJobs(deletedJobs || [], []);

    const gameState: GameState = {
      day: settings.current_day || 0,
      cash: Number(settings.cash) || 500000,
      efficiency: Number(settings.efficiency) || 1.0,
      paused: settings.paused ?? true,
      speed: settings.speed || 1000,
      shopRate: Number(settings.shop_rate) || 125,
      overheadDaily: Number(settings.overhead_daily) || 4500,

      hangars: transformHangars(hangarsResult.data || []),
      aircraftModels: transformAircraftModels(aircraftModelsResult.data || []),
      personnel: transformPersonnel(personnelResult.data || []),
      teams: transformTeams(teamsResult.data || []),
      roles: transformRoles(rolesResult.data || []),
      shifts: transformShifts(shiftsResult.data || []),
      bases: transformBases(basesResult.data || []),
      holidays: transformHolidays(holidaysResult.data || []),
      expenseItems: transformExpenseItems(expenseItemsResult.data || []),
      capexItems: transformCapexItems(capexItemsResult.data || []),
      partMarkups: transformMarkupTiers(partMarkupsResult.data || []),
      serviceMarkups: transformMarkupTiers(serviceMarkupsResult.data || []),
      projectStages: transformProjectStages(projectStagesResult.data || []),
      standardServices: transformStandardServices(standardServicesResult.data || []),
      cursors: transformCursors(cursorsResult.data || []),
      financialHistory: transformFinancialHistory(financialHistoryResult.data || []),

      backlog,
      schedule: scheduledJobs,
      graveyard,

      events: [],
      activeEvent: null,
      notifications: [],

      uiState: settings.ui_state || getDefaultUIState(),
    };

    return gameState;
  } catch (error) {
    logger.error('Error loading game state:', error);
    return null;
  }
}

// ============================================
// SAVE FUNCTIONS - Persist data to Supabase
// ============================================

export async function saveGameState(state: GameState): Promise<boolean> {
  const orgId = await getOrganizationId();
  if (!orgId) {
    logger.error('No organization ID found');
    return false;
  }

  try {
    // Save settings - query existing ID first for proper upsert
    const { data: existingSettings } = await supabase
      .from('organization_settings')
      .select('id')
      .eq('organization_id', orgId)
      .maybeSingle();

    await supabase
      .from('organization_settings')
      .upsert({
        ...(existingSettings?.id && { id: existingSettings.id }),
        organization_id: orgId,
        current_day: state.day,
        cash: state.cash,
        efficiency: state.efficiency,
        paused: state.paused,
        speed: state.speed,
        shop_rate: state.shopRate,
        overhead_daily: state.overheadDaily,
        ui_state: state.uiState,
        updated_at: new Date().toISOString(),
      }, { onConflict: 'organization_id' });

    // Save all entities - using upsert for idempotency
    await Promise.all([
      saveJobs(orgId, state.backlog, false),
      saveJobs(orgId, state.graveyard, true),
      saveScheduledJobs(orgId, state.schedule),
      saveHangars(orgId, state.hangars),
      saveAircraftModels(orgId, state.aircraftModels),
      savePersonnel(orgId, state.personnel),
      saveTeams(orgId, state.teams),
      saveRoles(orgId, state.roles),
      saveShifts(orgId, state.shifts),
      saveBases(orgId, state.bases),
      saveHolidays(orgId, state.holidays),
      saveExpenseItems(orgId, state.expenseItems),
      saveCapexItems(orgId, state.capexItems),
      saveMarkupTiers(orgId, 'parts', state.partMarkups),
      saveMarkupTiers(orgId, 'services', state.serviceMarkups),
      saveProjectStages(orgId, state.projectStages),
      saveStandardServices(orgId, state.standardServices),
      saveCursors(orgId, state.cursors),
      saveFinancialHistory(orgId, state.financialHistory),
    ]);

    return true;
  } catch (error) {
    logger.error('Error saving game state:', error);
    return false;
  }
}

// ============================================
// TRANSFORM FUNCTIONS - DB to Frontend format
// ============================================

function transformJobs(dbJobs: DbJob[], quoteLines: DbQuoteLineItem[]): Job[] {
  return dbJobs.map(j => ({
    id: j.id,
    customer: j.customer,
    aircraftType: j.aircraft_type,
    description: j.description,
    estimatedHours: Number(j.estimated_hours),
    revenue: Number(j.revenue),
    partsRevenue: j.parts_revenue ? Number(j.parts_revenue) : undefined,
    color: j.color,
    deadlineDays: j.deadline_days,
    requiredHangarSize: j.required_hangar_size,
    isAOG: j.is_aog,
    arrivalDay: j.arrival_day,
    notes: j.notes,
    quoteLines: quoteLines
      .filter(ql => ql.job_id === j.id)
      .map(ql => ({
        id: ql.id,
        description: ql.description,
        category: ql.category,
        laborHours: Number(ql.labor_hours),
        laborRate: Number(ql.labor_rate),
        partsCost: Number(ql.parts_cost),
        partsMarkup: Number(ql.parts_markup),
        fixedPrice: ql.fixed_price ? Number(ql.fixed_price) : undefined,
      })),
  }));
}

function transformScheduledJobs(
  dbScheduled: DbScheduledJob[],
  jobs: Job[],
  nonWorkDays: DbNonWorkDay[],
  dailyEfforts: DbDailyEffort[]
): ScheduledJob[] {
  return dbScheduled.map(sj => {
    const job = jobs.find(j => j.id === sj.job_id);
    if (!job) return null;

    const jobNonWorkDays = nonWorkDays
      .filter(nwd => nwd.scheduled_job_id === sj.id)
      .map(nwd => nwd.day_offset);

    const jobDailyEfforts: Record<number, number> = {};
    dailyEfforts
      .filter(de => de.scheduled_job_id === sj.id)
      .forEach(de => {
        jobDailyEfforts[de.day_offset] = Number(de.effort);
      });

    return {
      ...job,
      startDate: sj.start_date,
      hangarId: sj.hangar_id,
      progress: Number(sj.progress),
      status: sj.status,
      endDate: sj.end_date,
      paymentReceived: sj.payment_received,
      nonWorkDays: jobNonWorkDays.length > 0 ? jobNonWorkDays : undefined,
      dailyEffort: Object.keys(jobDailyEfforts).length > 0 ? jobDailyEfforts : undefined,
    };
  }).filter(Boolean) as ScheduledJob[];
}

function transformHangars(dbHangars: DbHangar[]): Hangar[] {
  return dbHangars.map(h => ({
    id: h.id,
    name: h.name,
    size: h.size,
    supportedTypes: h.supported_types || [],
    baseId: h.base_id,
  }));
}

function transformAircraftModels(dbModels: DbAircraftModel[]): AircraftModel[] {
  return dbModels.map(m => ({
    id: m.id,
    name: m.name,
    manufacturer: m.manufacturer || '',
  }));
}

function transformPersonnel(dbPersonnel: DbPersonnel[]): Personnel[] {
  return dbPersonnel.map(p => ({
    id: p.id,
    name: p.name,
    roleId: p.role_id,
    teamId: p.team_id,
    baseId: p.base_id,
    efficiencyOverride: p.efficiency_override ? Number(p.efficiency_override) : undefined,
  }));
}

function transformTeams(dbTeams: DbTeam[]): Team[] {
  return dbTeams.map(t => ({
    id: t.id,
    name: t.name,
    color: t.color,
    shiftId: t.shift_id,
    baseId: t.base_id,
  }));
}

function transformRoles(dbRoles: DbRole[]): Role[] {
  return dbRoles.map(r => ({
    id: r.id,
    name: r.name,
    baseEfficiency: Number(r.base_efficiency),
    hourlyRate: Number(r.hourly_rate),
    burdenMultiplier: Number(r.burden_multiplier),
    hourlyCost: Number(r.hourly_cost),
  }));
}

function transformShifts(dbShifts: DbShift[]): Shift[] {
  return dbShifts.map(s => ({
    id: s.id,
    name: s.name,
    days: s.days || [],
    startHour: s.start_hour,
    duration: s.duration,
    breakCount: s.break_count,
    breakDuration: s.break_duration,
    meetingDuration: s.meeting_duration,
  }));
}

function transformBases(dbBases: DbBase[]): Base[] {
  return dbBases.map(b => ({
    id: b.id,
    name: b.name,
    location: b.location,
  }));
}

function transformHolidays(dbHolidays: DbHoliday[]): Holiday[] {
  return dbHolidays.map(h => ({
    id: h.id,
    name: h.name,
    date: h.date,
    dayIndex: h.day_index,
    enabled: h.enabled,
  }));
}

function transformExpenseItems(dbExpenses: DbExpenseItem[]): ExpenseItem[] {
  return dbExpenses.map(e => ({
    id: e.id,
    category: e.category,
    name: e.name,
    monthlyCost: Number(e.monthly_cost),
    overrides: e.overrides || undefined,
  }));
}

function transformCapexItems(dbCapex: DbCapexItem[]): CapexItem[] {
  return dbCapex.map(c => ({
    id: c.id,
    name: c.name,
    cost: Number(c.cost),
    plannedDay: c.planned_day,
    amortize: c.amortize,
  }));
}

function transformMarkupTiers(dbTiers: DbMarkupTier[]): MarkupTier[] {
  return dbTiers.map(t => ({
    maxLimit: Number(t.max_limit),
    markup: Number(t.markup),
  }));
}

function transformProjectStages(dbStages: DbProjectStage[]): ProjectStage[] {
  return dbStages.map(s => ({
    id: s.id,
    label: s.label,
    color: s.color,
    description: s.description,
  }));
}

function transformStandardServices(dbServices: DbStandardService[]): StandardService[] {
  return dbServices.map(s => ({
    id: s.id,
    description: s.description,
    category: s.category,
    laborHours: Number(s.labor_hours),
    laborRate: Number(s.labor_rate),
    partsCost: Number(s.parts_cost),
    partsMarkup: Number(s.parts_markup),
    fixedPrice: s.fixed_price ? Number(s.fixed_price) : undefined,
    applicableModelId: s.applicable_model_id,
  }));
}

function transformCursors(dbCursors: DbCursor[]): ProgressCursor[] {
  return dbCursors.map(c => ({
    id: c.id,
    label: c.label,
    dayOffset: c.day_offset,
    color: c.color,
    enabled: c.enabled,
  }));
}

function transformFinancialHistory(dbHistory: DbFinancialEntry[]): FinancialLogEntry[] {
  return dbHistory.map(h => ({
    day: h.day,
    income: Number(h.income),
    spend: Number(h.spend),
    profit: Number(h.profit),
  }));
}

// ============================================
// SAVE HELPER FUNCTIONS - Frontend to DB format
// ============================================

async function saveJobs(orgId: string, jobs: Job[], isDeleted: boolean): Promise<void> {
  if (jobs.length === 0) return;

  const dbJobs = jobs.map(j => ({
    id: j.id,
    organization_id: orgId,
    customer: j.customer,
    aircraft_type: j.aircraftType,
    description: j.description,
    estimated_hours: j.estimatedHours,
    revenue: j.revenue,
    parts_revenue: j.partsRevenue,
    color: j.color,
    deadline_days: j.deadlineDays,
    required_hangar_size: j.requiredHangarSize,
    is_aog: j.isAOG,
    arrival_day: j.arrivalDay,
    notes: j.notes,
    is_deleted: isDeleted,
    deleted_at: isDeleted ? new Date().toISOString() : null,
  }));

  await supabase.from('jobs').upsert(dbJobs, { onConflict: 'id' });

  // Save quote line items
  const allQuoteLines: any[] = [];
  jobs.forEach(j => {
    if (j.quoteLines) {
      j.quoteLines.forEach(ql => {
        allQuoteLines.push({
          id: ql.id,
          organization_id: orgId,
          job_id: j.id,
          description: ql.description,
          category: ql.category,
          labor_hours: ql.laborHours,
          labor_rate: ql.laborRate,
          parts_cost: ql.partsCost,
          parts_markup: ql.partsMarkup,
          fixed_price: ql.fixedPrice,
          updated_at: new Date().toISOString(),
        });
      });
    }
  });

  if (allQuoteLines.length > 0) {
    await supabase.from('quote_line_items').upsert(allQuoteLines, { onConflict: 'id' });
  }
}

async function saveScheduledJobs(orgId: string, scheduledJobs: ScheduledJob[]): Promise<void> {
  // First save the jobs data
  await saveJobs(orgId, scheduledJobs, false);

  if (scheduledJobs.length === 0) return;

  // Save scheduled job records
  const dbScheduled = scheduledJobs.map(sj => ({
    id: sj.id, // Use job ID as scheduled job ID for simplicity
    organization_id: orgId,
    job_id: sj.id,
    hangar_id: sj.hangarId,
    start_date: sj.startDate,
    end_date: sj.endDate,
    progress: sj.progress,
    status: sj.status,
    payment_received: sj.paymentReceived,
    updated_at: new Date().toISOString(),
  }));

  await supabase.from('scheduled_jobs').upsert(dbScheduled, { onConflict: 'id' });

  // Use atomic RPC functions for non-work days and daily efforts
  for (const sj of scheduledJobs) {
    // Atomic upsert for non-work days
    await supabase.rpc('upsert_scheduled_job_non_work_days', {
      p_scheduled_job_id: sj.id,
      p_day_offsets: sj.nonWorkDays || [],
    });

    // Atomic upsert for daily efforts
    const effortsArray = sj.dailyEffort
      ? Object.entries(sj.dailyEffort).map(([dayOffset, effort]) => ({
          day_offset: parseInt(dayOffset),
          effort: effort,
        }))
      : [];

    await supabase.rpc('upsert_scheduled_job_daily_efforts', {
      p_scheduled_job_id: sj.id,
      p_efforts: effortsArray,
    });
  }
}

async function saveHangars(orgId: string, hangars: Hangar[]): Promise<void> {
  const dbHangars = hangars.map(h => ({
    id: h.id,
    organization_id: orgId,
    name: h.name,
    size: h.size,
    supported_types: h.supportedTypes,
    base_id: h.baseId,
    updated_at: new Date().toISOString(),
  }));

  await supabase.from('hangars').upsert(dbHangars, { onConflict: 'id' });
}

async function saveAircraftModels(orgId: string, models: AircraftModel[]): Promise<void> {
  const dbModels = models.map(m => ({
    id: m.id,
    organization_id: orgId,
    code: m.id, // Use id as code (e.g., 'GULF', 'GLO')
    name: m.name,
    manufacturer: m.manufacturer || null,
    updated_at: new Date().toISOString(),
  }));

  await supabase.from('aircraft_models').upsert(dbModels, { onConflict: 'organization_id,code' });
}

async function savePersonnel(orgId: string, personnel: Personnel[]): Promise<void> {
  const dbPersonnel = personnel.map(p => ({
    id: p.id,
    organization_id: orgId,
    name: p.name,
    role_id: p.roleId,
    team_id: p.teamId,
    base_id: p.baseId,
    efficiency_override: p.efficiencyOverride,
    updated_at: new Date().toISOString(),
  }));

  await supabase.from('personnel').upsert(dbPersonnel, { onConflict: 'id' });
}

async function saveTeams(orgId: string, teams: Team[]): Promise<void> {
  const dbTeams = teams.map(t => ({
    id: t.id,
    organization_id: orgId,
    name: t.name,
    color: t.color,
    shift_id: t.shiftId,
    base_id: t.baseId,
    updated_at: new Date().toISOString(),
  }));

  await supabase.from('teams').upsert(dbTeams, { onConflict: 'id' });
}

async function saveRoles(orgId: string, roles: Role[]): Promise<void> {
  const dbRoles = roles.map(r => ({
    id: r.id,
    organization_id: orgId,
    name: r.name,
    base_efficiency: r.baseEfficiency,
    hourly_rate: r.hourlyRate,
    burden_multiplier: r.burdenMultiplier,
    hourly_cost: r.hourlyCost,
    updated_at: new Date().toISOString(),
  }));

  await supabase.from('roles').upsert(dbRoles, { onConflict: 'id' });
}

async function saveShifts(orgId: string, shifts: Shift[]): Promise<void> {
  const dbShifts = shifts.map(s => ({
    id: s.id,
    organization_id: orgId,
    name: s.name,
    days: s.days,
    start_hour: s.startHour,
    duration: s.duration,
    break_count: s.breakCount,
    break_duration: s.breakDuration,
    meeting_duration: s.meetingDuration,
    updated_at: new Date().toISOString(),
  }));

  await supabase.from('shifts').upsert(dbShifts, { onConflict: 'id' });
}

async function saveBases(orgId: string, bases: Base[]): Promise<void> {
  const dbBases = bases.map(b => ({
    id: b.id,
    organization_id: orgId,
    name: b.name,
    location: b.location,
    updated_at: new Date().toISOString(),
  }));

  await supabase.from('bases').upsert(dbBases, { onConflict: 'id' });
}

async function saveHolidays(orgId: string, holidays: Holiday[]): Promise<void> {
  const dbHolidays = holidays.map(h => ({
    id: h.id,
    organization_id: orgId,
    name: h.name,
    date: h.date,
    day_index: h.dayIndex,
    enabled: h.enabled,
    updated_at: new Date().toISOString(),
  }));

  await supabase.from('holidays').upsert(dbHolidays, { onConflict: 'id' });
}

async function saveExpenseItems(orgId: string, expenses: ExpenseItem[]): Promise<void> {
  const dbExpenses = expenses.map(e => ({
    id: e.id,
    organization_id: orgId,
    category: e.category,
    name: e.name,
    monthly_cost: e.monthlyCost,
    updated_at: new Date().toISOString(),
  }));

  await supabase.from('expense_items').upsert(dbExpenses, { onConflict: 'id' });
}

async function saveCapexItems(orgId: string, capex: CapexItem[]): Promise<void> {
  const dbCapex = capex.map(c => ({
    id: c.id,
    organization_id: orgId,
    name: c.name,
    cost: c.cost,
    planned_day: c.plannedDay,
    amortize: c.amortize,
    updated_at: new Date().toISOString(),
  }));

  await supabase.from('capex_items').upsert(dbCapex, { onConflict: 'id' });
}

async function saveMarkupTiers(orgId: string, tierType: 'parts' | 'services', tiers: MarkupTier[]): Promise<void> {
  // Delete existing tiers for this type
  await supabase.from('markup_tiers').delete().eq('organization_id', orgId).eq('tier_type', tierType);

  if (tiers.length === 0) return;

  const dbTiers = tiers.map((t, index) => ({
    id: `${orgId}-${tierType}-${index}`,
    organization_id: orgId,
    tier_type: tierType,
    max_limit: t.maxLimit,
    markup: t.markup,
    sort_order: index,
    updated_at: new Date().toISOString(),
  }));

  await supabase.from('markup_tiers').insert(dbTiers);
}

async function saveProjectStages(orgId: string, stages: ProjectStage[]): Promise<void> {
  const dbStages = stages.map((s, index) => ({
    id: s.id,
    organization_id: orgId,
    label: s.label,
    color: s.color,
    description: s.description,
    sort_order: index,
    updated_at: new Date().toISOString(),
  }));

  await supabase.from('project_stages').upsert(dbStages, { onConflict: 'id' });
}

async function saveStandardServices(orgId: string, services: StandardService[]): Promise<void> {
  const dbServices = services.map(s => ({
    id: s.id,
    organization_id: orgId,
    description: s.description,
    category: s.category,
    labor_hours: s.laborHours,
    labor_rate: s.laborRate,
    parts_cost: s.partsCost,
    parts_markup: s.partsMarkup,
    fixed_price: s.fixedPrice,
    applicable_model_id: s.applicableModelId,
    updated_at: new Date().toISOString(),
  }));

  await supabase.from('standard_services').upsert(dbServices, { onConflict: 'id' });
}

async function saveCursors(orgId: string, cursors: ProgressCursor[]): Promise<void> {
  const dbCursors = cursors.map(c => ({
    id: c.id,
    organization_id: orgId,
    label: c.label,
    day_offset: c.dayOffset,
    color: c.color,
    enabled: c.enabled,
    updated_at: new Date().toISOString(),
  }));

  await supabase.from('progress_cursors').upsert(dbCursors, { onConflict: 'id' });
}

async function saveFinancialHistory(orgId: string, history: FinancialLogEntry[]): Promise<void> {
  // Only save recent history to avoid huge tables
  const recentHistory = history.slice(-365); // Keep last year

  // Delete existing and insert new
  await supabase.from('financial_log_entries').delete().eq('organization_id', orgId);

  if (recentHistory.length === 0) return;

  const dbHistory = recentHistory.map(h => ({
    id: `${orgId}-${h.day}`,
    organization_id: orgId,
    day: h.day,
    income: h.income,
    spend: h.spend,
    profit: h.profit,
  }));

  await supabase.from('financial_log_entries').insert(dbHistory);
}

// ============================================
// INITIALIZATION - Set up new organization
// ============================================

export async function initializeOrganizationData(defaultState: GameState): Promise<boolean> {
  const orgId = await getOrganizationId();
  if (!orgId) {
    logger.error('No organization ID found');
    return false;
  }

  try {
    // Check if already initialized
    const { data: existing } = await supabase
      .from('organization_settings')
      .select('id')
      .eq('organization_id', orgId)
      .single();

    if (existing) {
      logger.log('Organization already initialized');
      return true;
    }

    // Initialize with default state
    await saveGameState(defaultState);
    return true;
  } catch (error) {
    logger.error('Error initializing organization:', error);
    return false;
  }
}

// Default UI State
function getDefaultUIState(): UIState {
  return {
    backlogOpen: false,
    analyticsOpen: false,
    pnlOpen: false,
    capacityOpen: false,
    rosterOpen: false,
    cellWidth: 40,
    layoutDims: {
      backlogWidth: 288,
      rosterWidth: 320,
      capacityHeight: 176,
      pnlHeight: 208,
      analyticsHeight: 192,
    },
    popouts: {
      analytics: false,
      backlog: false,
      pnl: false,
      cashflow: false,
      capacity: false,
      roster: false,
      graveyard: false,
    },
    selectedBaseId: 'ALL',
    tutorialActive: false,
    tutorialStep: 0,
  };
}
