// Database types for MRO-AI Supabase schema
// Auto-generated based on schema.sql

export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[];

export interface Database {
  public: {
    Tables: {
      organizations: {
        Row: {
          id: string;
          name: string;
          slug: string;
          subscription_status: 'trial' | 'active' | 'cancelled' | 'past_due';
          subscription_tier: string;
          trial_ends_at: string | null;
          stripe_customer_id: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          name: string;
          slug: string;
          subscription_status?: 'trial' | 'active' | 'cancelled' | 'past_due';
          subscription_tier?: string;
          trial_ends_at?: string | null;
          stripe_customer_id?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          name?: string;
          slug?: string;
          subscription_status?: 'trial' | 'active' | 'cancelled' | 'past_due';
          subscription_tier?: string;
          trial_ends_at?: string | null;
          stripe_customer_id?: string | null;
          created_at?: string;
          updated_at?: string;
        };
      };
      profiles: {
        Row: {
          id: string;
          organization_id: string | null;
          email: string;
          full_name: string | null;
          role: 'owner' | 'admin' | 'manager' | 'technician' | 'viewer';
          avatar_url: string | null;
          auth_provider: 'email' | 'google' | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id: string;
          organization_id?: string | null;
          email: string;
          full_name?: string | null;
          role?: 'owner' | 'admin' | 'manager' | 'technician' | 'viewer';
          avatar_url?: string | null;
          auth_provider?: 'email' | 'google' | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          organization_id?: string | null;
          email?: string;
          full_name?: string | null;
          role?: 'owner' | 'admin' | 'manager' | 'technician' | 'viewer';
          avatar_url?: string | null;
          auth_provider?: 'email' | 'google' | null;
          created_at?: string;
          updated_at?: string;
        };
      };
      invitations: {
        Row: {
          id: string;
          organization_id: string;
          email: string;
          role: 'admin' | 'manager' | 'technician' | 'viewer';
          invited_by: string | null;
          token: string;
          expires_at: string;
          accepted_at: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          organization_id: string;
          email: string;
          role: 'admin' | 'manager' | 'technician' | 'viewer';
          invited_by?: string | null;
          token?: string;
          expires_at?: string;
          accepted_at?: string | null;
          created_at?: string;
        };
        Update: {
          organization_id?: string;
          email?: string;
          role?: 'admin' | 'manager' | 'technician' | 'viewer';
          invited_by?: string | null;
          expires_at?: string;
          accepted_at?: string | null;
        };
      };
      bases: {
        Row: {
          id: string;
          organization_id: string;
          name: string;
          location: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          organization_id: string;
          name: string;
          location?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          organization_id?: string;
          name?: string;
          location?: string | null;
          created_at?: string;
        };
      };
      hangars: {
        Row: {
          id: string;
          organization_id: string;
          base_id: string | null;
          name: string;
          size: 'Small' | 'Medium' | 'Large' | null;
          supported_types: string[] | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          organization_id: string;
          base_id?: string | null;
          name: string;
          size?: 'Small' | 'Medium' | 'Large' | null;
          supported_types?: string[] | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          organization_id?: string;
          base_id?: string | null;
          name?: string;
          size?: 'Small' | 'Medium' | 'Large' | null;
          supported_types?: string[] | null;
          created_at?: string;
        };
      };
      aircraft_models: {
        Row: {
          id: string;
          organization_id: string;
          code: string;
          name: string;
          manufacturer: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          organization_id: string;
          code: string;
          name: string;
          manufacturer?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          organization_id?: string;
          code?: string;
          name?: string;
          manufacturer?: string | null;
          created_at?: string;
        };
      };
      roles: {
        Row: {
          id: string;
          organization_id: string;
          name: string;
          base_efficiency: number;
          hourly_rate: number;
          burden_multiplier: number;
          hourly_cost: number;
          created_at: string;
        };
        Insert: {
          id?: string;
          organization_id: string;
          name: string;
          base_efficiency?: number;
          hourly_rate: number;
          burden_multiplier?: number;
          hourly_cost: number;
          created_at?: string;
        };
        Update: {
          id?: string;
          organization_id?: string;
          name?: string;
          base_efficiency?: number;
          hourly_rate?: number;
          burden_multiplier?: number;
          hourly_cost?: number;
          created_at?: string;
        };
      };
      shifts: {
        Row: {
          id: string;
          organization_id: string;
          name: string;
          days: number[];
          start_hour: number;
          duration: number;
          break_count: number;
          break_duration: number;
          meeting_duration: number;
          created_at: string;
        };
        Insert: {
          id?: string;
          organization_id: string;
          name: string;
          days: number[];
          start_hour: number;
          duration: number;
          break_count?: number;
          break_duration?: number;
          meeting_duration?: number;
          created_at?: string;
        };
        Update: {
          id?: string;
          organization_id?: string;
          name?: string;
          days?: number[];
          start_hour?: number;
          duration?: number;
          break_count?: number;
          break_duration?: number;
          meeting_duration?: number;
          created_at?: string;
        };
      };
      teams: {
        Row: {
          id: string;
          organization_id: string;
          name: string;
          color: string | null;
          shift_id: string | null;
          base_id: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          organization_id: string;
          name: string;
          color?: string | null;
          shift_id?: string | null;
          base_id?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          organization_id?: string;
          name?: string;
          color?: string | null;
          shift_id?: string | null;
          base_id?: string | null;
          created_at?: string;
        };
      };
      personnel: {
        Row: {
          id: string;
          organization_id: string;
          name: string;
          role_id: string | null;
          team_id: string | null;
          base_id: string | null;
          efficiency_override: number | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          organization_id: string;
          name: string;
          role_id?: string | null;
          team_id?: string | null;
          base_id?: string | null;
          efficiency_override?: number | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          organization_id?: string;
          name?: string;
          role_id?: string | null;
          team_id?: string | null;
          base_id?: string | null;
          efficiency_override?: number | null;
          created_at?: string;
        };
      };
      jobs: {
        Row: {
          id: string;
          organization_id: string;
          customer: string;
          aircraft_type: string;
          description: string;
          estimated_hours: number;
          revenue: number;
          parts_revenue: number;
          color: string;
          deadline_days: number;
          required_hangar_size: 'Small' | 'Medium' | 'Large' | null;
          is_aog: boolean;
          arrival_day: number | null;
          notes: string | null;
          is_deleted: boolean;
          deleted_at: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          organization_id: string;
          customer: string;
          aircraft_type: string;
          description: string;
          estimated_hours: number;
          revenue: number;
          parts_revenue?: number;
          color?: string;
          deadline_days: number;
          required_hangar_size?: 'Small' | 'Medium' | 'Large' | null;
          is_aog?: boolean;
          arrival_day?: number | null;
          notes?: string | null;
          is_deleted?: boolean;
          deleted_at?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          organization_id?: string;
          customer?: string;
          aircraft_type?: string;
          description?: string;
          estimated_hours?: number;
          revenue?: number;
          parts_revenue?: number;
          color?: string;
          deadline_days?: number;
          required_hangar_size?: 'Small' | 'Medium' | 'Large' | null;
          is_aog?: boolean;
          arrival_day?: number | null;
          notes?: string | null;
          is_deleted?: boolean;
          deleted_at?: string | null;
          created_at?: string;
          updated_at?: string;
        };
      };
      quote_line_items: {
        Row: {
          id: string;
          job_id: string;
          organization_id: string;
          description: string;
          category: 'Labor' | 'Part' | 'Service' | null;
          labor_hours: number;
          labor_rate: number;
          parts_cost: number;
          parts_markup: number;
          fixed_price: number | null;
          sort_order: number;
          created_at: string;
        };
        Insert: {
          id?: string;
          job_id: string;
          organization_id: string;
          description: string;
          category?: 'Labor' | 'Part' | 'Service' | null;
          labor_hours?: number;
          labor_rate?: number;
          parts_cost?: number;
          parts_markup?: number;
          fixed_price?: number | null;
          sort_order?: number;
          created_at?: string;
        };
        Update: {
          id?: string;
          job_id?: string;
          organization_id?: string;
          description?: string;
          category?: 'Labor' | 'Part' | 'Service' | null;
          labor_hours?: number;
          labor_rate?: number;
          parts_cost?: number;
          parts_markup?: number;
          fixed_price?: number | null;
          sort_order?: number;
          created_at?: string;
        };
      };
      scheduled_jobs: {
        Row: {
          id: string;
          organization_id: string;
          job_id: string;
          hangar_id: string | null;
          start_date: number;
          end_date: number | null;
          progress: number;
          status: 'Scheduled' | 'In Progress' | 'Completed' | 'Late';
          payment_received: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          organization_id: string;
          job_id: string;
          hangar_id?: string | null;
          start_date: number;
          end_date?: number | null;
          progress?: number;
          status?: 'Scheduled' | 'In Progress' | 'Completed' | 'Late';
          payment_received?: boolean;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          organization_id?: string;
          job_id?: string;
          hangar_id?: string | null;
          start_date?: number;
          end_date?: number | null;
          progress?: number;
          status?: 'Scheduled' | 'In Progress' | 'Completed' | 'Late';
          payment_received?: boolean;
          created_at?: string;
          updated_at?: string;
        };
      };
      scheduled_job_non_work_days: {
        Row: {
          id: string;
          scheduled_job_id: string;
          day_offset: number;
        };
        Insert: {
          id?: string;
          scheduled_job_id: string;
          day_offset: number;
        };
        Update: {
          id?: string;
          scheduled_job_id?: string;
          day_offset?: number;
        };
      };
      scheduled_job_daily_efforts: {
        Row: {
          id: string;
          scheduled_job_id: string;
          day_offset: number;
          effort: number;
        };
        Insert: {
          id?: string;
          scheduled_job_id: string;
          day_offset: number;
          effort: number;
        };
        Update: {
          id?: string;
          scheduled_job_id?: string;
          day_offset?: number;
          effort?: number;
        };
      };
      standard_services: {
        Row: {
          id: string;
          organization_id: string;
          description: string;
          category: 'Labor' | 'Part' | 'Service' | null;
          labor_hours: number;
          labor_rate: number;
          parts_cost: number;
          parts_markup: number;
          applicable_model_id: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          organization_id: string;
          description: string;
          category?: 'Labor' | 'Part' | 'Service' | null;
          labor_hours?: number;
          labor_rate?: number;
          parts_cost?: number;
          parts_markup?: number;
          applicable_model_id?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          organization_id?: string;
          description?: string;
          category?: 'Labor' | 'Part' | 'Service' | null;
          labor_hours?: number;
          labor_rate?: number;
          parts_cost?: number;
          parts_markup?: number;
          applicable_model_id?: string | null;
          created_at?: string;
        };
      };
      project_stages: {
        Row: {
          id: string;
          organization_id: string;
          label: string;
          color: string;
          description: string | null;
          sort_order: number;
          created_at: string;
        };
        Insert: {
          id?: string;
          organization_id: string;
          label: string;
          color: string;
          description?: string | null;
          sort_order?: number;
          created_at?: string;
        };
        Update: {
          id?: string;
          organization_id?: string;
          label?: string;
          color?: string;
          description?: string | null;
          sort_order?: number;
          created_at?: string;
        };
      };
      holidays: {
        Row: {
          id: string;
          organization_id: string;
          name: string;
          date: string;
          day_index: number;
          enabled: boolean;
          created_at: string;
        };
        Insert: {
          id?: string;
          organization_id: string;
          name: string;
          date: string;
          day_index: number;
          enabled?: boolean;
          created_at?: string;
        };
        Update: {
          id?: string;
          organization_id?: string;
          name?: string;
          date?: string;
          day_index?: number;
          enabled?: boolean;
          created_at?: string;
        };
      };
      progress_cursors: {
        Row: {
          id: string;
          organization_id: string;
          label: string;
          day_offset: number;
          color: string;
          enabled: boolean;
          created_at: string;
        };
        Insert: {
          id?: string;
          organization_id: string;
          label: string;
          day_offset: number;
          color: string;
          enabled?: boolean;
          created_at?: string;
        };
        Update: {
          id?: string;
          organization_id?: string;
          label?: string;
          day_offset?: number;
          color?: string;
          enabled?: boolean;
          created_at?: string;
        };
      };
      expense_items: {
        Row: {
          id: string;
          organization_id: string;
          category: 'Facility' | 'Admin' | 'IT' | 'Marketing' | 'Personnel' | 'Other' | null;
          name: string;
          monthly_cost: number;
          created_at: string;
        };
        Insert: {
          id?: string;
          organization_id: string;
          category?: 'Facility' | 'Admin' | 'IT' | 'Marketing' | 'Personnel' | 'Other' | null;
          name: string;
          monthly_cost: number;
          created_at?: string;
        };
        Update: {
          id?: string;
          organization_id?: string;
          category?: 'Facility' | 'Admin' | 'IT' | 'Marketing' | 'Personnel' | 'Other' | null;
          name?: string;
          monthly_cost?: number;
          created_at?: string;
        };
      };
      expense_overrides: {
        Row: {
          id: string;
          expense_item_id: string;
          year_month: string;
          override_amount: number;
        };
        Insert: {
          id?: string;
          expense_item_id: string;
          year_month: string;
          override_amount: number;
        };
        Update: {
          id?: string;
          expense_item_id?: string;
          year_month?: string;
          override_amount?: number;
        };
      };
      capex_items: {
        Row: {
          id: string;
          organization_id: string;
          name: string;
          cost: number;
          planned_day: number;
          amortize: boolean;
          created_at: string;
        };
        Insert: {
          id?: string;
          organization_id: string;
          name: string;
          cost: number;
          planned_day: number;
          amortize?: boolean;
          created_at?: string;
        };
        Update: {
          id?: string;
          organization_id?: string;
          name?: string;
          cost?: number;
          planned_day?: number;
          amortize?: boolean;
          created_at?: string;
        };
      };
      markup_tiers: {
        Row: {
          id: string;
          organization_id: string;
          tier_type: 'parts' | 'services';
          max_limit: number;
          markup: number;
          sort_order: number;
          created_at: string;
        };
        Insert: {
          id?: string;
          organization_id: string;
          tier_type: 'parts' | 'services';
          max_limit: number;
          markup: number;
          sort_order?: number;
          created_at?: string;
        };
        Update: {
          id?: string;
          organization_id?: string;
          tier_type?: 'parts' | 'services';
          max_limit?: number;
          markup?: number;
          sort_order?: number;
          created_at?: string;
        };
      };
      financial_log_entries: {
        Row: {
          id: string;
          organization_id: string;
          day: number;
          income: number;
          spend: number;
          profit: number;
          created_at: string;
        };
        Insert: {
          id?: string;
          organization_id: string;
          day: number;
          income?: number;
          spend?: number;
          profit?: number;
          created_at?: string;
        };
        Update: {
          id?: string;
          organization_id?: string;
          day?: number;
          income?: number;
          spend?: number;
          profit?: number;
          created_at?: string;
        };
      };
      organization_settings: {
        Row: {
          id: string;
          organization_id: string;
          current_day: number;
          cash: number;
          efficiency: number;
          paused: boolean;
          speed: number;
          shop_rate: number;
          overhead_daily: number;
          ui_state: Json;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          organization_id: string;
          current_day?: number;
          cash?: number;
          efficiency?: number;
          paused?: boolean;
          speed?: number;
          shop_rate?: number;
          overhead_daily?: number;
          ui_state?: Json;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          organization_id?: string;
          current_day?: number;
          cash?: number;
          efficiency?: number;
          paused?: boolean;
          speed?: number;
          shop_rate?: number;
          overhead_daily?: number;
          ui_state?: Json;
          created_at?: string;
          updated_at?: string;
        };
      };
    };
    Views: {};
    Functions: {
      get_user_organization_id: {
        Args: Record<string, never>;
        Returns: string;
      };
    };
    Enums: {};
  };
}

// Convenience type aliases
export type Organization = Database['public']['Tables']['organizations']['Row'];
export type Profile = Database['public']['Tables']['profiles']['Row'];
export type Base = Database['public']['Tables']['bases']['Row'];
export type Hangar = Database['public']['Tables']['hangars']['Row'];
export type AircraftModel = Database['public']['Tables']['aircraft_models']['Row'];
export type Role = Database['public']['Tables']['roles']['Row'];
export type Shift = Database['public']['Tables']['shifts']['Row'];
export type Team = Database['public']['Tables']['teams']['Row'];
export type Personnel = Database['public']['Tables']['personnel']['Row'];
export type Job = Database['public']['Tables']['jobs']['Row'];
export type QuoteLineItem = Database['public']['Tables']['quote_line_items']['Row'];
export type ScheduledJob = Database['public']['Tables']['scheduled_jobs']['Row'];
export type ScheduledJobNonWorkDay = Database['public']['Tables']['scheduled_job_non_work_days']['Row'];
export type ScheduledJobDailyEffort = Database['public']['Tables']['scheduled_job_daily_efforts']['Row'];
export type StandardService = Database['public']['Tables']['standard_services']['Row'];
export type ProjectStage = Database['public']['Tables']['project_stages']['Row'];
export type Holiday = Database['public']['Tables']['holidays']['Row'];
export type ProgressCursor = Database['public']['Tables']['progress_cursors']['Row'];
export type ExpenseItem = Database['public']['Tables']['expense_items']['Row'];
export type ExpenseOverride = Database['public']['Tables']['expense_overrides']['Row'];
export type CapexItem = Database['public']['Tables']['capex_items']['Row'];
export type MarkupTier = Database['public']['Tables']['markup_tiers']['Row'];
export type FinancialLogEntry = Database['public']['Tables']['financial_log_entries']['Row'];
export type OrganizationSettings = Database['public']['Tables']['organization_settings']['Row'];

// Insert types
export type OrganizationInsert = Database['public']['Tables']['organizations']['Insert'];
export type ProfileInsert = Database['public']['Tables']['profiles']['Insert'];
export type JobInsert = Database['public']['Tables']['jobs']['Insert'];
export type ScheduledJobInsert = Database['public']['Tables']['scheduled_jobs']['Insert'];
