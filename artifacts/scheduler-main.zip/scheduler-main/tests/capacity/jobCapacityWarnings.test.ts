import { describe, it, expect } from 'vitest';
import { renderHook } from '@testing-library/react';
import { useCapacityData } from '../../hooks/useCapacityData';
import type { GameState, ScheduledJob, Personnel, Team, Shift, Role, Hangar, Base } from '../../types';

// Helper to create minimal valid GameState
const createMockGameState = (overrides: Partial<GameState> = {}): GameState => ({
  day: 100,
  cash: 100000,
  efficiency: 1.0,
  paused: false,
  speed: 1,
  hangars: [],
  aircraftModels: [],
  customAircraftPackages: [],
  shopRate: 125,
  standardServices: [],
  projectStages: [],
  partMarkups: [],
  serviceMarkups: [],
  backlog: [],
  schedule: [],
  graveyard: [],
  bases: [],
  personnel: [],
  teams: [],
  shifts: [],
  roles: [],
  holidays: [],
  overheadDaily: 4500,
  capacityBufferPercent: 15,
  expenseItems: [],
  capexItems: [],
  cursors: [],
  events: [],
  activeEvent: null,
  notifications: [],
  financialHistory: [],
  uiState: {
    backlogOpen: true,
    analyticsOpen: false,
    pnlOpen: false,
    capacityOpen: true,
    rosterOpen: false,
    cellWidth: 40,
    layoutDims: {
      backlogWidth: 280,
      rosterWidth: 200,
      capacityHeight: 120,
      pnlHeight: 200,
      analyticsHeight: 200
    },
    popouts: {
      analytics: false,
      backlog: false,
      pnl: false,
      cashflow: false,
      capacity: false,
      roster: false
    },
    selectedBaseId: 'ALL',
    tutorialActive: false,
    tutorialStep: 0,
    onboardingCompleted: false,
    completedSections: []
  },
  ...overrides
});

// Helper to create workforce
const createWorkforce = (personnelCount: number = 2) => {
  const bases: Base[] = [
    { id: 'base-1', name: 'Main Base', location: 'Airport A' }
  ];

  const shifts: Shift[] = [
    {
      id: 'shift-1',
      name: 'Day Shift',
      days: [1, 2, 3, 4, 5], // Mon-Fri
      startHour: 8,
      duration: 8,
      breakCount: 1,
      breakDuration: 30,
      meetingDuration: 15
    }
  ];

  const roles: Role[] = [
    {
      id: 'role-1',
      name: 'Mechanic',
      baseEfficiency: 1.0,
      hourlyRate: 45,
      burdenMultiplier: 1.35,
      hourlyCost: 60.75
    }
  ];

  const teams: Team[] = [
    {
      id: 'team-1',
      name: 'A Team',
      color: 'blue-500',
      shiftId: 'shift-1',
      baseId: 'base-1'
    }
  ];

  const personnel: Personnel[] = Array.from({ length: personnelCount }, (_, i) => ({
    id: `person-${i + 1}`,
    name: `Worker ${i + 1}`,
    roleId: 'role-1',
    teamId: 'team-1',
    baseId: 'base-1'
  }));

  const hangars: Hangar[] = [
    { id: 'hangar-1', name: 'Hangar A', size: 'Large', supportedTypes: [], baseId: 'base-1' }
  ];

  return { personnel, teams, shifts, roles, bases, hangars };
};

// Helper to create a scheduled job
const createJob = (overrides: Partial<ScheduledJob> = {}): ScheduledJob => ({
  id: `job-${Math.random().toString(36).substring(7)}`,
  customer: 'N12345',
  aircraftType: 'cessna-172',
  description: 'Test Job',
  estimatedHours: 40,
  revenue: 5000,
  color: '#3b82f6',
  deadlineDays: 5,
  requiredHangarSize: 'Small',
  isAOG: false,
  startDate: 100,
  hangarId: 'hangar-1',
  progress: 0,
  status: 'Scheduled',
  ...overrides
});

describe('Job Capacity Warnings', () => {
  describe('Warning Detection', () => {
    it('should not warn for jobs well under capacity', () => {
      const workforce = createWorkforce(2);
      // 2 workers * ~7.25 effective hours = ~14.5 capacity per day
      // Job: 10 hours over 5 days = 2 hours/day (well under capacity)
      const job = createJob({
        estimatedHours: 10,
        deadlineDays: 5
      });

      const gameState = createMockGameState({
        ...workforce,
        schedule: [job],
        capacityBufferPercent: 15
      });

      const { result } = renderHook(() => useCapacityData(gameState));
      const status = result.current.getJobCapacityStatus(job);

      expect(status.hasWarning).toBe(false);
      expect(status.severity).toBe('none');
      expect(status.overloadedDays).toBe(0);
    });

    it('should warn for jobs exceeding buffer threshold', () => {
      const workforce = createWorkforce(2);
      // ~14.5 capacity, 15% buffer = effective capacity ~12.3
      // Job: 70 hours over 5 days = 14 hours/day (exceeds 12.3)
      const job = createJob({
        estimatedHours: 70,
        deadlineDays: 5
      });

      const gameState = createMockGameState({
        ...workforce,
        schedule: [job],
        capacityBufferPercent: 15
      });

      const { result } = renderHook(() => useCapacityData(gameState));
      const status = result.current.getJobCapacityStatus(job);

      expect(status.hasWarning).toBe(true);
      expect(['warning', 'critical']).toContain(status.severity);
      expect(status.overloadedDays).toBeGreaterThan(0);
    });

    it('should return critical severity when over 100% capacity', () => {
      const workforce = createWorkforce(2);
      // ~14.5 capacity
      // Job: 100 hours over 5 days = 20 hours/day (138% of capacity)
      const job = createJob({
        estimatedHours: 100,
        deadlineDays: 5
      });

      const gameState = createMockGameState({
        ...workforce,
        schedule: [job],
        capacityBufferPercent: 15
      });

      const { result } = renderHook(() => useCapacityData(gameState));
      const status = result.current.getJobCapacityStatus(job);

      expect(status.hasWarning).toBe(true);
      expect(status.severity).toBe('critical');
      expect(status.maxUtilization).toBeGreaterThan(100);
    });
  });

  describe('Multi-Job Scenarios', () => {
    it('should detect overload from cumulative job load', () => {
      const workforce = createWorkforce(2);
      // Two jobs that individually are fine but together exceed capacity
      const job1 = createJob({
        id: 'job-1',
        estimatedHours: 40,
        deadlineDays: 5,
        startDate: 100
      });
      const job2 = createJob({
        id: 'job-2',
        estimatedHours: 40,
        deadlineDays: 5,
        startDate: 100
      });

      const gameState = createMockGameState({
        ...workforce,
        schedule: [job1, job2],
        capacityBufferPercent: 15
      });

      const { result } = renderHook(() => useCapacityData(gameState));

      // Total: 80 hours over 5 days = 16 hours/day vs ~14.5 capacity
      const status1 = result.current.getJobCapacityStatus(job1);
      const status2 = result.current.getJobCapacityStatus(job2);

      // Both jobs should show warnings since the cumulative load exceeds capacity
      expect(status1.hasWarning || status2.hasWarning).toBe(true);
    });

    it('should not warn when jobs are staggered without overlap', () => {
      const workforce = createWorkforce(2);
      // Two jobs that don't overlap
      const job1 = createJob({
        id: 'job-1',
        estimatedHours: 20,
        deadlineDays: 5,
        startDate: 100
      });
      const job2 = createJob({
        id: 'job-2',
        estimatedHours: 20,
        deadlineDays: 5,
        startDate: 105 // Starts after job1 ends
      });

      const gameState = createMockGameState({
        ...workforce,
        schedule: [job1, job2],
        capacityBufferPercent: 15
      });

      const { result } = renderHook(() => useCapacityData(gameState));

      const status1 = result.current.getJobCapacityStatus(job1);
      const status2 = result.current.getJobCapacityStatus(job2);

      // Individual jobs at 4 hours/day are under capacity
      expect(status1.hasWarning).toBe(false);
      expect(status2.hasWarning).toBe(false);
    });

    it('should correctly count overloaded days for overlapping jobs', () => {
      const workforce = createWorkforce(2);
      // Job 1: days 100-104
      // Job 2: days 102-106 (overlaps days 102-104)
      const job1 = createJob({
        id: 'job-1',
        estimatedHours: 36, // ~7.2/day, alone would be under capacity
        deadlineDays: 5,
        startDate: 100
      });
      const job2 = createJob({
        id: 'job-2',
        estimatedHours: 36,
        deadlineDays: 5,
        startDate: 102
      });

      const gameState = createMockGameState({
        ...workforce,
        schedule: [job1, job2],
        capacityBufferPercent: 15
      });

      const { result } = renderHook(() => useCapacityData(gameState));
      const overloadedDays = result.current.getOverloadedDays();

      // Days 102-104 overlap, should have ~14.4 hours/day (over buffer)
      // These days should be overloaded
      const overlappingDays = overloadedDays.filter(d => d >= 102 && d <= 104);
      expect(overlappingDays.length).toBeGreaterThan(0);
    });
  });

  describe('AOG Jobs', () => {
    it('should still calculate capacity status for AOG jobs', () => {
      const workforce = createWorkforce(2);
      const aogJob = createJob({
        estimatedHours: 100,
        deadlineDays: 2,
        isAOG: true
      });

      const gameState = createMockGameState({
        ...workforce,
        schedule: [aogJob],
        capacityBufferPercent: 15
      });

      const { result } = renderHook(() => useCapacityData(gameState));
      const status = result.current.getJobCapacityStatus(aogJob);

      // The hook should still calculate the status (UI decides whether to show warning)
      expect(status).toHaveProperty('hasWarning');
      expect(status).toHaveProperty('severity');
      // AOG job with 100hrs over 2 days = 50hrs/day is definitely over capacity
      expect(status.hasWarning).toBe(true);
    });
  });

  describe('Warning Status Properties', () => {
    it('should return correct worstDayIndex', () => {
      const workforce = createWorkforce(2);
      const job = createJob({
        estimatedHours: 100,
        deadlineDays: 5,
        startDate: 100
      });

      const gameState = createMockGameState({
        ...workforce,
        schedule: [job],
        capacityBufferPercent: 15
      });

      const { result } = renderHook(() => useCapacityData(gameState));
      const status = result.current.getJobCapacityStatus(job);

      // worstDayIndex should be within the job's span
      expect(status.worstDayIndex).toBeGreaterThanOrEqual(100);
      expect(status.worstDayIndex).toBeLessThan(105);
    });

    it('should track correct number of overloaded days', () => {
      const workforce = createWorkforce(2);
      // Job that's overloaded for all 5 days
      const job = createJob({
        estimatedHours: 100,
        deadlineDays: 5,
        startDate: 100
      });

      const gameState = createMockGameState({
        ...workforce,
        schedule: [job],
        capacityBufferPercent: 15
      });

      const { result } = renderHook(() => useCapacityData(gameState));
      const status = result.current.getJobCapacityStatus(job);

      // All 5 days should be overloaded (20 hours/day vs ~14.5 capacity)
      // But only weekdays count if shift is Mon-Fri
      expect(status.overloadedDays).toBeGreaterThan(0);
      expect(status.overloadedDays).toBeLessThanOrEqual(5);
    });

    it('should include jobId in status', () => {
      const workforce = createWorkforce(2);
      const job = createJob({
        id: 'test-job-123',
        estimatedHours: 100,
        deadlineDays: 5
      });

      const gameState = createMockGameState({
        ...workforce,
        schedule: [job],
        capacityBufferPercent: 15
      });

      const { result } = renderHook(() => useCapacityData(gameState));
      const status = result.current.getJobCapacityStatus(job);

      expect(status.jobId).toBe('test-job-123');
    });
  });

  describe('Job with Variable Daily Effort', () => {
    it('should correctly warn when specific days are overloaded', () => {
      const workforce = createWorkforce(2);
      // Job with front-loaded effort
      const job = createJob({
        estimatedHours: 40,
        deadlineDays: 5,
        startDate: 100,
        dailyEffort: {
          0: 3.0, // Day 100: heavy
          1: 3.0, // Day 101: heavy
          2: 1.0, // Day 102: normal
          3: 0.5, // Day 103: light
          4: 0.5  // Day 104: light
        }
      });

      const gameState = createMockGameState({
        ...workforce,
        schedule: [job],
        capacityBufferPercent: 15
      });

      const { result } = renderHook(() => useCapacityData(gameState));

      // Total weight = 8, total hours = 40
      // Day 100: (3/8)*40 = 15 hours (over ~14.5 capacity)
      // Day 101: (3/8)*40 = 15 hours (over capacity)
      // Day 102: (1/8)*40 = 5 hours (under capacity)
      // Day 103: (0.5/8)*40 = 2.5 hours (under capacity)
      // Day 104: (0.5/8)*40 = 2.5 hours (under capacity)

      const day100Data = result.current.getDayData(100);
      const day104Data = result.current.getDayData(104);

      expect(day100Data.load).toBe(15);
      expect(day104Data.load).toBe(2.5);
    });

    it('should not count nonWorkDays as overloaded', () => {
      const workforce = createWorkforce(2);
      const job = createJob({
        estimatedHours: 40,
        deadlineDays: 5,
        startDate: 100,
        nonWorkDays: [0, 2, 4] // Only work on days 1 and 3
      });

      const gameState = createMockGameState({
        ...workforce,
        schedule: [job],
        capacityBufferPercent: 15
      });

      const { result } = renderHook(() => useCapacityData(gameState));

      // Day 100, 102, 104 should have 0 load
      expect(result.current.dailyLoads[100]).toBe(0);
      expect(result.current.dailyLoads[102]).toBe(0);
      expect(result.current.dailyLoads[104]).toBe(0);

      // Days 101 and 103 should have load (40 hours / 2 days = 20 hours each)
      expect(result.current.dailyLoads[101]).toBe(20);
      expect(result.current.dailyLoads[103]).toBe(20);
    });
  });

  describe('Buffer Percentage Impact', () => {
    it('should be more sensitive with higher buffer percentage', () => {
      const workforce = createWorkforce(2);
      const job = createJob({
        estimatedHours: 60, // ~12 hours/day
        deadlineDays: 5,
        startDate: 100
      });

      // Test with different buffer percentages
      const state30Buffer = createMockGameState({
        ...workforce,
        schedule: [job],
        capacityBufferPercent: 30 // Very sensitive, warns at 70% capacity
      });

      const state5Buffer = createMockGameState({
        ...workforce,
        schedule: [job],
        capacityBufferPercent: 5 // Less sensitive, warns at 95% capacity
      });

      const { result: result30 } = renderHook(() => useCapacityData(state30Buffer));
      const { result: result5 } = renderHook(() => useCapacityData(state5Buffer));

      const status30 = result30.current.getJobCapacityStatus(job);
      const status5 = result5.current.getJobCapacityStatus(job);

      // 12 hours/day vs ~14.5 capacity = ~83% utilization
      // With 30% buffer (warn at 70%), should warn
      // With 5% buffer (warn at 95%), should not warn
      expect(status30.overloadedDays).toBeGreaterThanOrEqual(status5.overloadedDays);
    });
  });
});
