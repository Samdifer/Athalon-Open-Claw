import { describe, it, expect, beforeEach } from 'vitest';
import { renderHook } from '@testing-library/react';
import { useCapacityData } from '../../hooks/useCapacityData';
import type { GameState, ScheduledJob, Personnel, Team, Shift, Role, Hangar, Base, Holiday } from '../../types';
import { TOTAL_DAYS } from '../../constants';

// Helper to create minimal valid GameState
const createMockGameState = (overrides: Partial<GameState> = {}): GameState => ({
  day: 100,
  cash: 100000,
  efficiency: 1.0,
  paused: false,
  speed: 1,
  hangars: [],
  aircraftModels: [],
  customAircraftPackages: [],
  shopRate: 125,
  standardServices: [],
  projectStages: [],
  partMarkups: [],
  serviceMarkups: [],
  backlog: [],
  schedule: [],
  graveyard: [],
  bases: [],
  personnel: [],
  teams: [],
  shifts: [],
  roles: [],
  holidays: [],
  overheadDaily: 4500,
  capacityBufferPercent: 15,
  expenseItems: [],
  capexItems: [],
  cursors: [],
  events: [],
  activeEvent: null,
  notifications: [],
  financialHistory: [],
  uiState: {
    backlogOpen: true,
    analyticsOpen: false,
    pnlOpen: false,
    capacityOpen: true,
    rosterOpen: false,
    cellWidth: 40,
    layoutDims: {
      backlogWidth: 280,
      rosterWidth: 200,
      capacityHeight: 120,
      pnlHeight: 200,
      analyticsHeight: 200
    },
    popouts: {
      analytics: false,
      backlog: false,
      pnl: false,
      cashflow: false,
      capacity: false,
      roster: false
    },
    selectedBaseId: 'ALL',
    tutorialActive: false,
    tutorialStep: 0,
    onboardingCompleted: false,
    completedSections: []
  },
  ...overrides
});

// Helper to create test personnel with shifts
const createTestPersonnel = (): {
  personnel: Personnel[];
  teams: Team[];
  shifts: Shift[];
  roles: Role[];
  bases: Base[];
} => {
  const bases: Base[] = [
    { id: 'base-1', name: 'Main Base', location: 'Airport A' }
  ];

  const shifts: Shift[] = [
    {
      id: 'shift-1',
      name: 'Day Shift',
      days: [1, 2, 3, 4, 5], // Mon-Fri
      startHour: 8,
      duration: 8,
      breakCount: 1,
      breakDuration: 30,
      meetingDuration: 15
    }
  ];

  const roles: Role[] = [
    {
      id: 'role-1',
      name: 'Mechanic',
      baseEfficiency: 1.0,
      hourlyRate: 45,
      burdenMultiplier: 1.35,
      hourlyCost: 60.75
    }
  ];

  const teams: Team[] = [
    {
      id: 'team-1',
      name: 'A Team',
      color: 'blue-500',
      shiftId: 'shift-1',
      baseId: 'base-1'
    }
  ];

  const personnel: Personnel[] = [
    {
      id: 'person-1',
      name: 'John Doe',
      roleId: 'role-1',
      teamId: 'team-1',
      baseId: 'base-1'
    },
    {
      id: 'person-2',
      name: 'Jane Smith',
      roleId: 'role-1',
      teamId: 'team-1',
      baseId: 'base-1'
    }
  ];

  return { personnel, teams, shifts, roles, bases };
};

// Helper to create a scheduled job
const createMockJob = (overrides: Partial<ScheduledJob> = {}): ScheduledJob => ({
  id: 'job-1',
  customer: 'N12345',
  aircraftType: 'cessna-172',
  description: 'Annual Inspection',
  estimatedHours: 40,
  revenue: 5000,
  color: '#3b82f6',
  deadlineDays: 5,
  requiredHangarSize: 'Small',
  isAOG: false,
  startDate: 100,
  hangarId: 'hangar-1',
  progress: 0,
  status: 'Scheduled',
  ...overrides
});

describe('useCapacityData Hook', () => {
  describe('Initialization', () => {
    it('should return Float32Arrays for daily data', () => {
      const gameState = createMockGameState();
      const { result } = renderHook(() => useCapacityData(gameState));

      expect(result.current.dailyCapacities).toBeInstanceOf(Float32Array);
      expect(result.current.dailyLoads).toBeInstanceOf(Float32Array);
      expect(result.current.dailyCapacities.length).toBe(TOTAL_DAYS);
      expect(result.current.dailyLoads.length).toBe(TOTAL_DAYS);
    });

    it('should provide all expected methods', () => {
      const gameState = createMockGameState();
      const { result } = renderHook(() => useCapacityData(gameState));

      expect(typeof result.current.getDayData).toBe('function');
      expect(typeof result.current.getJobCapacityStatus).toBe('function');
      expect(typeof result.current.getOverloadedDays).toBe('function');
      expect(typeof result.current.getRangeData).toBe('function');
    });
  });

  describe('Capacity Calculation', () => {
    it('should calculate capacity based on personnel and shifts', () => {
      const { personnel, teams, shifts, roles, bases } = createTestPersonnel();
      const gameState = createMockGameState({
        personnel,
        teams,
        shifts,
        roles,
        bases
      });

      const { result } = renderHook(() => useCapacityData(gameState));

      // Day 100 is a specific day - check it has capacity on workdays
      // With 2 personnel, 8hr shift - 0.75hr breaks = 7.25hr effective
      // 2 * 7.25 * 1.0 efficiency = 14.5 hours capacity per workday
      const dayData = result.current.getDayData(100);

      // Check a weekday has non-zero capacity
      // Day 100 from Jan 1, 2024 - need to figure out what day of week it is
      // But we can just check that some days have capacity
      const hasCapacityDays = Array.from(result.current.dailyCapacities).filter(c => c > 0);
      expect(hasCapacityDays.length).toBeGreaterThan(0);
    });

    it('should return zero capacity on holidays', () => {
      const { personnel, teams, shifts, roles, bases } = createTestPersonnel();
      const holidays: Holiday[] = [
        { id: 'h1', name: 'Test Holiday', date: '2024-04-10', dayIndex: 100, enabled: true }
      ];

      const gameState = createMockGameState({
        personnel,
        teams,
        shifts,
        roles,
        bases,
        holidays
      });

      const { result } = renderHook(() => useCapacityData(gameState));
      const holidayData = result.current.getDayData(100);

      expect(holidayData.capacity).toBe(0);
      expect(holidayData.isHoliday).toBe(true);
    });

    it('should filter by baseId when provided', () => {
      const { personnel, teams, shifts, roles } = createTestPersonnel();
      const bases: Base[] = [
        { id: 'base-1', name: 'Main Base', location: 'Airport A' },
        { id: 'base-2', name: 'Secondary Base', location: 'Airport B' }
      ];

      // Add personnel at different bases
      const personnelWithBases: Personnel[] = [
        ...personnel,
        {
          id: 'person-3',
          name: 'Bob Wilson',
          roleId: 'role-1',
          teamId: 'team-1',
          baseId: 'base-2'
        }
      ];

      const gameState = createMockGameState({
        personnel: personnelWithBases,
        teams,
        shifts,
        roles,
        bases
      });

      const { result: allBases } = renderHook(() => useCapacityData(gameState, { baseId: 'ALL' }));
      const { result: base1Only } = renderHook(() => useCapacityData(gameState, { baseId: 'base-1' }));

      // Base 1 only should have less capacity than all bases
      const allCapacity = Array.from(allBases.current.dailyCapacities).reduce((a, b) => a + b, 0);
      const base1Capacity = Array.from(base1Only.current.dailyCapacities).reduce((a, b) => a + b, 0);

      expect(base1Capacity).toBeLessThan(allCapacity);
    });
  });

  describe('Load Calculation', () => {
    it('should calculate load from scheduled jobs', () => {
      const { personnel, teams, shifts, roles, bases } = createTestPersonnel();
      const hangars: Hangar[] = [
        { id: 'hangar-1', name: 'Hangar A', size: 'Large', supportedTypes: [], baseId: 'base-1' }
      ];

      const job = createMockJob({
        startDate: 100,
        deadlineDays: 5,
        estimatedHours: 40,
        hangarId: 'hangar-1'
      });

      const gameState = createMockGameState({
        personnel,
        teams,
        shifts,
        roles,
        bases,
        hangars,
        schedule: [job]
      });

      const { result } = renderHook(() => useCapacityData(gameState));

      // Job spans days 100-104, 40 hours over 5 days = 8 hours/day
      const day100Load = result.current.dailyLoads[100];
      const day104Load = result.current.dailyLoads[104];
      const day105Load = result.current.dailyLoads[105];

      expect(day100Load).toBe(8); // 40 hours / 5 days
      expect(day104Load).toBe(8);
      expect(day105Load).toBe(0); // Job ended
    });

    it('should respect nonWorkDays for jobs', () => {
      const { personnel, teams, shifts, roles, bases } = createTestPersonnel();
      const hangars: Hangar[] = [
        { id: 'hangar-1', name: 'Hangar A', size: 'Large', supportedTypes: [], baseId: 'base-1' }
      ];

      const job = createMockJob({
        startDate: 100,
        deadlineDays: 5,
        estimatedHours: 40,
        hangarId: 'hangar-1',
        nonWorkDays: [2] // Day offset 2 (day 102) is non-work
      });

      const gameState = createMockGameState({
        personnel,
        teams,
        shifts,
        roles,
        bases,
        hangars,
        schedule: [job]
      });

      const { result } = renderHook(() => useCapacityData(gameState));

      // Day 102 should have 0 load due to nonWorkDays
      const day102Load = result.current.dailyLoads[102];
      expect(day102Load).toBe(0);

      // Other days should have proportionally more load
      // 40 hours over 4 working days = 10 hours/day
      const day100Load = result.current.dailyLoads[100];
      expect(day100Load).toBe(10);
    });

    it('should respect dailyEffort weights', () => {
      const { personnel, teams, shifts, roles, bases } = createTestPersonnel();
      const hangars: Hangar[] = [
        { id: 'hangar-1', name: 'Hangar A', size: 'Large', supportedTypes: [], baseId: 'base-1' }
      ];

      const job = createMockJob({
        startDate: 100,
        deadlineDays: 4,
        estimatedHours: 40,
        hangarId: 'hangar-1',
        dailyEffort: {
          0: 2.0, // Double effort
          1: 1.0, // Normal
          2: 0.5, // Half effort
          3: 0.5  // Half effort
        }
      });

      const gameState = createMockGameState({
        personnel,
        teams,
        shifts,
        roles,
        bases,
        hangars,
        schedule: [job]
      });

      const { result } = renderHook(() => useCapacityData(gameState));

      // Total weight = 2 + 1 + 0.5 + 0.5 = 4
      // Day 100: (2/4) * 40 = 20 hours
      // Day 101: (1/4) * 40 = 10 hours
      // Day 102: (0.5/4) * 40 = 5 hours
      // Day 103: (0.5/4) * 40 = 5 hours
      expect(result.current.dailyLoads[100]).toBe(20);
      expect(result.current.dailyLoads[101]).toBe(10);
      expect(result.current.dailyLoads[102]).toBe(5);
      expect(result.current.dailyLoads[103]).toBe(5);
    });

    it('should filter jobs by hangarIds option', () => {
      const { personnel, teams, shifts, roles, bases } = createTestPersonnel();
      const hangars: Hangar[] = [
        { id: 'hangar-1', name: 'Hangar A', size: 'Large', supportedTypes: [], baseId: 'base-1' },
        { id: 'hangar-2', name: 'Hangar B', size: 'Medium', supportedTypes: [], baseId: 'base-1' }
      ];

      const job1 = createMockJob({ id: 'job-1', startDate: 100, hangarId: 'hangar-1', estimatedHours: 40, deadlineDays: 5 });
      const job2 = createMockJob({ id: 'job-2', startDate: 100, hangarId: 'hangar-2', estimatedHours: 20, deadlineDays: 5 });

      const gameState = createMockGameState({
        personnel,
        teams,
        shifts,
        roles,
        bases,
        hangars,
        schedule: [job1, job2]
      });

      const { result: allHangars } = renderHook(() => useCapacityData(gameState));
      const { result: hangar1Only } = renderHook(() => useCapacityData(gameState, { hangarIds: ['hangar-1'] }));

      // All hangars should have 12 hours/day (8 + 4)
      expect(allHangars.current.dailyLoads[100]).toBe(12);

      // Hangar 1 only should have 8 hours/day
      expect(hangar1Only.current.dailyLoads[100]).toBe(8);
    });
  });

  describe('getDayData', () => {
    it('should return complete day data', () => {
      const { personnel, teams, shifts, roles, bases } = createTestPersonnel();
      const hangars: Hangar[] = [
        { id: 'hangar-1', name: 'Hangar A', size: 'Large', supportedTypes: [], baseId: 'base-1' }
      ];

      const job = createMockJob({
        startDate: 100,
        deadlineDays: 5,
        estimatedHours: 40,
        hangarId: 'hangar-1'
      });

      const gameState = createMockGameState({
        personnel,
        teams,
        shifts,
        roles,
        bases,
        hangars,
        schedule: [job]
      });

      const { result } = renderHook(() => useCapacityData(gameState));
      const dayData = result.current.getDayData(100);

      expect(dayData).toHaveProperty('dayIndex', 100);
      expect(dayData).toHaveProperty('capacity');
      expect(dayData).toHaveProperty('load');
      expect(dayData).toHaveProperty('utilization');
      expect(dayData).toHaveProperty('isHoliday');
      expect(dayData).toHaveProperty('isOverloaded');
    });

    it('should calculate utilization correctly', () => {
      const { personnel, teams, shifts, roles, bases } = createTestPersonnel();
      const hangars: Hangar[] = [
        { id: 'hangar-1', name: 'Hangar A', size: 'Large', supportedTypes: [], baseId: 'base-1' }
      ];

      // Create a job that exactly matches capacity
      const job = createMockJob({
        startDate: 100,
        deadlineDays: 1,
        estimatedHours: 14.5, // Matches expected capacity
        hangarId: 'hangar-1'
      });

      const gameState = createMockGameState({
        personnel,
        teams,
        shifts,
        roles,
        bases,
        hangars,
        schedule: [job]
      });

      const { result } = renderHook(() => useCapacityData(gameState));
      const dayData = result.current.getDayData(100);

      // Utilization should be ~100% (load / capacity * 100)
      if (dayData.capacity > 0) {
        expect(dayData.utilization).toBeCloseTo((dayData.load / dayData.capacity) * 100, 1);
      }
    });

    it('should return safe defaults for out-of-range days', () => {
      const gameState = createMockGameState();
      const { result } = renderHook(() => useCapacityData(gameState));

      const negativeDay = result.current.getDayData(-1);
      const farFutureDay = result.current.getDayData(TOTAL_DAYS + 100);

      expect(negativeDay.capacity).toBe(0);
      expect(negativeDay.load).toBe(0);
      expect(farFutureDay.capacity).toBe(0);
      expect(farFutureDay.load).toBe(0);
    });
  });

  describe('getJobCapacityStatus', () => {
    it('should return no warning for jobs under capacity', () => {
      const { personnel, teams, shifts, roles, bases } = createTestPersonnel();
      const hangars: Hangar[] = [
        { id: 'hangar-1', name: 'Hangar A', size: 'Large', supportedTypes: [], baseId: 'base-1' }
      ];

      // Small job that won't exceed capacity
      const job = createMockJob({
        startDate: 100,
        deadlineDays: 5,
        estimatedHours: 10, // Low hours
        hangarId: 'hangar-1'
      });

      const gameState = createMockGameState({
        personnel,
        teams,
        shifts,
        roles,
        bases,
        hangars,
        schedule: [job],
        capacityBufferPercent: 15
      });

      const { result } = renderHook(() => useCapacityData(gameState));
      const status = result.current.getJobCapacityStatus(job);

      expect(status.hasWarning).toBe(false);
      expect(status.severity).toBe('none');
    });

    it('should return warning when job exceeds buffer threshold', () => {
      const { personnel, teams, shifts, roles, bases } = createTestPersonnel();
      const hangars: Hangar[] = [
        { id: 'hangar-1', name: 'Hangar A', size: 'Large', supportedTypes: [], baseId: 'base-1' }
      ];

      // Large job that will exceed buffer
      const job = createMockJob({
        startDate: 100,
        deadlineDays: 5,
        estimatedHours: 100, // High hours - likely to exceed capacity
        hangarId: 'hangar-1'
      });

      const gameState = createMockGameState({
        personnel,
        teams,
        shifts,
        roles,
        bases,
        hangars,
        schedule: [job],
        capacityBufferPercent: 15
      });

      const { result } = renderHook(() => useCapacityData(gameState));
      const status = result.current.getJobCapacityStatus(job);

      // With 100 hours over 5 days = 20 hours/day vs ~14.5 capacity
      expect(status.hasWarning).toBe(true);
      expect(status.overloadedDays).toBeGreaterThan(0);
    });

    it('should return critical severity when load exceeds 100% capacity', () => {
      const { personnel, teams, shifts, roles, bases } = createTestPersonnel();
      const hangars: Hangar[] = [
        { id: 'hangar-1', name: 'Hangar A', size: 'Large', supportedTypes: [], baseId: 'base-1' }
      ];

      // Very large job that definitely exceeds 100% capacity
      const job = createMockJob({
        startDate: 100,
        deadlineDays: 1,
        estimatedHours: 50, // Way over capacity for 1 day
        hangarId: 'hangar-1'
      });

      const gameState = createMockGameState({
        personnel,
        teams,
        shifts,
        roles,
        bases,
        hangars,
        schedule: [job],
        capacityBufferPercent: 15
      });

      const { result } = renderHook(() => useCapacityData(gameState));
      const status = result.current.getJobCapacityStatus(job);

      expect(status.hasWarning).toBe(true);
      expect(status.severity).toBe('critical');
      expect(status.maxUtilization).toBeGreaterThan(100);
    });

    it('should respect different buffer percentages', () => {
      const { personnel, teams, shifts, roles, bases } = createTestPersonnel();
      const hangars: Hangar[] = [
        { id: 'hangar-1', name: 'Hangar A', size: 'Large', supportedTypes: [], baseId: 'base-1' }
      ];

      // Job that's at ~90% capacity
      const job = createMockJob({
        startDate: 100,
        deadlineDays: 5,
        estimatedHours: 65, // ~13 hours/day vs ~14.5 capacity = ~90%
        hangarId: 'hangar-1'
      });

      // With 15% buffer (warn at 85%), should warn
      const gameState15 = createMockGameState({
        personnel,
        teams,
        shifts,
        roles,
        bases,
        hangars,
        schedule: [job],
        capacityBufferPercent: 15
      });

      // With 5% buffer (warn at 95%), should not warn
      const gameState5 = createMockGameState({
        personnel,
        teams,
        shifts,
        roles,
        bases,
        hangars,
        schedule: [job],
        capacityBufferPercent: 5
      });

      const { result: result15 } = renderHook(() => useCapacityData(gameState15));
      const { result: result5 } = renderHook(() => useCapacityData(gameState5));

      const status15 = result15.current.getJobCapacityStatus(job);
      const status5 = result5.current.getJobCapacityStatus(job);

      // Higher buffer = more likely to warn
      expect(status15.overloadedDays).toBeGreaterThanOrEqual(status5.overloadedDays);
    });
  });

  describe('getOverloadedDays', () => {
    it('should return empty array when no overloaded days', () => {
      const gameState = createMockGameState();
      const { result } = renderHook(() => useCapacityData(gameState));

      const overloadedDays = result.current.getOverloadedDays();
      expect(overloadedDays).toEqual([]);
    });

    it('should return day indices that exceed buffer', () => {
      const { personnel, teams, shifts, roles, bases } = createTestPersonnel();
      const hangars: Hangar[] = [
        { id: 'hangar-1', name: 'Hangar A', size: 'Large', supportedTypes: [], baseId: 'base-1' }
      ];

      // Job that exceeds capacity
      const job = createMockJob({
        startDate: 100,
        deadlineDays: 3,
        estimatedHours: 60, // 20 hours/day vs ~14.5 capacity
        hangarId: 'hangar-1'
      });

      const gameState = createMockGameState({
        personnel,
        teams,
        shifts,
        roles,
        bases,
        hangars,
        schedule: [job],
        capacityBufferPercent: 15
      });

      const { result } = renderHook(() => useCapacityData(gameState));
      const overloadedDays = result.current.getOverloadedDays();

      // Should have overloaded days in range 100-102
      expect(overloadedDays.length).toBeGreaterThan(0);
      expect(overloadedDays.every(d => d >= 100 && d <= 102)).toBe(true);
    });
  });

  describe('getRangeData', () => {
    it('should return data for specified day range', () => {
      const gameState = createMockGameState();
      const { result } = renderHook(() => useCapacityData(gameState));

      const rangeData = result.current.getRangeData(100, 107);

      expect(rangeData.length).toBe(7);
      expect(rangeData[0].dayIndex).toBe(100);
      expect(rangeData[6].dayIndex).toBe(106);
    });

    it('should clamp to valid day range', () => {
      const gameState = createMockGameState();
      const { result } = renderHook(() => useCapacityData(gameState));

      // Request range that extends beyond TOTAL_DAYS
      const rangeData = result.current.getRangeData(TOTAL_DAYS - 3, TOTAL_DAYS + 10);

      expect(rangeData.length).toBe(3);
      expect(rangeData[rangeData.length - 1].dayIndex).toBe(TOTAL_DAYS - 1);
    });

    it('should return empty array for invalid range', () => {
      const gameState = createMockGameState();
      const { result } = renderHook(() => useCapacityData(gameState));

      const rangeData = result.current.getRangeData(-10, -5);
      expect(rangeData.length).toBe(0);
    });
  });
});
