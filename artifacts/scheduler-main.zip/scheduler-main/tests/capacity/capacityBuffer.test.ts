import { describe, it, expect } from 'vitest';
import { DEFAULT_CAPACITY_BUFFER_PERCENT } from '../../constants';
import type { GameState, UIState } from '../../types';

describe('Capacity Buffer Setting', () => {
  describe('Constants', () => {
    it('should have DEFAULT_CAPACITY_BUFFER_PERCENT defined', () => {
      expect(DEFAULT_CAPACITY_BUFFER_PERCENT).toBeDefined();
      expect(typeof DEFAULT_CAPACITY_BUFFER_PERCENT).toBe('number');
    });

    it('should have default buffer of 15%', () => {
      expect(DEFAULT_CAPACITY_BUFFER_PERCENT).toBe(15);
    });

    it('should be in valid range (0-30)', () => {
      expect(DEFAULT_CAPACITY_BUFFER_PERCENT).toBeGreaterThanOrEqual(0);
      expect(DEFAULT_CAPACITY_BUFFER_PERCENT).toBeLessThanOrEqual(30);
    });
  });

  describe('GameState Type Integration', () => {
    it('should accept capacityBufferPercent in GameState', () => {
      const partialState: Pick<GameState, 'capacityBufferPercent'> = {
        capacityBufferPercent: 15
      };

      expect(partialState.capacityBufferPercent).toBe(15);
    });

    it('should accept different buffer values', () => {
      const testCases = [0, 5, 10, 15, 20, 25, 30];

      testCases.forEach(value => {
        const state: Pick<GameState, 'capacityBufferPercent'> = {
          capacityBufferPercent: value
        };
        expect(state.capacityBufferPercent).toBe(value);
      });
    });
  });

  describe('Buffer Threshold Calculation', () => {
    it('should calculate correct warning threshold from buffer', () => {
      // buffer 15% means warn at 85% (100 - 15)
      const buffer = 15;
      const warningThreshold = 100 - buffer;
      expect(warningThreshold).toBe(85);
    });

    it('should calculate buffer multiplier correctly', () => {
      const testCases = [
        { buffer: 0, expectedMultiplier: 1.0 },   // No buffer, warn at 100%
        { buffer: 10, expectedMultiplier: 0.9 },  // Warn at 90%
        { buffer: 15, expectedMultiplier: 0.85 }, // Warn at 85%
        { buffer: 20, expectedMultiplier: 0.8 },  // Warn at 80%
        { buffer: 30, expectedMultiplier: 0.7 }   // Warn at 70%
      ];

      testCases.forEach(({ buffer, expectedMultiplier }) => {
        const multiplier = 1 - (buffer / 100);
        expect(multiplier).toBeCloseTo(expectedMultiplier, 2);
      });
    });

    it('should determine overload status based on buffer', () => {
      const checkOverload = (load: number, capacity: number, bufferPercent: number): boolean => {
        const bufferMultiplier = 1 - (bufferPercent / 100);
        const effectiveCapacity = capacity * bufferMultiplier;
        return effectiveCapacity > 0 && load > effectiveCapacity;
      };

      // 100 capacity, 85 load, 15% buffer (effective = 85)
      // 85 load vs 85 effective = not overloaded
      expect(checkOverload(85, 100, 15)).toBe(false);

      // 100 capacity, 86 load, 15% buffer (effective = 85)
      // 86 load vs 85 effective = overloaded
      expect(checkOverload(86, 100, 15)).toBe(true);

      // 100 capacity, 90 load, 5% buffer (effective = 95)
      // 90 load vs 95 effective = not overloaded
      expect(checkOverload(90, 100, 5)).toBe(false);

      // 100 capacity, 96 load, 5% buffer (effective = 95)
      // 96 load vs 95 effective = overloaded
      expect(checkOverload(96, 100, 5)).toBe(true);
    });
  });

  describe('Warning Severity Levels', () => {
    it('should classify as warning when between buffer and 100%', () => {
      const classifySeverity = (utilization: number): 'none' | 'warning' | 'critical' => {
        if (utilization > 100) return 'critical';
        if (utilization > 85) return 'warning'; // Assuming 15% buffer
        return 'none';
      };

      expect(classifySeverity(80)).toBe('none');
      expect(classifySeverity(85)).toBe('none');
      expect(classifySeverity(86)).toBe('warning');
      expect(classifySeverity(99)).toBe('warning');
      expect(classifySeverity(100)).toBe('warning');
      expect(classifySeverity(101)).toBe('critical');
      expect(classifySeverity(150)).toBe('critical');
    });

    it('should return correct severity based on buffer threshold', () => {
      const classifySeverityWithBuffer = (
        load: number,
        capacity: number,
        bufferPercent: number
      ): 'none' | 'warning' | 'critical' => {
        if (capacity === 0) return 'none';

        const utilization = (load / capacity) * 100;
        const bufferMultiplier = 1 - (bufferPercent / 100);
        const effectiveCapacity = capacity * bufferMultiplier;

        if (load <= effectiveCapacity) return 'none';
        if (utilization > 100) return 'critical';
        return 'warning';
      };

      // At 90% with 15% buffer (threshold 85%) - warning
      expect(classifySeverityWithBuffer(90, 100, 15)).toBe('warning');

      // At 90% with 5% buffer (threshold 95%) - none
      expect(classifySeverityWithBuffer(90, 100, 5)).toBe('none');

      // At 105% - always critical
      expect(classifySeverityWithBuffer(105, 100, 15)).toBe('critical');

      // Zero capacity - none
      expect(classifySeverityWithBuffer(10, 0, 15)).toBe('none');
    });
  });

  describe('Edge Cases', () => {
    it('should handle 0% buffer correctly', () => {
      const bufferMultiplier = 1 - (0 / 100);
      expect(bufferMultiplier).toBe(1.0);

      // With 0% buffer, only warn when load > capacity
      const isOverloaded = (load: number, capacity: number) => {
        return load > capacity * bufferMultiplier;
      };

      expect(isOverloaded(100, 100)).toBe(false);
      expect(isOverloaded(100.1, 100)).toBe(true);
    });

    it('should handle maximum buffer correctly', () => {
      const maxBuffer = 30;
      const bufferMultiplier = 1 - (maxBuffer / 100);
      expect(bufferMultiplier).toBe(0.7);

      // With 30% buffer, warn when load > 70% capacity
      const effectiveCapacity = 100 * bufferMultiplier;
      expect(effectiveCapacity).toBe(70);
    });

    it('should handle zero capacity gracefully', () => {
      const checkOverload = (load: number, capacity: number, bufferPercent: number): boolean => {
        const bufferMultiplier = 1 - (bufferPercent / 100);
        const effectiveCapacity = capacity * bufferMultiplier;
        return effectiveCapacity > 0 && load > effectiveCapacity;
      };

      // Zero capacity should never be considered overloaded
      expect(checkOverload(100, 0, 15)).toBe(false);
      expect(checkOverload(0, 0, 15)).toBe(false);
    });

    it('should handle floating point precision', () => {
      const buffer = 15;
      const capacity = 14.5; // Common value from shift calculations
      const bufferMultiplier = 1 - (buffer / 100);
      const effectiveCapacity = capacity * bufferMultiplier;

      // 14.5 * 0.85 = 12.325
      expect(effectiveCapacity).toBeCloseTo(12.325, 3);
    });
  });
});
