import { describe, it, expect, beforeAll, beforeEach } from 'vitest';
import 'fake-indexeddb/auto';
import { initDB, saveGame, loadGame } from '../persistence';
import { createMockGameState, resetIdCounter } from './utils/testHelpers';

/**
 * Persistence Layer Tests
 *
 * Note: fake-indexeddb is used to simulate IndexedDB in the test environment.
 * These tests verify the basic save/load functionality.
 */

describe('Persistence Layer', () => {
  // Initialize DB once before all tests
  beforeAll(async () => {
    await initDB();
  });

  beforeEach(() => {
    resetIdCounter();
  });

  describe('initDB', () => {
    it('should initialize the database without errors', async () => {
      // initDB was called in beforeAll, this just verifies it can be called again
      await expect(initDB()).resolves.toBeUndefined();
    });
  });

  describe('saveGame and loadGame', () => {
    it('should save and load a simple game state', async () => {
      const state = createMockGameState({ day: 100, cash: 50000 });
      const saveId = 'test-' + Date.now();

      await saveGame(saveId, state);
      const loaded = await loadGame(saveId);

      expect(loaded).not.toBeNull();
      expect(loaded?.day).toBe(100);
      expect(loaded?.cash).toBe(50000);
    });

    it('should return null for non-existent save', async () => {
      const loaded = await loadGame('non-existent-' + Date.now());
      expect(loaded).toBeNull();
    });

    it('should overwrite existing save', async () => {
      const saveId = 'overwrite-test-' + Date.now();
      const state1 = createMockGameState({ day: 100 });
      const state2 = createMockGameState({ day: 200 });

      await saveGame(saveId, state1);
      await saveGame(saveId, state2);
      const loaded = await loadGame(saveId);

      expect(loaded?.day).toBe(200);
    });

    it('should preserve nested objects', async () => {
      const state = createMockGameState();
      state.backlog = [{
        id: 'job-1',
        customer: 'N12345',
        aircraftType: 'cessna-172',
        description: 'Annual',
        estimatedHours: 40,
        revenue: 5000,
        color: 'blue',
        deadlineDays: 5,
        requiredHangarSize: 'Medium',
        isAOG: false
      }];
      const saveId = 'nested-test-' + Date.now();

      await saveGame(saveId, state);
      const loaded = await loadGame(saveId);

      expect(loaded?.backlog).toHaveLength(1);
      expect(loaded?.backlog[0].id).toBe('job-1');
    });
  });
});
