import { describe, it, expect, vi, beforeEach } from 'vitest';
import type { SystemRole, User, Invitation } from '../../types';

/**
 * User Invitation Tests
 *
 * These tests verify the invitation flow for adding new users to an organization.
 */

describe('Invitation Validation', () => {
  describe('Email Validation', () => {
    const isValidEmail = (email: string): boolean => {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      return emailRegex.test(email);
    };

    it('should accept valid email addresses', () => {
      expect(isValidEmail('user@example.com')).toBe(true);
      expect(isValidEmail('john.doe@company.org')).toBe(true);
      expect(isValidEmail('tech+aviation@hangar.co')).toBe(true);
    });

    it('should reject invalid email addresses', () => {
      expect(isValidEmail('notanemail')).toBe(false);
      expect(isValidEmail('missing@domain')).toBe(false);
      expect(isValidEmail('')).toBe(false);
    });
  });

  describe('Duplicate User Check', () => {
    const checkDuplicateUser = (email: string, existingUsers: User[]): User | undefined => {
      return existingUsers.find(u => u.email.toLowerCase() === email.toLowerCase());
    };

    it('should detect existing user (case insensitive)', () => {
      const existingUsers: User[] = [
        { id: '1', email: 'test@example.com', name: 'Test User', role: 'Technician', status: 'Active' },
        { id: '2', email: 'admin@example.com', name: 'Admin User', role: 'Admin', status: 'Active' },
      ];

      expect(checkDuplicateUser('test@example.com', existingUsers)).toBeDefined();
      expect(checkDuplicateUser('TEST@EXAMPLE.COM', existingUsers)).toBeDefined();
      expect(checkDuplicateUser('Test@Example.Com', existingUsers)).toBeDefined();
    });

    it('should not find non-existing user', () => {
      const existingUsers: User[] = [
        { id: '1', email: 'test@example.com', name: 'Test User', role: 'Technician', status: 'Active' },
      ];

      expect(checkDuplicateUser('new@example.com', existingUsers)).toBeUndefined();
    });

    it('should handle empty user list', () => {
      const existingUsers: User[] = [];
      expect(checkDuplicateUser('any@example.com', existingUsers)).toBeUndefined();
    });
  });

  describe('Authentication Check', () => {
    it('should require authentication to invite users', () => {
      const validateInviteAuth = (user: User | null): string | null => {
        if (!user) {
          return 'Not authenticated';
        }
        return null;
      };

      expect(validateInviteAuth(null)).toBe('Not authenticated');
      expect(validateInviteAuth({
        id: '1',
        email: 'admin@example.com',
        name: 'Admin',
        role: 'Admin',
        status: 'Active',
      })).toBeNull();
    });
  });
});

describe('Role Mapping for Invitations', () => {
  const mapSystemRoleToDbRole = (role: SystemRole): 'admin' | 'manager' | 'technician' | 'viewer' => {
    switch (role) {
      case 'Admin':
        return 'admin';
      case 'Manager':
        return 'manager';
      case 'Technician':
        return 'technician';
      default:
        return 'technician';
    }
  };

  it('should map Admin to admin', () => {
    expect(mapSystemRoleToDbRole('Admin')).toBe('admin');
  });

  it('should map Manager to manager', () => {
    expect(mapSystemRoleToDbRole('Manager')).toBe('manager');
  });

  it('should map Technician to technician', () => {
    expect(mapSystemRoleToDbRole('Technician')).toBe('technician');
  });
});

describe('Invitation Creation', () => {
  interface InvitationData {
    email: string;
    name: string;
    role: SystemRole;
    organizationId: string;
    invitedBy: string;
  }

  const createInvitationRecord = (data: InvitationData): Partial<Invitation> => {
    return {
      email: data.email.toLowerCase(),
      role: data.role === 'Admin' ? 'admin' : data.role === 'Manager' ? 'manager' : 'technician',
      organizationId: data.organizationId,
      invitedBy: data.invitedBy,
    };
  };

  it('should create invitation with lowercase email', () => {
    const invitation = createInvitationRecord({
      email: 'NEW.USER@EXAMPLE.COM',
      name: 'New User',
      role: 'Technician',
      organizationId: 'org-123',
      invitedBy: 'admin-456',
    });

    expect(invitation.email).toBe('new.user@example.com');
  });

  it('should include organization and inviter info', () => {
    const invitation = createInvitationRecord({
      email: 'user@example.com',
      name: 'User',
      role: 'Manager',
      organizationId: 'org-123',
      invitedBy: 'admin-456',
    });

    expect(invitation.organizationId).toBe('org-123');
    expect(invitation.invitedBy).toBe('admin-456');
  });

  it('should map role correctly', () => {
    const adminInvite = createInvitationRecord({
      email: 'admin@example.com',
      name: 'Admin',
      role: 'Admin',
      organizationId: 'org-123',
      invitedBy: 'owner-789',
    });

    expect(adminInvite.role).toBe('admin');
  });
});

describe('Invited User State', () => {
  const createInvitedUser = (
    invitationId: string,
    email: string,
    name: string,
    role: SystemRole
  ): User => ({
    id: invitationId,
    email,
    name,
    role,
    status: 'Invited',
    avatar: name.substring(0, 2).toUpperCase(),
  });

  it('should create user with Invited status', () => {
    const user = createInvitedUser('inv-123', 'new@example.com', 'New User', 'Technician');

    expect(user.status).toBe('Invited');
    expect(user.id).toBe('inv-123');
  });

  it('should generate avatar from name initials', () => {
    const user = createInvitedUser('inv-123', 'john@example.com', 'John Doe', 'Manager');

    expect(user.avatar).toBe('JO'); // First two characters
  });

  it('should handle single-word names', () => {
    const user = createInvitedUser('inv-123', 'madonna@example.com', 'Madonna', 'Admin');

    expect(user.avatar).toBe('MA');
  });
});

describe('Invitation Error Handling', () => {
  describe('Duplicate Invitation', () => {
    const handleInviteError = (errorCode: string): string => {
      if (errorCode === '23505') { // PostgreSQL unique constraint violation
        return 'An invitation has already been sent to this email';
      }
      return 'Failed to create invitation';
    };

    it('should detect duplicate invitation', () => {
      expect(handleInviteError('23505'))
        .toBe('An invitation has already been sent to this email');
    });

    it('should return generic error for other codes', () => {
      expect(handleInviteError('12345'))
        .toBe('Failed to create invitation');
    });
  });

  describe('Existing User', () => {
    it('should throw error for existing user', () => {
      const existingUsers: User[] = [
        { id: '1', email: 'existing@example.com', name: 'Existing', role: 'Technician', status: 'Active' },
      ];

      const validateNewInvite = (email: string): string | null => {
        const existing = existingUsers.find(u => u.email.toLowerCase() === email.toLowerCase());
        if (existing) {
          return 'User already exists in this organization';
        }
        return null;
      };

      expect(validateNewInvite('existing@example.com'))
        .toBe('User already exists in this organization');
      expect(validateNewInvite('new@example.com')).toBeNull();
    });
  });

  describe('Organization Not Found', () => {
    it('should throw error when organization ID is missing', () => {
      const validateOrganization = (orgId: string | null): string | null => {
        if (!orgId) {
          return 'Organization not found';
        }
        return null;
      };

      expect(validateOrganization(null)).toBe('Organization not found');
      expect(validateOrganization('')).toBe('Organization not found');
      expect(validateOrganization('org-123')).toBeNull();
    });
  });
});

describe('Invitation UI State', () => {
  describe('Update All Users List', () => {
    it('should add invited user to allUsers list', () => {
      let allUsers: User[] = [
        { id: '1', email: 'existing@example.com', name: 'Existing', role: 'Admin', status: 'Active' },
      ];

      const newUser: User = {
        id: 'inv-123',
        email: 'new@example.com',
        name: 'New User',
        role: 'Technician',
        status: 'Invited',
      };

      // Simulate adding invited user
      allUsers = [...allUsers, newUser];

      expect(allUsers.length).toBe(2);
      expect(allUsers.find(u => u.email === 'new@example.com')).toBeDefined();
    });
  });

  describe('Invitation Success', () => {
    it('should complete invitation flow successfully', () => {
      const onInviteSuccess = vi.fn();

      // Simulate successful invitation
      const invitationSuccessful = true;
      if (invitationSuccessful) {
        onInviteSuccess();
      }

      expect(onInviteSuccess).toHaveBeenCalledTimes(1);
    });
  });
});

describe('Invitation Types', () => {
  describe('Invitation Interface', () => {
    it('should have all required fields', () => {
      const invitation: Invitation = {
        id: 'inv-123',
        organizationId: 'org-456',
        email: 'user@example.com',
        role: 'technician',
        invitedBy: 'admin-789',
        token: 'random-token',
        expiresAt: '2024-12-31T00:00:00Z',
        acceptedAt: null,
        createdAt: '2024-01-01T00:00:00Z',
      };

      expect(invitation.id).toBe('inv-123');
      expect(invitation.organizationId).toBe('org-456');
      expect(invitation.email).toBe('user@example.com');
      expect(invitation.role).toBe('technician');
      expect(invitation.invitedBy).toBe('admin-789');
      expect(invitation.token).toBeDefined();
      expect(invitation.expiresAt).toBeDefined();
      expect(invitation.acceptedAt).toBeNull();
      expect(invitation.createdAt).toBeDefined();
    });
  });

  describe('Accepted Invitation', () => {
    it('should have acceptedAt when invitation is used', () => {
      const acceptedInvitation: Invitation = {
        id: 'inv-123',
        organizationId: 'org-456',
        email: 'user@example.com',
        role: 'technician',
        invitedBy: 'admin-789',
        token: 'random-token',
        expiresAt: '2024-12-31T00:00:00Z',
        acceptedAt: '2024-06-15T10:30:00Z',
        createdAt: '2024-01-01T00:00:00Z',
      };

      expect(acceptedInvitation.acceptedAt).not.toBeNull();
    });
  });
});

describe('Invitation Role Options', () => {
  it('should provide valid role options for invitation', () => {
    const roleOptions: { value: SystemRole; label: string }[] = [
      { value: 'Admin', label: 'Admin' },
      { value: 'Manager', label: 'Manager' },
      { value: 'Technician', label: 'Technician' },
    ];

    expect(roleOptions.length).toBe(3);
    expect(roleOptions.find(r => r.value === 'Admin')).toBeDefined();
    expect(roleOptions.find(r => r.value === 'Manager')).toBeDefined();
    expect(roleOptions.find(r => r.value === 'Technician')).toBeDefined();
  });
});

describe('Invitation Permission Checks', () => {
  const canInviteUsers = (currentUser: User | null): boolean => {
    if (!currentUser) return false;
    // Only Admin and Manager can invite users
    return currentUser.role === 'Admin' || currentUser.role === 'Manager';
  };

  it('should allow Admin to invite users', () => {
    const admin: User = {
      id: '1',
      email: 'admin@example.com',
      name: 'Admin User',
      role: 'Admin',
      status: 'Active',
    };
    expect(canInviteUsers(admin)).toBe(true);
  });

  it('should allow Manager to invite users', () => {
    const manager: User = {
      id: '2',
      email: 'manager@example.com',
      name: 'Manager User',
      role: 'Manager',
      status: 'Active',
    };
    expect(canInviteUsers(manager)).toBe(true);
  });

  it('should not allow Technician to invite users', () => {
    const tech: User = {
      id: '3',
      email: 'tech@example.com',
      name: 'Tech User',
      role: 'Technician',
      status: 'Active',
    };
    expect(canInviteUsers(tech)).toBe(false);
  });

  it('should not allow unauthenticated user to invite', () => {
    expect(canInviteUsers(null)).toBe(false);
  });
});
