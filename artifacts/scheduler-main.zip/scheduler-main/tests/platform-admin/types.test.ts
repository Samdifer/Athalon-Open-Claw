import { describe, it, expect } from 'vitest';
import type {
  PlatformRole,
  SubscriptionStatus,
  Organization,
  PlatformAdminInvite,
  PlatformAuditLog,
  ImpersonationSession,
  PlatformMetrics,
  User
} from '../../types';

describe('Platform Admin Types', () => {
  describe('PlatformRole', () => {
    it('should accept valid platform roles', () => {
      const superAdmin: PlatformRole = 'super_admin';
      const supportAdmin: PlatformRole = 'support_admin';
      const billingAdmin: PlatformRole = 'billing_admin';

      expect(superAdmin).toBe('super_admin');
      expect(supportAdmin).toBe('support_admin');
      expect(billingAdmin).toBe('billing_admin');
    });
  });

  describe('SubscriptionStatus', () => {
    it('should accept valid subscription statuses', () => {
      const trial: SubscriptionStatus = 'trial';
      const active: SubscriptionStatus = 'active';
      const cancelled: SubscriptionStatus = 'cancelled';
      const pastDue: SubscriptionStatus = 'past_due';

      expect(trial).toBe('trial');
      expect(active).toBe('active');
      expect(cancelled).toBe('cancelled');
      expect(pastDue).toBe('past_due');
    });
  });

  describe('Organization', () => {
    it('should have correct structure', () => {
      const org: Organization = {
        id: 'test-id',
        name: 'Test Org',
        slug: 'test-org',
        subscriptionStatus: 'trial',
        subscriptionTier: 'standard',
        trialEndsAt: '2024-12-31T00:00:00Z',
        stripeCustomerId: null,
        gracePeriodUsed: false,
        gracePeriodEndsAt: null,
        createdAt: '2024-01-01T00:00:00Z',
        updatedAt: '2024-01-01T00:00:00Z',
        userCount: 5,
        ownerEmail: 'owner@test.com',
        ownerName: 'Test Owner'
      };

      expect(org.id).toBe('test-id');
      expect(org.subscriptionStatus).toBe('trial');
      expect(org.userCount).toBe(5);
    });

    it('should allow null for optional fields', () => {
      const org: Organization = {
        id: 'test-id',
        name: 'Test Org',
        slug: 'test-org',
        subscriptionStatus: 'active',
        subscriptionTier: 'standard',
        trialEndsAt: null,
        stripeCustomerId: null,
        gracePeriodUsed: false,
        gracePeriodEndsAt: null,
        createdAt: '2024-01-01T00:00:00Z',
        updatedAt: '2024-01-01T00:00:00Z'
      };

      expect(org.trialEndsAt).toBeNull();
      expect(org.stripeCustomerId).toBeNull();
      expect(org.userCount).toBeUndefined();
    });
  });

  describe('PlatformAdminInvite', () => {
    it('should have correct structure', () => {
      const invite: PlatformAdminInvite = {
        id: 'invite-id',
        email: 'admin@test.com',
        role: 'support_admin',
        invitedBy: 'inviter-id',
        token: 'unique-token',
        expiresAt: '2024-12-31T00:00:00Z',
        acceptedAt: null,
        createdAt: '2024-01-01T00:00:00Z'
      };

      expect(invite.email).toBe('admin@test.com');
      expect(invite.role).toBe('support_admin');
      expect(invite.acceptedAt).toBeNull();
    });
  });

  describe('PlatformAuditLog', () => {
    it('should have correct structure', () => {
      const log: PlatformAuditLog = {
        id: 'log-id',
        adminId: 'admin-id',
        action: 'update_organization',
        targetType: 'organization',
        targetId: 'org-id',
        details: { changes: { name: 'New Name' } },
        ipAddress: '192.168.1.1',
        createdAt: '2024-01-01T00:00:00Z'
      };

      expect(log.action).toBe('update_organization');
      expect(log.targetType).toBe('organization');
      expect(log.details).toHaveProperty('changes');
    });

    it('should allow null for target fields', () => {
      const log: PlatformAuditLog = {
        id: 'log-id',
        adminId: null,
        action: 'system_event',
        targetType: null,
        targetId: null,
        details: {},
        ipAddress: null,
        createdAt: '2024-01-01T00:00:00Z'
      };

      expect(log.adminId).toBeNull();
      expect(log.targetType).toBeNull();
    });
  });

  describe('ImpersonationSession', () => {
    it('should have correct structure', () => {
      const session: ImpersonationSession = {
        adminId: 'admin-id',
        adminEmail: 'admin@test.com',
        targetUserId: 'user-id',
        targetUserEmail: 'user@test.com',
        targetOrgId: 'org-id',
        targetOrgName: 'Test Org',
        startedAt: Date.now(),
        expiresAt: Date.now() + 3600000
      };

      expect(session.adminId).toBe('admin-id');
      expect(session.expiresAt).toBeGreaterThan(session.startedAt);
    });

    it('should calculate expiration correctly', () => {
      const now = Date.now();
      const oneHour = 60 * 60 * 1000;

      const session: ImpersonationSession = {
        adminId: 'admin-id',
        adminEmail: 'admin@test.com',
        targetUserId: 'user-id',
        targetUserEmail: 'user@test.com',
        targetOrgId: 'org-id',
        targetOrgName: 'Test Org',
        startedAt: now,
        expiresAt: now + oneHour
      };

      const timeRemaining = session.expiresAt - now;
      expect(timeRemaining).toBe(oneHour);
    });
  });

  describe('PlatformMetrics', () => {
    it('should have correct structure', () => {
      const metrics: PlatformMetrics = {
        totalOrganizations: 100,
        activeOrganizations: 60,
        trialOrganizations: 30,
        cancelledOrganizations: 5,
        pastDueOrganizations: 5,
        totalUsers: 500,
        signupsLast7Days: 10,
        signupsLast30Days: 35,
        trialsExpiringIn7Days: 8,
        mrr: 12000,
        arr: 144000
      };

      expect(metrics.totalOrganizations).toBe(100);
      expect(metrics.mrr).toBe(12000);
      expect(metrics.arr).toBe(metrics.mrr * 12);
    });

    it('should calculate percentages correctly', () => {
      const metrics: PlatformMetrics = {
        totalOrganizations: 100,
        activeOrganizations: 60,
        trialOrganizations: 30,
        cancelledOrganizations: 5,
        pastDueOrganizations: 5,
        totalUsers: 500,
        signupsLast7Days: 10,
        signupsLast30Days: 35,
        trialsExpiringIn7Days: 8,
        mrr: 12000,
        arr: 144000
      };

      const activePercentage = (metrics.activeOrganizations / metrics.totalOrganizations) * 100;
      expect(activePercentage).toBe(60);

      const trialPercentage = (metrics.trialOrganizations / metrics.totalOrganizations) * 100;
      expect(trialPercentage).toBe(30);
    });
  });

  describe('User with Platform Admin fields', () => {
    it('should have platform admin fields', () => {
      const user: User = {
        id: 'user-id',
        email: 'admin@test.com',
        name: 'Test Admin',
        role: 'Admin',
        status: 'Active',
        isPlatformAdmin: true,
        platformRole: 'super_admin',
        organizationId: 'org-id'
      };

      expect(user.isPlatformAdmin).toBe(true);
      expect(user.platformRole).toBe('super_admin');
    });

    it('should work without platform admin fields', () => {
      const user: User = {
        id: 'user-id',
        email: 'user@test.com',
        name: 'Regular User',
        role: 'Technician',
        status: 'Active'
      };

      expect(user.isPlatformAdmin).toBeUndefined();
      expect(user.platformRole).toBeUndefined();
    });
  });
});
