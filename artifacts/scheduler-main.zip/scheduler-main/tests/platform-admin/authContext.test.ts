import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import type { ImpersonationSession, PlatformRole } from '../../types';

// Storage key constant
const IMPERSONATION_KEY = 'AM_IMPERSONATION_SESSION';

// Test the mapDatabaseRole logic
describe('Database Role Mapping', () => {
  const mapDatabaseRole = (dbRole: string): 'Admin' | 'Manager' | 'Technician' => {
    switch (dbRole) {
      case 'owner':
      case 'admin':
        return 'Admin';
      case 'manager':
        return 'Manager';
      case 'technician':
      case 'viewer':
        return 'Technician';
      default:
        return 'Technician';
    }
  };

  it('should map owner role to Admin', () => {
    expect(mapDatabaseRole('owner')).toBe('Admin');
  });

  it('should map admin role to Admin', () => {
    expect(mapDatabaseRole('admin')).toBe('Admin');
  });

  it('should map manager role to Manager', () => {
    expect(mapDatabaseRole('manager')).toBe('Manager');
  });

  it('should map technician role to Technician', () => {
    expect(mapDatabaseRole('technician')).toBe('Technician');
  });

  it('should map viewer role to Technician', () => {
    expect(mapDatabaseRole('viewer')).toBe('Technician');
  });

  it('should default unknown roles to Technician', () => {
    expect(mapDatabaseRole('unknown')).toBe('Technician');
    expect(mapDatabaseRole('')).toBe('Technician');
  });
});

// Test profileToUser conversion
describe('Profile to User Conversion', () => {
  interface DBProfile {
    id: string;
    organization_id: string | null;
    email: string;
    full_name: string;
    role: string;
    avatar_url: string | null;
    auth_provider: string | null;
    created_at: string;
    updated_at: string;
    is_platform_admin: boolean | null;
    platform_role: string | null;
  }

  const profileToUser = (profile: DBProfile) => ({
    id: profile.id,
    email: profile.email,
    name: profile.full_name,
    role: profile.role === 'admin' || profile.role === 'owner' ? 'Admin' :
          profile.role === 'manager' ? 'Manager' : 'Technician',
    status: 'Active' as const,
    avatar: profile.avatar_url || profile.full_name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase(),
    isPlatformAdmin: profile.is_platform_admin || false,
    platformRole: profile.platform_role as PlatformRole | undefined,
    organizationId: profile.organization_id || undefined,
  });

  it('should convert a regular user profile', () => {
    const profile: DBProfile = {
      id: 'user-123',
      organization_id: 'org-456',
      email: 'user@test.com',
      full_name: 'John Doe',
      role: 'technician',
      avatar_url: null,
      auth_provider: 'email',
      created_at: '2024-01-01T00:00:00Z',
      updated_at: '2024-01-01T00:00:00Z',
      is_platform_admin: false,
      platform_role: null,
    };

    const user = profileToUser(profile);

    expect(user.id).toBe('user-123');
    expect(user.email).toBe('user@test.com');
    expect(user.name).toBe('John Doe');
    expect(user.role).toBe('Technician');
    expect(user.status).toBe('Active');
    expect(user.avatar).toBe('JD'); // Initials from name
    expect(user.isPlatformAdmin).toBe(false);
    expect(user.platformRole).toBeNull();
    expect(user.organizationId).toBe('org-456');
  });

  it('should convert a platform admin profile', () => {
    const profile: DBProfile = {
      id: 'admin-789',
      organization_id: 'org-456',
      email: 'admin@platform.com',
      full_name: 'Platform Admin',
      role: 'admin',
      avatar_url: 'https://example.com/avatar.png',
      auth_provider: 'email',
      created_at: '2024-01-01T00:00:00Z',
      updated_at: '2024-01-01T00:00:00Z',
      is_platform_admin: true,
      platform_role: 'super_admin',
    };

    const user = profileToUser(profile);

    expect(user.isPlatformAdmin).toBe(true);
    expect(user.platformRole).toBe('super_admin');
    expect(user.avatar).toBe('https://example.com/avatar.png');
  });

  it('should handle null organization_id', () => {
    const profile: DBProfile = {
      id: 'user-123',
      organization_id: null,
      email: 'user@test.com',
      full_name: 'Solo User',
      role: 'technician',
      avatar_url: null,
      auth_provider: 'email',
      created_at: '2024-01-01T00:00:00Z',
      updated_at: '2024-01-01T00:00:00Z',
      is_platform_admin: false,
      platform_role: null,
    };

    const user = profileToUser(profile);

    expect(user.organizationId).toBeUndefined();
  });

  it('should generate avatar from single name', () => {
    const profile: DBProfile = {
      id: 'user-123',
      organization_id: 'org-456',
      email: 'user@test.com',
      full_name: 'Madonna',
      role: 'technician',
      avatar_url: null,
      auth_provider: null,
      created_at: '2024-01-01T00:00:00Z',
      updated_at: '2024-01-01T00:00:00Z',
      is_platform_admin: false,
      platform_role: null,
    };

    const user = profileToUser(profile);

    expect(user.avatar).toBe('M');
  });
});

// Test impersonation session management
describe('Impersonation Session', () => {
  beforeEach(() => {
    localStorage.clear();
  });

  afterEach(() => {
    localStorage.clear();
  });

  it('should create a valid impersonation session', () => {
    const now = Date.now();
    const session: ImpersonationSession = {
      adminId: 'admin-123',
      adminEmail: 'admin@platform.com',
      targetUserId: 'user-456',
      targetUserEmail: 'user@test.com',
      targetOrgId: 'org-789',
      targetOrgName: 'Test Organization',
      startedAt: now,
      expiresAt: now + 60 * 60 * 1000, // 1 hour
    };

    expect(session.expiresAt).toBeGreaterThan(session.startedAt);
    expect(session.expiresAt - session.startedAt).toBe(3600000); // 1 hour in ms
  });

  it('should serialize impersonation session to JSON correctly', () => {
    const session: ImpersonationSession = {
      adminId: 'admin-123',
      adminEmail: 'admin@platform.com',
      targetUserId: 'user-456',
      targetUserEmail: 'user@test.com',
      targetOrgId: 'org-789',
      targetOrgName: 'Test Organization',
      startedAt: Date.now(),
      expiresAt: Date.now() + 3600000,
    };

    const serialized = JSON.stringify(session);
    expect(serialized).toContain('"adminId":"admin-123"');
    expect(serialized).toContain('"targetUserId":"user-456"');

    const parsed = JSON.parse(serialized);
    expect(parsed.adminId).toBe('admin-123');
    expect(parsed.targetUserId).toBe('user-456');
  });

  it('should deserialize impersonation session from JSON correctly', () => {
    const session: ImpersonationSession = {
      adminId: 'admin-123',
      adminEmail: 'admin@platform.com',
      targetUserId: 'user-456',
      targetUserEmail: 'user@test.com',
      targetOrgId: 'org-789',
      targetOrgName: 'Test Organization',
      startedAt: Date.now(),
      expiresAt: Date.now() + 3600000,
    };

    const serialized = JSON.stringify(session);
    const retrieved: ImpersonationSession = JSON.parse(serialized);

    expect(retrieved.adminEmail).toBe(session.adminEmail);
    expect(retrieved.targetOrgName).toBe('Test Organization');
  });

  it('should detect expired session', () => {
    const expiredSession: ImpersonationSession = {
      adminId: 'admin-123',
      adminEmail: 'admin@platform.com',
      targetUserId: 'user-456',
      targetUserEmail: 'user@test.com',
      targetOrgId: 'org-789',
      targetOrgName: 'Test Organization',
      startedAt: Date.now() - 7200000, // 2 hours ago
      expiresAt: Date.now() - 3600000, // Expired 1 hour ago
    };

    const isExpired = expiredSession.expiresAt < Date.now();
    expect(isExpired).toBe(true);
  });

  it('should detect valid (non-expired) session', () => {
    const validSession: ImpersonationSession = {
      adminId: 'admin-123',
      adminEmail: 'admin@platform.com',
      targetUserId: 'user-456',
      targetUserEmail: 'user@test.com',
      targetOrgId: 'org-789',
      targetOrgName: 'Test Organization',
      startedAt: Date.now(),
      expiresAt: Date.now() + 3600000, // Expires in 1 hour
    };

    const isExpired = validSession.expiresAt < Date.now();
    expect(isExpired).toBe(false);
  });

  it('should handle session clearing logic', () => {
    // Simulate session management state
    let sessionState: ImpersonationSession | null = {
      adminId: 'admin-123',
      adminEmail: 'admin@platform.com',
      targetUserId: 'user-456',
      targetUserEmail: 'user@test.com',
      targetOrgId: 'org-789',
      targetOrgName: 'Test Organization',
      startedAt: Date.now(),
      expiresAt: Date.now() + 3600000,
    };

    expect(sessionState).not.toBeNull();

    // Clear session
    sessionState = null;
    expect(sessionState).toBeNull();
  });
});

// Test impersonation permission checks
describe('Impersonation Permissions', () => {
  it('should allow super_admin to impersonate', () => {
    const canImpersonate = (platformRole: PlatformRole | null): boolean => {
      return platformRole === 'super_admin' || platformRole === 'support_admin';
    };

    expect(canImpersonate('super_admin')).toBe(true);
  });

  it('should allow support_admin to impersonate', () => {
    const canImpersonate = (platformRole: PlatformRole | null): boolean => {
      return platformRole === 'super_admin' || platformRole === 'support_admin';
    };

    expect(canImpersonate('support_admin')).toBe(true);
  });

  it('should not allow billing_admin to impersonate', () => {
    const canImpersonate = (platformRole: PlatformRole | null): boolean => {
      return platformRole === 'super_admin' || platformRole === 'support_admin';
    };

    expect(canImpersonate('billing_admin')).toBe(false);
  });

  it('should not allow null role to impersonate', () => {
    const canImpersonate = (platformRole: PlatformRole | null): boolean => {
      return platformRole === 'super_admin' || platformRole === 'support_admin';
    };

    expect(canImpersonate(null)).toBe(false);
  });

  it('should prevent impersonating platform admins', () => {
    const canImpersonateTarget = (targetIsPlatformAdmin: boolean): boolean => {
      return !targetIsPlatformAdmin;
    };

    expect(canImpersonateTarget(true)).toBe(false);
    expect(canImpersonateTarget(false)).toBe(true);
  });
});

// Test auth error message mapping
describe('Auth Error Messages', () => {
  const getAuthErrorMessage = (errorMessage: string): string => {
    switch (errorMessage) {
      case 'Invalid login credentials':
        return 'Invalid email or password.';
      case 'Email not confirmed':
        return 'Please verify your email address before signing in.';
      case 'User already registered':
        return 'An account with this email already exists.';
      case 'Password should be at least 6 characters':
        return 'Password must be at least 6 characters.';
      case 'Signup requires a valid password':
        return 'Please enter a valid password.';
      default:
        return errorMessage || 'An error occurred. Please try again.';
    }
  };

  it('should map invalid credentials error', () => {
    expect(getAuthErrorMessage('Invalid login credentials')).toBe('Invalid email or password.');
  });

  it('should map email not confirmed error', () => {
    expect(getAuthErrorMessage('Email not confirmed'))
      .toBe('Please verify your email address before signing in.');
  });

  it('should map user already registered error', () => {
    expect(getAuthErrorMessage('User already registered'))
      .toBe('An account with this email already exists.');
  });

  it('should map password length error', () => {
    expect(getAuthErrorMessage('Password should be at least 6 characters'))
      .toBe('Password must be at least 6 characters.');
  });

  it('should map invalid password error', () => {
    expect(getAuthErrorMessage('Signup requires a valid password'))
      .toBe('Please enter a valid password.');
  });

  it('should return original message for unknown errors', () => {
    expect(getAuthErrorMessage('Some unknown error'))
      .toBe('Some unknown error');
  });

  it('should return default message for empty error', () => {
    expect(getAuthErrorMessage(''))
      .toBe('An error occurred. Please try again.');
  });
});

// Test SystemRole to database role mapping
describe('SystemRole to Database Role Mapping', () => {
  const mapSystemRoleToDb = (systemRole: 'Admin' | 'Manager' | 'Technician'): string => {
    switch (systemRole) {
      case 'Admin':
        return 'admin';
      case 'Manager':
        return 'manager';
      case 'Technician':
        return 'technician';
    }
  };

  it('should map Admin to admin', () => {
    expect(mapSystemRoleToDb('Admin')).toBe('admin');
  });

  it('should map Manager to manager', () => {
    expect(mapSystemRoleToDb('Manager')).toBe('manager');
  });

  it('should map Technician to technician', () => {
    expect(mapSystemRoleToDb('Technician')).toBe('technician');
  });
});
