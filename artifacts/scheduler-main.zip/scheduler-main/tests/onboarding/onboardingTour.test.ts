import { describe, it, expect } from 'vitest';
import {
  TOUR_STEPS,
  TOUR_SECTIONS,
  QUICK_TOUR_STEPS,
  getCurrentSection,
  getSectionIndex,
} from '../../components/OnboardingTour';

describe('OnboardingTour - TOUR_STEPS structure', () => {
  it('should have steps defined', () => {
    expect(TOUR_STEPS.length).toBeGreaterThan(0);
  });

  it('should have required properties on each step', () => {
    TOUR_STEPS.forEach((step, index) => {
      expect(step.title, `Step ${index} missing title`).toBeDefined();
      expect(typeof step.title).toBe('string');
      expect(step.content, `Step ${index} missing content`).toBeDefined();
      expect(typeof step.content).toBe('string');
      expect(step.icon, `Step ${index} missing icon`).toBeDefined();
      // targetId can be null or string
      expect(step.targetId === null || typeof step.targetId === 'string').toBe(true);
    });
  });

  it('should have at least 30 tour steps for comprehensive coverage', () => {
    expect(TOUR_STEPS.length).toBeGreaterThanOrEqual(30);
  });

  it('should start with welcome step', () => {
    expect(TOUR_STEPS[0].title).toBe('Welcome to AeroManager');
    expect(TOUR_STEPS[0].targetId).toBeNull();
  });

  it('should end with setup defaults step', () => {
    const lastStep = TOUR_STEPS[TOUR_STEPS.length - 1];
    expect(lastStep.title).toBe('Setup Defaults?');
  });
});

describe('OnboardingTour - TOUR_SECTIONS structure', () => {
  it('should have 6 sections defined', () => {
    expect(TOUR_SECTIONS.length).toBe(6);
  });

  it('should have required properties on each section', () => {
    TOUR_SECTIONS.forEach((section, index) => {
      expect(section.id, `Section ${index} missing id`).toBeDefined();
      expect(section.name, `Section ${index} missing name`).toBeDefined();
      expect(typeof section.startStep).toBe('number');
      expect(typeof section.endStep).toBe('number');
      expect(section.description, `Section ${index} missing description`).toBeDefined();
    });
  });

  it('should have unique section ids', () => {
    const ids = TOUR_SECTIONS.map(s => s.id);
    const uniqueIds = new Set(ids);
    expect(uniqueIds.size).toBe(ids.length);
  });

  it('should have sections in ascending step order', () => {
    for (let i = 1; i < TOUR_SECTIONS.length; i++) {
      expect(TOUR_SECTIONS[i].startStep).toBeGreaterThan(TOUR_SECTIONS[i - 1].startStep);
    }
  });

  it('should have no gaps between sections', () => {
    for (let i = 1; i < TOUR_SECTIONS.length; i++) {
      expect(TOUR_SECTIONS[i].startStep).toBe(TOUR_SECTIONS[i - 1].endStep + 1);
    }
  });

  it('should cover all steps from 0 to last step', () => {
    expect(TOUR_SECTIONS[0].startStep).toBe(0);
    // Last section should cover the last step (endStep should be TOUR_STEPS.length - 1)
    const lastSection = TOUR_SECTIONS[TOUR_SECTIONS.length - 1];
    expect(lastSection.endStep).toBeGreaterThanOrEqual(TOUR_STEPS.length - 1);
  });

  it('should have valid step ranges (startStep <= endStep)', () => {
    TOUR_SECTIONS.forEach((section) => {
      expect(section.startStep).toBeLessThanOrEqual(section.endStep);
    });
  });

  it('should have expected section names', () => {
    const expectedNames = [
      'Overview',
      'Dashboard Panels',
      'Configuration',
      'Personnel',
      'Financials',
      'Quoting & Scheduling'
    ];
    const actualNames = TOUR_SECTIONS.map(s => s.name);
    expect(actualNames).toEqual(expectedNames);
  });
});

describe('OnboardingTour - getCurrentSection helper', () => {
  it('should return first section for step 0', () => {
    const section = getCurrentSection(0);
    expect(section).toBeDefined();
    expect(section?.id).toBe('overview');
    expect(section?.name).toBe('Overview');
  });

  it('should return first section for step 1', () => {
    const section = getCurrentSection(1);
    expect(section?.id).toBe('overview');
  });

  it('should return second section for step 2', () => {
    const section = getCurrentSection(2);
    expect(section?.id).toBe('panels');
    expect(section?.name).toBe('Dashboard Panels');
  });

  it('should return correct section for step 9 (last of panels)', () => {
    const section = getCurrentSection(9);
    expect(section?.id).toBe('panels');
  });

  it('should return config section for step 10', () => {
    const section = getCurrentSection(10);
    expect(section?.id).toBe('config');
  });

  it('should return last section for last step', () => {
    const lastStepIndex = TOUR_STEPS.length - 1;
    const section = getCurrentSection(lastStepIndex);
    expect(section?.id).toBe('quoting');
  });

  it('should return undefined for negative step', () => {
    const section = getCurrentSection(-1);
    expect(section).toBeUndefined();
  });

  it('should return undefined for step beyond range', () => {
    const section = getCurrentSection(TOUR_STEPS.length + 10);
    expect(section).toBeUndefined();
  });

  it('should return correct section for every valid step', () => {
    TOUR_STEPS.forEach((_, stepIndex) => {
      const section = getCurrentSection(stepIndex);
      expect(section, `No section found for step ${stepIndex}`).toBeDefined();
      expect(stepIndex).toBeGreaterThanOrEqual(section!.startStep);
      expect(stepIndex).toBeLessThanOrEqual(section!.endStep);
    });
  });
});

describe('OnboardingTour - getSectionIndex helper', () => {
  it('should return 0 for first section steps', () => {
    expect(getSectionIndex(0)).toBe(0);
    expect(getSectionIndex(1)).toBe(0);
  });

  it('should return 1 for second section steps', () => {
    expect(getSectionIndex(2)).toBe(1);
    expect(getSectionIndex(9)).toBe(1);
  });

  it('should return correct indices for all sections', () => {
    TOUR_SECTIONS.forEach((section, expectedIndex) => {
      // Test start of section
      expect(getSectionIndex(section.startStep)).toBe(expectedIndex);
      // Test end of section
      expect(getSectionIndex(section.endStep)).toBe(expectedIndex);
    });
  });

  it('should return -1 for invalid steps', () => {
    expect(getSectionIndex(-1)).toBe(-1);
    expect(getSectionIndex(TOUR_STEPS.length + 10)).toBe(-1);
  });

  it('should return last section index for last step', () => {
    const lastStepIndex = TOUR_STEPS.length - 1;
    expect(getSectionIndex(lastStepIndex)).toBe(TOUR_SECTIONS.length - 1);
  });
});

describe('OnboardingTour - QUICK_TOUR_STEPS structure', () => {
  it('should have 8 quick tour steps', () => {
    expect(QUICK_TOUR_STEPS.length).toBe(8);
  });

  it('should have required properties on each step', () => {
    QUICK_TOUR_STEPS.forEach((step, index) => {
      expect(step.title, `Quick step ${index} missing title`).toBeDefined();
      expect(step.content, `Quick step ${index} missing content`).toBeDefined();
      expect(step.icon, `Quick step ${index} missing icon`).toBeDefined();
    });
  });

  it('should start with welcome step', () => {
    expect(QUICK_TOUR_STEPS[0].title).toBe('Welcome to AeroManager');
  });

  it('should end with help step', () => {
    expect(QUICK_TOUR_STEPS[QUICK_TOUR_STEPS.length - 1].title).toBe('Get Help Anytime');
  });

  it('should cover key features in order', () => {
    const titles = QUICK_TOUR_STEPS.map(s => s.title);
    expect(titles).toContain('The Scheduling Timeline');
    expect(titles).toContain('Create a Quote');
    expect(titles).toContain('Schedule Work');
    expect(titles).toContain('Track Finances');
    expect(titles).toContain('Manage Your Team');
    expect(titles).toContain('Configure Settings');
  });
});

describe('OnboardingTour - Tour content quality', () => {
  it('should not have empty titles or content', () => {
    TOUR_STEPS.forEach((step, index) => {
      expect(step.title.trim().length, `Step ${index} has empty title`).toBeGreaterThan(0);
      expect(step.content.trim().length, `Step ${index} has empty content`).toBeGreaterThan(0);
    });
  });

  it('should have reasonable content length (not too short)', () => {
    TOUR_STEPS.forEach((step, index) => {
      expect(step.content.length, `Step ${index} content too short`).toBeGreaterThan(20);
    });
  });

  it('should have inline term definitions using **bold** markers', () => {
    // Check that some steps have bold definitions
    const stepsWithBoldTerms = TOUR_STEPS.filter(s => s.content.includes('**'));
    expect(stepsWithBoldTerms.length).toBeGreaterThan(10);
  });

  it('should define key aviation terms', () => {
    const allContent = TOUR_STEPS.map(s => s.content).join(' ');
    expect(allContent).toContain('MRO');
    expect(allContent).toContain('hangar');
    expect(allContent).toContain('AOG');
    expect(allContent).toContain('tail number');
    expect(allContent).toContain('A&P');
  });
});

describe('OnboardingTour - Section progression logic', () => {
  it('should be able to calculate progress percentage', () => {
    const calculateProgress = (step: number): number => {
      return ((step + 1) / TOUR_STEPS.length) * 100;
    };

    expect(calculateProgress(0)).toBeCloseTo(100 / TOUR_STEPS.length, 2);
    expect(calculateProgress(TOUR_STEPS.length - 1)).toBe(100);
    // Approximately 50% at the middle step (within 5% tolerance)
    const midStep = Math.floor(TOUR_STEPS.length / 2);
    const midProgress = calculateProgress(midStep);
    expect(midProgress).toBeGreaterThan(45);
    expect(midProgress).toBeLessThan(55);
  });

  it('should be able to skip to next section', () => {
    const skipToNextSection = (currentStep: number): number => {
      const currentSection = getCurrentSection(currentStep);
      if (!currentSection) return currentStep;

      const currentSectionIndex = getSectionIndex(currentStep);
      if (currentSectionIndex >= TOUR_SECTIONS.length - 1) {
        // Already in last section, go to last step
        return TOUR_STEPS.length - 1;
      }

      // Go to start of next section
      return TOUR_SECTIONS[currentSectionIndex + 1].startStep;
    };

    // From overview (0), skip to panels (2)
    expect(skipToNextSection(0)).toBe(2);
    expect(skipToNextSection(1)).toBe(2);

    // From panels (2-9), skip to config (10)
    expect(skipToNextSection(5)).toBe(10);
    expect(skipToNextSection(9)).toBe(10);

    // From last section, go to last step
    expect(skipToNextSection(30)).toBe(TOUR_STEPS.length - 1);
  });

  it('should track completed sections correctly', () => {
    const trackCompletedSections = (
      completedSections: string[],
      currentStep: number
    ): string[] => {
      const currentSection = getCurrentSection(currentStep);
      if (!currentSection) return completedSections;

      // If at end of section and section not already tracked
      if (currentStep === currentSection.endStep && !completedSections.includes(currentSection.id)) {
        return [...completedSections, currentSection.id];
      }
      return completedSections;
    };

    let completed: string[] = [];

    // Complete overview section (step 1 is end)
    completed = trackCompletedSections(completed, 1);
    expect(completed).toContain('overview');

    // Complete panels section (step 9 is end)
    completed = trackCompletedSections(completed, 9);
    expect(completed).toContain('panels');

    // Duplicate call shouldn't add again
    completed = trackCompletedSections(completed, 9);
    expect(completed.filter(s => s === 'panels').length).toBe(1);

    // Mid-section step shouldn't add
    completed = trackCompletedSections(completed, 12);
    expect(completed).not.toContain('config');
  });
});
