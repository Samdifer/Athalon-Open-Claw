import { describe, it, expect } from 'vitest';

describe('WelcomeSplash - User name extraction', () => {
  it('should extract first name from full name', () => {
    const extractFirstName = (userName?: string): string | undefined => {
      return userName?.split(' ')[0];
    };

    expect(extractFirstName('John Smith')).toBe('John');
    expect(extractFirstName('Mary')).toBe('Mary');
    expect(extractFirstName('John Patrick Smith')).toBe('John');
  });

  it('should handle undefined userName', () => {
    const extractFirstName = (userName?: string): string | undefined => {
      return userName?.split(' ')[0];
    };

    expect(extractFirstName(undefined)).toBeUndefined();
    expect(extractFirstName()).toBeUndefined();
  });

  it('should handle empty string', () => {
    const extractFirstName = (userName?: string): string | undefined => {
      return userName?.split(' ')[0];
    };

    expect(extractFirstName('')).toBe('');
  });

  it('should generate appropriate greeting', () => {
    const getGreeting = (firstName?: string): string => {
      return firstName ? `Welcome, ${firstName}!` : 'Welcome to AeroManager!';
    };

    expect(getGreeting('John')).toBe('Welcome, John!');
    expect(getGreeting(undefined)).toBe('Welcome to AeroManager!');
    expect(getGreeting('')).toBe('Welcome to AeroManager!');
  });
});

describe('WelcomeSplash - Button visibility', () => {
  it('should show demo button when onLoadDemo is provided', () => {
    const shouldShowDemoButton = (onLoadDemo?: () => void): boolean => {
      return typeof onLoadDemo === 'function';
    };

    expect(shouldShowDemoButton(() => {})).toBe(true);
    expect(shouldShowDemoButton(undefined)).toBe(false);
  });
});

describe('WelcomeSplash - Action handlers', () => {
  it('should have three action options', () => {
    const actions = ['startTour', 'loadDemo', 'skip'];
    expect(actions.length).toBe(3);
  });

  it('should define clear action labels', () => {
    const actionLabels = {
      startTour: 'Take the Tour',
      loadDemo: 'Load Demo Data',
      skip: 'Start Fresh'
    };

    expect(actionLabels.startTour).toBe('Take the Tour');
    expect(actionLabels.loadDemo).toBe('Load Demo Data');
    expect(actionLabels.skip).toBe('Start Fresh');
  });
});

describe('WelcomeSplash - Content structure', () => {
  it('should have introductory text explaining the app', () => {
    const introText = 'AeroManager helps you plan aircraft maintenance, track your team\'s capacity, and forecast revenue.';
    expect(introText).toContain('aircraft maintenance');
    expect(introText).toContain('capacity');
    expect(introText).toContain('revenue');
  });

  it('should have a call to action prompt', () => {
    const ctaText = 'How would you like to get started?';
    expect(ctaText).toContain('get started');
  });

  it('should include estimated tour time', () => {
    const tourTimeText = '(2 min)';
    expect(tourTimeText).toContain('2 min');
  });
});
