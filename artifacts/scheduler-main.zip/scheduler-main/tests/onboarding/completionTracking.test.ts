import { describe, it, expect } from 'vitest';
import { TOUR_STEPS, TOUR_SECTIONS, getCurrentSection } from '../../components/OnboardingTour';

// Simulated UIState onboarding fields (matching types.ts)
interface OnboardingUIState {
  tutorialActive: boolean;
  tutorialStep: number;
  onboardingCompleted: boolean;
  onboardingCompletedAt?: number;
  completedSections: string[];
}

describe('Completion Tracking - UIState defaults', () => {
  it('should have correct default values for new users', () => {
    const defaultUIState: OnboardingUIState = {
      tutorialActive: false,
      tutorialStep: 0,
      onboardingCompleted: false,
      onboardingCompletedAt: undefined,
      completedSections: []
    };

    expect(defaultUIState.tutorialActive).toBe(false);
    expect(defaultUIState.tutorialStep).toBe(0);
    expect(defaultUIState.onboardingCompleted).toBe(false);
    expect(defaultUIState.onboardingCompletedAt).toBeUndefined();
    expect(defaultUIState.completedSections).toEqual([]);
  });
});

describe('Completion Tracking - handleTutorialClose logic', () => {
  it('should mark onboarding as complete when closing on last step', () => {
    const handleTutorialClose = (state: OnboardingUIState): Partial<OnboardingUIState> => {
      const currentStep = state.tutorialStep;
      const wasLastStep = currentStep === TOUR_STEPS.length - 1;
      const currentSection = getCurrentSection(currentStep);
      let completedSections = [...state.completedSections];

      if (currentSection && currentStep === currentSection.endStep && !completedSections.includes(currentSection.id)) {
        completedSections.push(currentSection.id);
      }

      return {
        tutorialActive: false,
        tutorialStep: 0,
        onboardingCompleted: wasLastStep || state.onboardingCompleted,
        onboardingCompletedAt: wasLastStep ? Date.now() : state.onboardingCompletedAt,
        completedSections
      };
    };

    // Closing on last step
    const stateAtLastStep: OnboardingUIState = {
      tutorialActive: true,
      tutorialStep: TOUR_STEPS.length - 1,
      onboardingCompleted: false,
      onboardingCompletedAt: undefined,
      completedSections: []
    };

    const result = handleTutorialClose(stateAtLastStep);
    expect(result.onboardingCompleted).toBe(true);
    expect(result.onboardingCompletedAt).toBeDefined();
    expect(result.tutorialActive).toBe(false);
  });

  it('should NOT mark onboarding as complete when closing mid-tour', () => {
    const handleTutorialClose = (state: OnboardingUIState): Partial<OnboardingUIState> => {
      const currentStep = state.tutorialStep;
      const wasLastStep = currentStep === TOUR_STEPS.length - 1;

      return {
        tutorialActive: false,
        tutorialStep: 0,
        onboardingCompleted: wasLastStep || state.onboardingCompleted,
        onboardingCompletedAt: wasLastStep ? Date.now() : state.onboardingCompletedAt,
      };
    };

    // Closing mid-tour (step 10)
    const stateAtMidTour: OnboardingUIState = {
      tutorialActive: true,
      tutorialStep: 10,
      onboardingCompleted: false,
      onboardingCompletedAt: undefined,
      completedSections: []
    };

    const result = handleTutorialClose(stateAtMidTour);
    expect(result.onboardingCompleted).toBe(false);
    expect(result.onboardingCompletedAt).toBeUndefined();
  });

  it('should preserve existing completion status', () => {
    const handleTutorialClose = (state: OnboardingUIState): Partial<OnboardingUIState> => {
      const currentStep = state.tutorialStep;
      const wasLastStep = currentStep === TOUR_STEPS.length - 1;

      return {
        tutorialActive: false,
        tutorialStep: 0,
        onboardingCompleted: wasLastStep || state.onboardingCompleted,
        onboardingCompletedAt: wasLastStep ? Date.now() : state.onboardingCompletedAt,
      };
    };

    // Already completed user re-opening tour
    const previousTimestamp = Date.now() - 86400000; // 1 day ago
    const alreadyCompletedState: OnboardingUIState = {
      tutorialActive: true,
      tutorialStep: 5, // Closed early this time
      onboardingCompleted: true,
      onboardingCompletedAt: previousTimestamp,
      completedSections: ['overview', 'panels']
    };

    const result = handleTutorialClose(alreadyCompletedState);
    expect(result.onboardingCompleted).toBe(true);
    expect(result.onboardingCompletedAt).toBe(previousTimestamp);
  });

  it('should track section completion when closing at section end', () => {
    const handleTutorialClose = (state: OnboardingUIState): Partial<OnboardingUIState> => {
      const currentStep = state.tutorialStep;
      const currentSection = getCurrentSection(currentStep);
      let completedSections = [...state.completedSections];

      if (currentSection && currentStep === currentSection.endStep && !completedSections.includes(currentSection.id)) {
        completedSections.push(currentSection.id);
      }

      return {
        tutorialActive: false,
        tutorialStep: 0,
        completedSections
      };
    };

    // Closing at end of 'panels' section (step 9)
    const stateAtSectionEnd: OnboardingUIState = {
      tutorialActive: true,
      tutorialStep: 9,
      onboardingCompleted: false,
      onboardingCompletedAt: undefined,
      completedSections: ['overview']
    };

    const result = handleTutorialClose(stateAtSectionEnd);
    expect(result.completedSections).toContain('panels');
    expect(result.completedSections).toContain('overview');
    expect(result.completedSections?.length).toBe(2);
  });
});

describe('Completion Tracking - Skip welcome for returning users', () => {
  it('should skip welcome splash when onboarding completed', () => {
    const shouldShowWelcome = (uiState: OnboardingUIState): boolean => {
      return !uiState.onboardingCompleted;
    };

    const newUserState: OnboardingUIState = {
      tutorialActive: false,
      tutorialStep: 0,
      onboardingCompleted: false,
      onboardingCompletedAt: undefined,
      completedSections: []
    };

    const returningUserState: OnboardingUIState = {
      tutorialActive: false,
      tutorialStep: 0,
      onboardingCompleted: true,
      onboardingCompletedAt: Date.now() - 86400000,
      completedSections: ['overview', 'panels', 'config', 'personnel', 'financials', 'quoting']
    };

    expect(shouldShowWelcome(newUserState)).toBe(true);
    expect(shouldShowWelcome(returningUserState)).toBe(false);
  });
});

describe('Completion Tracking - Section progress calculation', () => {
  it('should calculate section completion percentage', () => {
    const calculateSectionProgress = (completedSections: string[]): number => {
      return (completedSections.length / TOUR_SECTIONS.length) * 100;
    };

    expect(calculateSectionProgress([])).toBe(0);
    expect(calculateSectionProgress(['overview'])).toBeCloseTo(16.67, 1);
    expect(calculateSectionProgress(['overview', 'panels'])).toBeCloseTo(33.33, 1);
    expect(calculateSectionProgress(TOUR_SECTIONS.map(s => s.id))).toBe(100);
  });

  it('should identify remaining sections', () => {
    const getRemainingSections = (completedSections: string[]): string[] => {
      return TOUR_SECTIONS
        .filter(s => !completedSections.includes(s.id))
        .map(s => s.id);
    };

    const completed = ['overview', 'panels'];
    const remaining = getRemainingSections(completed);

    expect(remaining).toContain('config');
    expect(remaining).toContain('personnel');
    expect(remaining).toContain('financials');
    expect(remaining).toContain('quoting');
    expect(remaining.length).toBe(4);
  });
});

describe('Completion Tracking - Timestamp validation', () => {
  it('should set completion timestamp on full completion', () => {
    const completeOnboarding = (): OnboardingUIState => {
      return {
        tutorialActive: false,
        tutorialStep: 0,
        onboardingCompleted: true,
        onboardingCompletedAt: Date.now(),
        completedSections: TOUR_SECTIONS.map(s => s.id)
      };
    };

    const before = Date.now();
    const state = completeOnboarding();
    const after = Date.now();

    expect(state.onboardingCompletedAt).toBeDefined();
    expect(state.onboardingCompletedAt).toBeGreaterThanOrEqual(before);
    expect(state.onboardingCompletedAt).toBeLessThanOrEqual(after);
  });

  it('should preserve original timestamp on re-completion', () => {
    const originalTimestamp = Date.now() - 86400000; // 1 day ago

    const handleReCompletion = (state: OnboardingUIState): OnboardingUIState => {
      // If already completed, don't update timestamp
      if (state.onboardingCompleted && state.onboardingCompletedAt) {
        return state;
      }
      return {
        ...state,
        onboardingCompleted: true,
        onboardingCompletedAt: Date.now()
      };
    };

    const alreadyCompletedState: OnboardingUIState = {
      tutorialActive: false,
      tutorialStep: 0,
      onboardingCompleted: true,
      onboardingCompletedAt: originalTimestamp,
      completedSections: TOUR_SECTIONS.map(s => s.id)
    };

    const result = handleReCompletion(alreadyCompletedState);
    expect(result.onboardingCompletedAt).toBe(originalTimestamp);
  });
});
