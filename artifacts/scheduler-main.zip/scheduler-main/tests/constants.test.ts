import { describe, it, expect } from 'vitest';
import {
  // Numeric Constants
  MECHANIC_HOURS_PER_MONTH,
  HOURLY_COST_AVG,
  SHOP_RATE,
  MONTHLY_OVERHEAD,
  DAILY_OVERHEAD,
  HIRING_COST,
  FIRING_COST,
  DEFAULT_CELL_WIDTH,
  STICKY_COL_WIDTH,
  START_YEAR,
  TIMELINE_YEARS,
  TOTAL_DAYS,
  ZOOM_LEVELS,
  DEFAULT_CAPACITY_BUFFER_PERCENT,
  DEFAULT_PAYMENT_TERMS,
  PAYMENT_TERMS_OPTIONS,
  MAX_HISTORY_SIZE,
  // Initial Data Arrays
  INITIAL_HOLIDAYS,
  INITIAL_ROLES,
  INITIAL_BASES,
  INITIAL_SHIFTS,
  INITIAL_TEAMS,
  INITIAL_PERSONNEL,
  INITIAL_AIRCRAFT_MODELS,
  INITIAL_HANGARS,
  INITIAL_BACKLOG,
  INITIAL_PROJECT_STAGES,
  INITIAL_EXPENSES,
  INITIAL_CURSORS,
  INITIAL_SCHEDULE,
  // Other exports
  DEFAULT_MARKUP_TIERS,
  GLOSSARY
} from '../constants';

describe('Constants - Numeric Values', () => {
  describe('Financial Constants', () => {
    it('should have positive shop rate', () => {
      expect(SHOP_RATE).toBeGreaterThan(0);
      expect(SHOP_RATE).toBe(175); // Expected value for Part 145 MRO
    });

    it('should have positive hourly cost', () => {
      expect(HOURLY_COST_AVG).toBeGreaterThan(0);
    });

    it('should have positive monthly overhead', () => {
      expect(MONTHLY_OVERHEAD).toBeGreaterThan(0);
    });

    it('should calculate daily overhead correctly', () => {
      expect(DAILY_OVERHEAD).toBeCloseTo(MONTHLY_OVERHEAD / 30, 2);
    });

    it('should have positive hiring and firing costs', () => {
      expect(HIRING_COST).toBeGreaterThan(0);
      expect(FIRING_COST).toBeGreaterThan(0);
    });

    it('should have valid payment terms options', () => {
      expect(PAYMENT_TERMS_OPTIONS).toContain(DEFAULT_PAYMENT_TERMS);
      expect(PAYMENT_TERMS_OPTIONS.every(t => t > 0)).toBe(true);
    });
  });

  describe('Timeline Constants', () => {
    it('should have START_YEAR as 2024', () => {
      expect(START_YEAR).toBe(2024);
    });

    it('should have 4 timeline years', () => {
      expect(TIMELINE_YEARS).toBe(4);
    });

    it('should have correct total days (including leap year)', () => {
      // 2024 is a leap year (366 days), 2025-2027 are not (365 each)
      const expectedDays = 366 + 365 + 365 + 365;
      expect(TOTAL_DAYS).toBe(expectedDays);
      expect(TOTAL_DAYS).toBe(1461);
    });
  });

  describe('UI Constants', () => {
    it('should have positive cell width', () => {
      expect(DEFAULT_CELL_WIDTH).toBeGreaterThan(0);
    });

    it('should have positive sticky column width', () => {
      expect(STICKY_COL_WIDTH).toBeGreaterThan(0);
    });

    it('should have zoom levels in ascending order', () => {
      for (let i = 1; i < ZOOM_LEVELS.length; i++) {
        expect(ZOOM_LEVELS[i]).toBeGreaterThan(ZOOM_LEVELS[i - 1]);
      }
    });

    it('should include default cell width in zoom levels', () => {
      expect(ZOOM_LEVELS).toContain(DEFAULT_CELL_WIDTH);
    });
  });

  describe('Capacity Constants', () => {
    it('should have capacity buffer between 0 and 50', () => {
      expect(DEFAULT_CAPACITY_BUFFER_PERCENT).toBeGreaterThanOrEqual(0);
      expect(DEFAULT_CAPACITY_BUFFER_PERCENT).toBeLessThanOrEqual(50);
    });

    it('should have max history size greater than 0', () => {
      expect(MAX_HISTORY_SIZE).toBeGreaterThan(0);
    });
  });
});

describe('Constants - Initial Data Arrays', () => {
  describe('INITIAL_BASES', () => {
    it('should be non-empty', () => {
      expect(INITIAL_BASES.length).toBeGreaterThan(0);
    });

    it('should have unique IDs', () => {
      const ids = INITIAL_BASES.map(b => b.id);
      const uniqueIds = new Set(ids);
      expect(uniqueIds.size).toBe(ids.length);
    });

    it('should have required fields on each base', () => {
      INITIAL_BASES.forEach(base => {
        expect(base.id).toBeDefined();
        expect(base.name).toBeDefined();
        expect(base.location).toBeDefined();
      });
    });
  });

  describe('INITIAL_SHIFTS', () => {
    it('should be non-empty', () => {
      expect(INITIAL_SHIFTS.length).toBeGreaterThan(0);
    });

    it('should have unique IDs', () => {
      const ids = INITIAL_SHIFTS.map(s => s.id);
      const uniqueIds = new Set(ids);
      expect(uniqueIds.size).toBe(ids.length);
    });

    it('should have valid day arrays (0-6)', () => {
      INITIAL_SHIFTS.forEach(shift => {
        expect(shift.days.length).toBeGreaterThan(0);
        shift.days.forEach(day => {
          expect(day).toBeGreaterThanOrEqual(0);
          expect(day).toBeLessThanOrEqual(6);
        });
      });
    });

    it('should have valid start hours (0-23)', () => {
      INITIAL_SHIFTS.forEach(shift => {
        expect(shift.startHour).toBeGreaterThanOrEqual(0);
        expect(shift.startHour).toBeLessThanOrEqual(23);
      });
    });

    it('should have positive duration', () => {
      INITIAL_SHIFTS.forEach(shift => {
        expect(shift.duration).toBeGreaterThan(0);
      });
    });
  });

  describe('INITIAL_ROLES', () => {
    it('should be non-empty', () => {
      expect(INITIAL_ROLES.length).toBeGreaterThan(0);
    });

    it('should have unique IDs', () => {
      const ids = INITIAL_ROLES.map(r => r.id);
      const uniqueIds = new Set(ids);
      expect(uniqueIds.size).toBe(ids.length);
    });

    it('should have positive efficiency values', () => {
      INITIAL_ROLES.forEach(role => {
        expect(role.baseEfficiency).toBeGreaterThan(0);
      });
    });

    it('should have hourly cost roughly matching rate * burden', () => {
      INITIAL_ROLES.forEach(role => {
        const expectedCost = role.hourlyRate * role.burdenMultiplier;
        // Allow for rounding to whole numbers
        expect(role.hourlyCost).toBeGreaterThanOrEqual(Math.floor(expectedCost));
        expect(role.hourlyCost).toBeLessThanOrEqual(Math.ceil(expectedCost));
      });
    });
  });

  describe('INITIAL_TEAMS', () => {
    it('should be non-empty', () => {
      expect(INITIAL_TEAMS.length).toBeGreaterThan(0);
    });

    it('should have unique IDs', () => {
      const ids = INITIAL_TEAMS.map(t => t.id);
      const uniqueIds = new Set(ids);
      expect(uniqueIds.size).toBe(ids.length);
    });

    it('should reference valid shifts', () => {
      const shiftIds = new Set(INITIAL_SHIFTS.map(s => s.id));
      INITIAL_TEAMS.forEach(team => {
        expect(shiftIds.has(team.shiftId)).toBe(true);
      });
    });
  });

  describe('INITIAL_PERSONNEL', () => {
    it('should be non-empty', () => {
      expect(INITIAL_PERSONNEL.length).toBeGreaterThan(0);
    });

    it('should have unique IDs', () => {
      const ids = INITIAL_PERSONNEL.map(p => p.id);
      const uniqueIds = new Set(ids);
      expect(uniqueIds.size).toBe(ids.length);
    });

    it('should reference valid roles', () => {
      const roleIds = new Set(INITIAL_ROLES.map(r => r.id));
      INITIAL_PERSONNEL.forEach(person => {
        expect(roleIds.has(person.roleId)).toBe(true);
      });
    });

    it('should reference valid teams', () => {
      const teamIds = new Set(INITIAL_TEAMS.map(t => t.id));
      INITIAL_PERSONNEL.forEach(person => {
        if (person.teamId) {
          expect(teamIds.has(person.teamId)).toBe(true);
        }
      });
    });
  });

  describe('INITIAL_HANGARS', () => {
    it('should be non-empty', () => {
      expect(INITIAL_HANGARS.length).toBeGreaterThan(0);
    });

    it('should have unique IDs', () => {
      const ids = INITIAL_HANGARS.map(h => h.id);
      const uniqueIds = new Set(ids);
      expect(uniqueIds.size).toBe(ids.length);
    });

    it('should reference valid bases', () => {
      const baseIds = new Set(INITIAL_BASES.map(b => b.id));
      INITIAL_HANGARS.forEach(hangar => {
        expect(baseIds.has(hangar.baseId)).toBe(true);
      });
    });

    it('should have valid sizes', () => {
      const validSizes = ['Small', 'Medium', 'Large'];
      INITIAL_HANGARS.forEach(hangar => {
        expect(validSizes).toContain(hangar.size);
      });
    });
  });

  describe('INITIAL_AIRCRAFT_MODELS', () => {
    it('should be non-empty', () => {
      expect(INITIAL_AIRCRAFT_MODELS.length).toBeGreaterThan(0);
    });

    it('should have unique IDs', () => {
      const ids = INITIAL_AIRCRAFT_MODELS.map(a => a.id);
      const uniqueIds = new Set(ids);
      expect(uniqueIds.size).toBe(ids.length);
    });

    it('should have required fields', () => {
      INITIAL_AIRCRAFT_MODELS.forEach(model => {
        expect(model.id).toBeDefined();
        expect(model.name).toBeDefined();
        expect(model.manufacturer).toBeDefined();
      });
    });
  });

  describe('INITIAL_HOLIDAYS', () => {
    it('should be non-empty', () => {
      expect(INITIAL_HOLIDAYS.length).toBeGreaterThan(0);
    });

    it('should have unique IDs', () => {
      const ids = INITIAL_HOLIDAYS.map(h => h.id);
      const uniqueIds = new Set(ids);
      expect(uniqueIds.size).toBe(ids.length);
    });

    it('should have valid day indices', () => {
      INITIAL_HOLIDAYS.forEach(holiday => {
        expect(holiday.dayIndex).toBeGreaterThanOrEqual(0);
        expect(holiday.dayIndex).toBeLessThan(TOTAL_DAYS);
      });
    });
  });

  describe('INITIAL_PROJECT_STAGES', () => {
    it('should be non-empty', () => {
      expect(INITIAL_PROJECT_STAGES.length).toBeGreaterThan(0);
    });

    it('should have unique IDs', () => {
      const ids = INITIAL_PROJECT_STAGES.map(s => s.id);
      const uniqueIds = new Set(ids);
      expect(uniqueIds.size).toBe(ids.length);
    });
  });

  describe('INITIAL_EXPENSES', () => {
    it('should be non-empty', () => {
      expect(INITIAL_EXPENSES.length).toBeGreaterThan(0);
    });

    it('should have unique IDs', () => {
      const ids = INITIAL_EXPENSES.map(e => e.id);
      const uniqueIds = new Set(ids);
      expect(uniqueIds.size).toBe(ids.length);
    });

    it('should have positive monthly costs', () => {
      INITIAL_EXPENSES.forEach(expense => {
        expect(expense.monthlyCost).toBeGreaterThanOrEqual(0);
      });
    });

    it('should have valid categories', () => {
      const validCategories = ['Facility', 'Admin', 'IT', 'Marketing', 'Personnel', 'Other'];
      INITIAL_EXPENSES.forEach(expense => {
        expect(validCategories).toContain(expense.category);
      });
    });
  });
});

describe('Constants - Markup Tiers', () => {
  it('should have markup tiers defined', () => {
    expect(DEFAULT_MARKUP_TIERS).toBeDefined();
    expect(DEFAULT_MARKUP_TIERS.length).toBeGreaterThan(0);
  });

  it('should have tiers in ascending order by limit', () => {
    for (let i = 1; i < DEFAULT_MARKUP_TIERS.length; i++) {
      expect(DEFAULT_MARKUP_TIERS[i].maxLimit).toBeGreaterThan(DEFAULT_MARKUP_TIERS[i - 1].maxLimit);
    }
  });

  it('should have markup values greater than 1', () => {
    DEFAULT_MARKUP_TIERS.forEach(tier => {
      expect(tier.markup).toBeGreaterThanOrEqual(1.0);
    });
  });

  it('should have decreasing markups as limits increase', () => {
    for (let i = 1; i < DEFAULT_MARKUP_TIERS.length; i++) {
      expect(DEFAULT_MARKUP_TIERS[i].markup).toBeLessThanOrEqual(DEFAULT_MARKUP_TIERS[i - 1].markup);
    }
  });
});

describe('Constants - Glossary', () => {
  it('should have entries defined', () => {
    expect(Object.keys(GLOSSARY).length).toBeGreaterThan(0);
  });

  it('should have required fields on each entry', () => {
    Object.values(GLOSSARY).forEach(entry => {
      expect(entry.term).toBeDefined();
      expect(entry.definition).toBeDefined();
      expect(entry.category).toBeDefined();
    });
  });

  it('should have valid categories', () => {
    const validCategories = ['aviation', 'personnel', 'financial', 'scheduling'];
    Object.values(GLOSSARY).forEach(entry => {
      expect(validCategories).toContain(entry.category);
    });
  });

  it('should include key aviation terms', () => {
    expect(GLOSSARY.aog).toBeDefined();
    expect(GLOSSARY.mro).toBeDefined();
    expect(GLOSSARY.hangar).toBeDefined();
  });
});
