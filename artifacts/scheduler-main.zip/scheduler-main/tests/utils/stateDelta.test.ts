import { describe, it, expect, beforeEach } from 'vitest';
import {
  calculateDelta,
  applyDelta,
  createForwardDelta,
  isDeltaEmpty,
  estimateDeltaSize
} from '../../utils/stateDelta';
import { createMockGameState, createMockJob, resetIdCounter } from './testHelpers';
import type { GameState } from '../../types';

describe('State Delta Utilities', () => {
  beforeEach(() => {
    resetIdCounter();
  });

  describe('calculateDelta', () => {
    it('should return empty changes when states are identical', () => {
      const state = createMockGameState();
      const delta = calculateDelta(state, state, 'no change');

      expect(delta.changes).toHaveLength(0);
      expect(delta.desc).toBe('no change');
    });

    it('should detect primitive value changes', () => {
      const prevState = createMockGameState({ day: 100 });
      const nextState = { ...prevState, day: 101 };

      const delta = calculateDelta(prevState, nextState, 'advance day');

      expect(delta.changes.length).toBeGreaterThan(0);
      const dayChange = delta.changes.find(c => c.key === 'day');
      expect(dayChange).toBeDefined();
      expect(dayChange?.previousValue).toBe(100);
    });

    it('should detect cash changes', () => {
      const prevState = createMockGameState({ cash: 50000 });
      const nextState = { ...prevState, cash: 55000 };

      const delta = calculateDelta(prevState, nextState, 'income');

      const cashChange = delta.changes.find(c => c.key === 'cash');
      expect(cashChange).toBeDefined();
      expect(cashChange?.previousValue).toBe(50000);
    });

    it('should detect array changes in backlog', () => {
      const prevState = createMockGameState({ backlog: [] });
      const newJob = createMockJob({ id: 'new-job' });
      const nextState = { ...prevState, backlog: [newJob] };

      const delta = calculateDelta(prevState, nextState, 'add job');

      const backlogChange = delta.changes.find(c => c.key === 'backlog');
      expect(backlogChange).toBeDefined();
      expect(backlogChange?.previousValue).toEqual([]);
    });

    it('should detect changes in schedule array', () => {
      const prevState = createMockGameState();
      const hangarId = prevState.hangars[0].id;
      const nextState = {
        ...prevState,
        schedule: [{
          ...createMockJob({ id: 'scheduled-job' }),
          startDate: 100,
          hangarId,
          progress: 0,
          status: 'Scheduled' as const
        }]
      };

      const delta = calculateDelta(prevState, nextState, 'schedule job');

      const scheduleChange = delta.changes.find(c => c.key === 'schedule');
      expect(scheduleChange).toBeDefined();
    });

    it('should store deep copies for array changes', () => {
      const job = createMockJob({ id: 'test-job' });
      const prevState = createMockGameState({ backlog: [job] });
      const nextState = { ...prevState, backlog: [] };

      const delta = calculateDelta(prevState, nextState, 'remove job');
      const backlogChange = delta.changes.find(c => c.key === 'backlog');

      // Modify the original job
      job.description = 'Modified';

      // The stored previous value should not be affected
      expect((backlogChange?.previousValue as typeof prevState.backlog)[0].description).not.toBe('Modified');
    });

    it('should track multiple changes in a single delta', () => {
      const prevState = createMockGameState({ day: 100, cash: 50000 });
      const nextState = { ...prevState, day: 101, cash: 55000 };

      const delta = calculateDelta(prevState, nextState, 'multiple changes');

      expect(delta.changes.length).toBe(2);
      expect(delta.changes.some(c => c.key === 'day')).toBe(true);
      expect(delta.changes.some(c => c.key === 'cash')).toBe(true);
    });
  });

  describe('applyDelta', () => {
    it('should revert a primitive value change', () => {
      const prevState = createMockGameState({ day: 100 });
      const nextState = { ...prevState, day: 101 };

      const delta = calculateDelta(prevState, nextState, 'advance day');
      const restoredState = applyDelta(nextState, delta);

      expect(restoredState.day).toBe(100);
    });

    it('should revert an array change', () => {
      const job = createMockJob({ id: 'test-job' });
      const prevState = createMockGameState({ backlog: [job] });
      const nextState = { ...prevState, backlog: [] };

      const delta = calculateDelta(prevState, nextState, 'remove job');
      const restoredState = applyDelta(nextState, delta);

      expect(restoredState.backlog).toHaveLength(1);
      expect(restoredState.backlog[0].id).toBe('test-job');
    });

    it('should return new state object (immutable)', () => {
      const prevState = createMockGameState({ day: 100 });
      const nextState = { ...prevState, day: 101 };

      const delta = calculateDelta(prevState, nextState, 'advance day');
      const restoredState = applyDelta(nextState, delta);

      expect(restoredState).not.toBe(nextState);
      expect(restoredState).not.toBe(prevState);
    });

    it('should handle multiple changes', () => {
      const prevState = createMockGameState({ day: 100, cash: 50000, shopRate: 125 });
      const nextState = { ...prevState, day: 101, cash: 55000, shopRate: 150 };

      const delta = calculateDelta(prevState, nextState, 'multiple changes');
      const restoredState = applyDelta(nextState, delta);

      expect(restoredState.day).toBe(100);
      expect(restoredState.cash).toBe(50000);
      expect(restoredState.shopRate).toBe(125);
    });
  });

  describe('createForwardDelta', () => {
    it('should create a forward delta for redo', () => {
      const state1 = createMockGameState({ day: 100 });
      const state2 = { ...state1, day: 101 };

      // Delta to undo (go from state2 back to state1)
      const undoDelta = calculateDelta(state1, state2, 'advance day');

      // Create forward delta (to redo - go from state1 back to state2)
      const redoDelta = createForwardDelta(state2, undoDelta);

      // Apply undo
      const afterUndo = applyDelta(state2, undoDelta);
      expect(afterUndo.day).toBe(100);

      // Apply redo
      const afterRedo = applyDelta(afterUndo, redoDelta);
      expect(afterRedo.day).toBe(101);
    });

    it('should preserve description', () => {
      const state1 = createMockGameState({ day: 100 });
      const state2 = { ...state1, day: 101 };

      const undoDelta = calculateDelta(state1, state2, 'advance day');
      const redoDelta = createForwardDelta(state2, undoDelta);

      expect(redoDelta.desc).toBe('advance day');
    });
  });

  describe('isDeltaEmpty', () => {
    it('should return true for empty delta', () => {
      const state = createMockGameState();
      const delta = calculateDelta(state, state, 'no change');

      expect(isDeltaEmpty(delta)).toBe(true);
    });

    it('should return false for delta with changes', () => {
      const prevState = createMockGameState({ day: 100 });
      const nextState = { ...prevState, day: 101 };
      const delta = calculateDelta(prevState, nextState, 'change');

      expect(isDeltaEmpty(delta)).toBe(false);
    });
  });

  describe('estimateDeltaSize', () => {
    it('should return small size for empty delta', () => {
      const state = createMockGameState();
      const delta = calculateDelta(state, state, 'no change');

      const size = estimateDeltaSize(delta);
      expect(size).toBeLessThan(100);
    });

    it('should return larger size for delta with array changes', () => {
      const jobs = Array.from({ length: 10 }, (_, i) => createMockJob({ id: `job-${i}` }));
      const prevState = createMockGameState({ backlog: jobs });
      const nextState = { ...prevState, backlog: [] };

      const delta = calculateDelta(prevState, nextState, 'clear backlog');
      const size = estimateDeltaSize(delta);

      expect(size).toBeGreaterThan(100);
    });

    it('should be smaller than full state serialization', () => {
      const prevState = createMockGameState({ day: 100 });
      const nextState = { ...prevState, day: 101 };

      const delta = calculateDelta(prevState, nextState, 'small change');
      const deltaSize = estimateDeltaSize(delta);
      const fullStateSize = JSON.stringify(prevState).length;

      expect(deltaSize).toBeLessThan(fullStateSize);
    });
  });

  describe('Edge cases', () => {
    it('should handle boolean changes', () => {
      const prevState = createMockGameState({ paused: true });
      const nextState = { ...prevState, paused: false };

      const delta = calculateDelta(prevState, nextState, 'unpause');
      const pausedChange = delta.changes.find(c => c.key === 'paused');

      expect(pausedChange?.previousValue).toBe(true);

      const restored = applyDelta(nextState, delta);
      expect(restored.paused).toBe(true);
    });

    it('should handle efficiency (float) changes', () => {
      const prevState = createMockGameState({ efficiency: 1.0 });
      const nextState = { ...prevState, efficiency: 0.85 };

      const delta = calculateDelta(prevState, nextState, 'reduce efficiency');
      const restored = applyDelta(nextState, delta);

      expect(restored.efficiency).toBe(1.0);
    });

    it('should handle empty arrays correctly', () => {
      const prevState = createMockGameState({ backlog: [] });
      const job = createMockJob();
      const nextState = { ...prevState, backlog: [job] };

      const delta = calculateDelta(prevState, nextState, 'add job');
      const restored = applyDelta(nextState, delta);

      expect(restored.backlog).toEqual([]);
    });
  });
});
