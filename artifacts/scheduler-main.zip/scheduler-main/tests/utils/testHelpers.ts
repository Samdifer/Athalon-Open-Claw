import type {
  GameState, Job, ScheduledJob, Hangar, Personnel, Team, Role, Shift, Base,
  AircraftModel, UIState, ProgressCursor, Holiday, ExpenseItem
} from '../../types';

/**
 * Factory functions for creating test data
 */

let idCounter = 0;
const generateId = () => `test-${++idCounter}`;

// Reset counter between test runs
export const resetIdCounter = () => { idCounter = 0; };

export const createMockBase = (overrides: Partial<Base> = {}): Base => ({
  id: generateId(),
  name: 'Test Base',
  location: 'Test Location',
  ...overrides
});

export const createMockShift = (overrides: Partial<Shift> = {}): Shift => ({
  id: generateId(),
  name: 'Day Shift',
  days: [1, 2, 3, 4, 5], // Mon-Fri
  startHour: 8,
  duration: 8,
  breakCount: 1,
  breakDuration: 30,
  meetingDuration: 15,
  ...overrides
});

export const createMockRole = (overrides: Partial<Role> = {}): Role => ({
  id: generateId(),
  name: 'Technician',
  baseEfficiency: 1.0,
  hourlyRate: 45,
  burdenMultiplier: 1.35,
  hourlyCost: 60.75,
  ...overrides
});

export const createMockTeam = (shiftId: string, overrides: Partial<Team> = {}): Team => ({
  id: generateId(),
  name: 'Alpha Team',
  color: 'blue-500',
  shiftId,
  ...overrides
});

export const createMockPersonnel = (roleId: string, teamId: string | null, overrides: Partial<Personnel> = {}): Personnel => ({
  id: generateId(),
  name: 'John Doe',
  roleId,
  teamId,
  ...overrides
});

export const createMockHangar = (baseId: string, overrides: Partial<Hangar> = {}): Hangar => ({
  id: generateId(),
  name: 'Hangar A',
  size: 'Medium',
  supportedTypes: [],
  baseId,
  ...overrides
});

export const createMockAircraftModel = (overrides: Partial<AircraftModel> = {}): AircraftModel => ({
  id: generateId(),
  name: 'Cessna 172',
  manufacturer: 'Cessna',
  ...overrides
});

export const createMockJob = (overrides: Partial<Job> = {}): Job => ({
  id: generateId(),
  customer: 'N12345',
  aircraftType: 'cessna-172',
  description: 'Annual Inspection',
  estimatedHours: 40,
  revenue: 5000,
  color: 'blue-500',
  deadlineDays: 5,
  requiredHangarSize: 'Medium',
  isAOG: false,
  ...overrides
});

export const createMockScheduledJob = (hangarId: string, overrides: Partial<ScheduledJob> = {}): ScheduledJob => ({
  ...createMockJob(),
  startDate: 100,
  hangarId,
  progress: 0,
  status: 'Scheduled',
  ...overrides
});

export const createMockHoliday = (overrides: Partial<Holiday> = {}): Holiday => ({
  id: generateId(),
  name: 'Test Holiday',
  date: '2024-12-25',
  dayIndex: 359,
  enabled: true,
  ...overrides
});

export const createMockExpenseItem = (overrides: Partial<ExpenseItem> = {}): ExpenseItem => ({
  id: generateId(),
  category: 'Facility',
  name: 'Rent',
  monthlyCost: 5000,
  ...overrides
});

export const createMockCursor = (overrides: Partial<ProgressCursor> = {}): ProgressCursor => ({
  id: generateId(),
  label: 'Deadline',
  dayOffset: 30,
  color: 'bg-red-500',
  enabled: true,
  ...overrides
});

export const createMockUIState = (overrides: Partial<UIState> = {}): UIState => ({
  backlogOpen: false,
  analyticsOpen: false,
  pnlOpen: false,
  capacityOpen: false,
  rosterOpen: false,
  cellWidth: 40,
  layoutDims: {
    backlogWidth: 288,
    rosterWidth: 320,
    capacityHeight: 176,
    pnlHeight: 208,
    analyticsHeight: 192
  },
  popouts: {
    analytics: false,
    backlog: false,
    pnl: false,
    cashflow: false,
    capacity: false,
    roster: false
  },
  selectedBaseId: 'ALL',
  tutorialActive: false,
  tutorialStep: 0,
  onboardingCompleted: false,
  completedSections: [],
  ...overrides
});

/**
 * Create a minimal valid GameState for testing
 */
export const createMockGameState = (overrides: Partial<GameState> = {}): GameState => {
  const base = createMockBase();
  const shift = createMockShift();
  const role = createMockRole();
  const team = createMockTeam(shift.id, { baseId: base.id });
  const hangar = createMockHangar(base.id);
  const aircraftModel = createMockAircraftModel();

  return {
    day: 100,
    cash: 50000,
    efficiency: 1.0,
    paused: true,
    speed: 1000,
    hangars: [hangar],
    aircraftModels: [aircraftModel],
    customAircraftPackages: [],
    shopRate: 125,
    standardServices: [],
    projectStages: [],
    partMarkups: [{ maxLimit: 500, markup: 1.30 }, { maxLimit: 2500, markup: 1.15 }, { maxLimit: Infinity, markup: 1.05 }],
    serviceMarkups: [{ maxLimit: 500, markup: 1.30 }, { maxLimit: 2500, markup: 1.15 }, { maxLimit: Infinity, markup: 1.05 }],
    paymentTerms: 30,
    backlog: [],
    schedule: [],
    graveyard: [],
    bases: [base],
    personnel: [],
    teams: [team],
    shifts: [shift],
    roles: [role],
    holidays: [],
    overheadDaily: 4500,
    capacityBufferPercent: 15,
    expenseItems: [],
    capexItems: [],
    cursors: [],
    events: [],
    activeEvent: null,
    notifications: [],
    financialHistory: [],
    uiState: createMockUIState(),
    ...overrides
  };
};

/**
 * Create a GameState with personnel for capacity testing
 */
export const createGameStateWithPersonnel = (personnelCount: number = 5): GameState => {
  const base = createMockBase({ id: 'base-1' });
  const shift = createMockShift({ id: 'shift-1' });
  const role = createMockRole({ id: 'role-1' });
  const team = createMockTeam(shift.id, { id: 'team-1', baseId: base.id });
  const hangar = createMockHangar(base.id, { id: 'hangar-1' });

  const personnel: Personnel[] = [];
  for (let i = 0; i < personnelCount; i++) {
    personnel.push(createMockPersonnel(role.id, team.id, {
      id: `personnel-${i}`,
      name: `Tech ${i + 1}`,
      baseId: base.id
    }));
  }

  return createMockGameState({
    bases: [base],
    shifts: [shift],
    roles: [role],
    teams: [team],
    hangars: [hangar],
    personnel
  });
};

/**
 * Create a GameState with scheduled jobs for testing
 */
export const createGameStateWithJobs = (jobCount: number = 3): GameState => {
  const state = createGameStateWithPersonnel();
  const hangarId = state.hangars[0].id;

  const schedule: ScheduledJob[] = [];
  for (let i = 0; i < jobCount; i++) {
    schedule.push(createMockScheduledJob(hangarId, {
      id: `job-${i}`,
      startDate: 100 + (i * 5),
      estimatedHours: 40,
      deadlineDays: 5
    }));
  }

  return { ...state, schedule };
};
