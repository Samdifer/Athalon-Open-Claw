
import React, { useState, useEffect, useRef, useCallback, Suspense, lazy, startTransition } from 'react';
import {
  Calendar,
  Users, Settings, DollarSign, Save, MapPin, Database, Loader2, Monitor, CircleHelp, Minimize2, Edit, CheckCircle, ArrowRight, LocateFixed, ZoomIn, ZoomOut, LogOut, User as UserIcon, Sparkles, Undo2, Redo2,
  SlidersHorizontal, Ban, Key, ChevronDown, Check, Maximize2, Layout, BarChart2, Minimize, Table2, Shield, Gauge, Book
} from 'lucide-react';
import {
  GameState, ScheduledJob, MONTH_NAMES, Job, Hangar, AircraftModel, GameNotification, Personnel, Team, Role, StandardService, ProjectStage, Shift, Holiday, Base, UIState, ProgressCursor
} from './types';
import {
  INITIAL_BACKLOG, INITIAL_HANGARS, INITIAL_AIRCRAFT_MODELS, INITIAL_SCHEDULE,
  DAILY_OVERHEAD, HOURLY_COST_AVG,
  INITIAL_ROLES, INITIAL_TEAMS, INITIAL_PERSONNEL, STANDARD_SERVICES, INITIAL_PROJECT_STAGES, INITIAL_SHIFTS, INITIAL_EXPENSES, INITIAL_HOLIDAYS,
  DEFAULT_CELL_WIDTH, START_YEAR, TOTAL_DAYS, INITIAL_BASES, STICKY_COL_WIDTH, ZOOM_LEVELS, DEFAULT_MARKUP_TIERS, INITIAL_CURSORS,
  DEFAULT_CAPACITY_BUFFER_PERCENT, DEFAULT_PAYMENT_TERMS, MAX_HISTORY_SIZE
} from './constants';
import GanttBoard from './components/GanttBoard';
import AnalyticsPanel from './components/AnalyticsPanel';
import BacklogPanel from './components/BacklogPanel';
import DailyFinancialTracker from './components/DailyFinancialTracker';
import CapacityForecaster from './components/CapacityForecaster';
import DraggableWindow from './components/DraggableWindow';
import RosterPanel from './components/RosterPanel';
import { StateDelta, calculateDelta, applyDelta, createForwardDelta, isDeltaEmpty } from './utils/stateDelta';
import OnboardingTour, { TOUR_SECTIONS, TOUR_STEPS, QUICK_TOUR_STEPS, getSectionIndex, getCurrentSection, TourType } from './components/OnboardingTour';
import WelcomeSplash from './components/WelcomeSplash';
import GraveyardPanel from './components/GraveyardPanel';
import ProjectListPanel from './components/ProjectListPanel';
import { CapacityWarningData } from './components/CapacityWarningModal';
import { Tooltip } from './components/ui';
import { useCapacityData } from './hooks';
import { initDB, saveGame, loadGame } from './persistence';
import { loadGameState, saveGameState, initializeOrganizationData } from './lib/gameDataService';

// ============================================================================
// PERFORMANCE: Lazy-loaded components for modals and heavy panels
// These components only load when the user actually opens them
// ============================================================================
const PersonnelManager = lazy(() => import('./components/PersonnelManager'));
const ConfigurationPanel = lazy(() => import('./components/ConfigurationPanel'));
const FinancialPanel = lazy(() => import('./components/FinancialPanel'));
const QuoteBuilder = lazy(() => import('./components/QuoteBuilder'));
const JobDetailsModal = lazy(() => import('./components/JobDetailsModal'));
const UnifiedCapacityDashboard = lazy(() => import('./components/UnifiedCapacityDashboard'));
const CashflowForecastExpanded = lazy(() => import('./components/CashflowForecastExpanded'));
const FullScreenDashboard = lazy(() => import('./components/FullScreenDashboard'));
const SetupDefaultsPanel = lazy(() => import('./components/SetupDefaultsPanel'));
const MagicSchedulerWizard = lazy(() => import('./components/MagicSchedulerWizard'));
const GlossaryModal = lazy(() => import('./components/GlossaryModal'));
const CapacityWarningModal = lazy(() => import('./components/CapacityWarningModal'));

// Modal loading fallback component
const ModalLoader: React.FC<{ message?: string }> = ({ message = 'Loading...' }) => (
  <div className="fixed inset-0 z-[100] flex items-center justify-center bg-[#08090a]/80 backdrop-blur-sm">
    <div className="bg-[#0d0e10] border border-white/[0.08] rounded-xl p-6 flex flex-col items-center gap-3">
      <Loader2 className="w-8 h-8 text-white/70 animate-spin" />
      <span className="text-sm text-[#9ca3af]">{message}</span>
    </div>
  </div>
);

// Auth & Routing
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { TimelineSyncProvider, useTimelineSync } from './contexts/TimelineSyncContext';
import { RouterProvider } from 'react-router-dom';
import { router, PageLoader } from './router';
import UserManagement from './components/admin/UserManagement';
import ChangePasswordModal from './components/auth/ChangePasswordModal';

// Platform Admin
import { PlatformDashboard, ImpersonationBanner } from './components/platform-admin';

export const DOLLAR_SIGN = "$";
const LEGACY_STORAGE_KEY = 'AEROMANAGER_DATA_V1';
const CURRENT_PROFILE_ID = 'default_company_profile';

const createNote = (message: string): GameNotification => ({
    id: Math.random().toString(36).substring(2, 11),
    message,
    timestamp: Date.now()
});

const DEFAULT_LAYOUT_DIMS = {
  backlogWidth: 288,
  rosterWidth: 320,
  capacityHeight: 176,
  pnlHeight: 208,
  analyticsHeight: 192
};

// Helper to get today's index relative to simulation start
const getTodayIndex = () => {
    const start = new Date(START_YEAR, 0, 1).getTime();
    const now = new Date().getTime();
    return Math.max(0, Math.floor((now - start) / (1000 * 60 * 60 * 24)));
};

// Default Initial State Factory
const getInitialState = (): GameState => ({
    day: 701, // Dec 2, 2025 - start of 3-month outlook
    cash: 50000,
    efficiency: 1.0,
    paused: true,
    speed: 1000,
    hangars: [...INITIAL_HANGARS],
    aircraftModels: [...INITIAL_AIRCRAFT_MODELS],
    customAircraftPackages: [],
    shopRate: 175,
    backlog: [...INITIAL_BACKLOG],
    schedule: [...INITIAL_SCHEDULE],
    graveyard: [], // Initialize empty graveyard
    personnel: [...INITIAL_PERSONNEL],
    teams: [...INITIAL_TEAMS],
    shifts: [...INITIAL_SHIFTS],
    roles: [...INITIAL_ROLES],
    standardServices: [...STANDARD_SERVICES],
    projectStages: [...INITIAL_PROJECT_STAGES],
    partMarkups: [...DEFAULT_MARKUP_TIERS],
    serviceMarkups: [...DEFAULT_MARKUP_TIERS],
    paymentTerms: DEFAULT_PAYMENT_TERMS,
    overheadDaily: DAILY_OVERHEAD,
    capacityBufferPercent: DEFAULT_CAPACITY_BUFFER_PERCENT,
    expenseItems: [...INITIAL_EXPENSES],
    capexItems: [],
    holidays: [...INITIAL_HOLIDAYS],
    bases: [...INITIAL_BASES],
    cursors: [...INITIAL_CURSORS],
    events: [],
    activeEvent: null,
    notifications: [createNote("Welcome to AeroManager! Drag a project to start.")],
    financialHistory: [],
    uiState: {
        backlogOpen: false,
        analyticsOpen: false,
        pnlOpen: false,
        capacityOpen: false,
        rosterOpen: false,
        cellWidth: DEFAULT_CELL_WIDTH,
        layoutDims: { ...DEFAULT_LAYOUT_DIMS },
        popouts: {
            analytics: false,
            backlog: false,
            pnl: false,
            cashflow: false,
            capacity: false,
            roster: false,
            graveyard: false
        },
        scenarioStart: getTodayIndex(), 
        scenarioEnd: getTodayIndex() + 90,
        selectedBaseId: 'ALL',
        tutorialActive: false,
        tutorialStep: 0,
        onboardingCompleted: false,
        onboardingCompletedAt: undefined,
        completedSections: []
    }
});

// PERFORMANCE: Use delta-based history instead of full state snapshots
// This reduces memory from ~25-100MB to ~1-5MB for 50 history entries
type HistoryEntry = StateDelta;

interface DashboardProps {
  onShowPlatformAdmin?: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ onShowPlatformAdmin }) => {
  const { user, logout, isPlatformAdmin } = useAuth();
  
  // PERFORMANCE FIX: Use lazy initialization for gameState to prevent recalculating initial state on every render
  const [gameState, setGameState] = useState<GameState>(getInitialState);
  
  const [isLoading, setIsLoading] = useState(true);
  const [dbReady, setDbReady] = useState(false);

  // Undo/Redo Stacks
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [future, setFuture] = useState<HistoryEntry[]>([]);
  const [lastAction, setLastAction] = useState<string | null>(null);

  const [view, setView] = useState<'board' | 'personnel' | 'config' | 'financials' | 'quote' | 'fullscreen' | 'setup' | 'admin'>('board');
  const [selectedJob, setSelectedJob] = useState<Job | ScheduledJob | null>(null);
  
  // Scheduling Edit Controls
  const [scheduleEditMode, setScheduleEditMode] = useState(false);
  const [editTool, setEditTool] = useState<'distribute' | 'block'>('distribute');

  // View Options State
  const [viewDropdownOpen, setViewDropdownOpen] = useState(false);
  const [viewCapacityMode, setViewCapacityMode] = useState(false);
  const [simplifiedViewMode, setSimplifiedViewMode] = useState(false);

  const [isSaving, setIsSaving] = useState(false);
  
  // Track dragged job for hover compatibility visual
  const [draggedJob, setDraggedJob] = useState<Job | ScheduledJob | null>(null);
  
  // Track job being edited in Quote Builder
  const [editingQuoteJob, setEditingQuoteJob] = useState<Job | ScheduledJob | null>(null);

  // Quote Success Popup State
  const [quoteSuccess, setQuoteSuccess] = useState<{ active: boolean, job: Job | null }>({ active: false, job: null });
  const [highlightedJobId, setHighlightedJobId] = useState<string | null>(null);

  const [visibleDayStart, setVisibleDayStart] = useState(gameState.day);
  
  // Initialize with Date.now() to force initial scroll to today on mount
  const [scrollToTodayTrigger, setScrollToTodayTrigger] = useState<number>(() => Date.now());

  // Layout Resizing State
  const [resizing, setResizing] = useState<{ target: string, startX: number, startY: number, startDims: typeof DEFAULT_LAYOUT_DIMS } | null>(null);

  // State to control if financial panel opens in edit mode
  const [financialsInitialEditMode, setFinancialsInitialEditMode] = useState(false);

  // State to drive tab selection during tutorial
  const [tutorialTab, setTutorialTab] = useState<string | null>(null);

  // Welcome Splash State - Defaults to true on mount (first login)
  const [showWelcome, setShowWelcome] = useState(true);

  // Tour Type - Quick (8 steps) or Full (35+ steps)
  const [tourType, setTourType] = useState<TourType>('full');

  // Password Change Modal State
  const [showPasswordModal, setShowPasswordModal] = useState(false);

  // Glossary Modal State
  const [showGlossary, setShowGlossary] = useState(false);

  // Capacity Warning Modal State
  const [capacityWarning, setCapacityWarning] = useState<{
    isOpen: boolean;
    data: CapacityWarningData | null;
    nextAvailableDay: number | null;
  }>({
    isOpen: false,
    data: null,
    nextAvailableDay: null
  });

  // --- Magic Scheduler State ---
  const [magicState, setMagicState] = useState<{
      step: 'inactive' | 'intro' | 'selecting' | 'prioritizing' | 'results';
      selectedIds: string[];
      // Priority is determined by index in selectedIds array (0 = Priority 1)
      results: { jobId: string, oldEnd: number, newEnd: number, daysAdded: number }[];
  }>({
      step: 'inactive',
      selectedIds: [],
      results: []
  });

  // --- Scroll Sync Refs ---
  const ganttScrollRef = useRef<HTMLDivElement>(null);
  const trackerScrollRef = useRef<HTMLDivElement>(null);
  const capacityScrollRef = useRef<HTMLDivElement>(null);

  // --- Capacity Data Hook ---
  const { dailyCapacities, dailyLoads, getDayData } = useCapacityData(gameState, {
    baseId: gameState.uiState.selectedBaseId
  });

  // Helper to update UI State inside GameState
  const updateUI = (updates: Partial<UIState>) => {
      setGameState(prev => ({
          ...prev,
          uiState: { ...prev.uiState, ...updates }
      }));
  };

  const togglePopout = (key: keyof UIState['popouts'], value: boolean) => {
      setGameState(prev => ({
          ...prev,
          uiState: {
              ...prev.uiState,
              popouts: { ...prev.uiState.popouts, [key]: value }
          }
      }));
  };

  // --- Zoom Handling ---
  const handleZoom = useCallback((newWidth: number) => {
      const container = ganttScrollRef.current;
      if (container) {
          const currentScrollLeft = container.scrollLeft;
          const visibleWidth = container.clientWidth;

          // Calculate current center day
          const centerPixel = currentScrollLeft + (visibleWidth / 2);
          const currentDayIndex = (centerPixel - STICKY_COL_WIDTH) / gameState.uiState.cellWidth;

          // Update State
          updateUI({ cellWidth: newWidth });

          // Adjust scroll to maintain center day
          setTimeout(() => {
              if (ganttScrollRef.current) {
                  const newCenterPixel = (currentDayIndex * newWidth) + STICKY_COL_WIDTH;
                  const newScrollLeft = newCenterPixel - (visibleWidth / 2);
                  ganttScrollRef.current.scrollTo({ left: Math.max(0, newScrollLeft), behavior: 'auto' });
              }
          }, 0);
      } else {
          updateUI({ cellWidth: newWidth });
      }
  }, [gameState.uiState.cellWidth]);

  const handleZoomIn = useCallback(() => {
      const currentIndex = ZOOM_LEVELS.indexOf(gameState.uiState.cellWidth);
      if (currentIndex < ZOOM_LEVELS.length - 1) {
          handleZoom(ZOOM_LEVELS[currentIndex + 1]);
      }
  }, [gameState.uiState.cellWidth, handleZoom]);

  const handleZoomOut = useCallback(() => {
      const currentIndex = ZOOM_LEVELS.indexOf(gameState.uiState.cellWidth);
      if (currentIndex > 0) {
          handleZoom(ZOOM_LEVELS[currentIndex - 1]);
      }
  }, [gameState.uiState.cellWidth, handleZoom]);

  // --- View Mode Toggles ---
  const toggleViewCapacity = () => {
      if (!viewCapacityMode) {
          setViewCapacityMode(true);
          setSimplifiedViewMode(false);
      } else {
          setViewCapacityMode(false);
      }
  };

  const toggleSimplified = () => {
      if (!simplifiedViewMode) {
          setSimplifiedViewMode(true);
          setViewCapacityMode(false);
      } else {
          setSimplifiedViewMode(false);
      }
  };

  // --- Initialization Effect (DB Load) ---
  useEffect(() => {
      const initialize = async () => {
          console.log("[Dashboard Init] Starting initialization...", {
              isPlatformAdmin,
              userOrgId: user?.organizationId,
              userId: user?.id
          });

          try {
              // Platform admins viewing as themselves (not impersonating) may not have an org
              // In this case, just show default state immediately
              if (isPlatformAdmin && !user?.organizationId) {
                  console.log("[Dashboard Init] Platform admin without organization - using default state");
                  const defaultState = getInitialState();
                  setGameState(defaultState);
                  setDbReady(true);
                  setIsLoading(false);
                  return;
              }

              // Try to load from Supabase first (cloud storage)
              console.log("[Dashboard Init] Loading game state from Supabase...");
              let data: GameState | null = await loadGameState();
              console.log("[Dashboard Init] loadGameState result:", data ? "data loaded" : "null");

              // If no cloud data, try legacy local storage (IndexedDB/localStorage)
              if (!data) {
                  console.log("No cloud data found, checking local storage...");
                  await initDB();

                  let localData: any = await loadGame(CURRENT_PROFILE_ID);

                  // Migration from Legacy LocalStorage if IndexedDB is empty
                  if (!localData) {
                      const legacy = localStorage.getItem(LEGACY_STORAGE_KEY);
                      if (legacy) {
                          try {
                              console.log("Migrating legacy data...");
                              localData = JSON.parse(legacy);
                          } catch (e) {
                              console.warn("Failed to parse legacy data");
                          }
                      }
                  }

                  // If we found local data, migrate it to Supabase
                  if (localData) {
                      console.log("Found local data, migrating to cloud...");
                      data = localData as GameState;

                      // Save to Supabase for future use
                      const migrationSuccess = await initializeOrganizationData(data);
                      if (!migrationSuccess) {
                          console.error("Failed to migrate data to cloud - data may not persist");
                          setGameState(prev => ({
                              ...prev,
                              notifications: [
                                  ...prev.notifications,
                                  createNote("⚠️ Cloud sync failed - data may not persist across sessions")
                              ]
                          }));
                      }
                  } else {
                      // No data anywhere - initialize with defaults
                      console.log("No existing data found, initializing with defaults...");
                      const defaultState = getInitialState();
                      const initSuccess = await initializeOrganizationData(defaultState);
                      if (initSuccess) {
                          console.log("Organization initialized successfully");
                          data = defaultState;
                      } else {
                          console.error("Failed to initialize organization - using local-only mode");
                          data = defaultState;
                          setGameState(prev => ({
                              ...prev,
                              notifications: [
                                  ...prev.notifications,
                                  createNote("⚠️ Cloud storage unavailable - running in local-only mode")
                              ]
                          }));
                      }
                  }
              } else {
                  console.log("Loaded game state from cloud successfully");
              }

              setDbReady(true);

              if (data) {
                   // Migrate old saves that might lack baseId in hangars
                  const migratedHangars = (data.hangars || []).map((h: Hangar) => ({
                    ...h,
                    baseId: h.baseId || (INITIAL_BASES[0]?.id)
                  }));

                  // Ensure UI State exists
                  const mergedUIState: UIState = {
                      ...getInitialState().uiState,
                      ...(data.uiState || {})
                  };

                  setGameState({
                      ...data,
                      hangars: migratedHangars,
                      graveyard: data.graveyard || [], // Ensure graveyard exists
                      partMarkups: data.partMarkups || [...DEFAULT_MARKUP_TIERS],
                      serviceMarkups: data.serviceMarkups || [...DEFAULT_MARKUP_TIERS],
                      bases: data.bases || INITIAL_BASES,
                      cursors: data.cursors || [...INITIAL_CURSORS],
                      uiState: mergedUIState,
                      day: getTodayIndex()
                  });

                  // Skip welcome splash if onboarding was previously completed OR user has existing data
                  const hasExistingData = (data.backlog?.length > 0) || (data.schedule?.length > 0);
                  if (mergedUIState.onboardingCompleted || hasExistingData) {
                      setShowWelcome(false);
                  }
              }
          } catch (e) {
              console.error("[Dashboard Init] Failed to initialize:", e);
              // Fall back to defaults on error
              const fallbackState = getInitialState();
              setGameState({
                  ...fallbackState,
                  notifications: [
                      ...fallbackState.notifications,
                      createNote("❌ Failed to load saved data - starting fresh")
                  ]
              });
          } finally {
              console.log("[Dashboard Init] Initialization complete, setting isLoading=false");
              setDbReady(true);
              setIsLoading(false);
          }
      };
      initialize();
  }, []);

  // --- Global Keyboard Shortcuts Effect ---
  useEffect(() => {
      const handleKeyDown = (e: KeyboardEvent) => {
          // Escape to exit edit mode
          if (e.key === 'Escape' && scheduleEditMode) {
              e.preventDefault();
              setScheduleEditMode(false);
              return;
          }

          // Cmd+? or Ctrl+? to open glossary (? is Shift+/)
          if ((e.metaKey || e.ctrlKey) && e.shiftKey && e.key === '/') {
              e.preventDefault();
              setShowGlossary(prev => !prev);
          }
      };

      window.addEventListener('keydown', handleKeyDown);
      return () => window.removeEventListener('keydown', handleKeyDown);
  }, [scheduleEditMode]);

  // --- Auto-Save Effect (saves to Supabase cloud) ---
  useEffect(() => {
      if (!dbReady || isLoading) return;

      const saveTimer = setTimeout(async () => {
          setIsSaving(true);
          try {
              // Save to Supabase (cloud)
              const success = await saveGameState(gameState);
              if (!success) {
                  console.warn("Cloud save failed, falling back to local storage");
                  // Fallback to local storage
                  try {
                      await saveGame(CURRENT_PROFILE_ID, gameState);
                      console.log("Saved to local storage as fallback");
                  } catch (localError) {
                      console.error("Local save also failed:", localError);
                      // Notify user of save failure
                      setGameState(prev => ({
                          ...prev,
                          notifications: [
                              ...prev.notifications.slice(-4), // Keep last 4 notifications
                              createNote("⚠️ Save failed - changes may not persist")
                          ]
                      }));
                  }
              }
          } catch (e) {
              console.error("Save failed:", e);
              // Try local fallback
              try {
                  await saveGame(CURRENT_PROFILE_ID, gameState);
                  console.log("Saved to local storage as fallback after error");
              } catch (localError) {
                  console.error("Local save also failed:", localError);
                  // Notify user of save failure
                  setGameState(prev => ({
                      ...prev,
                      notifications: [
                          ...prev.notifications.slice(-4), // Keep last 4 notifications
                          createNote("⚠️ Save failed - changes may not persist")
                      ]
                  }));
              }
          } finally {
              setIsSaving(false);
          }
      }, 2000); // Debounce 2s

      return () => clearTimeout(saveTimer);
  }, [gameState, dbReady, isLoading]);

  // --- Resizing Logic ---
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!resizing) return;
      e.preventDefault();
      
      const { target, startX, startY, startDims } = resizing;
      let newDims = { ...startDims };

      if (target === 'backlog') {
          const delta = e.clientX - startX;
          newDims.backlogWidth = Math.max(200, Math.min(600, startDims.backlogWidth + delta));
      } else if (target === 'roster') {
          const delta = startX - e.clientX; // Dragging left increases width
          newDims.rosterWidth = Math.max(200, Math.min(600, startDims.rosterWidth + delta));
      } else if (target === 'pnl') {
          const delta = startY - e.clientY; // Dragging up increases height
          newDims.pnlHeight = Math.max(100, Math.min(600, startDims.pnlHeight + delta));
      } else if (target === 'capacity') {
          const delta = startY - e.clientY;
          newDims.capacityHeight = Math.max(100, Math.min(600, startDims.capacityHeight + delta));
      } else if (target === 'analytics') {
          const delta = startY - e.clientY;
          newDims.analyticsHeight = Math.max(100, Math.min(600, startDims.analyticsHeight + delta));
      }

      updateUI({ layoutDims: newDims });
    };

    const handleMouseUp = () => {
      setResizing(null);
    };

    if (resizing) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
    }

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [resizing]);

  const startResize = (e: React.MouseEvent, target: string) => {
      e.preventDefault();
      e.stopPropagation();
      setResizing({
          target,
          startX: e.clientX,
          startY: e.clientY,
          startDims: gameState.uiState.layoutDims
      });
  };

  // --- Undo/Redo Logic (Delta-Based for Memory Efficiency) ---
  // PERFORMANCE: Instead of storing full state snapshots (~500KB-2MB each),
  // we store only the changes (deltas) between states (~1-50KB each).
  // This reduces memory usage by ~95% (25-100MB → 1-5MB for 50 history entries)

  const pushHistory = (newState: GameState, desc: string = "Update") => {
      // Calculate the delta between current and new state
      const delta = calculateDelta(gameState, newState, desc);

      // Only push to history if there are actual changes
      if (!isDeltaEmpty(delta)) {
        setHistory(prev => {
          const newHistory = [...prev, delta];
          // Cap history to prevent memory bloat
          if (newHistory.length > MAX_HISTORY_SIZE) {
            return newHistory.slice(-MAX_HISTORY_SIZE);
          }
          return newHistory;
        });
        setFuture([]); // Clear redo stack on new action
      }

      setGameState(newState);
      setLastAction(desc);
  };

  const handleUndo = useCallback(() => {
      if (history.length === 0) return;
      const delta = history[history.length - 1];
      const newHistory = history.slice(0, -1);

      // Create forward delta before applying reverse delta
      const forwardDelta = createForwardDelta(gameState, delta);

      // Apply the delta to revert to previous state
      const previousState = applyDelta(gameState, delta);

      setFuture(prev => [forwardDelta, ...prev]);
      setHistory(newHistory);
      setGameState(previousState);
      setLastAction(`Undone: ${delta.desc}`);
  }, [history, gameState]);

  const handleRedo = useCallback(() => {
      if (future.length === 0) return;
      const delta = future[0];
      const newFuture = future.slice(1);

      // Create reverse delta before applying forward delta
      const reverseDelta = createForwardDelta(gameState, delta);

      // Apply the forward delta to restore the state
      const nextState = applyDelta(gameState, delta);

      setHistory(prev => {
        const newHistory = [...prev, reverseDelta];
        if (newHistory.length > MAX_HISTORY_SIZE) {
          return newHistory.slice(-MAX_HISTORY_SIZE);
        }
        return newHistory;
      });
      setFuture(newFuture);
      setGameState(nextState);
      setLastAction(`Redone: ${delta.desc}`);
  }, [future, gameState]);

  // --- Job Redistribution Logic ---
  const handleJobRedistribution = useCallback((jobId: string, targetDayOffset: number, newHours: number) => {
      setGameState(prev => {
          const newSchedule = prev.schedule.map(j => {
              if (j.id !== jobId) return j;

              const totalHours = j.estimatedHours;
              const activeDays: number[] = [];
              const currentWeights = [];

              // 1. Identify Active Days
              for (let i = 0; i < j.deadlineDays; i++) {
                  if (!j.nonWorkDays?.includes(i)) {
                      activeDays.push(i);
                      // Use current dailyEffort or default to 1 if undefined (simplification for initial loading)
                      // BUT here we want to treat values as HOURS if we are in distribute mode.
                      // If undefined, we assume even distribution initially: total / activeCount
                      const currentVal = (j.dailyEffort && j.dailyEffort[i] !== undefined)
                          ? j.dailyEffort[i]
                          : (totalHours / (j.deadlineDays - (j.nonWorkDays?.length || 0)));
                      currentWeights.push(currentVal);
                  }
              }

              // 2. Calculate Difference caused by the edit
              // Find current hours for the target day
              const currentTargetVal = (j.dailyEffort && j.dailyEffort[targetDayOffset] !== undefined)
                  ? j.dailyEffort[targetDayOffset]
                  : (totalHours / activeDays.length); // Fallback if not set yet

              const diff = currentTargetVal - newHours; // Positive if reducing, Negative if increasing

              // 3. Distribute Difference to OTHER active days
              const otherActiveDays = activeDays.filter(d => d !== targetDayOffset);

              // If no other days, we can't redistribute (or we just change total estimate? Prompt implies constant total).
              // If no other days, we just clamp the change or update total. Let's assume strictly constant total for now.
              if (otherActiveDays.length === 0) {
                  // Can't redistribute.
                  return j;
              }

              const amountPerDay = diff / otherActiveDays.length;

              const newDailyEffort: Record<number, number> = { ...(j.dailyEffort || {}) };

              // Initialize existing values if missing in map
              activeDays.forEach(d => {
                  if (newDailyEffort[d] === undefined) {
                      newDailyEffort[d] = totalHours / activeDays.length;
                  }
              });

              // Apply changes
              newDailyEffort[targetDayOffset] = newHours;
              otherActiveDays.forEach(d => {
                  const currentVal = newDailyEffort[d] || 0;
                  newDailyEffort[d] = Math.max(0, currentVal + amountPerDay);
              });

              // 4. Auto-Block / Unblock based on Hours
              // If set to ~0, treat as block. If raised from 0, treat as unblock.
              let newNonWorkDays = [...(j.nonWorkDays || [])];

              if (newHours <= 0.05) { // Threshold for "Zero" to allow for small float errors
                  if (!newNonWorkDays.includes(targetDayOffset)) {
                      newNonWorkDays.push(targetDayOffset);
                      newNonWorkDays.sort((a,b) => a-b);
                  }
              } else {
                  newNonWorkDays = newNonWorkDays.filter(d => d !== targetDayOffset);
              }

              return { ...j, dailyEffort: newDailyEffort, nonWorkDays: newNonWorkDays };
          });
          return { ...prev, schedule: newSchedule };
      });
  }, []);

  // --- Job Resizing Logic (Drag Handles) ---
  const handleJobResize = useCallback((jobId: string, newStart: number, newDuration: number) => {
      pushHistory(gameState, "Resized Project");
      setGameState(prev => {
          const job = prev.schedule.find(j => j.id === jobId);
          if (!job) return prev;

          const oldStart = job.startDate;
          const startDiff = newStart - oldStart;

          // Intelligently shift Daily Effort keys if start changed
          // Work performed on "Day 5" should stay on "Day 5" even if project starts earlier or later (relative to calendar)
          // "Day 5" is relative to project start.
          // If start moves -2 (earlier), old relative day 0 becomes relative day 2.

          let newDailyEffort: Record<number, number> = {};

          // If start changed, we need to map old offsets to new offsets to preserve calendar-day alignment of effort
          if (startDiff !== 0) {
              Object.entries(job.dailyEffort || {}).forEach(([dayOffsetStr, effort]) => {
                  const oldOffset = parseInt(dayOffsetStr);
                  const newOffset = oldOffset - startDiff;
                  // Only keep if within new duration bounds
                  if (newOffset >= 0 && newOffset < newDuration) {
                      newDailyEffort[newOffset] = effort as number;
                  }
              });
          } else {
              // If only duration changed (end dragged), just copy existing and prune if shorter
              newDailyEffort = { ...(job.dailyEffort || {}) };
              if (newDuration < job.deadlineDays) {
                  Object.keys(newDailyEffort).forEach(key => {
                      if (parseInt(key) >= newDuration) delete newDailyEffort[parseInt(key)];
                  });
              }
          }

          // Shift Non-Work Days similarly
          let newNonWorkDays = [...(job.nonWorkDays || [])];
          if (startDiff !== 0) {
              newNonWorkDays = newNonWorkDays.map(d => d - startDiff).filter(d => d >= 0 && d < newDuration);
          } else {
              newNonWorkDays = newNonWorkDays.filter(d => d < newDuration);
          }

          const updatedJob = {
              ...job,
              startDate: newStart,
              deadlineDays: newDuration,
              dailyEffort: newDailyEffort,
              nonWorkDays: newNonWorkDays
          };

          return {
              ...prev,
              schedule: prev.schedule.map(j => j.id === jobId ? updatedJob : j)
          };
      });
  }, [gameState]);

  // --- Capacity Check for Job Drop ---
  const checkCapacityForDrop = useCallback((job: Job | ScheduledJob, dayIndex: number): CapacityWarningData | null => {
    const bufferPercent = gameState.capacityBufferPercent ?? 15;
    const bufferMultiplier = 1 - (bufferPercent / 100);
    const deadlineDays = job.deadlineDays || 7;
    const avgHoursPerDay = job.estimatedHours / deadlineDays;

    let worstDayIndex = dayIndex;
    let worstDayLoad = 0;
    let worstDayCapacity = 0;
    let worstDayUtilization = 0;
    let totalOverloadedDays = 0;
    let maxNewLoad = 0;
    let maxNewCapacity = 0;
    let maxNewUtilization = 0;

    // Check each day of the job span
    for (let d = 0; d < deadlineDays; d++) {
      const checkDayIndex = dayIndex + d;
      if (checkDayIndex >= TOTAL_DAYS) continue;

      const currentLoad = dailyLoads[checkDayIndex] || 0;
      const capacity = dailyCapacities[checkDayIndex] || 0;
      const effectiveCapacity = capacity * bufferMultiplier;

      // Estimate load contribution from this job on this day
      const jobLoadOnDay = avgHoursPerDay;
      const newLoad = currentLoad + jobLoadOnDay;
      const newUtilization = capacity > 0 ? (newLoad / capacity) * 100 : 0;

      // Track if this day would be overloaded
      if (effectiveCapacity > 0 && newLoad > effectiveCapacity) {
        totalOverloadedDays++;
        if (newUtilization > maxNewUtilization) {
          maxNewUtilization = newUtilization;
          maxNewLoad = newLoad;
          maxNewCapacity = capacity;
          worstDayIndex = checkDayIndex;
          worstDayLoad = currentLoad;
          worstDayCapacity = capacity;
          worstDayUtilization = capacity > 0 ? (currentLoad / capacity) * 100 : 0;
        }
      }
    }

    // Only show warning if there are overloaded days
    if (totalOverloadedDays === 0) return null;

    return {
      jobId: job.id,
      jobName: job.customer || 'Unknown Job',
      hangarId: '',
      dayIndex,
      estimatedHours: job.estimatedHours,
      deadlineDays,
      capacityInfo: {
        worstDayIndex,
        worstDayLoad,
        worstDayCapacity,
        worstDayUtilization,
        totalOverloadedDays,
        maxNewLoad,
        maxNewCapacity,
        maxNewUtilization
      }
    };
  }, [gameState.capacityBufferPercent, dailyLoads, dailyCapacities]);

  // Find next available day with capacity
  const findNextAvailableDay = useCallback((job: Job | ScheduledJob, startFromDay: number): number | null => {
    const bufferPercent = gameState.capacityBufferPercent ?? 15;
    const bufferMultiplier = 1 - (bufferPercent / 100);
    const deadlineDays = job.deadlineDays || 7;
    const avgHoursPerDay = job.estimatedHours / deadlineDays;
    const maxLookahead = 365; // Look up to 1 year ahead

    for (let dayOffset = 0; dayOffset < maxLookahead; dayOffset++) {
      const candidateStart = startFromDay + dayOffset;
      let hasOverload = false;

      for (let d = 0; d < deadlineDays; d++) {
        const checkDayIndex = candidateStart + d;
        if (checkDayIndex >= TOTAL_DAYS) {
          hasOverload = true;
          break;
        }

        const currentLoad = dailyLoads[checkDayIndex] || 0;
        const capacity = dailyCapacities[checkDayIndex] || 0;
        const effectiveCapacity = capacity * bufferMultiplier;
        const newLoad = currentLoad + avgHoursPerDay;

        if (effectiveCapacity > 0 && newLoad > effectiveCapacity) {
          hasOverload = true;
          break;
        }
      }

      if (!hasOverload) return candidateStart;
    }

    return null;
  }, [gameState.capacityBufferPercent, dailyLoads, dailyCapacities]);

  // Execute the job drop (schedule or move)
  const executeJobDrop = useCallback((jobId: string, hangarId: string, dayIndex: number) => {
    // 1. Check Backlog (New Schedule)
    const backlogJob = gameState.backlog.find(j => j.id === jobId);
    if (backlogJob) {
      const newScheduleItem: ScheduledJob = {
        ...backlogJob,
        startDate: dayIndex,
        hangarId,
        progress: 0,
        status: 'Scheduled',
      };

      pushHistory(gameState, `Scheduled: ${backlogJob.customer}`);

      setGameState(prev => ({
        ...prev,
        backlog: prev.backlog.filter(j => j.id !== jobId),
        schedule: [...prev.schedule, newScheduleItem]
      }));
      return;
    }

    // 2. Check Schedule (Move Existing)
    const scheduleJob = gameState.schedule.find(j => j.id === jobId);
    if (scheduleJob) {
      const updatedJob = {
        ...scheduleJob,
        startDate: dayIndex,
        hangarId: hangarId
      };

      pushHistory(gameState, `Moved: ${scheduleJob.customer}`);

      setGameState(prev => ({
        ...prev,
        schedule: prev.schedule.map(j => j.id === jobId ? updatedJob : j)
      }));
    }
  }, [gameState, pushHistory]);

  // Handle job drop - always execute (capacity warnings shown via day header indicators)
  const handleJobDropWithCapacityCheck = useCallback((jobId: string, hangarId: string, dayIndex: number) => {
    const job = gameState.backlog.find(j => j.id === jobId) || gameState.schedule.find(j => j.id === jobId);
    if (!job) return;

    // Always proceed with drop - capacity conflicts are shown non-blocking via day indicators
    executeJobDrop(jobId, hangarId, dayIndex);
  }, [gameState, executeJobDrop]);

  // Handle find available slot (from right-click context menu)
  const handleFindAvailableSlot = useCallback((job: ScheduledJob) => {
    // Find next available day starting from current position + 1
    const nextAvailable = findNextAvailableDay(job, job.startDate + 1);

    if (nextAvailable !== null) {
      // Move job to the available slot
      pushHistory(gameState, "Moved to Available Slot");
      setGameState(prev => ({
        ...prev,
        schedule: prev.schedule.map(j =>
          j.id === job.id ? { ...j, startDate: nextAvailable } : j
        )
      }));
    } else {
      // No available slot found - could show a notification
      console.log('No available slot found within the next year');
    }
  }, [gameState, findNextAvailableDay, pushHistory]);

  // --- Auto Scheduling Algorithm (Batch Capable) ---
  const calculateAutoSchedule = useCallback((jobId: string, startDateIndex: number, simulationState?: GameState) => {
      // Use provided simulation state or fall back to current state
      const stateToUse: GameState = simulationState || gameState;
      
      const jobToSchedule = stateToUse.backlog.find(j => j.id === jobId) || stateToUse.schedule.find(j => j.id === jobId);
      if (!jobToSchedule) return { deadlineDays: 1, dailyEffort: {} };

      const requiredHours = jobToSchedule.estimatedHours;
      const dailyEffort: Record<number, number> = {};
      
      const scopeBaseId = stateToUse.uiState.selectedBaseId;
      const isGlobal = !scopeBaseId || scopeBaseId === 'ALL';
      
      const MAX_LOOKAHEAD = 1095; // 3 years
      const capacityMap = new Float32Array(MAX_LOOKAHEAD);
      const loadMap = new Float32Array(MAX_LOOKAHEAD);

      const relevantPersonnel = isGlobal 
          ? stateToUse.personnel 
          : stateToUse.personnel.filter(p => p.baseId === scopeBaseId);

      const dailyLaborProfile = new Float32Array(7); // 0-6 Sun-Sat
      
      relevantPersonnel.forEach(p => {
          const team = stateToUse.teams.find(t => t.id === p.teamId);
          const role = stateToUse.roles.find(r => r.id === p.roleId);
          if (team && role) {
              const shift = stateToUse.shifts.find(s => s.id === team.shiftId);
              if (shift) {
                  const totalBreakMins = ((shift.breakCount || 0) * (shift.breakDuration || 0)) + (shift.meetingDuration || 0);
                  const effectiveDuration = Math.max(0, shift.duration - (totalBreakMins / 60));
                  const efficiency = p.efficiencyOverride ?? role.baseEfficiency ?? 1.0;
                  const dailyOutput = effectiveDuration * efficiency;
                  for (const dayIndex of shift.days) { 
                      dailyLaborProfile[dayIndex] += dailyOutput; 
                  }
              }
          }
      });

      for (let i = 0; i < MAX_LOOKAHEAD; i++) {
          const dayAbs = startDateIndex + i;
          const isHoliday = stateToUse.holidays.some(h => h.dayIndex === dayAbs && h.enabled);
          if (!isHoliday && dayAbs < TOTAL_DAYS) {
              const dayOfWeek = (dayAbs + 1) % 7; 
              capacityMap[i] = dailyLaborProfile[dayOfWeek];
          }
      }

      stateToUse.schedule.forEach(otherJob => {
          if (otherJob.id === jobId) return; // Skip self if already scheduled
          const otherJobHangar = stateToUse.hangars.find(h => h.id === otherJob.hangarId);
          if (!isGlobal && otherJobHangar && otherJobHangar.baseId !== scopeBaseId) return;

          const start = otherJob.startDate;
          if (start + otherJob.deadlineDays < startDateIndex) return;
          
          for (let d = 0; d < otherJob.deadlineDays; d++) {
              const absDay = start + d;
              const relativeDay = absDay - startDateIndex;
              
              if (relativeDay >= 0 && relativeDay < MAX_LOOKAHEAD) {
                  let weight = 1;
                  if (otherJob.dailyEffort && otherJob.dailyEffort[d] !== undefined) {
                      weight = otherJob.dailyEffort[d];
                  } else if (otherJob.nonWorkDays?.includes(d)) {
                      weight = 0;
                  }
                  
                  let totalW = 0;
                  for(let k=0; k<otherJob.deadlineDays; k++) {
                      let w = 1;
                      if(otherJob.dailyEffort && otherJob.dailyEffort[k] !== undefined) w = otherJob.dailyEffort[k];
                      else if(otherJob.nonWorkDays?.includes(k)) w = 0;
                      totalW += w;
                  }
                  
                  if (totalW > 0) {
                      const hours = (weight / totalW) * otherJob.estimatedHours;
                      loadMap[relativeDay] += hours;
                  }
              }
          }
      });

      let remainingHours = requiredHours;
      let dayOffset = 0;

      while (remainingHours > 0.01 && dayOffset < MAX_LOOKAHEAD) {
          const capacity = capacityMap[dayOffset] || 0;
          const existingLoad = loadMap[dayOffset] || 0;
          const netAvailable = Math.max(0, capacity - existingLoad);
          
          if (netAvailable > 0.1) { 
              const take = Math.min(netAvailable, remainingHours);
              dailyEffort[dayOffset] = take; 
              remainingHours -= take;
          } else {
              dailyEffort[dayOffset] = 0; 
          }
          
          dayOffset++;
      }

      return {
          deadlineDays: dayOffset,
          dailyEffort: dailyEffort
      };

  }, [gameState.schedule, gameState.backlog, gameState.personnel, gameState.teams, gameState.shifts, gameState.roles, gameState.holidays, gameState.hangars, gameState.uiState.selectedBaseId]);

  // --- Magic Scheduler Logic ---
  const handleMagicSchedulerToggle = () => {
      setMagicState(prev => ({
          step: prev.step === 'inactive' ? 'intro' : 'inactive',
          selectedIds: [],
          results: []
      }));
  };

  const handleMagicJobSelection = (job: ScheduledJob) => {
      if (magicState.step !== 'selecting') return;
      setMagicState(prev => {
          const exists = prev.selectedIds.includes(job.id);
          const newIds = exists 
              ? prev.selectedIds.filter(id => id !== job.id)
              : [...prev.selectedIds, job.id]; // Keep order of selection
          return { ...prev, selectedIds: newIds };
      });
  };

  const handleMagicOptimization = () => {
      // 1. Jobs are prioritized by their order in selectedIds
      const sortedJobIds = [...magicState.selectedIds];

      // 2. Clone State for simulation
      // We start with a base where ALL selected jobs are removed from the schedule/load consideration.
      // This allows us to re-introduce them one by one in priority order.
      let simulationState: GameState = JSON.parse(JSON.stringify(gameState));
      
      // Filter out ALL selected jobs from the simulation schedule to create a "clean slate" relative to them
      simulationState.schedule = simulationState.schedule.filter((j: ScheduledJob) => !sortedJobIds.includes(j.id));
      
      const batchResults: typeof magicState.results = [];

      // 3. Iterate and Optimize sequentially
      sortedJobIds.forEach(jobId => {
          // Find original job data to preserve its properties (start date, hangar, etc)
          const originalJob = gameState.schedule.find(j => j.id === jobId) || gameState.backlog.find(j => j.id === jobId);
          if (!originalJob) return;

          const originalEnd = ('startDate' in originalJob) ? originalJob.startDate + originalJob.deadlineDays : 0;
          const startDay = ('startDate' in originalJob) ? originalJob.startDate : gameState.day;

          // Prepare a clean copy of the job for simulation
          const jobForSim = { 
              ...originalJob, 
              dailyEffort: {}, 
              nonWorkDays: [], 
              startDate: startDay 
          } as ScheduledJob;
          
          // Inject this single job into the simulation state so the calculator can 'see' it as the target
          // The calculator filters out the target job when calculating load, so this is safe.
          // However, we need it in the array if the calculator tries to look up metadata.
          simulationState.schedule.push(jobForSim);
          
          // Run the optimizer against the current accumulated load (which includes previously optimized higher-priority jobs)
          const result = calculateAutoSchedule(jobId, startDay, simulationState);
          
          if (result) {
              const newEnd = startDay + result.deadlineDays;
              
              // Apply optimization results to the job in simulationState
              // effectively "committing" its load to the board for the next iteration
              const updatedJobIndex = simulationState.schedule.findIndex((j: any) => j.id === jobId);
              if (updatedJobIndex !== -1) {
                  simulationState.schedule[updatedJobIndex] = {
                      ...simulationState.schedule[updatedJobIndex],
                      deadlineDays: result.deadlineDays,
                      dailyEffort: result.dailyEffort,
                      nonWorkDays: [] // Cleared by optimization
                  };
              }
              
              batchResults.push({
                  jobId,
                  oldEnd: originalEnd,
                  newEnd,
                  daysAdded: Math.max(0, newEnd - originalEnd)
              });
          }
      });

      // 4. Commit Final State
      // The simulationState now contains the full schedule with optimized selected jobs + untouched unselected jobs
      pushHistory(simulationState, "Magic Schedule Optimization");
      setMagicState(prev => ({ ...prev, step: 'results', results: batchResults }));
  };

  // --- Tutorial Handlers ---
  const handleStartOnboarding = (type: TourType = 'full') => {
      setTourType(type);
      updateUI({ tutorialActive: true, tutorialStep: 0 });
      setView('board');
      setScrollToTodayTrigger(Date.now());
  };

  const handleTutorialNext = () => {
      const nextStep = gameState.uiState.tutorialStep + 1;
      const uiUpdates: Partial<UIState> = { tutorialStep: nextStep };

      // Quick Tour: Simple navigation, stay on board view
      if (tourType === 'quick') {
          // Step 3: Open backlog panel to show it
          if (nextStep === 3) { uiUpdates.backlogOpen = true; }
          // Final step: Close all panels
          if (nextStep === QUICK_TOUR_STEPS.length - 1) {
              uiUpdates.backlogOpen = false;
          }
          updateUI(uiUpdates);
          return;
      }

      // Full Tour: Complex UI transitions
      // Action: Open Roster (Transitions 2->3)
      if (nextStep === 3) { uiUpdates.rosterOpen = true; }

      // Action: Open Capacity, Close Roster (Transitions 4->5)
      if (nextStep === 5) { uiUpdates.rosterOpen = false; uiUpdates.capacityOpen = true; }

      // Action: Open PnL, Close Capacity (Transitions 6->7)
      if (nextStep === 7) { uiUpdates.capacityOpen = false; uiUpdates.pnlOpen = true; }

      // Action: Open Analytics, Close PnL (Transitions 8->9)
      if (nextStep === 9) { uiUpdates.pnlOpen = false; uiUpdates.analyticsOpen = true; }

      // Action: Config View, Close Analytics (Transitions 10->11)
      if (nextStep === 11) {
          setView('config');
          uiUpdates.analyticsOpen = false;
      }

      // Action: Switch Tabs in Config
      if (nextStep === 12) { setTutorialTab('fleet'); } // Should default
      if (nextStep === 13) { setTutorialTab('hangars'); }
      if (nextStep === 14) { setTutorialTab('stages'); }

      // Action: Back to Board (Transitions 14->15)
      if (nextStep === 15) { setView('board'); setTutorialTab(null); }

      // Action: Open Personnel View (Transitions 15->16)
      if (nextStep === 16) { setView('personnel'); setTutorialTab('roster'); }

      // Action: Switch Tabs in Personnel
      if (nextStep === 17) { setTutorialTab('roster'); }
      if (nextStep === 18) { setTutorialTab('assignments'); }
      if (nextStep === 19) { setTutorialTab('roles'); }
      if (nextStep === 20) { setTutorialTab('holidays'); }
      if (nextStep === 21) { setTutorialTab('analysis'); }

      // Action: Back to Board (Transitions 21->22)
      if (nextStep === 22) { setView('board'); setTutorialTab(null); }

      // Action: Open Financial View (Transitions 22->23)
      if (nextStep === 23) { setView('financials'); setTutorialTab('general'); }

      // Action: Switch Tabs in Financial
      if (nextStep === 24) { setTutorialTab('financial'); } // Projections
      if (nextStep === 25) { setTutorialTab('fpa'); }
      if (nextStep === 26) { setTutorialTab('general'); }

      // Action: Back to Board, Close all modals (Transitions 26->27)
      if (nextStep === 27) {
          setView('board');
          setTutorialTab(null);
          uiUpdates.backlogOpen = false;
          uiUpdates.analyticsOpen = false;
          uiUpdates.pnlOpen = false;
          uiUpdates.capacityOpen = false;
          uiUpdates.rosterOpen = false;
      }

      // Action: Open Backlog (Transitions 27->28)
      if (nextStep === 28) { uiUpdates.backlogOpen = true; }

      // Action: Open Quote View (Transitions 29->30)
      if (nextStep === 30) { setView('quote'); }

      // Action: Back to Board (Transitions 34->35)
      if (nextStep === 35) { setView('board'); }

      updateUI(uiUpdates);
  };

  const handleTutorialPrev = () => {
      const prevStep = Math.max(0, gameState.uiState.tutorialStep - 1);
      const uiUpdates: Partial<UIState> = { tutorialStep: prevStep };

      // Quick Tour: Simple navigation
      if (tourType === 'quick') {
          // Step 2 (going back from 3): Close backlog
          if (prevStep === 2) { uiUpdates.backlogOpen = false; }
          updateUI(uiUpdates);
          return;
      }

      // Full Tour: Reverse Actions
      if (prevStep === 2) { uiUpdates.rosterOpen = false; } // Back from Open Roster to Access Roster
      if (prevStep === 4) { uiUpdates.capacityOpen = false; uiUpdates.rosterOpen = true; } // Back to Roster
      if (prevStep === 6) { uiUpdates.pnlOpen = false; uiUpdates.capacityOpen = true; } // Back to Capacity
      if (prevStep === 8) { uiUpdates.analyticsOpen = false; uiUpdates.pnlOpen = true; } // Back to PnL
      if (prevStep === 10) { setView('board'); uiUpdates.analyticsOpen = true; } // Back to Board+Analytics

      if (prevStep === 12) { setTutorialTab('fleet'); }
      if (prevStep === 13) { setTutorialTab('hangars'); }
      if (prevStep === 14) { setView('config'); setTutorialTab('stages'); } // Back to Config

      if (prevStep === 15) { setView('board'); } // Back from Personnel to Board

      if (prevStep === 16) { setView('personnel'); setTutorialTab('roster'); }
      if (prevStep === 17) { setTutorialTab('roster'); }
      if (prevStep === 18) { setTutorialTab('assignments'); }
      if (prevStep === 19) { setTutorialTab('roles'); }
      if (prevStep === 20) { setTutorialTab('holidays'); }

      if (prevStep === 21) { setView('personnel'); setTutorialTab('analysis'); } // Back from Board to Personnel

      if (prevStep === 22) { setView('board'); } // Back from Financials to Board

      if (prevStep === 23) { setView('financials'); setTutorialTab('general'); }
      if (prevStep === 24) { setTutorialTab('financial'); }
      if (prevStep === 25) { setTutorialTab('fpa'); }

      if (prevStep === 26) { setView('financials'); setTutorialTab('general'); } // Back to Financials

      if (prevStep === 27) { uiUpdates.backlogOpen = false; } // Close backlog

      if (prevStep === 29) { setView('board'); uiUpdates.backlogOpen = true; } // Back from Quote to Board

      if (prevStep === 34) { setView('quote'); } // Back to Quote

      updateUI(uiUpdates);
  };

  const handleTutorialClose = () => {
      const currentStep = gameState.uiState.tutorialStep;
      const steps = tourType === 'quick' ? QUICK_TOUR_STEPS : TOUR_STEPS;
      const wasLastStep = currentStep === steps.length - 1;

      // Track which section was completed (if at end of a section)
      const currentSection = getCurrentSection(currentStep);
      let completedSections = [...(gameState.uiState.completedSections || [])];
      if (currentSection && currentStep === currentSection.endStep && !completedSections.includes(currentSection.id)) {
          completedSections.push(currentSection.id);
      }

      updateUI({
          tutorialActive: false,
          tutorialStep: 0,
          onboardingCompleted: wasLastStep || gameState.uiState.onboardingCompleted,
          onboardingCompletedAt: wasLastStep ? Date.now() : gameState.uiState.onboardingCompletedAt,
          completedSections
      });
      setView('board');
      setTutorialTab(null);
  };

  const handleTutorialSetup = () => {
      updateUI({ tutorialActive: false });
      setView('setup');
  };

  const handleLoadDemoData = () => {
      // getInitialState() includes all INITIAL_* demo data from constants.ts
      const demoState = getInitialState();

      // Preserve current day/date context
      demoState.day = gameState.day;

      setGameState(demoState);
      pushHistory(demoState, "Loaded demo data");
      setShowWelcome(false);
  };

  const handleSkipSection = () => {
      const currentStep = gameState.uiState.tutorialStep;
      const currentSectionIdx = getSectionIndex(currentStep);

      const nextSection = TOUR_SECTIONS[currentSectionIdx + 1];

      if (nextSection) {
          // Jump to start of next section
          const nextStep = nextSection.startStep;
          const uiUpdates: Partial<UIState> = { tutorialStep: nextStep };

          // Reset UI state for new section - close any panels that might be open
          uiUpdates.rosterOpen = false;
          uiUpdates.capacityOpen = false;
          uiUpdates.pnlOpen = false;
          uiUpdates.analyticsOpen = false;
          uiUpdates.backlogOpen = false;

          // Set view based on section
          if (nextSection.id === 'config') setView('config');
          else if (nextSection.id === 'personnel') setView('personnel');
          else if (nextSection.id === 'financials') setView('financials');
          else if (nextSection.id === 'quoting') setView('board');
          else setView('board');

          setTutorialTab(null);
          updateUI(uiUpdates);
      } else {
          // No more sections, end tour
          handleTutorialClose();
      }
  };

  const handleCollapseAll = () => {
      updateUI({
          backlogOpen: false,
          analyticsOpen: false,
          pnlOpen: false,
          capacityOpen: false,
          rosterOpen: false,
          popouts: {
              analytics: false,
              backlog: false,
              pnl: false,
              cashflow: false,
              capacity: false,
              roster: false,
              graveyard: false
          }
      });
  };

  const handleQuoteSuccessConfirm = () => {
      setQuoteSuccess({ active: false, job: null });
      setView('board');
      updateUI({ backlogOpen: true });
      if (quoteSuccess.job) {
          setHighlightedJobId(quoteSuccess.job.id);
          setTimeout(() => {
              setHighlightedJobId(null);
          }, 10000);
      }
  };

  // --- Deletion & Graveyard Logic ---
  
  const handleDeleteJob = (jobId: string, permanent: boolean = false) => {
      // Find the job in either backlog or schedule
      const jobInBacklog = gameState.backlog.find(j => j.id === jobId);
      const jobInSchedule = gameState.schedule.find(j => j.id === jobId);
      const jobToDelete = jobInBacklog || jobInSchedule;

      if (!jobToDelete) return;

      // Remove from active lists
      const newBacklog = gameState.backlog.filter(j => j.id !== jobId);
      const newSchedule = gameState.schedule.filter(j => j.id !== jobId);

      if (permanent) {
          // Hard delete
          pushHistory(gameState, "Permanently Deleted Job");
          setGameState(prev => ({
              ...prev,
              backlog: newBacklog,
              schedule: newSchedule
          }));
      } else {
          // Soft delete (move to graveyard)
          pushHistory(gameState, "Moved Job to Graveyard");
          // If it was scheduled, strip scheduling info to make it a plain Job again for storage
          // or keep it as is to preserve history? Let's strip to simple Job for simplicity in graveyard
          // but keeping properties is safer for restore.
          // We'll cast it to Job to store in graveyard array.
          setGameState(prev => ({
              ...prev,
              backlog: newBacklog,
              schedule: newSchedule,
              graveyard: [...prev.graveyard, jobToDelete]
          }));
      }
      setSelectedJob(null);
  };

  const handleRestoreFromGraveyard = (job: Job) => {
      pushHistory(gameState, "Restored Job from Graveyard");
      setGameState(prev => ({
          ...prev,
          graveyard: prev.graveyard.filter(j => j.id !== job.id),
          backlog: [...prev.backlog, job]
      }));
  };

  const handlePermanentDeleteFromGraveyard = (jobId: string) => {
      pushHistory(gameState, "Permanently Deleted Job from Graveyard");
      setGameState(prev => ({
          ...prev,
          graveyard: prev.graveyard.filter(j => j.id !== jobId)
      }));
  };

  // --- Scroll Sync ---
  const handleChartScroll = useCallback((e: React.UIEvent<HTMLDivElement> | number) => {
    const scrollLeft = typeof e === 'number' ? e : (e.target as HTMLDivElement).scrollLeft;
    [ganttScrollRef, trackerScrollRef, capacityScrollRef].forEach(ref => {
         if(ref.current && ref.current.scrollLeft !== scrollLeft) {
             ref.current.scrollLeft = scrollLeft;
         }
    });
  }, []);

  // --- PERFORMANCE: Extracted handlers for GanttBoard to prevent re-renders ---
  const handleZoomChange = useCallback((w: number) => updateUI({ cellWidth: w }), []);

  const handleDayClick = useCallback((day: number) => setGameState(prev => ({ ...prev, day })), []);

  const handleJobDayToggle = useCallback((jobId: string, dayOffset: number) => {
      setGameState(prev => {
          const job = prev.schedule.find((j: ScheduledJob) => j.id === jobId);
          if (!job) return prev;
          const isCurrentlyBlocked = job.nonWorkDays?.includes(dayOffset);

          if (isCurrentlyBlocked) {
              // Unblock: Just remove from list
              return {
                  ...prev,
                  schedule: prev.schedule.map((j: ScheduledJob) => {
                      if (j.id !== jobId) return j;
                      const newNonWork = (j.nonWorkDays || []).filter((d: number) => d !== dayOffset);
                      return { ...j, nonWorkDays: newNonWork };
                  })
              };
          } else {
              // Block: Set hours to 0 via redistribution (handled by handleJobRedistribution)
              // We need to call this after this state update, so we schedule it
              setTimeout(() => handleJobRedistribution(jobId, dayOffset, 0), 0);
              return prev;
          }
      });
  }, [handleJobRedistribution]);

  const handleJobEffortChange = useCallback((jobId: string, dayOffset: number, hours: number) => {
      handleJobRedistribution(jobId, dayOffset, hours);
  }, [handleJobRedistribution]);

  const handleDragStart = useCallback((e: React.DragEvent, job: Job | ScheduledJob) => {
      e.dataTransfer.setData('jobId', job.id);
      e.dataTransfer.effectAllowed = 'move';
      setDraggedJob(job);
  }, []);

  const handleDragEnd = useCallback(() => setDraggedJob(null), []);

  const handleHangarReorder = useCallback((srcId: string, targetId: string) => {
      setGameState(prev => {
          const srcIdx = prev.hangars.findIndex(h => h.id === srcId);
          const targetIdx = prev.hangars.findIndex(h => h.id === targetId);
          if (srcIdx === -1 || targetIdx === -1) return prev;

          const newHangars = [...prev.hangars];
          const [moved] = newHangars.splice(srcIdx, 1);
          newHangars.splice(targetIdx, 0, moved);

          pushHistory(prev, "Reordered Hangars");
          return { ...prev, hangars: newHangars };
      });
  }, []);

  if (isLoading) {
      console.log("[Dashboard Render] Still loading...");
      return (
          <div className="h-screen w-screen bg-[#08090a] flex flex-col items-center justify-center gap-4">
              <Loader2 size={32} className="animate-spin text-white/60" />
              <div className="text-sm font-medium tracking-wide text-white/80">Loading...</div>
          </div>
      );
  }

  console.log("[Dashboard Render] Rendering main dashboard, isLoading:", isLoading, "dbReady:", dbReady);

  return (
    <TimelineSyncProvider initialCellWidth={gameState.uiState.cellWidth}>
    <div className="flex flex-col h-screen bg-[#08090a] text-[#e8e8e8] overflow-hidden font-sans selection:bg-indigo-500/30 relative">
      
      {/* Welcome Splash - Shows only if showWelcome is true */}
      {showWelcome && (
          <WelcomeSplash
              onStartTour={(type) => {
                  setShowWelcome(false);
                  handleStartOnboarding(type);
              }}
              onSkip={() => setShowWelcome(false)}
              onLoadDemo={handleLoadDemoData}
              userName={user?.name}
              hasExistingData={gameState.backlog.length > 0 || gameState.schedule.length > 0}
          />
      )}

      {/* Onboarding Tour Overlay */}
      <OnboardingTour
          active={gameState.uiState.tutorialActive}
          step={gameState.uiState.tutorialStep}
          tourType={tourType}
          onNext={handleTutorialNext}
          onPrev={handleTutorialPrev}
          onClose={handleTutorialClose}
          onSetup={handleTutorialSetup}
          onSkipSection={handleSkipSection}
      />

      {/* Magic Scheduler Overlay - Lazy loaded */}
      {magicState.step !== 'inactive' && (
          <Suspense fallback={<ModalLoader message="Loading scheduler..." />}>
              <MagicSchedulerWizard
                  step={magicState.step}
                  selectedJobs={gameState.schedule.filter(j => magicState.selectedIds.includes(j.id))}
                  results={magicState.results}
                  onClose={handleMagicSchedulerToggle}
                  onStartSelection={() => setMagicState(prev => ({ ...prev, step: 'selecting' }))}
                  onConfirmSelection={() => setMagicState(prev => ({ ...prev, step: 'prioritizing' }))}
                  onReorderSelectedJobs={(newOrderIds) => setMagicState(prev => ({ ...prev, selectedIds: newOrderIds }))}
                  onRunOptimization={handleMagicOptimization}
              />
          </Suspense>
      )}

      {/* Quote Success Popup */}
      {quoteSuccess.active && quoteSuccess.job && (
          <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-[#08090a]/80 backdrop-blur-sm animate-in fade-in duration-300">
              <div className="bg-[#0d0e10] border border-white/[0.08] rounded-xl shadow-2xl p-8 max-w-lg w-full flex flex-col items-center text-center relative overflow-hidden">
                  <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-1 bg-gradient-to-r from-transparent via-emerald-500 to-transparent rounded-full" />
                  <div className="w-16 h-16 bg-emerald-500/10 rounded-full flex items-center justify-center mb-6 border border-emerald-500/20">
                      <CheckCircle size={32} className="text-emerald-400" />
                  </div>
                  <h2 className="text-xl font-semibold text-white mb-2">Quote Created Successfully</h2>
                  <p className="text-[#9ca3af] text-sm mb-6">The work order has been generated and added to your quotes list.</p>
                  <div className="bg-[#141517] rounded-lg p-4 border border-white/[0.06] w-full mb-6">
                      <div className="flex justify-between items-center mb-2">
                          <span className="text-xs font-medium text-[#6b7280] uppercase">Customer</span>
                          <span className="text-sm font-semibold text-white">{quoteSuccess.job.customer}</span>
                      </div>
                      <div className="flex justify-between items-center">
                          <span className="text-xs font-medium text-[#6b7280] uppercase">Total Value</span>
                          <span className="text-lg font-mono font-semibold text-emerald-400">{DOLLAR_SIGN}{quoteSuccess.job.revenue.toLocaleString()}</span>
                      </div>
                  </div>
                  <button
                      onClick={handleQuoteSuccessConfirm}
                      className="w-full py-2.5 bg-emerald-500 hover:bg-emerald-400 text-white font-medium rounded-lg transition-colors flex items-center justify-center gap-2 text-sm"
                  >
                      View in Quotes <ArrowRight size={16} />
                  </button>
              </div>
          </div>
      )}

      {/* Panels/Modals */}
      {showPasswordModal && (
          <ChangePasswordModal onClose={() => setShowPasswordModal(false)} />
      )}

      {/* Glossary Modal - Only mount when open (lazy loaded) */}
      {showGlossary && (
          <Suspense fallback={<ModalLoader message="Loading glossary..." />}>
              <GlossaryModal
                  isOpen={showGlossary}
                  onClose={() => setShowGlossary(false)}
              />
          </Suspense>
      )}

      {/* Capacity Warning Modal - Only mount when open (lazy loaded) */}
      {capacityWarning.isOpen && (
          <Suspense fallback={<ModalLoader message="Checking capacity..." />}>
              <CapacityWarningModal
                  isOpen={capacityWarning.isOpen}
                  data={capacityWarning.data}
                  nextAvailableDay={capacityWarning.nextAvailableDay}
                  onCancel={() => setCapacityWarning({ isOpen: false, data: null, nextAvailableDay: null })}
                  onScheduleAnyway={() => {
                    if (capacityWarning.data) {
                      executeJobDrop(
                        capacityWarning.data.jobId,
                        capacityWarning.data.hangarId,
                        capacityWarning.data.dayIndex
                      );
                    }
                    setCapacityWarning({ isOpen: false, data: null, nextAvailableDay: null });
                  }}
                  onFindAvailable={() => {
                    if (capacityWarning.data && capacityWarning.nextAvailableDay !== null) {
                      executeJobDrop(
                        capacityWarning.data.jobId,
                        capacityWarning.data.hangarId,
                        capacityWarning.nextAvailableDay
                      );
                    }
                    setCapacityWarning({ isOpen: false, data: null, nextAvailableDay: null });
                  }}
              />
          </Suspense>
      )}

      {view === 'setup' && (
          <Suspense fallback={<ModalLoader message="Loading setup..." />}>
              <SetupDefaultsPanel
                 gameState={gameState}
                 onUpdateGameState={(updates) => setGameState(prev => ({ ...prev, ...updates }))}
                 onClose={() => setView('board')}
              />
          </Suspense>
      )}

      {view === 'fullscreen' && (
          <Suspense fallback={<ModalLoader message="Loading dashboard..." />}>
              <FullScreenDashboard
                  gameState={gameState}
                  onClose={() => setView('board')}
                  onJobClick={setSelectedJob}
              />
          </Suspense>
      )}

      {view === 'admin' && (
          <UserManagement onClose={() => setView('board')} />
      )}

      {/* Main App Header */}
      {/* INCREASED Z-INDEX TO 60 TO SIT ABOVE GANTT HEADER (z-50) */}
      <header className="h-14 bg-[#0d0e10] border-b border-white/[0.06] flex items-center justify-between px-4 shrink-0 z-[60] relative">
        <div className="flex items-center gap-2 sm:gap-6 shrink-0">
           <div className="flex items-center gap-3">
             <div>
               <h1 className="text-lg font-semibold text-white leading-none">AeroManager</h1>
               <div className="text-[10px] text-indigo-400 font-medium">Part 145 Ops</div>
             </div>

             <button
                onClick={handleStartOnboarding}
                className="p-2 text-[#6b7280] hover:text-indigo-400 hover:bg-white/[0.05] rounded-lg transition-colors relative group hidden sm:block"
                title="Start Tutorial"
             >
               <CircleHelp size={18} />
             </button>
             <button
                onClick={() => setShowGlossary(true)}
                className="p-2 text-[#6b7280] hover:text-emerald-400 hover:bg-white/[0.05] rounded-lg transition-colors relative group hidden sm:block"
                title="Glossary (Cmd+?)"
             >
               <Book size={18} />
             </button>
           </div>

           <div className="flex items-center bg-[#141517] rounded-lg border border-white/[0.08] p-1">
               <div className="flex items-center gap-2 px-3 py-1 border-r border-white/[0.08]">
                   <MapPin size={12} className="text-[#6b7280]" />
                   <select
                      value={gameState.uiState.selectedBaseId}
                      onChange={(e) => updateUI({ selectedBaseId: e.target.value })}
                      className="bg-transparent text-xs font-medium text-[#e8e8e8] outline-none cursor-pointer hover:text-indigo-400 transition-colors max-w-[80px] sm:max-w-none"
                   >
                       <option value="ALL">All Bases</option>
                       {gameState.bases.map(b => (
                           <option key={b.id} value={b.id}>{b.name}</option>
                       ))}
                   </select>
               </div>

               <div className="flex items-center gap-1 px-2 border-r border-white/[0.08] hidden sm:flex">
                   <button
                        onClick={handleZoomOut}
                        className="p-1 hover:bg-white/[0.05] rounded text-[#6b7280] disabled:opacity-30"
                        disabled={gameState.uiState.cellWidth <= ZOOM_LEVELS[0]}
                        title="Zoom Out"
                   >
                       <ZoomOut size={12} />
                   </button>
                   <button
                        onClick={handleZoomIn}
                        className="p-1 hover:bg-white/[0.05] rounded text-[#6b7280] disabled:opacity-30"
                        disabled={gameState.uiState.cellWidth >= ZOOM_LEVELS[ZOOM_LEVELS.length - 1]}
                        title="Zoom In"
                   >
                       <ZoomIn size={12} />
                   </button>
               </div>

               <div className="flex flex-col gap-0.5 pl-1">
                   <button
                       onClick={() => setScrollToTodayTrigger(Date.now())}
                       className="p-0.5 hover:bg-white/[0.05] rounded text-[#6b7280] hover:text-indigo-400 transition-colors"
                       title="Center on Selected Date"
                   >
                       <LocateFixed size={12} />
                   </button>
                   <button
                       onClick={() => {
                           setGameState(prev => ({ ...prev, day: getTodayIndex() }));
                           setTimeout(() => setScrollToTodayTrigger(Date.now()), 10);
                       }}
                       className="p-0.5 hover:bg-white/[0.05] rounded text-[#6b7280] hover:text-emerald-400 transition-colors"
                       title="Go to Today"
                   >
                       <Calendar size={12} />
                   </button>
               </div>
           </div>

           {/* Undo/Redo Controls */}
           {(history.length > 0 || future.length > 0) && (
               <div className="flex items-center bg-[#141517] rounded-lg border border-white/[0.08] p-1 hidden lg:flex">
                   <button onClick={handleUndo} disabled={history.length === 0} className="p-1.5 hover:bg-white/[0.05] rounded text-[#9ca3af] disabled:opacity-30">
                       <Undo2 size={14} />
                   </button>
                   <button onClick={handleRedo} disabled={future.length === 0} className="p-1.5 hover:bg-white/[0.05] rounded text-[#9ca3af] disabled:opacity-30">
                       <Redo2 size={14} />
                   </button>
               </div>
           )}
           {/* Action Status Display */}
           {lastAction && (
               <div className="ml-2 text-xs font-mono text-[#6b7280] animate-fade-in truncate max-w-[150px] hidden xl:block">
                   {lastAction}
               </div>
           )}
        </div>

        {/* REMOVED OVERFLOW-X-AUTO TO ALLOW DROPDOWNS TO OVERFLOW VISIBLY */}
        <div className="flex items-center gap-2 ml-4">
           <div className="flex items-center bg-[#141517] rounded-lg border border-white/[0.08] p-1 shrink-0 hidden md:flex">
               <div className="px-3 flex flex-col items-center leading-none">
                   <span className="text-[9px] text-[#6b7280] font-medium uppercase mb-0.5">Selected Date</span>
                   <span className="text-xs font-semibold text-indigo-400 flex items-center gap-1.5">
                       <Calendar size={10} />
                       {(() => {
                          const d = new Date(START_YEAR, 0, 1 + gameState.day);
                          return `${MONTH_NAMES[d.getMonth()]} ${d.getDate()}, ${d.getFullYear().toString().substring(2)}`;
                       })()}
                   </span>
               </div>
           </div>

           <div className="flex items-center gap-1 shrink-0">
               <button
                  id="btn-financials"
                  onClick={() => { setFinancialsInitialEditMode(false); startTransition(() => setView('financials')); }}
                  className="flex flex-col items-center justify-center gap-1 p-2 text-[#6b7280] hover:text-white hover:bg-white/[0.05] rounded-lg transition-colors relative group min-w-[44px]"
                  title="Financials"
               >
                   <DollarSign size={18} />
                   <span className="text-[9px] font-medium hidden lg:block leading-none">Finance</span>
               </button>
               <button
                  id="btn-personnel"
                  onClick={() => startTransition(() => setView('personnel'))}
                  className="flex-1 flex flex-col items-center justify-center gap-1 p-2 text-[#6b7280] hover:text-white hover:bg-white/[0.05] rounded-lg transition-colors relative group min-w-[44px]"
                  title="Personnel"
               >
                   <Users size={18} />
                   <span className="text-[9px] font-medium hidden lg:block leading-none">Staff</span>
               </button>
               <button
                  id="btn-config"
                  onClick={() => startTransition(() => setView('config'))}
                  className="flex-1 flex flex-col items-center justify-center gap-1 p-2 text-[#6b7280] hover:text-white hover:bg-white/[0.05] rounded-lg transition-colors relative group min-w-[44px]"
                  title="Configuration"
               >
                   <Settings size={18} />
                   <span className="text-[9px] font-medium hidden lg:block leading-none">Config</span>
               </button>

               <div className="w-px h-8 bg-white/[0.08] mx-1 hidden sm:block shrink-0" />

               {/* Magic Scheduler Button */}
               <button
                  onClick={handleMagicSchedulerToggle}
                  className={`flex flex-col items-center justify-center gap-1 p-2 rounded-lg transition-colors min-w-[44px] shrink-0 ${magicState.step !== 'inactive' ? 'bg-violet-500 text-white' : 'text-[#6b7280] hover:text-violet-400 hover:bg-white/[0.05]'}`}
                  title="Magic Scheduler"
               >
                   <Sparkles size={18} />
                   <span className="text-[9px] font-medium hidden lg:block leading-none">Magic</span>
               </button>

               <div className="relative shrink-0">
                   <Tooltip content="Edit Mode: Click scheduled jobs to adjust daily work hours or block off non-work days." position="bottom">
                       <button
                          onClick={() => setScheduleEditMode(!scheduleEditMode)}
                          className={`flex flex-col items-center justify-center gap-1 p-2 rounded-lg transition-colors min-w-[44px] ${scheduleEditMode ? 'bg-amber-500 text-[#08090a]' : 'text-[#6b7280] hover:text-white hover:bg-white/[0.05]'}`}
                       >
                           <Edit size={18} />
                           <span className="text-[9px] font-medium hidden lg:block leading-none">Edit</span>
                       </button>
                   </Tooltip>

                   {/* Edit Tools Pop-up */}
                   {scheduleEditMode && (
                       <div className="absolute top-full right-0 mt-2 bg-[#141517] border border-white/[0.08] rounded-lg shadow-xl p-2 flex flex-col gap-1 z-[100] animate-in fade-in slide-in-from-top-2 min-w-[140px]">
                           <div className="text-[9px] font-medium text-[#6b7280] uppercase px-2 pb-1 border-b border-white/[0.06] mb-1">Active Tool</div>
                           <button
                                onClick={() => setEditTool('distribute')}
                                className={`flex items-center gap-2 px-2 py-1.5 rounded text-xs font-medium text-left ${editTool === 'distribute' ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' : 'text-[#e8e8e8] hover:bg-white/[0.05]'}`}
                           >
                               <SlidersHorizontal size={14} /> Distribute Hrs
                           </button>
                           <button
                                onClick={() => setEditTool('block')}
                                className={`flex items-center gap-2 px-2 py-1.5 rounded text-xs font-medium text-left ${editTool === 'block' ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30' : 'text-[#e8e8e8] hover:bg-white/[0.05]'}`}
                           >
                               <Ban size={14} /> Block Days
                           </button>
                       </div>
                   )}
               </div>

               {/* View Button with Dropdown */}
               <div className="relative shrink-0">
                   <button
                      onClick={() => setViewDropdownOpen(!viewDropdownOpen)}
                      className="flex flex-col items-center justify-center gap-1 p-2 text-[#6b7280] hover:text-white hover:bg-white/[0.05] rounded-lg transition-colors min-w-[44px]"
                      title="View Options"
                   >
                       {viewCapacityMode ? <BarChart2 size={18} className="text-indigo-400" /> : simplifiedViewMode ? <Minimize size={18} className="text-emerald-400" /> : <Monitor size={18} />}
                       <span className="text-[9px] font-medium hidden lg:block leading-none flex items-center gap-0.5">
                           View <ChevronDown size={8} />
                       </span>
                   </button>

                   {viewDropdownOpen && (
                       <div className="absolute top-full right-0 mt-2 bg-[#141517] border border-white/[0.08] rounded-lg shadow-xl p-1 z-[100] animate-in fade-in slide-in-from-top-2 min-w-[180px]">
                           <div className="flex flex-col gap-1">
                               <button
                                   onClick={() => { startTransition(() => setView('fullscreen')); setViewDropdownOpen(false); }}
                                   className="flex items-center gap-3 px-3 py-2 rounded text-xs font-medium text-left text-[#e8e8e8] hover:bg-white/[0.05] transition-colors"
                               >
                                   <Maximize2 size={14} className="text-[#6b7280]" />
                                   Full Screen Display
                               </button>

                               <div className="h-px bg-white/[0.06] my-0.5" />

                               <button
                                   onClick={() => {
                                       if (!viewCapacityMode) {
                                           setViewCapacityMode(true);
                                           setSimplifiedViewMode(false);
                                       } else {
                                           setViewCapacityMode(false);
                                       }
                                   }}
                                   className={`flex items-center gap-3 px-3 py-2 rounded text-xs font-medium text-left transition-colors ${viewCapacityMode ? 'bg-indigo-500/10 text-indigo-400' : 'text-[#e8e8e8] hover:bg-white/[0.05]'}`}
                               >
                                   <div className={`w-3.5 h-3.5 rounded border flex items-center justify-center ${viewCapacityMode ? 'bg-indigo-500 border-indigo-500' : 'border-white/[0.2]'}`}>
                                       {viewCapacityMode && <Check size={10} className="text-white" />}
                                   </div>
                                   Show Capacity
                               </button>

                               <button
                                   onClick={() => {
                                       if (!simplifiedViewMode) {
                                           setSimplifiedViewMode(true);
                                           setViewCapacityMode(false);
                                       } else {
                                           setSimplifiedViewMode(false);
                                       }
                                   }}
                                   className={`flex items-center gap-3 px-3 py-2 rounded text-xs font-medium text-left transition-colors ${simplifiedViewMode ? 'bg-emerald-500/10 text-emerald-400' : 'text-[#e8e8e8] hover:bg-white/[0.05]'}`}
                               >
                                   <div className={`w-3.5 h-3.5 rounded border flex items-center justify-center ${simplifiedViewMode ? 'bg-emerald-500 border-emerald-500' : 'border-white/[0.2]'}`}>
                                       {simplifiedViewMode && <Check size={10} className="text-white" />}
                                   </div>
                                   Simplified View
                               </button>

                               <div className="h-px bg-white/[0.06] my-0.5" />

                               <button
                                   onClick={() => { togglePopout('projectList', true); setViewDropdownOpen(false); }}
                                   className="flex items-center gap-3 px-3 py-2 rounded text-xs font-medium text-left text-[#e8e8e8] hover:bg-white/[0.05] transition-colors"
                               >
                                   <Table2 size={14} className="text-[#6b7280]" />
                                   Project List
                               </button>

                               <button
                                   onClick={() => { togglePopout('unifiedCapacity', true); setViewDropdownOpen(false); }}
                                   className="flex items-center gap-3 px-3 py-2 rounded text-xs font-medium text-left text-[#e8e8e8] hover:bg-white/[0.05] transition-colors"
                               >
                                   <Gauge size={14} className="text-amber-500" />
                                   Capacity Command Center
                               </button>
                           </div>
                       </div>
                   )}
               </div>

               <button
                  onClick={handleCollapseAll}
                  className="flex flex-col items-center justify-center gap-1 p-2 text-[#6b7280] hover:text-white hover:bg-white/[0.05] rounded-lg transition-colors min-w-[44px] shrink-0"
                  title="Collapse All Panels"
               >
                   <Minimize2 size={18} />
                   <span className="text-[9px] font-medium hidden lg:block leading-none">Clear</span>
               </button>

               <div className="w-px h-8 bg-white/[0.08] mx-1 hidden sm:block shrink-0" />

               {/* Admin / User Menu */}
               <div className="relative group/user shrink-0">
                   <button className="flex flex-col items-center justify-center gap-1 p-2 text-[#6b7280] hover:text-white hover:bg-white/[0.05] rounded-lg transition-colors min-w-[44px]">
                       <UserIcon size={18} />
                       <span className="text-[9px] font-medium hidden lg:block leading-none">User</span>
                   </button>
                   <div className="absolute right-0 top-full mt-2 w-48 bg-[#141517] border border-white/[0.08] rounded-lg shadow-xl opacity-0 invisible group-hover/user:opacity-100 group-hover/user:visible transition-all z-[100]">
                        <div className="p-3 border-b border-white/[0.06]">
                            <p className="text-sm font-semibold text-white">{user?.name}</p>
                            <p className="text-xs text-[#6b7280]">{user?.email}</p>
                        </div>
                        <button onClick={() => startTransition(() => setView('admin'))} className="w-full text-left px-4 py-2 text-sm text-[#e8e8e8] hover:bg-white/[0.05]">
                            Admin Panel
                        </button>
                        {isPlatformAdmin && onShowPlatformAdmin && (
                          <button onClick={onShowPlatformAdmin} className="w-full text-left px-4 py-2 text-sm text-indigo-400 hover:bg-white/[0.05] flex items-center gap-2">
                            <Shield size={14} /> Platform Admin
                          </button>
                        )}
                        <button onClick={() => setShowPasswordModal(true)} className="w-full text-left px-4 py-2 text-sm text-[#e8e8e8] hover:bg-white/[0.05] flex items-center gap-2">
                            <Key size={14} /> Change Password
                        </button>
                        <button onClick={logout} className="w-full text-left px-4 py-2 text-sm text-rose-400 hover:bg-white/[0.05] flex items-center gap-2">
                            <LogOut size={14} /> Sign Out
                        </button>
                   </div>
               </div>
           </div>
        </div>
      </header>

      {/* Main Workspace */}
      <div className="flex-1 flex overflow-hidden relative">
          
          {/* Left Sidebar (Backlog) */}
          {!gameState.uiState.popouts.backlog && (
              <div id="panel-backlog" className="h-full relative flex z-20 shrink-0">
                 <BacklogPanel 
                    backlog={gameState.backlog}
                    onDragStart={(e, job) => {
                        e.dataTransfer.setData('jobId', job.id);
                        e.dataTransfer.effectAllowed = 'move';
                        setDraggedJob(job);
                    }}
                    onDragEnd={() => setDraggedJob(null)}
                    onJobClick={(job) => setSelectedJob(job)}
                    isOpen={gameState.uiState.backlogOpen}
                    onToggle={() => updateUI({ backlogOpen: !gameState.uiState.backlogOpen })}
                    isPoppedOut={false}
                    onPopOut={() => togglePopout('backlog', true)}
                    onNewQuote={() => setView('quote')}
                    onOpenGraveyard={() => togglePopout('graveyard', true)}
                    width={gameState.uiState.layoutDims.backlogWidth}
                    highlightedJobId={highlightedJobId}
                 />
                 {gameState.uiState.backlogOpen && (
                     <div
                        className="w-2 h-full cursor-col-resize absolute right-0 top-0 z-50 transition-colors group flex items-center justify-center hover:bg-cyan-500/30"
                        onMouseDown={(e) => startResize(e, 'backlog')}
                     >
                        <div className="w-0.5 h-8 bg-white/[0.06] group-hover:bg-cyan-400/70 rounded-full transition-colors" />
                     </div>
                 )}
              </div>
          )}
          
          {/* Main Gantt Board Area - Strictly Flex-1 with min-h-0 to ensure shrinking */}
          <div className="flex-1 flex flex-col min-w-0 bg-[#08090a] relative min-h-0 h-full">
             {/* Board Container: Grows to fill available space, Shrinks when bottom panel grows */}
             <div className="grow shrink basis-0 overflow-hidden relative min-h-0" id="board-main">
                <GanttBoard
                   gameState={gameState}
                   cellWidth={gameState.uiState.cellWidth}
                   onZoomChange={handleZoomChange}
                   onJobDrop={handleJobDropWithCapacityCheck}
                   onJobClick={setSelectedJob}
                   onDayClick={handleDayClick}
                   scheduleEditMode={scheduleEditMode}
                   editTool={editTool}
                   onJobDayToggle={handleJobDayToggle}
                   onJobEffortChange={handleJobEffortChange}
                   onJobResize={handleJobResize}
                   onVisibleDateRangeChange={setVisibleDayStart}
                   scrollToTodayTrigger={scrollToTodayTrigger}
                   onScroll={handleChartScroll}
                   draggedJob={draggedJob}
                   onDragStart={handleDragStart}
                   onDragEnd={handleDragEnd}
                   onHangarReorder={handleHangarReorder}
                   scrollRef={ganttScrollRef}
                   selectedBaseId={gameState.uiState.selectedBaseId}
                   scenarioStart={gameState.uiState.scenarioStart}
                   scenarioEnd={gameState.uiState.scenarioEnd}
                   magicMode={magicState.step === 'selecting'}
                   selectedMagicJobIds={magicState.selectedIds}
                   onMagicJobToggle={handleMagicJobSelection}
                   viewCapacityMode={viewCapacityMode}
                   simplifiedViewMode={simplifiedViewMode}
                   onFindAvailableSlot={handleFindAvailableSlot}
                />
             </div>

             {/* Bottom Docked Panels - Flex Item, shrinks 0 to maintain size */}
             <div className="flex flex-col shrink-0 border-t border-white/[0.06] bg-[#0d0e10] z-30 relative">
                 {!gameState.uiState.popouts.pnl && (
                     <div id="panel-pnl" className="relative">
                        {gameState.uiState.pnlOpen && (
                            <div
                                className="h-2 w-full cursor-row-resize absolute top-0 left-0 z-50 transition-colors group flex items-center justify-center hover:bg-cyan-500/30"
                                onMouseDown={(e) => startResize(e, 'pnl')}
                            >
                                <div className="h-0.5 w-8 bg-white/[0.06] group-hover:bg-cyan-400/70 rounded-full transition-colors" />
                            </div>
                        )}
                        <DailyFinancialTracker 
                            gameState={gameState}
                            visibleDayStart={visibleDayStart}
                            cellWidth={gameState.uiState.cellWidth}
                            isOpen={gameState.uiState.pnlOpen}
                            onToggle={() => updateUI({ pnlOpen: !gameState.uiState.pnlOpen })}
                            isPoppedOut={false}
                            onPopOut={() => togglePopout('pnl', true)}
                            scrollRef={trackerScrollRef}
                            onScroll={handleChartScroll}
                            height={gameState.uiState.layoutDims.pnlHeight}
                            selectedBaseId={gameState.uiState.selectedBaseId}
                        />
                     </div>
                 )}
                 
                 {!gameState.uiState.popouts.capacity && (
                     <div id="panel-capacity" className="relative">
                        {gameState.uiState.capacityOpen && (
                            <div
                                className="h-2 w-full cursor-row-resize absolute top-0 left-0 z-50 transition-colors group flex items-center justify-center hover:bg-cyan-500/30"
                                onMouseDown={(e) => startResize(e, 'capacity')}
                            >
                                <div className="h-0.5 w-8 bg-white/[0.06] group-hover:bg-cyan-400/70 rounded-full transition-colors" />
                            </div>
                        )}
                        <CapacityForecaster 
                            gameState={gameState}
                            visibleDayStart={visibleDayStart}
                            cellWidth={gameState.uiState.cellWidth}
                            isOpen={gameState.uiState.capacityOpen}
                            onToggle={() => updateUI({ capacityOpen: !gameState.uiState.capacityOpen })}
                            isPoppedOut={false}
                            onPopOut={() => togglePopout('capacity', true)}
                            scrollRef={capacityScrollRef}
                            onScroll={handleChartScroll}
                            height={gameState.uiState.layoutDims.capacityHeight}
                            selectedBaseId={gameState.uiState.selectedBaseId}
                        />
                     </div>
                 )}

                 {!gameState.uiState.popouts.analytics && (
                     <div id="panel-analytics" className="relative">
                        {gameState.uiState.analyticsOpen && (
                            <div
                                className="h-2 w-full cursor-row-resize absolute top-0 left-0 z-50 transition-colors group flex items-center justify-center hover:bg-cyan-500/30"
                                onMouseDown={(e) => startResize(e, 'analytics')}
                            >
                                <div className="h-0.5 w-8 bg-white/[0.06] group-hover:bg-cyan-400/70 rounded-full transition-colors" />
                            </div>
                        )}
                        <AnalyticsPanel 
                            gameState={gameState}
                            isOpen={gameState.uiState.analyticsOpen}
                            onToggle={() => updateUI({ analyticsOpen: !gameState.uiState.analyticsOpen })}
                            isPoppedOut={false}
                            onPopOut={() => togglePopout('analytics', true)}
                            scenarioStart={gameState.uiState.scenarioStart || gameState.day}
                            scenarioEnd={gameState.uiState.scenarioEnd || (gameState.day + 30)}
                            setScenarioStart={(d) => updateUI({ scenarioStart: d })}
                            setScenarioEnd={(d) => updateUI({ scenarioEnd: d })}
                            height={gameState.uiState.layoutDims.analyticsHeight}
                            selectedBaseId={gameState.uiState.selectedBaseId}
                        />
                     </div>
                 )}
             </div>
          </div>

          {/* Right Sidebar (Roster) */}
          {!gameState.uiState.popouts.roster && (
              <div id="panel-roster" className="h-full relative flex z-30">
                  {gameState.uiState.rosterOpen && (
                     <div
                        className="w-2 h-full cursor-col-resize absolute left-0 top-0 z-50 transition-colors group flex items-center justify-center hover:bg-cyan-500/30"
                        onMouseDown={(e) => startResize(e, 'roster')}
                     >
                        <div className="w-0.5 h-8 bg-white/[0.06] group-hover:bg-cyan-400/70 rounded-full transition-colors" />
                     </div>
                  )}
                  <RosterPanel 
                      gameState={gameState}
                      isOpen={gameState.uiState.rosterOpen}
                      onToggle={() => updateUI({ rosterOpen: !gameState.uiState.rosterOpen })}
                      width={gameState.uiState.layoutDims.rosterWidth}
                      selectedBaseId={gameState.uiState.selectedBaseId}
                      onPopOut={() => togglePopout('roster', true)}
                  />
              </div>
          )}

      </div>

      {/* --- Popped Out Windows --- */}

      {gameState.uiState.popouts.backlog && (
          <DraggableWindow 
              title="Quotes"
              onClose={() => { togglePopout('backlog', false); updateUI({ backlogOpen: false }); }}
              initialWidth={400} initialHeight={600}
          >
              <BacklogPanel 
                  backlog={gameState.backlog}
                  onDragStart={(e, job) => { e.dataTransfer.setData('jobId', job.id); setDraggedJob(job); }}
                  onDragEnd={() => setDraggedJob(null)}
                  onJobClick={setSelectedJob}
                  isOpen={true}
                  onToggle={() => {}}
                  isPoppedOut={true}
                  onPopOut={() => {}}
                  onNewQuote={() => setView('quote')}
                  onOpenGraveyard={() => togglePopout('graveyard', true)}
                  highlightedJobId={highlightedJobId}
              />
          </DraggableWindow>
      )}

      {gameState.uiState.popouts.graveyard && (
          <DraggableWindow
              title="Project Graveyard"
              onClose={() => togglePopout('graveyard', false)}
              initialWidth={350} initialHeight={500}
          >
              <GraveyardPanel
                  graveyard={gameState.graveyard}
                  onRestore={handleRestoreFromGraveyard}
                  onPermanentDelete={handlePermanentDeleteFromGraveyard}
              />
          </DraggableWindow>
      )}

      {gameState.uiState.popouts.projectList && (
          <DraggableWindow
              title="Project List"
              onClose={() => togglePopout('projectList', false)}
              initialWidth={1200} initialHeight={600}
          >
              <ProjectListPanel
                  gameState={gameState}
                  selectedBaseId={gameState.uiState.selectedBaseId}
              />
          </DraggableWindow>
      )}

      {gameState.uiState.popouts.roster && (
          <DraggableWindow 
              title="Station Roster"
              onClose={() => { togglePopout('roster', false); updateUI({ rosterOpen: false }); }}
              initialWidth={350} initialHeight={600}
          >
              <RosterPanel 
                  gameState={gameState}
                  isOpen={true}
                  onToggle={() => {}}
                  selectedBaseId={gameState.uiState.selectedBaseId}
                  onPopOut={() => {}}
              />
          </DraggableWindow>
      )}

      {gameState.uiState.popouts.pnl && (
          <DraggableWindow 
              title="Daily Financial Tracker"
              onClose={() => { togglePopout('pnl', false); updateUI({ pnlOpen: false }); }}
              initialWidth={800} initialHeight={400}
          >
              <DailyFinancialTracker 
                  gameState={gameState}
                  visibleDayStart={visibleDayStart}
                  cellWidth={Math.max(40, gameState.uiState.cellWidth)}
                  isOpen={true}
                  onToggle={() => {}}
                  isPoppedOut={true}
                  onPopOut={() => {}}
                  selectedBaseId={gameState.uiState.selectedBaseId}
              />
          </DraggableWindow>
      )}

      {gameState.uiState.popouts.capacity && (
          <DraggableWindow 
              title="Capacity Forecaster"
              onClose={() => { togglePopout('capacity', false); updateUI({ capacityOpen: false }); }}
              initialWidth={800} initialHeight={400}
          >
              <CapacityForecaster 
                  gameState={gameState}
                  visibleDayStart={visibleDayStart}
                  cellWidth={Math.max(40, gameState.uiState.cellWidth)}
                  isOpen={true}
                  onToggle={() => {}}
                  isPoppedOut={true}
                  onPopOut={() => {}}
                  selectedBaseId={gameState.uiState.selectedBaseId}
              />
          </DraggableWindow>
      )}

      {gameState.uiState.popouts.analytics && (
          <DraggableWindow 
              title="Station Analytics"
              onClose={() => { togglePopout('analytics', false); updateUI({ analyticsOpen: false }); }}
              initialWidth={800} initialHeight={500}
          >
              <AnalyticsPanel 
                  gameState={gameState}
                  isOpen={true}
                  onToggle={() => {}}
                  isPoppedOut={true}
                  onPopOut={() => {}}
                  scenarioStart={gameState.uiState.scenarioStart || gameState.day}
                  scenarioEnd={gameState.uiState.scenarioEnd || (gameState.day + 30)}
                  setScenarioStart={(d) => updateUI({ scenarioStart: d })}
                  setScenarioEnd={(d) => updateUI({ scenarioEnd: d })}
                  selectedBaseId={gameState.uiState.selectedBaseId}
              />
          </DraggableWindow>
      )}

      {/* --- Modals & Overlays --- */}

      {selectedJob && (
          <Suspense fallback={<ModalLoader message="Loading job details..." />}>
              <JobDetailsModal
                  job={selectedJob}
                  aircraftModels={gameState.aircraftModels}
                  projectStages={gameState.projectStages}
                  onClose={() => setSelectedJob(null)}
                  onSave={(updatedJob) => {
                      pushHistory(gameState, "Updated Job");
                      if ('status' in updatedJob) {
                          setGameState(prev => ({
                              ...prev,
                              schedule: prev.schedule.map(j => j.id === updatedJob.id ? (updatedJob as ScheduledJob) : j)
                          }));
                      } else {
                          setGameState(prev => ({
                              ...prev,
                              backlog: prev.backlog.map(j => j.id === updatedJob.id ? (updatedJob as Job) : j)
                          }));
                      }
                  }}
                  onDelete={(id, permanent) => handleDeleteJob(id, permanent)}
                  onEditQuote={() => {
                      setEditingQuoteJob(selectedJob);
                      setView('quote');
                      setSelectedJob(null);
                  }}
                  onAutoSchedule={(id, start) => calculateAutoSchedule(id, start)}
              />
          </Suspense>
      )}

      {view === 'personnel' && (
          <Suspense fallback={<ModalLoader message="Loading personnel..." />}>
              <PersonnelManager
                  gameState={gameState}
                  onUpdatePersonnel={(p) => setGameState(prev => ({ ...prev, personnel: p }))}
                  onUpdateTeams={(t) => setGameState(prev => ({ ...prev, teams: t }))}
                  onUpdateShifts={(s) => setGameState(prev => ({ ...prev, shifts: s }))}
                  onUpdateRoles={(r) => setGameState(prev => ({ ...prev, roles: r }))}
                  onUpdateHolidays={(h) => setGameState(prev => ({ ...prev, holidays: h }))}
                  onClose={() => setView('board')}
                  activeTabOverride={tutorialTab as any}
              />
          </Suspense>
      )}

      {view === 'config' && (
          <Suspense fallback={<ModalLoader message="Loading configuration..." />}>
              <ConfigurationPanel
                  gameState={gameState}
                  onUpdateHangars={(h) => setGameState(prev => ({ ...prev, hangars: h }))}
                  onUpdateBases={(b) => setGameState(prev => ({ ...prev, bases: b }))}
                  onUpdateAircraft={(m) => setGameState(prev => ({ ...prev, aircraftModels: m }))}
                  onUpdateCustomPackages={(p) => setGameState(prev => ({ ...prev, customAircraftPackages: p }))}
                  onUpdateProjectStages={(s) => setGameState(prev => ({ ...prev, projectStages: s }))}
                  onUpdateCursors={(c) => setGameState(prev => ({ ...prev, cursors: c }))}
                  onClose={() => setView('board')}
                  activeTabOverride={tutorialTab as any}
              />
          </Suspense>
      )}

      {view === 'financials' && (
          <Suspense fallback={<ModalLoader message="Loading financials..." />}>
              <FinancialPanel
                  gameState={gameState}
                  onClose={() => setView('board')}
                  onUpdateCash={(c) => setGameState(prev => ({ ...prev, cash: c }))}
                  onUpdateShopRate={(r) => setGameState(prev => ({ ...prev, shopRate: r }))}
                  onUpdateOverhead={(o) => setGameState(prev => ({ ...prev, overheadDaily: o }))}
                  initialEditMode={financialsInitialEditMode}
                  onUpdateState={(partial) => setGameState(prev => ({ ...prev, ...partial }))}
                  onExpand={() => updateUI({ popouts: { ...gameState.uiState.popouts, cashflow: true } })}
                  activeTabOverride={tutorialTab as any}
              />
          </Suspense>
      )}

      {view === 'quote' && (
          <Suspense fallback={<ModalLoader message="Loading quote builder..." />}>
              <QuoteBuilder
                  gameState={gameState}
                  onClose={() => { setView('board'); setEditingQuoteJob(null); }}
                  onSave={(job) => {
                       pushHistory(gameState, "Updated Quote");
                       const isUpdate = editingQuoteJob && editingQuoteJob.id === job.id;
                       setGameState(prev => {
                           const newState = { ...prev };
                           if (isUpdate) {
                               const inSchedule = prev.schedule.some(j => j.id === job.id);
                               if (inSchedule) {
                                   newState.schedule = prev.schedule.map(j => j.id === job.id ? (job as ScheduledJob) : j);
                               } else {
                                   newState.backlog = prev.backlog.map(j => j.id === job.id ? (job as Job) : j);
                               }
                               const newNote = createNote(`Quote updated for ${job.customer}`);
                               newState.notifications = [...prev.notifications, newNote];
                           } else {
                               newState.backlog = [...prev.backlog, job as Job];
                           }
                           return newState;
                       });
                       if (!isUpdate) {
                           setQuoteSuccess({ active: true, job: job as Job });
                       }
                  }}
                  onUpdateStandardServices={(srv) => setGameState(prev => ({ ...prev, standardServices: srv }))}
                  existingJob={editingQuoteJob}
              />
          </Suspense>
      )}

      {gameState.uiState.popouts.cashflow && (
          <DraggableWindow
              title="Cashflow Forecast (Extended)"
              onClose={() => togglePopout('cashflow', false)}
              initialWidth={800} initialHeight={500}
          >
              <Suspense fallback={<ModalLoader message="Loading cashflow..." />}>
                  <CashflowForecastExpanded gameState={gameState} />
              </Suspense>
          </DraggableWindow>
      )}

      {gameState.uiState.popouts.unifiedCapacity && (
          <DraggableWindow
              title="Capacity Command Center"
              onClose={() => togglePopout('unifiedCapacity', false)}
              initialWidth={1000} initialHeight={650}
          >
              <Suspense fallback={<ModalLoader message="Loading capacity..." />}>
                  <UnifiedCapacityDashboard
                      gameState={gameState}
                      focusedDayIndex={gameState.day}
                      cellWidth={gameState.uiState.cellWidth}
                      selectedBaseId={gameState.uiState.selectedBaseId}
                      onClose={() => togglePopout('unifiedCapacity', false)}
                      onJobClick={setSelectedJob}
                  />
              </Suspense>
          </DraggableWindow>
      )}

      {isSaving && (
          <div className="fixed bottom-4 left-4 bg-[#141517] border border-emerald-500/20 text-emerald-400 px-3 py-1.5 rounded-lg text-xs font-medium flex items-center gap-2 shadow-lg z-[9000]">
              <Save size={12} className="animate-pulse" /> Saving...
          </div>
      )}

    </div>
    </TimelineSyncProvider>
  );
};

const RouterRoot: React.FC = () => {
  const { isAuthenticated, isLoading, isPlatformAdmin, impersonationSession } = useAuth();

  // Track whether platform admin is viewing platform dashboard or main app
  const [showPlatformDashboard, setShowPlatformDashboard] = useState(false);

  // Auto-show platform dashboard for platform admins (unless impersonating)
  useEffect(() => {
    if (isAuthenticated && isPlatformAdmin && !impersonationSession) {
      setShowPlatformDashboard(true);
    } else if (impersonationSession) {
      setShowPlatformDashboard(false);
    }
  }, [isAuthenticated, isPlatformAdmin, impersonationSession]);

  // Show loading state
  if (isLoading) {
    return <PageLoader />;
  }

  // If authenticated, show dashboard or platform admin
  if (isAuthenticated) {
    // Show impersonation banner if active
    const impersonationBanner = impersonationSession ? <ImpersonationBanner /> : null;

    // Platform admin viewing platform dashboard
    if (isPlatformAdmin && showPlatformDashboard && !impersonationSession) {
      return (
        <>
          {impersonationBanner}
          <PlatformDashboard onExitPlatformAdmin={() => setShowPlatformDashboard(false)} />
        </>
      );
    }

    // Regular dashboard (or platform admin viewing as customer)
    return (
      <>
        {impersonationBanner}
        <div className={impersonationSession ? 'pt-10' : ''}>
          <Dashboard onShowPlatformAdmin={isPlatformAdmin ? () => setShowPlatformDashboard(true) : undefined} />
        </div>
      </>
    );
  }

  // Not authenticated - use React Router for marketing pages
  return <RouterProvider router={router} />;
};

const App: React.FC = () => {
  return (
    <AuthProvider>
      <RouterRoot />
    </AuthProvider>
  );
};

export default App;
