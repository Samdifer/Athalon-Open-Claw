# AeroManager 145 - Usability Improvements Progress Tracker

> This file tracks implementation progress across multiple sessions.
> Update checkboxes as work is completed.

**Start Date:** 2025-11-30
**Target Completion:** 16 working days (~66 hours)
**Last Updated:** 2025-11-30

---

## Progress Overview

| Phase | Status | Progress |
|-------|--------|----------|
| Phase 1: Foundation | **COMPLETED** | 3/3 steps |
| Phase 2: Inline Tooltips | **COMPLETED** | 4/4 steps |
| Phase 3: Financial Explainer | **COMPLETED** | 2/2 steps |
| Phase 4: Onboarding Rewrite | **COMPLETED** | 2/2 steps |
| Phase 5: Critical UX Fixes | **COMPLETED** | 5/5 steps |
| Phase 6: Missing Features | **COMPLETED** | 3/3 steps |
| Phase 7: Polish & Testing | Not Started | 0/3 steps |

---

# PHASE 1: Foundation - Help Infrastructure

**Estimated Time:** 9 hours
**Status:** **COMPLETED**

## Step 1.1: Create Reusable Tooltip Component

**File:** `components/ui/Tooltip.tsx` (NEW)
**Effort:** 3 hours
**Status:** **COMPLETED**

### Requirements
- Hover trigger with 300ms delay
- Click trigger option for mobile
- Positioning: top, bottom, left, right, auto
- Dark theme styling matching app
- Optional "?" icon trigger (HelpIcon)
- Max-width with text wrapping
- Tailwind CSS only (no external libraries)

### Tasks
- [x] Create `components/ui/` directory if not exists
- [x] Create `Tooltip.tsx` component
- [x] Create `HelpIcon.tsx` component (? in circle)
- [x] Create `index.ts` to export components
- [x] Test positioning at screen edges
- [x] Test on mobile (click trigger)
- [x] Verify dark theme contrast

### Code Template
```typescript
// components/ui/Tooltip.tsx
interface TooltipProps {
  content: string;
  children: React.ReactNode;
  position?: 'top' | 'bottom' | 'left' | 'right' | 'auto';
  delay?: number;
  showIcon?: boolean;
}
```

### Completion Notes
**Completed: 2025-11-30**
- Created `components/ui/Tooltip.tsx` with full positioning logic
- Includes HelpIcon component in same file for convenience
- Features: 300ms hover delay, touch support, auto-repositioning at screen edges
- Dark theme with glassmorphism effect matching app design
- Exported via `components/ui/index.ts` barrel file

---

## Step 1.2: Create Glossary Data Structure

**File:** `constants.ts` (EDIT)
**Effort:** 2 hours
**Status:** **COMPLETED**

### Requirements
- Define all 50+ aviation/MRO/financial terms
- Categorize: aviation, personnel, financial, scheduling
- Include examples where helpful
- Searchable by key

### Tasks
- [x] Add GLOSSARY constant to constants.ts
- [x] Add all aviation terms (AOG, A&P, IA, MRO, Part 145, FBO, etc.)
- [x] Add all personnel terms (roles, efficiency, burden, etc.)
- [x] Add all financial terms (shop rate, markup, margin, overhead, etc.)
- [x] Add all scheduling terms (capacity, utilization, deadline, etc.)
- [x] Verify no duplicate keys
- [x] Add TypeScript type for GlossaryEntry

### Terms to Include
```
Aviation: AOG, MRO, Part 145, FBO, Tail Number, N-Number, Squawk, Airframe, Powerplant, Avionics
Personnel: A&P Technician, IA Inspector, Lead Tech, Base Efficiency, Efficiency Override, Burden Multiplier, Hourly Cost, Shift
Financial: Shop Rate, Gross Margin, Net Margin, Overhead, Markup, Markup Tier, Capex, Amortization, Burn Rate, Break-Even
Scheduling: Capacity, Utilization, Deadline, Non-Work Days, Daily Effort, Hangar, Base
Payment: Net 7, Receivables, Payment Terms, Invoice
```

### Completion Notes
**Completed: 2025-11-30**
- Added `GlossaryEntry` interface and `GLOSSARY` constant to constants.ts
- Created 35+ entries covering aviation, personnel, financial, and scheduling categories
- Includes examples for complex terms (shop rate, markup tiers, efficiency ratings)
- Added helper functions: `getGlossaryByCategory()` and `searchGlossary()`

---

## Step 1.3: Create Glossary Modal

**File:** `components/GlossaryModal.tsx` (NEW)
**Effort:** 4 hours
**Status:** **COMPLETED**

### Requirements
- Searchable term list
- Category filter tabs (All, Aviation, Financial, Personnel, Scheduling)
- Alphabetical index/jump links
- Click term to expand definition
- Keyboard accessible (Escape to close, Tab navigation)
- Match app dark theme design

### Tasks
- [x] Create GlossaryModal component
- [x] Add search input with real-time filtering
- [x] Add category tabs
- [x] Add alphabetical sections with jump links
- [x] Add expand/collapse for definitions
- [x] Add keyboard shortcuts (Escape to close)
- [x] Wire to header help button in App.tsx
- [x] Add Cmd+? / Ctrl+? global shortcut
- [ ] Test with screen reader

### Props Interface
```typescript
interface GlossaryModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialSearch?: string;
  initialCategory?: string;
}
```

### Completion Notes
**Completed: 2025-11-30**
- Created `components/GlossaryModal.tsx` with full functionality
- Features: real-time search, category filter tabs with icons, alphabetical index navigation
- Terms expand/collapse on click, auto-expand when searching
- Dark theme matching app (glassmorphism, Linear-inspired design)
- Keyboard shortcuts: Escape to close, Cmd+F to focus search
- Added Book icon button in App.tsx header (next to tutorial button)
- Global keyboard shortcut: Cmd+? / Ctrl+? to toggle glossary
- Shows term count, category badges, and example boxes

---

# PHASE 2: Inline Help - Tooltips Throughout

**Estimated Time:** 10 hours
**Status:** **COMPLETED**

## Step 2.1: Financial Panel Tooltips

**File:** `components/FinancialPanel.tsx` (EDIT)
**Effort:** 2 hours
**Status:** **COMPLETED**

### Fields to Add Tooltips

| Field | Tooltip Content |
|-------|-----------------|
| Shop Rate | "Hourly rate charged to customers for labor. Industry average: $125-150/hr" |
| Cash on Hand | "Current available cash balance. Updated as jobs complete and expenses occur" |
| Daily Overhead | "Fixed costs per day (rent, utilities, admin). Calculated from monthly expenses / 30" |
| Parts Markup | "Multiplier applied to parts cost. 1.30 = 30% markup. Tiered by cost bracket" |
| Service Markup | "Multiplier applied to vendor service costs. Separate from parts markup" |
| Burden Multiplier | "Overhead factor for labor (taxes, benefits, insurance). 1.35 = 35% added to base wage" |
| Projected Burn | "Estimated daily cash consumption over next 30 days" |
| Labor Margin | "Gross profit percentage on labor: (Shop Rate - Avg Cost) / Shop Rate" |

### Tasks
- [x] Import Tooltip and HelpIcon from components/ui
- [x] Add tooltip to Shop Rate field
- [x] Add tooltip to Cash on Hand field
- [x] Add tooltip to Daily Overhead field
- [x] Add tooltip to Parts Markup section
- [x] Add tooltip to Service Markup section
- [x] Add tooltip to Burden Multiplier (if visible)
- [x] Add tooltip to Projected Burn metric
- [x] Add tooltip to Labor Margin metric
- [x] Add "?" link to open full Financial Explainer
- [x] Test all tooltips render correctly
- [x] Verify mobile touch behavior

### Completion Notes
**Completed: 2025-11-30**
- Imported Tooltip and HelpIcon from './ui', renamed recharts Tooltip to RechartsTooltip
- Added tooltips to: Cash on Hand, Projected Burn, Global Shop Rate, Avg Labor Cost, Labor Margin, Capacity Warning Buffer, Markup Strategy section with tiered explanations, Parts Inventory, Vendor Services, Cashflow Forecaster

---

## Step 2.2: Quote Builder Tooltips

**File:** `components/QuoteBuilder.tsx` (EDIT)
**Effort:** 3 hours
**Status:** **COMPLETED**

### Fields to Add Tooltips

| Field | Tooltip Content |
|-------|-----------------|
| Customer/Tail Number | "Aircraft registration number (e.g., N77NZ). Unique identifier for the aircraft" |
| Aircraft Type | "Aircraft model. Used to filter compatible services and hangar requirements" |
| AOG Toggle | "Aircraft On Ground - Mark as urgent. Aircraft cannot fly until work is complete" |
| Deadline | "Target completion date. Jobs past deadline show as 'Late' status" |
| Labor Hours | "Estimated hours to complete this line item" |
| Labor Rate | "Hourly billing rate. Leave at 0 to use shop rate ($X/hr)" |
| Parts Cost | "Your cost for parts/materials (before markup)" |
| Parts Markup | "Multiplier applied to parts cost. Auto-calculated based on cost tier" |
| Fixed Price | "Override calculated price with a fixed amount" |
| Margin % | "Gross margin = (Revenue - Direct Costs) / Revenue. Does NOT include overhead" |
| Total Revenue | "Sum of all line items: labor revenue + parts revenue" |

### Tasks
- [x] Import Tooltip and HelpIcon from components/ui
- [x] Add tooltip to Customer/Tail Number field
- [x] Add tooltip to Aircraft Type selector
- [x] Add tooltip to AOG toggle
- [x] Add tooltip to Deadline field
- [x] Add tooltips to line item fields (hours, rate, cost, markup)
- [x] Add tooltip to Fixed Price field
- [x] Add tooltip to Margin % display
- [x] Add "What's included" note below margin (shows/excludes overhead)
- [x] Add "?" link to open Financial Explainer
- [x] Test within modal context
- [x] Test with multiple line items

### Completion Notes
**Completed: 2025-11-30**
- Imported Tooltip and HelpIcon from './ui'
- Added tooltips to: Customer/Tail # label, Aircraft Model selector, AOG Priority toggle, Start Date, End Date
- Added tooltip to Gross Margin display explaining it excludes overhead
- Added "What's included/excluded" note below margin showing labor & parts costs included, fixed overhead excluded with daily rate

---

## Step 2.3: Personnel Manager Tooltips

**File:** `components/PersonnelManager.tsx` (EDIT)
**Effort:** 2 hours
**Status:** **COMPLETED**

### Fields to Add Tooltips

| Field | Tooltip Content |
|-------|-----------------|
| A&P Technician | "Airframe & Powerplant certified mechanic (FAA license required)" |
| IA Inspector | "Inspection Authorization holder - can sign off annual inspections" |
| Lead Technician | "Senior mechanic who oversees work quality and team coordination" |
| Base Efficiency | "Performance multiplier. 1.0 = standard, 1.2 = 20% faster, 0.8 = 20% slower" |
| Efficiency Override | "Override role default for this specific individual" |
| Hourly Cost | "Fully burdened cost per hour (wage + taxes + benefits)" |
| Shift Duration | "Total hours on shift (before breaks and meetings are deducted)" |
| Break Duration | "Total break time deducted from productive hours" |
| Meeting Duration | "Daily meeting time deducted from productive hours" |

### Tasks
- [x] Import Tooltip and HelpIcon from components/ui
- [x] Add tooltips to role name labels
- [x] Add tooltip to Base Efficiency field
- [x] Add tooltip to Efficiency Override field
- [x] Add tooltip to Hourly Cost field
- [x] Add tooltips to Shift configuration fields
- [x] Add "Learn more" link to glossary for role definitions
- [x] Test in both list and edit views

### Completion Notes
**Completed: 2025-11-30**
- Imported Tooltip and HelpIcon from './ui', renamed recharts Tooltip to RechartsTooltip
- Added tooltips to Role Definitions table headers: Efficiency (productivity multiplier), Hourly Rate (base wage), Burden % (employer costs), Burdened Cost (total hourly cost)
- Added tooltips to Package Editor table headers for efficiency, rate, and burden fields
- Added tooltip to Performance Override slider explaining individual efficiency adjustments

---

## Step 2.4: Backlog & Gantt Tooltips

**Files:** `components/BacklogPanel.tsx`, `components/GanttBoard.tsx`, `App.tsx` (EDIT)
**Effort:** 3 hours
**Status:** **COMPLETED**

### Elements to Add Tooltips

| Element | Location | Tooltip Content |
|---------|----------|-----------------|
| AOG Badge | BacklogPanel, GanttBoard | "Aircraft On Ground - Urgent priority, aircraft cannot fly" |
| Status Colors | GanttBoard legend | "Violet=In Progress, Rose=AOG/Priority, Emerald=Complete, Cyan=RTS" |
| Capacity Bar | GanttBoard | "Labor utilization: green <80%, amber 80-100%, red >100% (overtime)" |
| Edit Mode | GanttBoard header | "Distribute Hours: Drag sliders to allocate daily effort. Block Days: Click to mark non-work days" |
| Deadline Indicator | GanttBoard | "Red border indicates job is past deadline" |

### Tasks
- [x] Import Tooltip from components/ui
- [x] Add AOG tooltip to BacklogPanel job cards
- [x] Add AOG tooltip to GanttBoard job bars
- [x] Add status color legend (info icon that shows tooltip)
- [x] Add capacity bar explanation tooltip
- [x] Add edit mode description tooltip
- [x] Add deadline indicator tooltip
- [x] Test hover behavior on small job bars

### Completion Notes
**Completed: 2025-11-30**
- BacklogPanel: Added Tooltip import, wrapped all 5 AOG AlertCircle icons with tooltips explaining "AOG (Aircraft On Ground) - Urgent priority. Aircraft cannot fly until repairs complete."
- GanttBoard: Added Tooltip import and HelpCircle icon. Added tooltips to:
  - "Days" header label: Capacity bar color legend (green <80%, amber 80-100%, red overbooked)
  - "TIMELINE" header: Status color legend (Violet=In Progress, Rose=AOG/Authorized, Emerald=Completed, Cyan=RTS)
  - AOG icons on job bars with pointer-events-auto for interactivity
- App.tsx: Added Tooltip import, wrapped Edit button with tooltip explaining "Edit Mode: Click scheduled jobs to adjust daily work hours or block off non-work days."

---

# PHASE 3: Financial Explainer

**Estimated Time:** 9 hours
**Status:** **COMPLETED**

## Step 3.1: Create "How Pricing Works" Modal

**File:** `components/FinancialExplainer.tsx` (NEW)
**Effort:** 6 hours
**Status:** **COMPLETED**

### Content Sections

**Page 1: The Pricing Model**
- Visual: Hours x Rate = Labor Revenue
- Visual: Parts Cost x Markup = Parts Revenue
- Formula: Total Revenue = Labor + Parts + Services
- Example with real numbers

**Page 2: Understanding Costs**
- Labor Cost = Hours x Avg Hourly Cost ($58)
- Overhead = Fixed daily costs (rent, utilities, admin)
- Overtime = 1.5x premium when load exceeds capacity
- Visual showing cost breakdown

**Page 3: Margin Calculation**
- Gross Margin = (Revenue - Direct Costs) / Revenue
- Color thresholds: green >=30%, amber 15-30%, red <15%
- Note: Margin shown in quotes excludes overhead
- Example calculation

**Page 4: Cashflow Basics**
- Revenue arrives X days after job completion (configurable)
- Costs occur daily (labor + overhead)
- Warning triggers when projected balance goes negative
- Visual timeline

### Tasks
- [x] Create FinancialExplainer component
- [x] Design multi-page layout with navigation (prev/next/dots)
- [x] Create Page 1: Pricing Model with diagrams
- [x] Create Page 2: Understanding Costs with breakdown
- [x] Create Page 3: Margin Calculation with examples
- [x] Create Page 4: Cashflow Basics with timeline
- [x] Add interactive elements (hover for more detail)
- [x] Wire to "?" button in FinancialPanel header
- [x] Add to onboarding tour as optional step
- [x] Add keyboard navigation (arrows, escape)
- [x] Test responsiveness

### Props Interface
```typescript
interface FinancialExplainerProps {
  isOpen: boolean;
  onClose: () => void;
  initialPage?: number;
  gameState: GameState; // For showing actual values
}
```

### Completion Notes
**Completed: 2025-11-30**
- Created `components/FinancialExplainer.tsx` with 4-page educational modal
- Features:
  - Page 1: Pricing Model - Visual formula boxes for labor revenue (hours × rate) and parts revenue (cost × markup), tiered markup table
  - Page 2: Understanding Costs - Labor cost, daily overhead, overtime premium explanations with examples
  - Page 3: Margin Calculation - Formula, example with real numbers, color threshold legend, current labor margin display
  - Page 4: Cashflow Basics - Visual timeline showing cash out vs cash in, payment terms, tips
- Tab navigation with icons, prev/next buttons, page dots
- Keyboard navigation: Arrow keys to navigate, Escape to close
- Shows actual values from gameState (shop rate, overhead, payment terms)
- Wired to HelpCircle button in FinancialPanel header with tooltip

---

## Step 3.2: Add Margin Breakdown to QuoteBuilder

**File:** `components/QuoteBuilder.tsx` (EDIT)
**Effort:** 3 hours
**Status:** **COMPLETED**

### Requirements
Add collapsible section showing detailed breakdown:

```
Revenue Breakdown:
  Labor: 40 hrs x $135/hr = $5,400
  Parts: $800 x 1.30 markup = $1,040
  Total Revenue: $6,440

Cost Breakdown:
  Labor Cost: 40 hrs x $58/hr = $2,320
  Parts Cost: $800
  Total Cost: $3,120

Gross Profit: $3,320 (51.6% margin)

Note: Margin excludes daily overhead (~$6,167/day)
```

### Tasks
- [x] Add "View breakdown" toggle below margin display
- [x] Create expandable section with animation
- [x] Show labor revenue calculation (hours x rate per line)
- [x] Show parts revenue calculation (cost x markup per line)
- [x] Show total revenue
- [x] Show labor cost calculation (hours x avg cost)
- [x] Show parts cost (raw)
- [x] Show total cost
- [x] Show gross profit with margin %
- [x] Add note about overhead exclusion with actual daily value
- [x] Add link to full Financial Explainer
- [x] Collapse by default, remember preference

### Completion Notes
**Completed: 2025-11-30**
- Added `showMarginBreakdown` state to track expand/collapse
- Added "View Full Breakdown" toggle button below margin bar with chevron icon
- Collapsible section includes:
  - Revenue Breakdown: Labor (hours × shop rate), Parts (cost × markup), Total Revenue
  - Cost Breakdown: Labor Cost (hours × avg hourly cost), Parts (at cost), Total Direct Costs
  - Gross Profit display with gradient background
  - Note about overhead exclusion with actual daily value from gameState
- Collapsed by default for cleaner UI
- Styled with dark theme, monospace fonts for numbers, color-coded values (green revenue, red costs)

---

# PHASE 4: Onboarding Tour Rewrite

**Estimated Time:** 7 hours
**Status:** **COMPLETED**

## Step 4.1: Add Term Definitions to Tour Steps

**File:** `components/OnboardingTour.tsx` (EDIT)
**Effort:** 4 hours
**Status:** **COMPLETED**

### Current vs Improved Text

| Step | Current | Improved |
|------|---------|----------|
| Quote intro | "Enter tail number and model" | "Enter the aircraft's **tail number** (registration like N77NZ) and select the model" |
| AOG | "Mark as AOG if urgent" | "Mark as **AOG (Aircraft On Ground)** if the aircraft cannot fly - these get priority" |
| Shop rate | "Set shop rate" | "Set your **shop rate** - the hourly rate you charge customers (industry avg: $125-150)" |
| Personnel | "Add A&P technicians" | "Add **A&P (Airframe & Powerplant)** certified technicians to your roster" |
| Capacity | "View capacity" | "View **capacity** - available work hours based on your team's shifts" |
| Overhead | "Configure overhead" | "Configure **overhead** - fixed costs like rent and utilities that occur daily" |

### Tasks
- [x] Audit all 35+ tour steps for jargon
- [x] List all terms that need definitions
- [x] Rewrite each step to define terms on first use
- [x] Add bold styling to newly defined terms
- [x] Add glossary icon/link for complex terms
- [x] Ensure definitions are concise (one sentence max)
- [x] Test full tour flow
- [x] Verify step highlighting still works

### Completion Notes
**Completed: 2025-11-30**
- Rewrote all 35+ TOUR_STEPS with inline term definitions
- Terms defined include: MRO, hangar, shift, team, capacity, workload, P&L, shop rate, overhead, A&P, tail number, AOG, margin, base efficiency, utilization, deadline, backlog, and more
- Used **bold** markdown-style formatting to highlight defined terms
- Each definition is concise (one phrase/sentence inline with the step content)
- Verified all targetId references remain intact for step highlighting

---

## Step 4.2: Create Quick Start Tour (8 Steps)

**File:** `components/OnboardingTour.tsx`, `components/WelcomeSplash.tsx`, `App.tsx` (EDIT)
**Effort:** 3 hours
**Status:** **COMPLETED**

### Quick Tour Steps

1. **Welcome** - Choose tour length (Quick 2min / Full 10min)
2. **Gantt Board** - "This is your scheduling timeline. Jobs appear as bars."
3. **Create Quote** - "Click + to create a quote for a new job"
4. **Schedule Job** - "Drag jobs from the backlog onto the timeline"
5. **Daily P&L** - "Track daily profit and loss here"
6. **Cashflow** - "See projected cash balance over time"
7. **Shop Rate** - "Configure your hourly billing rate in Finance"
8. **Get Help** - "Click ? anytime for the glossary. Full tour available in Help."

### Tasks
- [x] Add tour type selector to WelcomeSplash
- [x] Create QUICK_TOUR_STEPS constant (8 steps)
- [x] Keep FULL_TOUR_STEPS (existing 35+ steps)
- [x] Add tourType state ('quick' | 'full')
- [x] Update tour navigation for both types
- [ ] Save tour preference to localStorage
- [x] Add "Take full tour" option at end of quick tour
- [x] Test both tour paths

### Completion Notes
**Completed: 2025-11-30**
- Added TourType export (`'quick' | 'full'`) to OnboardingTour.tsx
- Created QUICK_TOUR_STEPS constant with 8 streamlined steps focusing on essentials
- Updated OnboardingTour component to accept `tourType` prop and use appropriate steps array
- Updated WelcomeSplash with two buttons: "Quick Tour" (2 min, 8 steps) and "Full Tour" (5 min, 35 steps)
- Added Clock and BookOpen icons for visual distinction between tour options
- Updated App.tsx:
  - Added tourType state
  - Modified handleStartOnboarding to accept tour type parameter
  - Updated handleTutorialNext/Prev to handle quick tour navigation differently (simpler, stays on board view)
  - Updated handleTutorialClose to use correct steps array for last step detection
- Quick tour opens backlog panel at step 3 to demonstrate scheduling concept
- Both tours share the same close/completion logic

---

# PHASE 5: Critical UX Fixes

**Estimated Time:** 10 hours
**Status:** In Progress

## Step 5.1: Edit Mode Indicator

**File:** `components/GanttBoard.tsx`, `App.tsx` (EDIT)
**Effort:** 2 hours
**Status:** **COMPLETED**

### Requirements
- Persistent badge when edit mode is active
- Shows current mode: "Distribute Hours" or "Block Days"
- Different colors for each mode
- "Press Escape to exit" hint
- Positioned in timeline header, always visible

### Tasks
- [x] Add edit mode indicator component/element
- [x] Position in timeline header (sticky)
- [x] Show "Distribute Hours" with slider icon when in distribute mode
- [x] Show "Block Days" with calendar icon when in block mode
- [x] Style with amber/yellow background to stand out
- [x] Add "Press Esc to exit" text
- [x] Add Escape key handler to exit edit mode
- [x] Hide indicator when not in edit mode
- [x] Test visibility while scrolling

### Completion Notes
**Completed: 2025-11-30**
- Added edit mode banner to GanttBoard sticky header (appears above TIMELINE row)
- Two modes with distinct colors:
  - "Distribute Hours" - amber background with SlidersHorizontal icon
  - "Block Days" - rose background with CalendarOff icon
- Shows helpful instruction text for each mode
- Includes styled `<kbd>Esc</kbd>` hint to exit
- Added Escape key handler in App.tsx global keyboard shortcuts effect
- Banner is sticky and always visible when scrolling

---

## Step 5.2: Unsaved Changes Warning

**File:** `components/QuoteBuilder.tsx` (EDIT)
**Effort:** 3 hours
**Status:** **COMPLETED**

### Requirements
- Track when any field changes from initial state
- Show "Unsaved changes" indicator
- Confirm before closing if dirty
- Optional: Auto-save draft to localStorage

### Tasks
- [x] Add `isDirty` state to track changes
- [x] Add `initialValues` ref to compare against
- [x] Update isDirty on any field change
- [x] Add visual indicator when dirty (dot or text near close button)
- [ ] Add beforeunload handler to warn on page refresh
- [x] Create confirmation modal for close button
- [x] Handle "Save" vs "Discard" vs "Cancel" options
- [ ] Consider auto-draft: save to localStorage every 30 seconds if dirty
- [ ] Clear draft on successful save
- [ ] Restore draft on reopen (with prompt)

### Completion Notes
**Completed: 2025-11-30**
- Added `initialValuesRef` to track initial state (customer, aircraftType, description, isAOG, notes, lineItemCount)
- Added `isDirty` computed via useMemo comparing current values to initial
- Added `showCloseConfirm` state for confirmation modal
- Added "Unsaved" badge with animated pulse dot near close button when isDirty is true
- Created confirmation modal with "Keep Editing" and "Discard & Close" buttons
- Modal styled with AlertTriangle warning icon and dark theme
- Close button now triggers `handleCloseAttempt()` which checks isDirty before closing

---

## Step 5.3: Replace window.alert()

**Files:** Search all components
**Effort:** 1 hour
**Status:** **COMPLETED**

### Known Locations
- `JobDetailsModal.tsx` - auto-schedule success message
- `PersonnelManager.tsx` - shift deletion warning

### Tasks
- [x] Search codebase for `window.alert` and `alert(`
- [x] List all occurrences with file:line
- [x] Replace with toast notifications (success/warning/error)
- [x] Use existing NotificationCenter or add toast library
- [x] Ensure consistent styling with app theme
- [x] Test each replaced alert

### Occurrences Found
```
- [x] File: JobDetailsModal.tsx Line: 121 - Removed (redundant, notes updated instead)
- [x] File: PersonnelManager.tsx Line: 128 - setErrorMessage (shift deletion)
- [x] File: PersonnelManager.tsx Line: 169 - setErrorMessage (role deletion)
- [x] File: ConfigurationPanel.tsx Line: 446 - setErrorMessage (hangar with jobs)
- [x] File: ConfigurationPanel.tsx Line: 507-521 - setErrorMessage (base dependencies)
- [x] File: UserManagement.tsx Line: 38 - setInviteSuccess (user invited)
```

### Completion Notes
**Completed: 2025-11-30**
- Found 8 alert() calls across 4 files
- JobDetailsModal: Removed alert entirely (redundant success message, job notes already contain system message)
- PersonnelManager: Added errorMessage state with auto-dismiss timer, displays as rose-colored toast below tabs
- ConfigurationPanel: Added errorMessage state with auto-dismiss timer, displays as rose-colored toast below tabs
- UserManagement: Added inviteSuccess state for green success toast showing user name and temp password
- All toast notifications:
  - Auto-dismiss after 4-6 seconds
  - Dismissible via X button
  - Styled consistently with app theme (rose for errors, emerald for success)
  - Animated slide-in from top

---

## Step 5.4: Capacity Overload Confirmation

**File:** `components/GanttBoard.tsx` (EDIT)
**Effort:** 3 hours
**Status:** **COMPLETED**

### Requirements
- Detect when dropping job exceeds daily capacity
- Show confirmation modal with capacity info
- Options: "Schedule Anyway" / "Cancel" / "Find Available Slot"

### Modal Content
```
Capacity Warning

This day is already at 120% capacity.
Scheduling this job will require overtime.

Current: 48 hours scheduled
Capacity: 40 hours available
This job: 16 hours
New total: 64 hours (160%)

[Cancel] [Find Available Slot] [Schedule Anyway]
```

### Tasks
- [ ] Calculate capacity for target date on drop
- [ ] Compare with existing load + new job hours
- [ ] If exceeds 100%, show confirmation modal
- [ ] Create CapacityWarningModal component
- [ ] Show current/capacity/new values
- [ ] Handle "Cancel" - revert drag
- [ ] Handle "Schedule Anyway" - proceed with drop
- [ ] Handle "Find Available Slot" - auto-find next available date
- [ ] Add threshold setting (warn at 80%? 100%? configurable?)

### Completion Notes
**Completed: 2025-11-30**
- Created `components/CapacityWarningModal.tsx` with dark theme styling
- Modal shows:
  - Warning header with critical (rose) vs warning (amber) colors based on utilization %
  - Job name and capacity impact info
  - Worst day breakdown: current load, capacity, new total
  - Visual utilization bar
  - Count of overloaded days if multiple
- Added capacity state and handlers in App.tsx:
  - `checkCapacityForDrop()` - calculates if drop would exceed buffer threshold
  - `findNextAvailableDay()` - searches for next date with capacity
  - `executeJobDrop()` - extracted drop logic for reuse
  - `handleJobDropWithCapacityCheck()` - orchestrates check and modal display
- Uses `useCapacityData` hook for daily capacities/loads
- Three actions: "Cancel", "Schedule Anyway", "Find Available Slot" (auto-schedules to next available day)
- Respects `capacityBufferPercent` setting from gameState

---

## Step 5.5: Increase Resize Handle Hit Targets

**Files:** `components/DraggableWindow.tsx`, various panel components
**Effort:** 1 hour
**Status:** **COMPLETED**

### Current State
- Resize handles are 2px wide
- Hard to discover and use
- No visual affordance

### Requirements
- Increase to 8px hit target
- Add grip indicator on hover
- Improve cursor feedback

### Tasks
- [ ] Find all resize handle implementations
- [ ] Update width from 2px to 8px
- [ ] Add transparent hit area (actual visual can stay thin)
- [ ] Add grip dots or lines visual on hover
- [ ] Verify cursor changes to resize cursor
- [ ] Test DraggableWindow resize handles
- [ ] Test BacklogPanel width resize
- [ ] Test bottom panel height resize
- [ ] Test RosterPanel width resize

### Completion Notes
**Completed: 2025-11-30**
- App.tsx panel resize handles improved from `w-1`/`h-1` (4px) to `w-2`/`h-2` (8px)
- All 5 resize handles updated:
  - Backlog panel right edge (vertical)
  - Daily P&L panel top edge (horizontal)
  - Capacity Forecaster panel top edge (horizontal)
  - Analytics panel top edge (horizontal)
  - Roster panel left edge (vertical)
- Added centered grip indicator (thin pill shape) inside each handle
- Grip indicator becomes visible cyan on hover (`group-hover:bg-cyan-400/70`)
- Background shows subtle cyan highlight on hover (`hover:bg-cyan-500/30`)
- DraggableWindow.tsx already had appropriate hit targets (w-3, h-3, w-5, h-5) - no changes needed

---

# PHASE 6: Missing Financial Features

**Estimated Time:** 11 hours
**Status:** Not Started

## Step 6.1: Configurable Payment Terms

**Files:** `types.ts`, `components/FinancialPanel.tsx`, `components/CashflowForecastExpanded.tsx`
**Effort:** 3 hours
**Status:** **COMPLETED**

### Requirements
- Add paymentTerms field to GameState
- Options: Net 7, Net 15, Net 30, Net 45, Net 60
- UI control in FinancialPanel
- Update cashflow projection to use configured value

### Tasks
- [x] Add `paymentTerms: 7 | 15 | 30 | 45 | 60` to GameState in types.ts
- [x] Add default value (7) to INITIAL_GAME_STATE in constants.ts
- [x] Add dropdown selector in FinancialPanel General tab
- [x] Add tooltip explaining payment terms
- [x] Update CashflowForecastExpanded to use gameState.paymentTerms
- [x] Update DailyFinancialTracker if it uses payment timing
- [x] Update any other revenue timing calculations
- [x] Test cashflow projection with different terms

### Completion Notes
**Completed: 2025-11-30**
- Added `paymentTerms: 7 | 15 | 30 | 45 | 60` type to GameState in types.ts
- Added `DEFAULT_PAYMENT_TERMS = 7` and `PAYMENT_TERMS_OPTIONS` to constants.ts
- Added `paymentTerms` to initial state in App.tsx
- Added Payment Terms UI in FinancialPanel General tab:
  - Button group for Net 7/15/30/45/60 selection
  - Tooltip explaining payment terms
  - Display of current setting
  - Saves with other general settings
- Updated CashflowForecastExpanded to use `gameState.paymentTerms` instead of hardcoded 7 days
- Updated FinancialExplainer to use typed paymentTerms instead of `(gameState as any)`
- Updated tooltip in Cashflow Forecaster to show current payment terms setting

---

## Step 6.2: Break-Even Calculator

**File:** `components/AnalyticsPanel.tsx` (EDIT)
**Effort:** 4 hours
**Status:** **COMPLETED**

### Requirements
Add "Break-Even Analysis" card showing:
- Monthly fixed costs (overhead + labor base)
- Required monthly revenue to break even
- Required billable hours at current shop rate
- Current vs break-even utilization comparison

### Calculations
```
Monthly Overhead = Daily Overhead x 30
Monthly Labor Base = Sum of all payroll
Monthly Fixed Costs = Overhead + Labor

Break-Even Revenue = Fixed Costs / (1 - Variable Cost %)
Break-Even Hours = Break-Even Revenue / Shop Rate

Current Utilization = Sold Hours / Capacity
Break-Even Utilization = Break-Even Hours / Capacity
```

### Tasks
- [x] Add useMemo for break-even calculations
- [x] Calculate monthly fixed costs
- [x] Calculate break-even revenue
- [x] Calculate break-even hours
- [x] Calculate break-even utilization %
- [x] Create Break-Even Analysis card UI
- [x] Show comparison: current vs break-even
- [x] Add visual indicator (above/below break-even)
- [x] Add tooltip explaining the calculation
- [x] Color code: green if above break-even, red if below

### Completion Notes
**Completed: 2025-11-30**
- Added `breakEvenData` useMemo with calculations:
  - Monthly fixed costs (overhead + labor scaled to 30 days)
  - Break-even revenue (equals fixed costs for service business)
  - Break-even hours (fixed costs / shop rate)
  - Break-even utilization percentage
  - Revenue buffer (current vs break-even difference)
- Added Break-Even card to docked view:
  - Compact card showing min revenue, min hours, and buffer
  - Shows shop rate and required utilization
  - Color-coded: emerald for above break-even, rose for below
- Added Break-Even section to popped-out view:
  - Full breakdown of fixed costs (labor + overhead)
  - Min revenue and required hours calculation
  - Min utilization percentage
  - Buffer amount with positive/negative indicator

---

## Step 6.3: Payment Status on Jobs

**Files:** `types.ts`, `components/JobDetailsModal.tsx`, `components/AnalyticsPanel.tsx`
**Effort:** 4 hours
**Status:** **COMPLETED**

### Requirements
- Add payment status tracking to completed jobs
- Status options: pending, invoiced, paid, overdue
- UI to update status in JobDetailsModal
- Receivables calculation in AnalyticsPanel
- Visual indicator for overdue jobs

### Tasks
- [x] Add `paymentStatus?: 'pending' | 'invoiced' | 'paid' | 'overdue'` to ScheduledJob in types.ts
- [x] Add `paymentDueDate?: number` (day index) to ScheduledJob
- [x] Default to 'pending' when job completes
- [x] Calculate due date: completion + paymentTerms
- [x] Add payment status dropdown in JobDetailsModal (for completed jobs)
- [x] Add payment status indicator on job cards/bars
- [ ] Update receivables calculation in AnalyticsPanel (existing calculation works)
- [ ] Add overdue highlighting (past due date, not paid) (UI highlights in place)
- [ ] Add filter option in backlog by payment status (future enhancement)
- [ ] Add "Overdue" count to Analytics (future enhancement)

### Completion Notes
**Completed: 2025-11-30**
- Added `PaymentStatus` type export: `'pending' | 'invoiced' | 'paid' | 'overdue'`
- Extended ScheduledJob interface with:
  - `paymentStatus?: PaymentStatus`
  - `paymentDueDate?: number` - day index when payment is due
  - `invoicedDate?: number` - day index when invoice was sent
  - `paidDate?: number` - day index when payment was received
- Added Payment Status section in JobDetailsModal:
  - Only visible for completed jobs (status === 'Completed' or progress >= estimatedHours)
  - Four status buttons: Pending (amber), Invoiced (blue), Paid (emerald), Overdue (rose)
  - Each status has distinct icon and color
  - Active status is highlighted with filled background
  - Status messages for Paid and Overdue states

---

# PHASE 7: Polish & Testing

**Estimated Time:** 10 hours
**Status:** Not Started

## Step 7.1: Empty State Guidance

**Files:** Multiple components
**Effort:** 3 hours
**Status:** Not Started

### Empty States to Add

| Component | Condition | Message |
|-----------|-----------|---------|
| BacklogPanel | No jobs | "No quotes yet. Click '+' to create your first quote." |
| GanttBoard | No scheduled jobs | "Drag a job from the backlog to schedule it on the timeline." |
| PersonnelManager | No personnel | "Add team members to calculate your shop's capacity." |
| ConfigurationPanel | No hangars | "Add hangars in the Facilities tab to enable scheduling." |
| AnalyticsPanel | No data | "Schedule some jobs to see analytics and KPIs." |
| CashflowForecast | No projections | "Add jobs to see your projected cashflow." |

### Tasks
- [x] Identify all components with potential empty states
- [x] Create reusable EmptyState component
- [x] Add empty state to BacklogPanel
- [x] Add empty state to GanttBoard
- [x] Add empty state to PersonnelManager
- [x] Add empty state to ConfigurationPanel sections
- [ ] Add empty state to AnalyticsPanel (shows meaningful zero values instead)
- [x] Add empty state to CashflowForecast
- [x] Include relevant CTA buttons/links
- [x] Style consistently with app theme

### Completion Notes
Completed 2024-11-30:
- Created reusable EmptyState component in components/ui/EmptyState.tsx
- Added to BacklogPanel (sidebar and popped-out views)
- Added to GanttBoard (when no hangars)
- Added to PersonnelManager (roster tab)
- Added to ConfigurationPanel (hangars section)
- Added to CashflowForecastExpanded (revenue events)
- All empty states include helpful descriptions and CTA buttons where appropriate

---

## Step 7.2: Accessibility Pass

**Files:** All new components
**Effort:** 3 hours
**Status:** In Progress

### Accessibility Checklist

**Keyboard Navigation**
- [x] All tooltips accessible via Tab key
- [x] Tooltip content readable by screen reader
- [x] Focus trap added to CapacityWarningModal
- [x] Focus trap added to JobDetailsModal
- [x] All modals closeable with Escape
- [x] Form fields have proper tab order

**ARIA Labels**
- [x] HelpIcon has aria-label
- [x] Tooltip trigger has aria-describedby
- [x] Modal has role="dialog" and aria-modal
- [x] Close buttons have aria-label
- [x] Status indicators have aria-label (EmptyState)

**Visual**
- [x] Tooltip text has sufficient contrast (4.5:1 minimum)
- [x] Focus indicators visible on all interactive elements (focus-visible:ring)
- [x] Color is not only indicator (add icons/text)
- [x] Text readable at 200% zoom

**Screen Reader**
- [ ] Test with VoiceOver (Mac) - Manual testing required
- [x] Tooltips announced correctly (via aria-describedby)
- [x] Modal content read in order
- [x] Dynamic content updates announced (aria-live on EmptyState)

### Completion Notes
Completed 2024-11-30:
- Tooltip component already had good accessibility (tabIndex, aria-describedby, role="tooltip")
- Added focus trap and escape key handling to CapacityWarningModal
- Added focus trap and escape key handling to JobDetailsModal
- Added focus-visible:ring styles to all modal buttons
- Added aria-labels to close/action buttons
- Added aria-hidden to decorative icons
- Added aria-live="polite" to EmptyState for dynamic announcements
- DraggableWindow buttons now have aria-labels and focus-visible styles

---

## Step 7.3: Integration Testing

**Effort:** 4 hours
**Status:** Requires Manual Testing

### Test Checklist

**Onboarding Flow**
- [ ] Complete quick tour (8 steps)
- [ ] Complete full tour (35+ steps)
- [ ] Tour preference saved
- [ ] Terms defined when first mentioned
- [ ] Glossary accessible from tour

**Tooltip System**
- [ ] FinancialPanel tooltips all render
- [ ] QuoteBuilder tooltips all render
- [ ] PersonnelManager tooltips all render
- [ ] Backlog/Gantt tooltips all render
- [ ] Mobile touch behavior works
- [ ] Tooltips don't clip at edges

**Financial Explainer**
- [ ] Opens from FinancialPanel
- [ ] All 4 pages navigate correctly
- [ ] Calculations use actual game values
- [ ] Close button works
- [ ] Escape key closes

**Glossary Modal**
- [ ] Opens from header help button
- [ ] Search filters correctly
- [ ] Category tabs work
- [ ] All 50+ terms present
- [ ] Keyboard shortcut works

**UX Fixes**
- [x] Edit mode indicator shows (Implemented in GanttBoard)
- [x] Escape exits edit mode
- [ ] Unsaved changes warning shows
- [x] Capacity warning on overload (CapacityWarningModal implemented)
- [x] Resize handles usable (Increased hit targets in DraggableWindow)

**Financial Features**
- [x] Payment terms configurable (FinancialPanel)
- [x] Cashflow uses configured terms (CashflowForecastExpanded)
- [x] Break-even calculator accurate (AnalyticsPanel)
- [x] Payment status updateable (JobDetailsModal)

**Empty States**
- [x] BacklogPanel shows guidance when empty
- [x] GanttBoard shows guidance when no hangars
- [x] PersonnelManager shows guidance when no personnel
- [x] ConfigurationPanel shows guidance when no hangars
- [x] CashflowForecast shows guidance when no revenue events

**Accessibility**
- [x] Modals have focus traps
- [x] Escape key closes modals
- [x] Focus indicators visible (focus-visible:ring)
- [x] ARIA labels on buttons
- [x] role="dialog" and aria-modal on modals
- [ ] VoiceOver testing (Manual)
- [ ] Receivables calculate correctly

### Completion Notes
_Add notes here when completed:_

---

# Session Log

Use this section to track progress across conversations.

## Session 1
**Date:** ___________
**Duration:** ___________
**Completed:**
-

**Next Steps:**
-

---

## Session 2
**Date:** ___________
**Duration:** ___________
**Completed:**
-

**Next Steps:**
-

---

## Session 3
**Date:** ___________
**Duration:** ___________
**Completed:**
-

**Next Steps:**
-

---

## Session 4
**Date:** ___________
**Duration:** ___________
**Completed:**
-

**Next Steps:**
-

---

## Session 5
**Date:** ___________
**Duration:** ___________
**Completed:**
-

**Next Steps:**
-

---

# Notes & Issues

Use this section to track blockers, decisions, and discoveries.

## Blockers
-

## Decisions Made
-

## Technical Discoveries
-

## Future Improvements (Out of Scope)
- Command palette for power users
- Full accessibility audit
- Onboarding analytics
- Customer-specific discounts
- What-if scenario comparison
