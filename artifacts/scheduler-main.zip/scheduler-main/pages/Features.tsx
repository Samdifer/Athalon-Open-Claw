import React from 'react';
import { HeroSection, Section, RevealOnScroll } from '../components/layout';
import { Button, Card, CardContent, Badge } from '../components/ui';
import {
  Calendar,
  DollarSign,
  Users,
  BarChart3,
  FileText,
  Settings,
  ArrowRight,
  Zap,
  Clock,
  AlertTriangle,
  CheckCircle2,
  TrendingUp,
  Target,
  Layers,
  Shield,
  Play,
  GitBranch,
  PieChart,
  Briefcase,
  Wrench,
  Bell,
  Search,
} from 'lucide-react';

const Features: React.FC = () => {
  // Main feature categories for the overview
  const featureCategories = [
    {
      id: 'scheduling',
      icon: Calendar,
      title: 'Gantt Scheduling',
      tagline: 'See your entire operation at a glance',
      description: 'Visual timeline scheduling with drag-and-drop. See conflicts before they happen. Plan weeks ahead with confidence.',
      color: 'violet',
      highlights: [
        'Drag-and-drop job scheduling',
        'Multi-hangar, multi-bay view',
        'Automatic conflict detection',
        'AOG priority handling',
        'Non-work day planning',
        'Zoom from days to months',
      ],
    },
    {
      id: 'financials',
      icon: DollarSign,
      title: 'Financial Forecasting',
      tagline: 'Know if you\'re making money—in real time',
      description: 'Track job profitability as work progresses. No more end-of-month surprises. Make data-driven decisions.',
      color: 'emerald',
      highlights: [
        'Real-time P&L tracking',
        'Cashflow forecasting',
        'Job cost analysis',
        'Overhead allocation',
        'Parts markup management',
        'Revenue projections',
      ],
    },
    {
      id: 'capacity',
      icon: Users,
      title: 'Capacity Planning',
      tagline: 'Know when you can take new work',
      description: 'See exactly how much capacity you have—by team, role, and timeframe. Never overcommit again.',
      color: 'blue',
      highlights: [
        'Labor capacity forecasting',
        'Team availability view',
        'Skill-based allocation',
        'Overtime prediction',
        'Resource utilization reports',
        'What-if scenarios',
      ],
    },
    {
      id: 'quoting',
      icon: FileText,
      title: 'Quote Builder',
      tagline: 'Professional quotes in minutes',
      description: 'Build accurate quotes with automated labor and parts pricing. Convert to jobs with one click.',
      color: 'amber',
      highlights: [
        'Line-item quoting',
        'Automatic labor pricing',
        'Parts markup tiers',
        'Quote templates',
        'PDF export',
        'Quote-to-job conversion',
      ],
    },
    {
      id: 'analytics',
      icon: BarChart3,
      title: 'Analytics Dashboard',
      tagline: 'Data-driven decisions',
      description: 'Track the KPIs that matter. Utilization rates, profitability trends, and performance metrics.',
      color: 'rose',
      highlights: [
        'Utilization tracking',
        'Revenue analytics',
        'On-time delivery rates',
        'Profitability trends',
        'Custom date ranges',
        'Exportable reports',
      ],
    },
    {
      id: 'personnel',
      icon: Settings,
      title: 'Personnel Management',
      tagline: 'Your team, organized',
      description: 'Manage technicians, shifts, roles, and efficiency ratings. Know who\'s working on what.',
      color: 'cyan',
      highlights: [
        'Team management',
        'Shift configuration',
        'Role & skill tracking',
        'Efficiency ratings',
        'Workload balancing',
        'Time-off tracking',
      ],
    },
  ];

  // Detailed feature spotlight data
  const featureSpotlights = [
    {
      id: 'scheduling',
      title: 'Visual Scheduling That Actually Works',
      description: 'Stop juggling spreadsheets and whiteboards. AeroManager\'s Gantt-style timeline shows every job, every bay, and every potential conflict in one view.',
      image: '/placeholder-gantt.png',
      features: [
        {
          icon: GitBranch,
          title: 'Drag-and-Drop',
          description: 'Move jobs around the timeline with a click. The system automatically recalculates labor and flags conflicts.',
        },
        {
          icon: AlertTriangle,
          title: 'Conflict Detection',
          description: 'Overlapping jobs, missing resources, deadline violations—see them before they become problems.',
        },
        {
          icon: Zap,
          title: 'AOG Priority',
          description: 'Flag urgent work and the entire team sees it immediately. Red borders, priority indicators, automatic alerts.',
        },
      ],
    },
    {
      id: 'financials',
      title: 'Real-Time Financial Visibility',
      description: 'Know if a job is profitable while it\'s still in progress—not three weeks after it\'s done. Track every dollar.',
      image: '/placeholder-financials.png',
      features: [
        {
          icon: TrendingUp,
          title: 'Live P&L',
          description: 'See profit margins update as work progresses. Catch cost overruns before they eat your margin.',
        },
        {
          icon: PieChart,
          title: 'Job Cost Breakdown',
          description: 'Labor, parts, overhead—see exactly where the money goes on every job.',
        },
        {
          icon: Target,
          title: 'Margin Alerts',
          description: 'Set thresholds and get notified when jobs trend below target profitability.',
        },
      ],
    },
    {
      id: 'capacity',
      title: 'Know Your Capacity',
      description: 'See exactly how much work you can handle—today, next week, next month. Stop guessing, start planning.',
      image: '/placeholder-capacity.png',
      features: [
        {
          icon: Users,
          title: 'Team View',
          description: 'See availability by team, shift, and role. Know who\'s free before you commit.',
        },
        {
          icon: Clock,
          title: 'Utilization Tracking',
          description: 'Target 80% utilization? The dashboard shows you exactly where you stand.',
        },
        {
          icon: Layers,
          title: 'What-If Planning',
          description: 'Model new jobs before you commit. See the impact on your entire schedule.',
        },
      ],
    },
  ];

  // Additional features list
  const additionalFeatures = [
    { icon: Bell, title: 'Notifications', description: 'Stay informed about deadlines, conflicts, and important updates' },
    { icon: Search, title: 'Smart Search', description: 'Find any job, customer, or aircraft in seconds' },
    { icon: Briefcase, title: 'Customer Portal', description: 'Let customers check job status without calling you' },
    { icon: Wrench, title: 'Aircraft Database', description: 'Track all aircraft types, registrations, and service history' },
    { icon: Shield, title: 'Audit Trail', description: 'Full history of every change for Part 145 compliance' },
    { icon: Layers, title: 'Multi-Location', description: 'Manage multiple hangars and bases from one account' },
  ];

  const colorClasses: Record<string, { bg: string; text: string; border: string; gradient: string }> = {
    violet: { bg: 'bg-violet-500/10', text: 'text-violet-400', border: 'border-violet-500/20', gradient: 'from-violet-500 to-violet-600' },
    emerald: { bg: 'bg-emerald-500/10', text: 'text-emerald-400', border: 'border-emerald-500/20', gradient: 'from-emerald-500 to-emerald-600' },
    blue: { bg: 'bg-blue-500/10', text: 'text-blue-400', border: 'border-blue-500/20', gradient: 'from-blue-500 to-blue-600' },
    amber: { bg: 'bg-amber-500/10', text: 'text-amber-400', border: 'border-amber-500/20', gradient: 'from-amber-500 to-amber-600' },
    rose: { bg: 'bg-rose-500/10', text: 'text-rose-400', border: 'border-rose-500/20', gradient: 'from-rose-500 to-rose-600' },
    cyan: { bg: 'bg-cyan-500/10', text: 'text-cyan-400', border: 'border-cyan-500/20', gradient: 'from-cyan-500 to-cyan-600' },
    indigo: { bg: 'bg-indigo-500/10', text: 'text-indigo-400', border: 'border-indigo-500/20', gradient: 'from-indigo-500 to-indigo-600' },
  };

  return (
    <>
      {/* Hero */}
      <HeroSection>
        <div className="text-center max-w-3xl mx-auto">
          <RevealOnScroll>
            <Badge variant="secondary" className="mb-6">Features</Badge>
          </RevealOnScroll>
          <RevealOnScroll delay={100}>
            <h1 className="text-[2.75rem] sm:text-[3.5rem] lg:text-[4rem] font-semibold text-white mb-6 leading-[1.1] tracking-tight">
              Everything you need to{' '}
              <span className="bg-gradient-to-r from-[#c8c8ff] via-[#a5b4fc] to-[#818cf8] bg-clip-text text-transparent">
                run your hangar
              </span>
            </h1>
          </RevealOnScroll>
          <RevealOnScroll delay={200}>
            <p className="text-lg text-[#9ca3af] max-w-2xl mx-auto mb-8">
              AeroManager combines scheduling, financials, and workforce management
              into one powerful platform built specifically for Part 145 operations.
            </p>
          </RevealOnScroll>
          <RevealOnScroll delay={300}>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Button
                variant="primary"
                size="lg"
                to="/register"
                icon={<ArrowRight className="h-4 w-4" />}
                iconPosition="right"
              >
                Start Free Trial
              </Button>
              <Button variant="secondary" size="lg" icon={<Play className="h-4 w-4" />}>
                Watch Demo
              </Button>
            </div>
          </RevealOnScroll>
        </div>
      </HeroSection>

      {/* Feature Overview Grid */}
      <Section padding="xl" background="panel" border="top">
        <div className="text-center mb-12">
          <RevealOnScroll>
            <h2 className="text-title-1 font-semibold text-white mb-4">
              Six powerful modules, one platform
            </h2>
            <p className="text-[#9ca3af] max-w-2xl mx-auto">
              Everything works together. Schedule a job, and financials update automatically.
              Assign crew, and capacity recalculates. No double entry.
            </p>
          </RevealOnScroll>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {featureCategories.map((feature, index) => {
            const colors = colorClasses[feature.color];
            return (
              <RevealOnScroll key={feature.id} delay={index * 80}>
                <a
                  href={`#${feature.id}`}
                  className="block h-full"
                >
                  <Card variant="elevated" className="h-full group hover:border-white/[0.12] transition-all">
                    <CardContent className="p-6">
                      <div className={`inline-flex p-3 rounded-xl ${colors.bg} ${colors.border} border mb-4 group-hover:scale-105 transition-transform`}>
                        <feature.icon className={`h-6 w-6 ${colors.text}`} />
                      </div>
                      <h3 className="text-lg font-semibold text-white mb-1 group-hover:text-indigo-400 transition-colors">
                        {feature.title}
                      </h3>
                      <p className="text-sm text-[#6b7280] mb-3">{feature.tagline}</p>
                      <p className="text-sm text-[#9ca3af] leading-relaxed">
                        {feature.description}
                      </p>
                    </CardContent>
                  </Card>
                </a>
              </RevealOnScroll>
            );
          })}
        </div>
      </Section>

      {/* Feature Spotlights */}
      {featureSpotlights.map((spotlight, spotlightIndex) => (
        <Section
          key={spotlight.id}
          id={spotlight.id}
          padding="xl"
          background={spotlightIndex % 2 === 0 ? 'default' : 'panel'}
          border="top"
        >
          <div className={`grid lg:grid-cols-2 gap-12 lg:gap-16 items-center ${
            spotlightIndex % 2 === 1 ? 'lg:flex-row-reverse' : ''
          }`}>
            {/* Content */}
            <RevealOnScroll className={spotlightIndex % 2 === 1 ? 'lg:order-2' : ''}>
              <div>
                <Badge variant="secondary" className="mb-4">
                  {featureCategories.find(f => f.id === spotlight.id)?.title}
                </Badge>
                <h2 className="text-title-1 font-semibold text-white mb-4">
                  {spotlight.title}
                </h2>
                <p className="text-lg text-[#9ca3af] mb-8">
                  {spotlight.description}
                </p>

                <div className="space-y-6">
                  {spotlight.features.map((feature, i) => (
                    <div key={i} className="flex gap-4">
                      <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center">
                        <feature.icon className="h-5 w-5 text-indigo-400" />
                      </div>
                      <div>
                        <h4 className="text-[15px] font-semibold text-white mb-1">{feature.title}</h4>
                        <p className="text-sm text-[#9ca3af]">{feature.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </RevealOnScroll>

            {/* Visual placeholder */}
            <RevealOnScroll delay={200} className={spotlightIndex % 2 === 1 ? 'lg:order-1' : ''}>
              <div className="relative">
                {/* Background glow */}
                <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/20 to-violet-500/20 rounded-2xl blur-3xl" />

                {/* Mock UI card */}
                <div className="relative bg-[#0d0e10] border border-white/[0.08] rounded-2xl p-6 shadow-2xl">
                  <div className="flex items-center gap-2 mb-4">
                    <div className="w-3 h-3 rounded-full bg-red-500/50" />
                    <div className="w-3 h-3 rounded-full bg-yellow-500/50" />
                    <div className="w-3 h-3 rounded-full bg-green-500/50" />
                    <div className="flex-1" />
                    <span className="text-xs text-[#6b7280]">
                      {featureCategories.find(f => f.id === spotlight.id)?.title}
                    </span>
                  </div>

                  {/* Mock content based on feature type */}
                  {spotlight.id === 'scheduling' && (
                    <div className="space-y-2">
                      {['Bay 1', 'Bay 2', 'Bay 3'].map((bay, i) => (
                        <div key={bay} className="flex items-center gap-3">
                          <span className="text-xs text-[#6b7280] w-12">{bay}</span>
                          <div className="flex-1 h-8 bg-white/[0.02] rounded overflow-hidden flex">
                            {[1, 2].map((job) => (
                              <div
                                key={job}
                                className={`h-full ${
                                  job === 1
                                    ? 'bg-violet-500/30 border-l-2 border-violet-500'
                                    : 'bg-emerald-500/30 border-l-2 border-emerald-500'
                                }`}
                                style={{ width: `${30 + i * 10 + job * 15}%`, marginLeft: job === 2 ? '4px' : 0 }}
                              />
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  {spotlight.id === 'financials' && (
                    <div className="space-y-4">
                      <div className="flex justify-between items-end">
                        <div>
                          <div className="text-xs text-[#6b7280]">Revenue (MTD)</div>
                          <div className="text-2xl font-bold text-white">$127,450</div>
                        </div>
                        <div className="text-right">
                          <div className="text-xs text-[#6b7280]">Margin</div>
                          <div className="text-lg font-semibold text-emerald-400">24.3%</div>
                        </div>
                      </div>
                      <div className="h-24 flex items-end gap-1">
                        {[40, 65, 45, 80, 60, 75, 55, 90, 70, 85].map((h, i) => (
                          <div
                            key={i}
                            className="flex-1 bg-gradient-to-t from-indigo-500/50 to-indigo-500/20 rounded-t"
                            style={{ height: `${h}%` }}
                          />
                        ))}
                      </div>
                    </div>
                  )}

                  {spotlight.id === 'capacity' && (
                    <div className="space-y-4">
                      {['A-Check Team', 'Avionics', 'Sheet Metal'].map((team, i) => (
                        <div key={team}>
                          <div className="flex justify-between text-xs mb-1">
                            <span className="text-[#9ca3af]">{team}</span>
                            <span className="text-white">{[78, 92, 65][i]}%</span>
                          </div>
                          <div className="h-2 bg-white/[0.05] rounded-full overflow-hidden">
                            <div
                              className={`h-full rounded-full ${
                                [78, 92, 65][i] > 85 ? 'bg-amber-500' : 'bg-emerald-500'
                              }`}
                              style={{ width: `${[78, 92, 65][i]}%` }}
                            />
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </RevealOnScroll>
          </div>
        </Section>
      ))}

      {/* All Features List */}
      <Section padding="xl" background="panel" border="top">
        <div className="text-center mb-12">
          <RevealOnScroll>
            <Badge variant="secondary" className="mb-4">And More</Badge>
            <h2 className="text-title-1 font-semibold text-white mb-4">
              Plus everything else you need
            </h2>
            <p className="text-[#9ca3af] max-w-2xl mx-auto">
              The features above are just the highlights. Here's what else comes included.
            </p>
          </RevealOnScroll>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {additionalFeatures.map((feature, i) => (
            <RevealOnScroll key={i} delay={i * 75}>
              <div className="flex gap-4 p-5 bg-[#0d0e10] border border-white/[0.06] rounded-xl">
                <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-white/[0.04] border border-white/[0.06] flex items-center justify-center">
                  <feature.icon className="h-5 w-5 text-[#9ca3af]" />
                </div>
                <div>
                  <h4 className="text-[15px] font-medium text-white mb-1">{feature.title}</h4>
                  <p className="text-sm text-[#6b7280]">{feature.description}</p>
                </div>
              </div>
            </RevealOnScroll>
          ))}
        </div>

        {/* Feature highlights for each category */}
        <div className="mt-16">
          <RevealOnScroll>
            <h3 className="text-lg font-semibold text-white text-center mb-8">
              Complete feature breakdown
            </h3>
          </RevealOnScroll>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featureCategories.map((category, i) => {
              const colors = colorClasses[category.color];
              return (
                <RevealOnScroll key={category.id} delay={i * 100}>
                  <div className="p-6 bg-[#0d0e10] border border-white/[0.06] rounded-xl">
                    <div className={`inline-flex p-2 rounded-lg ${colors.bg} ${colors.border} border mb-4`}>
                      <category.icon className={`h-5 w-5 ${colors.text}`} />
                    </div>
                    <h4 className="text-[15px] font-semibold text-white mb-4">{category.title}</h4>
                    <div className="space-y-2">
                      {category.highlights.map((highlight, j) => (
                        <div key={j} className="flex items-center gap-2">
                          <CheckCircle2 className="h-4 w-4 text-emerald-500 flex-shrink-0" />
                          <span className="text-sm text-[#9ca3af]">{highlight}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </RevealOnScroll>
              );
            })}
          </div>
        </div>
      </Section>

      {/* CTA Section */}
      <Section padding="xl" background="default" border="top">
        <RevealOnScroll>
          <div className="text-center max-w-2xl mx-auto">
            <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 mb-6">
              <Zap className="h-7 w-7 text-indigo-400" />
            </div>
            <h2 className="text-title-1 font-semibold text-white mb-4">
              Ready to see it in action?
            </h2>
            <p className="text-[#9ca3af] mb-8">
              Start your 14-day free trial and experience the difference.
              No credit card required.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Button
                variant="primary"
                size="lg"
                to="/register"
                icon={<ArrowRight className="h-4 w-4" />}
                iconPosition="right"
              >
                Start Free Trial
              </Button>
              <Button variant="ghost" size="lg" to="/pricing">
                View Pricing
              </Button>
            </div>
          </div>
        </RevealOnScroll>
      </Section>
    </>
  );
};

export default Features;
