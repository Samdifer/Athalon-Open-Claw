import React, { useState } from 'react';
import { HeroSection, Section, RevealOnScroll } from '../components/layout';
import { Button, Badge, Card, CardContent } from '../components/ui';
import {
  ArrowRight,
  Calendar,
  DollarSign,
  Users,
  BarChart3,
  Clock,
  Shield,
  Zap,
  CheckCircle2,
  Play,
  BookOpen,
  Download,
  ChevronRight,
  Star,
  Plane,
  CalendarX2,
  EyeOff,
  Users2
} from 'lucide-react';

// Lead Magnet Modal Component
interface LeadMagnetModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const LeadMagnetModal: React.FC<LeadMagnetModalProps> = ({ isOpen, onClose }) => {
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // TODO: Integrate with SendGrid in Phase 5
    await new Promise(resolve => setTimeout(resolve, 1000));

    setIsSubmitted(true);
    setIsSubmitting(false);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/80 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* Modal */}
      <div className="relative bg-[#0d0e10] border border-white/[0.08] rounded-2xl max-w-lg w-full p-8 shadow-2xl">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-[#6b7280] hover:text-white transition-colors"
        >
          <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>

        {!isSubmitted ? (
          <>
            <div className="text-center mb-6">
              <div className="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-indigo-500/10 border border-indigo-500/20 mb-4">
                <BookOpen className="h-6 w-6 text-indigo-400" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">
                Get Your Free Guide
              </h3>
              <p className="text-[#9ca3af] text-sm">
                Enter your email and we'll send you the complete MRO Project Planning guide instantly.
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm text-[#9ca3af] mb-1.5">Name</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                  className="w-full px-4 py-3 bg-[#141517] border border-white/[0.08] rounded-lg text-white placeholder-[#6b7280] focus:outline-none focus:border-indigo-500/50 focus:ring-1 focus:ring-indigo-500/50 transition-colors"
                  placeholder="Your name"
                />
              </div>
              <div>
                <label className="block text-sm text-[#9ca3af] mb-1.5">Email</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="w-full px-4 py-3 bg-[#141517] border border-white/[0.08] rounded-lg text-white placeholder-[#6b7280] focus:outline-none focus:border-indigo-500/50 focus:ring-1 focus:ring-indigo-500/50 transition-colors"
                  placeholder="you@company.com"
                />
              </div>
              <Button
                type="submit"
                variant="primary"
                size="lg"
                fullWidth
                loading={isSubmitting}
              >
                Send Me The Guide
              </Button>
              <p className="text-xs text-[#6b7280] text-center">
                No spam. Unsubscribe anytime.
              </p>
            </form>
          </>
        ) : (
          <div className="text-center py-4">
            <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-emerald-500/10 border border-emerald-500/20 mb-4">
              <CheckCircle2 className="h-6 w-6 text-emerald-400" />
            </div>
            <h3 className="text-xl font-semibold text-white mb-2">
              Check Your Inbox
            </h3>
            <p className="text-[#9ca3af] text-sm mb-6">
              We've sent the guide to {email}. If you don't see it, check your spam folder.
            </p>
            <Button variant="secondary" onClick={onClose}>
              Close
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

const Landing: React.FC = () => {
  const [isLeadMagnetOpen, setIsLeadMagnetOpen] = useState(false);

  const features = [
    {
      icon: Calendar,
      title: 'Visual Scheduling',
      description: 'Drag-and-drop Gantt charts let you see every job, deadline, and resource conflict at a glance.',
    },
    {
      icon: DollarSign,
      title: 'Real-Time Financials',
      description: 'Track shop rate, overhead, and profitability as work progresses. No more end-of-month surprises.',
    },
    {
      icon: Users,
      title: 'Crew Management',
      description: 'Assign technicians by skill, shift, and availability. Balance workload across teams automatically.',
    },
    {
      icon: BarChart3,
      title: 'Capacity Forecasting',
      description: 'See labor capacity weeks ahead. Know when you can take new work and when you\'re maxed out.',
    },
    {
      icon: Clock,
      title: 'Quote to Cash',
      description: 'Build professional quotes, convert to jobs, and track through completion in one system.',
    },
    {
      icon: Shield,
      title: 'Part 145 Ready',
      description: 'Built for FAA Part 145 operations. Track AOG priorities, compliance deadlines, and audit trails.',
    },
  ];

  const benefits = [
    { stat: '40%', label: 'Less time scheduling', detail: 'compared to spreadsheets' },
    { stat: '3x', label: 'Faster quote turnaround', detail: 'with templates' },
    { stat: '99.9%', label: 'On-time delivery rate', detail: 'for customers' },
  ];

  const testimonials = [
    {
      quote: "We went from constant scheduling fires to actually planning ahead. Game changer for our operation.",
      author: "Mike Chen",
      role: "Director of Maintenance",
      company: "Pacific Aviation Services",
    },
    {
      quote: "The financial visibility alone paid for itself in the first month. We found $30K in unbilled labor.",
      author: "Sarah Johnson",
      role: "Operations Manager",
      company: "Atlantic MRO Group",
    },
    {
      quote: "Finally, software that understands how hangars actually work. Not some generic project tool.",
      author: "James Rodriguez",
      role: "Shop Foreman",
      company: "Desert Sky Aircraft",
    },
  ];

  const logos = [
    'ATLANTIC MRO',
    'PACIFIC AVIATION',
    'DESERT SKY',
    'SUMMIT AIR',
    'COASTAL AVIATION',
  ];

  return (
    <>
      {/* Hero Section */}
      <HeroSection>
        <div className="text-center max-w-4xl mx-auto">
          {/* Announcement Badge */}
          <RevealOnScroll>
            <div className="mb-8">
              <a
                href="/features#scheduling"
                className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/[0.04] border border-white/[0.08] text-sm text-zinc-300 hover:bg-white/[0.06] transition-colors group"
              >
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-50"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-white"></span>
                </span>
                <span>V2.0 Now Live: Automated Scheduling</span>
                <ChevronRight className="h-3.5 w-3.5 group-hover:translate-x-0.5 transition-transform" />
              </a>
            </div>
          </RevealOnScroll>

          {/* Headline */}
          <RevealOnScroll delay={100}>
            <h1 className="text-[2.75rem] sm:text-[3.5rem] lg:text-[4.5rem] font-semibold text-white mb-6 leading-[1.1] tracking-tight">
              Run your hangar like{' '}
              <span className="bg-gradient-to-r from-[#c8c8ff] via-[#a5b4fc] to-[#818cf8] bg-clip-text text-transparent">
                a well-oiled machine
              </span>
            </h1>
          </RevealOnScroll>

          {/* Subheadline */}
          <RevealOnScroll delay={200}>
            <p className="text-lg sm:text-xl text-[#9ca3af] mb-8 max-w-2xl mx-auto leading-relaxed">
              Stop losing jobs to scheduling conflicts. AeroManager gives your Part 145 operation
              complete visibility across hangars, crews, and financials.
            </p>
          </RevealOnScroll>

          {/* CTAs */}
          <RevealOnScroll delay={300}>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Button
                variant="primary"
                size="lg"
                to="/register"
                icon={<ArrowRight className="h-4 w-4" />}
                iconPosition="right"
              >
                Start Free Trial
              </Button>
              <Button
                variant="secondary"
                size="lg"
                to="/features"
                icon={<Play className="h-4 w-4" />}
              >
                Demo Under Construction
              </Button>
            </div>
          </RevealOnScroll>

          {/* Trust Indicators */}
          <RevealOnScroll delay={400}>
            <div className="mt-8 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-sm text-[#6b7280]">
              <span className="flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-zinc-400" />
                No credit card required
              </span>
              <span className="flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-zinc-400" />
                14-day free trial
              </span>
              <span className="flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-zinc-400" />
                Setup in 5 minutes
              </span>
            </div>
          </RevealOnScroll>
        </div>
      </HeroSection>

      {/* Logo Bar */}
      <Section padding="md" background="default" border="top">
        <RevealOnScroll>
          <div className="text-center">
            <p className="text-[#6b7280] text-sm uppercase tracking-wider mb-6">
              Trusted by Part 145 stations across the country
            </p>
            <div className="flex flex-wrap items-center justify-center gap-x-12 gap-y-4">
              {logos.map((logo) => (
                <span
                  key={logo}
                  className="text-sm font-semibold text-[#4b5563] tracking-wider opacity-60 hover:opacity-100 transition-opacity"
                >
                  {logo}
                </span>
              ))}
            </div>
          </div>
        </RevealOnScroll>
      </Section>

      {/* Problem/Solution Section */}
      <Section padding="xl" background="panel">
        <div className="max-w-4xl mx-auto">
          <RevealOnScroll>
            <div className="text-center mb-16">
              <Badge variant="secondary" className="mb-4">The Problem</Badge>
              <h2 className="text-title-1 font-semibold text-white mb-4">
                Your hangar is running on spreadsheets and whiteboards
              </h2>
              <p className="text-lg text-[#9ca3af] max-w-2xl mx-auto">
                Every MRO knows the pain: double-booked bays, surprise overtime,
                and no real visibility into whether you're actually making money on that job.
              </p>
            </div>
          </RevealOnScroll>

          <div className="grid md:grid-cols-3 gap-8 mb-16">
            {[
              { icon: CalendarX2, problem: 'Scheduling chaos', detail: 'Jobs slip, deadlines get missed, customers get angry' },
              { icon: EyeOff, problem: 'Financial blind spots', detail: 'You don\'t know if a job is profitable until it\'s done' },
              { icon: Users2, problem: 'Crew confusion', detail: 'Who\'s working on what? Nobody really knows' },
            ].map((item, i) => (
              <RevealOnScroll key={i} delay={i * 100}>
                <div className="text-center">
                  <div className="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-rose-500/10 border border-rose-500/20 mb-4">
                    <item.icon className="h-6 w-6 text-rose-400" />
                  </div>
                  <h3 className="text-lg font-semibold text-white mb-2">{item.problem}</h3>
                  <p className="text-sm text-[#9ca3af]">{item.detail}</p>
                </div>
              </RevealOnScroll>
            ))}
          </div>

          <RevealOnScroll>
            <div className="text-center">
              <Badge variant="primary" className="mb-4">The Solution</Badge>
              <h2 className="text-title-1 font-semibold text-white mb-4">
                One system for your entire operation
              </h2>
              <p className="text-lg text-[#9ca3af] max-w-2xl mx-auto">
                AeroManager connects scheduling, financials, and crew management in a single view.
                See everything. Control everything.
              </p>
            </div>
          </RevealOnScroll>
        </div>
      </Section>

      {/* Features Grid */}
      <Section padding="xl" background="default" border="top">
        <div className="text-center mb-16">
          <RevealOnScroll>
            <Badge variant="secondary" className="mb-4">Features</Badge>
            <h2 className="text-title-1 font-semibold text-white mb-4">
              Everything you need to run a modern hangar
            </h2>
            <p className="text-lg text-[#9ca3af] max-w-2xl mx-auto">
              Built specifically for Part 145 operations. No more forcing generic tools to fit aviation workflows.
            </p>
          </RevealOnScroll>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, i) => (
            <RevealOnScroll key={i} delay={i * 75}>
              <Card variant="elevated" className="h-full group hover:border-white/[0.12] transition-colors">
                <CardContent className="p-6">
                  <div className="inline-flex items-center justify-center w-10 h-10 rounded-lg bg-indigo-500/10 border border-indigo-500/20 mb-4 group-hover:bg-indigo-500/15 transition-colors">
                    <feature.icon className="h-5 w-5 text-indigo-400" />
                  </div>
                  <h3 className="text-lg font-semibold text-white mb-2">{feature.title}</h3>
                  <p className="text-sm text-[#9ca3af] leading-relaxed">{feature.description}</p>
                </CardContent>
              </Card>
            </RevealOnScroll>
          ))}
        </div>

        <RevealOnScroll delay={500}>
          <div className="text-center mt-12">
            <Button variant="secondary" to="/features" icon={<ArrowRight className="h-4 w-4" />} iconPosition="right">
              See All Features
            </Button>
          </div>
        </RevealOnScroll>
      </Section>

      {/* Stats Section */}
      <Section padding="lg" background="panel" border="both">
        <div className="grid md:grid-cols-3 gap-8 lg:gap-12">
          {benefits.map((benefit, i) => (
            <RevealOnScroll key={i} delay={i * 100}>
              <div className="text-center">
                <div className="text-4xl sm:text-5xl font-bold text-gradient mb-2">{benefit.stat}</div>
                <div className="text-lg font-medium text-white mb-1">{benefit.label}</div>
                <div className="text-sm text-[#6b7280]">{benefit.detail}</div>
              </div>
            </RevealOnScroll>
          ))}
        </div>
      </Section>

      {/* Lead Magnet Section - Hormozi Style */}
      <Section padding="xl" background="default">
        <div className="max-w-5xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left: Content */}
            <RevealOnScroll>
              <div>
                <Badge variant="warning" className="mb-4">
                  Free Resource
                </Badge>
                <h2 className="text-title-1 font-semibold text-white mb-4">
                  The Basics Guide to MRO Project Planning
                </h2>
                <p className="text-lg text-[#9ca3af] mb-6">
                  Stop guessing. Start planning. This 47-page guide reveals the exact system
                  top-performing hangars use to hit deadlines and protect margins.
                </p>

                <div className="space-y-4 mb-8">
                  {[
                    'The 5-step framework for bulletproof scheduling',
                    'How to calculate true job profitability (most shops get this wrong)',
                    'The crew utilization formula that prevents overtime blowouts',
                    'Templates for quoting, tracking, and customer communication',
                    'Real examples from Part 145 operations like yours',
                  ].map((item, i) => (
                    <div key={i} className="flex items-start gap-3">
                      <CheckCircle2 className="h-5 w-5 text-emerald-500 mt-0.5 flex-shrink-0" />
                      <span className="text-[#d1d5db]">{item}</span>
                    </div>
                  ))}
                </div>

                <div className="flex items-center gap-4 mb-6">
                  <div className="flex -space-x-2">
                    {[1, 2, 3, 4].map((i) => (
                      <div
                        key={i}
                        className="w-8 h-8 rounded-full bg-gradient-to-br from-indigo-400 to-violet-500 border-2 border-[#08090a] flex items-center justify-center text-xs text-white font-medium"
                      >
                        {['MC', 'SJ', 'JR', 'KW'][i-1]}
                      </div>
                    ))}
                  </div>
                  <div>
                    <div className="flex items-center gap-1 text-yellow-500">
                      {[1, 2, 3, 4, 5].map((i) => (
                        <Star key={i} className="h-3.5 w-3.5 fill-current" />
                      ))}
                    </div>
                    <p className="text-xs text-[#6b7280]">Downloaded by 2,400+ MRO professionals</p>
                  </div>
                </div>

                <Button
                  variant="primary"
                  size="lg"
                  onClick={() => setIsLeadMagnetOpen(true)}
                  icon={<Download className="h-4 w-4" />}
                >
                  Get Free Guide
                </Button>
              </div>
            </RevealOnScroll>

            {/* Right: Visual */}
            <RevealOnScroll delay={200}>
              <div className="relative">
                {/* Background glow */}
                <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/20 to-violet-500/20 rounded-2xl blur-3xl" />

                {/* Guide preview card */}
                <div className="relative bg-[#0d0e10] border border-white/[0.08] rounded-2xl p-8 shadow-2xl">
                  <div className="flex items-start gap-4 mb-6">
                    <div className="w-16 h-20 bg-gradient-to-br from-indigo-500 to-violet-600 rounded-lg flex items-center justify-center shadow-lg">
                      <BookOpen className="h-8 w-8 text-white" />
                    </div>
                    <div>
                      <div className="text-xs text-indigo-400 uppercase tracking-wider mb-1">Free Guide</div>
                      <h4 className="text-lg font-semibold text-white">The Basics Guide to MRO Project Planning</h4>
                      <p className="text-sm text-[#6b7280]">47 pages • PDF</p>
                    </div>
                  </div>

                  <div className="space-y-3">
                    {[
                      { chapter: '01', title: 'The Scheduling Foundation', pages: '8' },
                      { chapter: '02', title: 'Financial Visibility', pages: '12' },
                      { chapter: '03', title: 'Crew Management', pages: '10' },
                      { chapter: '04', title: 'Templates & Checklists', pages: '17' },
                    ].map((ch, i) => (
                      <div key={i} className="flex items-center gap-4 p-3 bg-white/[0.02] rounded-lg border border-white/[0.04]">
                        <span className="text-xs font-mono text-indigo-400">{ch.chapter}</span>
                        <span className="text-sm text-white flex-1">{ch.title}</span>
                        <span className="text-xs text-[#6b7280]">{ch.pages} pages</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </RevealOnScroll>
          </div>
        </div>
      </Section>

      {/* Testimonials */}
      <Section padding="xl" background="panel" border="top">
        <div className="text-center mb-16">
          <RevealOnScroll>
            <Badge variant="secondary" className="mb-4">Testimonials</Badge>
            <h2 className="text-title-1 font-semibold text-white mb-4">
              Hangars love AeroManager
            </h2>
            <p className="text-lg text-[#9ca3af] max-w-2xl mx-auto">
              Don't take our word for it. Here's what operations managers are saying.
            </p>
          </RevealOnScroll>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {testimonials.map((testimonial, i) => (
            <RevealOnScroll key={i} delay={i * 100}>
              <Card variant="elevated" className="h-full">
                <CardContent className="p-6">
                  <div className="flex items-center gap-1 text-yellow-500 mb-4">
                    {[1, 2, 3, 4, 5].map((s) => (
                      <Star key={s} className="h-4 w-4 fill-current" />
                    ))}
                  </div>
                  <p className="text-[#d1d5db] mb-6 leading-relaxed">"{testimonial.quote}"</p>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-indigo-400 to-violet-500 flex items-center justify-center text-sm text-white font-medium">
                      {testimonial.author.split(' ').map(n => n[0]).join('')}
                    </div>
                    <div>
                      <div className="text-sm font-medium text-white">{testimonial.author}</div>
                      <div className="text-xs text-[#6b7280]">{testimonial.role}, {testimonial.company}</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </RevealOnScroll>
          ))}
        </div>
      </Section>

      {/* Pricing Preview */}
      <Section padding="xl" background="default" border="top">
        <div className="max-w-3xl mx-auto text-center">
          <RevealOnScroll>
            <Badge variant="secondary" className="mb-4">Pricing</Badge>
            <h2 className="text-title-1 font-semibold text-white mb-4">
              Simple, transparent pricing
            </h2>
            <p className="text-lg text-[#9ca3af] mb-8">
              No per-seat fees. No hidden costs. One price for your entire operation.
            </p>
          </RevealOnScroll>

          <RevealOnScroll delay={100}>
            <Card variant="gradient" className="text-center mb-8">
              <CardContent className="p-8">
                <div className="flex items-baseline justify-center gap-2 mb-2">
                  <span className="text-5xl font-bold text-white">$200</span>
                  <span className="text-[#9ca3af]">/month</span>
                </div>
                <p className="text-[#9ca3af] mb-6">Unlimited seats • All features included</p>
                <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                  <Button variant="primary" size="lg" to="/register">
                    Start 14-Day Free Trial
                  </Button>
                  <Button variant="ghost" to="/pricing">
                    See Annual Pricing
                  </Button>
                </div>
              </CardContent>
            </Card>
          </RevealOnScroll>

          <RevealOnScroll delay={200}>
            <p className="text-sm text-[#6b7280]">
              Annual plan: $2,000/year (save 2 months)
            </p>
          </RevealOnScroll>
        </div>
      </Section>

      {/* Final CTA */}
      <Section padding="xl" background="panel" border="top">
        <RevealOnScroll>
          <div className="text-center max-w-2xl mx-auto">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 mb-6">
              <Plane className="h-8 w-8 text-indigo-400" />
            </div>
            <h2 className="text-title-1 font-semibold text-white mb-4">
              Ready to upgrade your hangar?
            </h2>
            <p className="text-lg text-[#9ca3af] mb-8">
              Join the shops that have ditched the spreadsheets and whiteboards.
              Start your free trial today—no credit card required.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Button
                variant="primary"
                size="lg"
                to="/register"
                icon={<ArrowRight className="h-4 w-4" />}
                iconPosition="right"
              >
                Start Free Trial
              </Button>
              <Button variant="ghost" size="lg" to="/contact">
                Talk to Sales
              </Button>
            </div>
          </div>
        </RevealOnScroll>
      </Section>

      {/* Lead Magnet Modal */}
      <LeadMagnetModal
        isOpen={isLeadMagnetOpen}
        onClose={() => setIsLeadMagnetOpen(false)}
      />
    </>
  );
};

export default Landing;
