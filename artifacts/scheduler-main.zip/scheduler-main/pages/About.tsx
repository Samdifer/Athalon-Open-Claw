import React from 'react';
import { HeroSection, Section, RevealOnScroll } from '../components/layout';
import { Button, Card, CardContent, Badge } from '../components/ui';
import { Target, Heart, Zap, Shield, ArrowRight, Plane, Users, Award, Globe, CheckCircle2 } from 'lucide-react';

const About: React.FC = () => {
  const values = [
    {
      icon: Target,
      title: 'Mission-Focused',
      description: 'We build tools that help 145 stations deliver on their promises to customers. Every feature starts with a real problem.',
    },
    {
      icon: Heart,
      title: 'Customer Obsessed',
      description: 'We listen to maintenance professionals daily. Our roadmap is driven by the people who use our software.',
    },
    {
      icon: Zap,
      title: 'Efficiency First',
      description: 'Technology should save time, not create more work. We obsess over making every interaction faster and simpler.',
    },
    {
      icon: Shield,
      title: 'Reliability',
      description: 'Aviation demands precision. Our software reflects that standard. 99.8% uptime and counting.',
    },
  ];

  const timeline = [
    {
      year: '2021',
      title: 'The frustration begins',
      description: 'After years of managing maintenance ops with spreadsheets and whiteboards, our founders knew there had to be a better way.',
    },
    {
      year: '2022',
      title: 'AeroManager is born',
      description: 'We launched our first version to a small group of Part 145 stations. The feedback was overwhelming—we were onto something.',
    },
    {
      year: '2023',
      title: 'Rapid growth',
      description: 'Word spread. More stations signed on. We doubled our team and tripled our feature set based on customer input.',
    },
    {
      year: '2024',
      title: 'V2.0 launches',
      description: 'Our most powerful release yet. Automated scheduling, advanced analytics, and the tools modern hangars need.',
    },
  ];

  const team = [
    { name: 'Alex Morgan', role: 'CEO & Co-Founder', background: 'Former Director of Maintenance at major Part 145 station' },
    { name: 'Jordan Lee', role: 'CTO & Co-Founder', background: 'Ex-Google engineer, aviation enthusiast since childhood' },
    { name: 'Sam Rivers', role: 'Head of Product', background: '15 years in aviation operations software' },
    { name: 'Chris Taylor', role: 'Head of Customer Success', background: 'A&P mechanic turned operations manager' },
  ];

  const stats = [
    { value: '50+', label: 'Part 145 Stations' },
    { value: '$47M+', label: 'Revenue Managed' },
    { value: '15', label: 'Team Members' },
    { value: '99.8%', label: 'Uptime SLA' },
  ];

  return (
    <>
      <HeroSection>
        <div className="text-center max-w-3xl mx-auto">
          <RevealOnScroll>
            <Badge variant="secondary" className="mb-6">About Us</Badge>
          </RevealOnScroll>
          <RevealOnScroll delay={100}>
            <h1 className="text-[2.75rem] sm:text-[3.5rem] lg:text-[4rem] font-semibold text-white mb-6 leading-[1.1] tracking-tight">
              Built by{' '}
              <span className="bg-gradient-to-r from-[#c8c8ff] via-[#a5b4fc] to-[#818cf8] bg-clip-text text-transparent">
                aviation professionals
              </span>
            </h1>
          </RevealOnScroll>
          <RevealOnScroll delay={200}>
            <p className="text-lg text-[#9ca3af] max-w-2xl mx-auto">
              We've walked in your shoes. AeroManager was born from years of experience
              running Part 145 operations and the frustration of inadequate tools.
            </p>
          </RevealOnScroll>
        </div>
      </HeroSection>

      {/* Stats Bar */}
      <Section padding="md" background="panel" border="top">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {stats.map((stat, i) => (
            <RevealOnScroll key={i} delay={i * 100}>
              <div className="text-center">
                <div className="text-3xl sm:text-4xl font-bold text-gradient mb-1">{stat.value}</div>
                <div className="text-sm text-[#6b7280]">{stat.label}</div>
              </div>
            </RevealOnScroll>
          ))}
        </div>
      </Section>

      {/* Our Story */}
      <Section padding="xl" background="default" border="top">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          <RevealOnScroll>
            <div>
              <Badge variant="secondary" className="mb-4">Our Story</Badge>
              <h2 className="text-title-1 font-semibold text-white mb-6">
                From hangar floor to software company
              </h2>
              <div className="space-y-4 text-[#9ca3af] leading-relaxed">
                <p>
                  After years of managing maintenance operations with spreadsheets, whiteboards,
                  and disconnected tools, our founders knew there had to be a better way.
                </p>
                <p>
                  They'd seen how modern software transformed other industries. Why was aviation
                  maintenance still stuck in the past? The tools that existed were either too
                  generic or too expensive for most Part 145 operations.
                </p>
                <p>
                  AeroManager was created to give repair stations the same level of
                  operational visibility that modern software companies enjoy—without requiring
                  an IT department to implement or maintain it.
                </p>
                <p>
                  Today, AeroManager helps maintenance organizations across the country
                  schedule smarter, forecast accurately, and run more profitable operations.
                </p>
              </div>
            </div>
          </RevealOnScroll>

          {/* Timeline */}
          <RevealOnScroll delay={200}>
            <div className="relative">
              {/* Timeline line */}
              <div className="absolute left-4 top-0 bottom-0 w-px bg-white/[0.08]" />

              <div className="space-y-8">
                {timeline.map((item, i) => (
                  <div key={i} className="relative pl-12">
                    {/* Dot */}
                    <div className="absolute left-2 top-1.5 w-4 h-4 rounded-full bg-indigo-500 border-4 border-[#08090a]" />

                    <div className="text-sm text-indigo-400 mb-1">{item.year}</div>
                    <h4 className="text-lg font-semibold text-white mb-2">{item.title}</h4>
                    <p className="text-sm text-[#9ca3af]">{item.description}</p>
                  </div>
                ))}
              </div>
            </div>
          </RevealOnScroll>
        </div>
      </Section>

      {/* Mission */}
      <Section padding="xl" background="panel" border="top">
        <div className="max-w-3xl mx-auto text-center">
          <RevealOnScroll>
            <Badge variant="secondary" className="mb-4">Our Mission</Badge>
            <h2 className="text-title-1 font-semibold text-white mb-6">
              Modernize aviation maintenance management
            </h2>
            <p className="text-xl text-[#9ca3af] leading-relaxed">
              We believe every Part 145 station deserves powerful, intuitive software
              to run their operation. Our mission is to give hangars of all sizes
              the tools they need to schedule smarter, forecast accurately, and
              deliver for their customers.
            </p>
          </RevealOnScroll>
        </div>
      </Section>

      {/* Values */}
      <Section padding="xl" background="default" border="top">
        <div className="text-center mb-12">
          <RevealOnScroll>
            <Badge variant="secondary" className="mb-4">Our Values</Badge>
            <h2 className="text-title-1 font-semibold text-white mb-4">
              What drives us
            </h2>
            <p className="text-[#9ca3af] max-w-2xl mx-auto">
              These principles guide every decision we make.
            </p>
          </RevealOnScroll>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {values.map((value, index) => (
            <RevealOnScroll key={value.title} delay={index * 100}>
              <Card variant="elevated" className="h-full text-center">
                <CardContent className="p-6">
                  <div className="inline-flex p-3 rounded-xl bg-indigo-500/10 border border-indigo-500/20 mb-4">
                    <value.icon className="h-6 w-6 text-indigo-400" />
                  </div>
                  <h3 className="text-lg font-semibold text-white mb-2">{value.title}</h3>
                  <p className="text-sm text-[#9ca3af]">{value.description}</p>
                </CardContent>
              </Card>
            </RevealOnScroll>
          ))}
        </div>
      </Section>

      {/* Team */}
      <Section padding="xl" background="panel" border="top">
        <div className="text-center mb-12">
          <RevealOnScroll>
            <Badge variant="secondary" className="mb-4">Our Team</Badge>
            <h2 className="text-title-1 font-semibold text-white mb-4">
              Meet the people behind AeroManager
            </h2>
            <p className="text-[#9ca3af] max-w-2xl mx-auto">
              A mix of aviation veterans and software engineers united by a common goal.
            </p>
          </RevealOnScroll>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 max-w-5xl mx-auto">
          {team.map((member, i) => (
            <RevealOnScroll key={i} delay={i * 100}>
              <Card variant="elevated" className="text-center">
                <CardContent className="p-6">
                  <div className="w-16 h-16 rounded-full bg-gradient-to-br from-indigo-400 to-violet-500 flex items-center justify-center text-xl text-white font-semibold mx-auto mb-4">
                    {member.name.split(' ').map(n => n[0]).join('')}
                  </div>
                  <h4 className="text-[15px] font-semibold text-white mb-1">{member.name}</h4>
                  <p className="text-sm text-indigo-400 mb-2">{member.role}</p>
                  <p className="text-xs text-[#6b7280]">{member.background}</p>
                </CardContent>
              </Card>
            </RevealOnScroll>
          ))}
        </div>
      </Section>

      {/* Why AeroManager */}
      <Section padding="xl" background="default" border="top">
        <div className="grid lg:grid-cols-2 gap-12 items-center max-w-5xl mx-auto">
          <RevealOnScroll>
            <div>
              <Badge variant="secondary" className="mb-4">Why AeroManager</Badge>
              <h2 className="text-title-1 font-semibold text-white mb-6">
                We understand hangars because we've run them
              </h2>
              <div className="space-y-4">
                {[
                  'Built by aviation professionals, not just software developers',
                  'Designed specifically for Part 145 workflows',
                  'No IT department required to implement',
                  'Actually affordable for mid-size operations',
                  'Support team that speaks your language',
                ].map((item, i) => (
                  <div key={i} className="flex items-center gap-3">
                    <CheckCircle2 className="h-5 w-5 text-emerald-500 flex-shrink-0" />
                    <span className="text-[#d1d5db]">{item}</span>
                  </div>
                ))}
              </div>
            </div>
          </RevealOnScroll>

          <RevealOnScroll delay={200}>
            <Card variant="gradient" className="text-center">
              <CardContent className="p-8">
                <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-indigo-500/20 border border-indigo-500/30 mb-6">
                  <Plane className="h-7 w-7 text-indigo-400" />
                </div>
                <blockquote className="text-lg text-white mb-4">
                  "We built the tool we wished we had when we were running the hangar."
                </blockquote>
                <div className="text-sm text-[#6b7280]">— AeroManager Founders</div>
              </CardContent>
            </Card>
          </RevealOnScroll>
        </div>
      </Section>

      {/* CTA */}
      <Section padding="xl" background="panel" border="top">
        <RevealOnScroll>
          <div className="text-center max-w-2xl mx-auto">
            <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 mb-6">
              <Plane className="h-7 w-7 text-indigo-400" />
            </div>
            <h2 className="text-title-1 font-semibold text-white mb-4">
              Join us on our mission
            </h2>
            <p className="text-[#9ca3af] mb-8">
              Try AeroManager free for 14 days and see how we can help transform your operation.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Button
                variant="primary"
                size="lg"
                to="/register"
                icon={<ArrowRight className="h-4 w-4" />}
                iconPosition="right"
              >
                Start Free Trial
              </Button>
              <Button variant="ghost" size="lg" to="/contact">
                Get in Touch
              </Button>
            </div>
          </div>
        </RevealOnScroll>
      </Section>
    </>
  );
};

export default About;
