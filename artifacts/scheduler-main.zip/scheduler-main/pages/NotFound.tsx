import React from 'react';
import { Link } from 'react-router-dom';
import { Home, ArrowLeft } from 'lucide-react';
import { Button } from '../components/ui';
import { HeroSection } from '../components/layout';

const NotFound: React.FC = () => {
  return (
    <HeroSection withGradient>
      <div className="text-center max-w-2xl mx-auto">
        {/* 404 Number */}
        <div className="mb-8">
          <span className="text-[120px] sm:text-[180px] font-bold leading-none text-gradient">
            404
          </span>
        </div>

        {/* Title */}
        <h1 className="text-title-1 font-semibold text-white mb-4">
          Page not found
        </h1>

        {/* Description */}
        <p className="text-lg text-[#9ca3af] mb-8 max-w-md mx-auto">
          Sorry, we couldn't find the page you're looking for. It might have been moved or doesn't exist.
        </p>

        {/* Actions */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <Button
            variant="primary"
            size="lg"
            to="/"
            icon={<Home className="h-4 w-4" />}
          >
            Back to Home
          </Button>
          <Button
            variant="ghost"
            size="lg"
            onClick={() => window.history.back()}
            icon={<ArrowLeft className="h-4 w-4" />}
          >
            Go Back
          </Button>
        </div>

        {/* Quick Links */}
        <div className="mt-12 pt-8 border-t border-white/[0.06]">
          <p className="text-sm text-[#6b7280] mb-4">Or check out these pages:</p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link to="/features" className="text-sm text-indigo-400 hover:text-indigo-300 transition-colors">
              Features
            </Link>
            <Link to="/pricing" className="text-sm text-indigo-400 hover:text-indigo-300 transition-colors">
              Pricing
            </Link>
            <Link to="/contact" className="text-sm text-indigo-400 hover:text-indigo-300 transition-colors">
              Contact
            </Link>
          </div>
        </div>
      </div>
    </HeroSection>
  );
};

export default NotFound;
