import React, { useState } from 'react';
import { HeroSection, Section, RevealOnScroll } from '../components/layout';
import { Button, Card, CardContent, Badge } from '../components/ui';
import { Mail, MessageSquare, Phone, MapPin, Send, Clock, CheckCircle2, Calendar, HelpCircle } from 'lucide-react';

// Contact Page with form - SendGrid integration ready
const Contact: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    phone: '',
    subject: '',
    message: '',
    source: '',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError(null);

    try {
      // SendGrid integration - send email via API route
      // In production, this would call your backend API
      // POST /api/contact with formData

      // For now, simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000));

      // In production:
      // const response = await fetch('/api/contact', {
      //   method: 'POST',
      //   headers: { 'Content-Type': 'application/json' },
      //   body: JSON.stringify(formData),
      // });
      // if (!response.ok) throw new Error('Failed to send message');

      setIsSubmitted(true);
    } catch (err) {
      setError('Failed to send message. Please try again or email us directly.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    setFormData((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));
  };

  const contactMethods = [
    {
      icon: Mail,
      title: 'Email Us',
      description: 'Send us a message anytime',
      value: 'hello@aeromanager.app',
      href: 'mailto:hello@aeromanager.app',
      action: 'Send email',
    },
    {
      icon: Phone,
      title: 'Call Us',
      description: 'Mon-Fri 9am-6pm ET',
      value: '(555) 123-4567',
      href: 'tel:+15551234567',
      action: 'Call now',
    },
    {
      icon: Calendar,
      title: 'Schedule Demo',
      description: 'See AeroManager in action',
      value: 'Book a 30-min call',
      href: '#demo',
      action: 'Book demo',
    },
  ];

  const faqs = [
    {
      question: 'How quickly will I hear back?',
      answer: 'We typically respond within 4 hours during business hours (Mon-Fri, 9am-6pm ET). Most inquiries get a response within 2 hours.',
    },
    {
      question: 'What if I need urgent support?',
      answer: 'Existing customers can reach our priority support line at (555) 123-4568 or email support@aeromanager.app.',
    },
    {
      question: 'Can I schedule a demo?',
      answer: 'Choose "Request a Demo" from the subject dropdown and we\'ll reach out to schedule a personalized walkthrough.',
    },
  ];

  const inputClasses = "w-full px-4 py-3 bg-[#0d0e10] border border-white/[0.08] rounded-lg text-white placeholder-[#6b7280] focus:outline-none focus:border-indigo-500/50 focus:ring-1 focus:ring-indigo-500/50 transition-all";

  return (
    <>
      <HeroSection>
        <div className="text-center max-w-3xl mx-auto">
          <RevealOnScroll>
            <Badge variant="secondary" className="mb-6">Contact</Badge>
          </RevealOnScroll>
          <RevealOnScroll delay={100}>
            <h1 className="text-[2.75rem] sm:text-[3.5rem] lg:text-[4rem] font-semibold text-white mb-6 leading-[1.1] tracking-tight">
              Let's{' '}
              <span className="bg-gradient-to-r from-[#c8c8ff] via-[#a5b4fc] to-[#818cf8] bg-clip-text text-transparent">
                talk
              </span>
            </h1>
          </RevealOnScroll>
          <RevealOnScroll delay={200}>
            <p className="text-lg text-[#9ca3af] max-w-2xl mx-auto">
              Have questions about AeroManager? Want to schedule a demo?
              We'd love to hear from you.
            </p>
          </RevealOnScroll>
        </div>
      </HeroSection>

      {/* Contact Methods */}
      <Section padding="md" background="panel" border="top">
        <div className="grid md:grid-cols-3 gap-6">
          {contactMethods.map((method, i) => (
            <RevealOnScroll key={i} delay={i * 100}>
              <Card variant="elevated" className="h-full group hover:border-white/[0.12] transition-colors">
                <CardContent className="p-6 text-center">
                  <div className="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-indigo-500/10 border border-indigo-500/20 mb-4 group-hover:bg-indigo-500/15 transition-colors">
                    <method.icon className="h-6 w-6 text-indigo-400" />
                  </div>
                  <h3 className="text-lg font-semibold text-white mb-1">{method.title}</h3>
                  <p className="text-sm text-[#6b7280] mb-2">{method.description}</p>
                  {method.href ? (
                    <a
                      href={method.href}
                      className="text-indigo-400 hover:text-indigo-300 text-sm font-medium transition-colors"
                    >
                      {method.value}
                    </a>
                  ) : (
                    <span className="text-white text-sm">{method.value}</span>
                  )}
                </CardContent>
              </Card>
            </RevealOnScroll>
          ))}
        </div>
      </Section>

      {/* Contact Form */}
      <Section padding="xl" background="default" border="top">
        <div className="grid lg:grid-cols-5 gap-12 lg:gap-16">
          {/* Form */}
          <div className="lg:col-span-3">
            <RevealOnScroll>
              <div className="mb-8">
                <Badge variant="secondary" className="mb-4">Send a Message</Badge>
                <h2 className="text-title-1 font-semibold text-white mb-4">
                  How can we help?
                </h2>
                <p className="text-[#9ca3af]">
                  Fill out the form below and we'll get back to you as soon as possible.
                </p>
              </div>

              {isSubmitted ? (
                <Card variant="gradient">
                  <CardContent className="p-8 text-center">
                    <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-emerald-500/20 border border-emerald-500/30 mb-6">
                      <CheckCircle2 className="h-8 w-8 text-emerald-400" />
                    </div>
                    <h3 className="text-xl font-semibold text-white mb-2">
                      Message sent successfully!
                    </h3>
                    <p className="text-[#9ca3af] mb-6">
                      Thanks for reaching out. We'll get back to you within 4 hours during business hours.
                    </p>
                    <Button variant="secondary" onClick={() => setIsSubmitted(false)}>
                      Send Another Message
                    </Button>
                  </CardContent>
                </Card>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="name" className="block text-sm font-medium text-[#9ca3af] mb-2">
                        Name *
                      </label>
                      <input
                        type="text"
                        id="name"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        required
                        className={inputClasses}
                        placeholder="Your name"
                      />
                    </div>
                    <div>
                      <label htmlFor="email" className="block text-sm font-medium text-[#9ca3af] mb-2">
                        Email *
                      </label>
                      <input
                        type="email"
                        id="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        required
                        className={inputClasses}
                        placeholder="you@company.com"
                      />
                    </div>
                  </div>

                  <div className="grid sm:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="company" className="block text-sm font-medium text-[#9ca3af] mb-2">
                        Company
                      </label>
                      <input
                        type="text"
                        id="company"
                        name="company"
                        value={formData.company}
                        onChange={handleChange}
                        className={inputClasses}
                        placeholder="Your company name"
                      />
                    </div>
                    <div>
                      <label htmlFor="phone" className="block text-sm font-medium text-[#9ca3af] mb-2">
                        Phone
                      </label>
                      <input
                        type="tel"
                        id="phone"
                        name="phone"
                        value={formData.phone}
                        onChange={handleChange}
                        className={inputClasses}
                        placeholder="(555) 123-4567"
                      />
                    </div>
                  </div>

                  <div>
                    <label htmlFor="subject" className="block text-sm font-medium text-[#9ca3af] mb-2">
                      Subject *
                    </label>
                    <select
                      id="subject"
                      name="subject"
                      value={formData.subject}
                      onChange={handleChange}
                      required
                      className={inputClasses}
                    >
                      <option value="">Select a subject</option>
                      <option value="demo">Request a Demo</option>
                      <option value="sales">Sales Inquiry</option>
                      <option value="support">Technical Support</option>
                      <option value="partnership">Partnership</option>
                      <option value="feedback">Product Feedback</option>
                      <option value="other">Other</option>
                    </select>
                  </div>

                  <div>
                    <label htmlFor="source" className="block text-sm font-medium text-[#9ca3af] mb-2">
                      How did you hear about us?
                    </label>
                    <select
                      id="source"
                      name="source"
                      value={formData.source}
                      onChange={handleChange}
                      className={inputClasses}
                    >
                      <option value="">Select an option</option>
                      <option value="google">Google Search</option>
                      <option value="referral">Referral</option>
                      <option value="social">Social Media</option>
                      <option value="trade-show">Trade Show</option>
                      <option value="publication">Industry Publication</option>
                      <option value="other">Other</option>
                    </select>
                  </div>

                  <div>
                    <label htmlFor="message" className="block text-sm font-medium text-[#9ca3af] mb-2">
                      Message *
                    </label>
                    <textarea
                      id="message"
                      name="message"
                      value={formData.message}
                      onChange={handleChange}
                      required
                      rows={5}
                      className={`${inputClasses} resize-none`}
                      placeholder="Tell us about your operation and how we can help..."
                    />
                  </div>

                  {error && (
                    <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-lg">
                      <p className="text-sm text-red-400">{error}</p>
                    </div>
                  )}

                  <Button
                    type="submit"
                    variant="primary"
                    size="lg"
                    fullWidth
                    loading={isSubmitting}
                    icon={<Send className="h-4 w-4" />}
                    iconPosition="right"
                  >
                    Send Message
                  </Button>

                  <p className="text-xs text-[#6b7280] text-center">
                    By submitting this form, you agree to our{' '}
                    <a href="/privacy" className="text-indigo-400 hover:underline">Privacy Policy</a>.
                  </p>
                </form>
              )}
            </RevealOnScroll>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-2">
            <RevealOnScroll delay={200}>
              <div className="space-y-6">
                {/* Response Time */}
                <Card variant="elevated">
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className="w-10 h-10 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center flex-shrink-0">
                        <Clock className="h-5 w-5 text-emerald-400" />
                      </div>
                      <div>
                        <h3 className="text-[15px] font-semibold text-white mb-1">Fast Response</h3>
                        <p className="text-sm text-[#6b7280]">
                          We typically respond within 4 hours during business hours (Mon-Fri, 9am-6pm ET).
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Support Card */}
                <Card variant="elevated">
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className="w-10 h-10 rounded-lg bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center flex-shrink-0">
                        <HelpCircle className="h-5 w-5 text-indigo-400" />
                      </div>
                      <div>
                        <h3 className="text-[15px] font-semibold text-white mb-1">Need Support?</h3>
                        <p className="text-sm text-[#6b7280] mb-3">
                          Existing customers can reach our support team directly.
                        </p>
                        <Button variant="secondary" size="sm" href="mailto:support@aeromanager.app">
                          Contact Support
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* FAQs */}
                <Card variant="elevated">
                  <CardContent className="p-6">
                    <h3 className="text-[15px] font-semibold text-white mb-4">Common Questions</h3>
                    <div className="space-y-4">
                      {faqs.map((faq, i) => (
                        <div key={i}>
                          <h4 className="text-sm font-medium text-white mb-1">{faq.question}</h4>
                          <p className="text-xs text-[#6b7280]">{faq.answer}</p>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {/* Location */}
                <Card variant="elevated">
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className="w-10 h-10 rounded-lg bg-white/[0.04] border border-white/[0.08] flex items-center justify-center flex-shrink-0">
                        <MapPin className="h-5 w-5 text-[#9ca3af]" />
                      </div>
                      <div>
                        <h3 className="text-[15px] font-semibold text-white mb-1">Location</h3>
                        <p className="text-sm text-[#6b7280]">
                          Based in the United States<br />
                          Serving Part 145 stations nationwide
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </RevealOnScroll>
          </div>
        </div>
      </Section>
    </>
  );
};

export default Contact;
