import React from 'react';
import { HeroSection, Section, RevealOnScroll } from '../components/layout';
import { Button, Card, CardContent, Badge } from '../components/ui';
import { Quote, ArrowRight, Star, TrendingUp, Clock, DollarSign, Users, CheckCircle2 } from 'lucide-react';

const Customers: React.FC = () => {
  const testimonials = [
    {
      quote: "Since switching to AeroManager, we've increased our billable hours by 18%. The visibility into our operation is incredible. We can finally see what's happening across all three hangars in real-time.",
      author: 'Mike Rodriguez',
      title: 'Director of Maintenance',
      company: 'Elite Aviation Services',
      location: 'Phoenix, AZ',
      metrics: { stat: '18%', label: 'increase in billable hours' },
    },
    {
      quote: "Finally, a tool built by people who understand Part 145 operations. No more spreadsheet chaos. The Gantt scheduling alone has transformed how we plan our work.",
      author: 'Sarah Chen',
      title: 'Operations Manager',
      company: 'Pacific MRO Solutions',
      location: 'Seattle, WA',
      metrics: { stat: '40%', label: 'less scheduling time' },
    },
    {
      quote: "The financial forecasting alone has saved us from making costly capacity mistakes. We caught a $50K overbooking before it became a crisis. Worth every penny.",
      author: 'James Wilson',
      title: 'VP of Operations',
      company: 'Precision Aircraft Maintenance',
      location: 'Dallas, TX',
      metrics: { stat: '$50K', label: 'saved in first month' },
    },
    {
      quote: "We went from constant fires to actually planning ahead. Our customers notice the difference—we haven't missed a delivery date in 6 months.",
      author: 'Maria Santos',
      title: 'Shop Manager',
      company: 'Coastal Aviation Services',
      location: 'Miami, FL',
      metrics: { stat: '99.5%', label: 'on-time delivery' },
    },
    {
      quote: "Our technicians love it. They can see their assignments, track their time, and know exactly what's expected. No more guessing or walking across the hangar to check the board.",
      author: 'David Kim',
      title: 'Lead Technician',
      company: 'Summit Air Maintenance',
      location: 'Denver, CO',
      metrics: { stat: '2hrs', label: 'saved per tech/day' },
    },
    {
      quote: "The quote builder paid for itself immediately. We used to spend an hour on each quote. Now it's 10 minutes and they look way more professional.",
      author: 'Jennifer Adams',
      title: 'Customer Service Manager',
      company: 'Atlantic MRO Group',
      location: 'Atlanta, GA',
      metrics: { stat: '85%', label: 'faster quoting' },
    },
  ];

  const stats = [
    { value: '50+', label: 'Part 145 Stations', icon: Users },
    { value: '3.2M+', label: 'Labor Hours Tracked', icon: Clock },
    { value: '$47M+', label: 'Revenue Managed', icon: DollarSign },
    { value: '99.8%', label: 'Uptime', icon: TrendingUp },
  ];

  const caseStudies = [
    {
      company: 'Pacific MRO Solutions',
      challenge: 'Managing 3 hangars with different teams using disconnected spreadsheets',
      solution: 'Unified scheduling and capacity planning across all locations',
      results: ['40% reduction in scheduling conflicts', '25% increase in utilization', 'Real-time visibility across locations'],
    },
    {
      company: 'Elite Aviation Services',
      challenge: 'No visibility into job profitability until weeks after completion',
      solution: 'Real-time financial tracking with job cost analysis',
      results: ['18% increase in billable hours', 'Identified $30K in unbilled labor', 'Margin visibility during jobs'],
    },
  ];

  const logos = [
    'ATLANTIC MRO',
    'PACIFIC AVIATION',
    'ELITE AVIATION',
    'SUMMIT AIR',
    'COASTAL AVIATION',
    'PRECISION AIRCRAFT',
  ];

  return (
    <>
      <HeroSection>
        <div className="text-center max-w-3xl mx-auto">
          <RevealOnScroll>
            <Badge variant="secondary" className="mb-6">Customer Stories</Badge>
          </RevealOnScroll>
          <RevealOnScroll delay={100}>
            <h1 className="text-[2.75rem] sm:text-[3.5rem] lg:text-[4rem] font-semibold text-white mb-6 leading-[1.1] tracking-tight">
              Trusted by{' '}
              <span className="bg-gradient-to-r from-[#c8c8ff] via-[#a5b4fc] to-[#818cf8] bg-clip-text text-transparent">
                elite 145 stations
              </span>
            </h1>
          </RevealOnScroll>
          <RevealOnScroll delay={200}>
            <p className="text-lg text-[#9ca3af] max-w-2xl mx-auto">
              See why leading Part 145 repair stations choose AeroManager
              to run their operations.
            </p>
          </RevealOnScroll>
        </div>
      </HeroSection>

      {/* Stats Bar */}
      <Section padding="md" background="panel" border="top">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {stats.map((stat, i) => (
            <RevealOnScroll key={i} delay={i * 100}>
              <div className="text-center">
                <div className="inline-flex items-center justify-center w-10 h-10 rounded-lg bg-indigo-500/10 border border-indigo-500/20 mb-3">
                  <stat.icon className="h-5 w-5 text-indigo-400" />
                </div>
                <div className="text-2xl sm:text-3xl font-bold text-white mb-1">{stat.value}</div>
                <div className="text-sm text-[#6b7280]">{stat.label}</div>
              </div>
            </RevealOnScroll>
          ))}
        </div>
      </Section>

      {/* Logo Cloud */}
      <Section padding="md" background="default" border="top">
        <RevealOnScroll>
          <div className="text-center">
            <p className="text-sm text-[#6b7280] uppercase tracking-wider mb-6">
              Trusted by Part 145 stations across the country
            </p>
            <div className="flex flex-wrap items-center justify-center gap-x-12 gap-y-4">
              {logos.map((logo) => (
                <span
                  key={logo}
                  className="text-sm font-semibold text-[#4b5563] tracking-wider opacity-60 hover:opacity-100 transition-opacity"
                >
                  {logo}
                </span>
              ))}
            </div>
          </div>
        </RevealOnScroll>
      </Section>

      {/* Featured Testimonials */}
      <Section padding="xl" background="panel" border="top">
        <div className="text-center mb-12">
          <RevealOnScroll>
            <Badge variant="secondary" className="mb-4">Testimonials</Badge>
            <h2 className="text-title-1 font-semibold text-white mb-4">
              What our customers say
            </h2>
            <p className="text-[#9ca3af] max-w-2xl mx-auto">
              Real results from real maintenance operations.
            </p>
          </RevealOnScroll>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {testimonials.map((testimonial, index) => (
            <RevealOnScroll key={testimonial.author} delay={index * 75}>
              <Card variant="elevated" className="h-full flex flex-col">
                <CardContent className="p-6 flex flex-col h-full">
                  {/* Rating */}
                  <div className="flex items-center gap-1 text-yellow-500 mb-4">
                    {[1, 2, 3, 4, 5].map((s) => (
                      <Star key={s} className="h-4 w-4 fill-current" />
                    ))}
                  </div>

                  {/* Quote */}
                  <p className="text-[#d1d5db] mb-6 flex-1 leading-relaxed">
                    "{testimonial.quote}"
                  </p>

                  {/* Metric highlight */}
                  <div className="bg-indigo-500/10 border border-indigo-500/20 rounded-lg p-3 mb-4">
                    <div className="text-xl font-bold text-indigo-400">{testimonial.metrics.stat}</div>
                    <div className="text-xs text-[#9ca3af]">{testimonial.metrics.label}</div>
                  </div>

                  {/* Author */}
                  <div className="flex items-center gap-3 pt-4 border-t border-white/[0.06]">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-indigo-400 to-violet-500 flex items-center justify-center text-sm text-white font-medium">
                      {testimonial.author.split(' ').map(n => n[0]).join('')}
                    </div>
                    <div>
                      <div className="text-sm font-medium text-white">{testimonial.author}</div>
                      <div className="text-xs text-[#6b7280]">{testimonial.title}</div>
                      <div className="text-xs text-indigo-400">{testimonial.company}</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </RevealOnScroll>
          ))}
        </div>
      </Section>

      {/* Case Studies */}
      <Section padding="xl" background="default" border="top">
        <div className="text-center mb-12">
          <RevealOnScroll>
            <Badge variant="secondary" className="mb-4">Case Studies</Badge>
            <h2 className="text-title-1 font-semibold text-white mb-4">
              Success stories in depth
            </h2>
            <p className="text-[#9ca3af] max-w-2xl mx-auto">
              See how operations like yours transformed with AeroManager.
            </p>
          </RevealOnScroll>
        </div>

        <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {caseStudies.map((study, i) => (
            <RevealOnScroll key={i} delay={i * 150}>
              <Card variant="gradient" className="h-full">
                <CardContent className="p-8">
                  <h3 className="text-xl font-semibold text-white mb-6">{study.company}</h3>

                  <div className="space-y-6">
                    <div>
                      <div className="text-xs uppercase tracking-wider text-rose-400 mb-2">Challenge</div>
                      <p className="text-[#9ca3af]">{study.challenge}</p>
                    </div>

                    <div>
                      <div className="text-xs uppercase tracking-wider text-indigo-400 mb-2">Solution</div>
                      <p className="text-[#9ca3af]">{study.solution}</p>
                    </div>

                    <div>
                      <div className="text-xs uppercase tracking-wider text-emerald-400 mb-2">Results</div>
                      <div className="space-y-2">
                        {study.results.map((result, j) => (
                          <div key={j} className="flex items-center gap-2">
                            <CheckCircle2 className="h-4 w-4 text-emerald-500 flex-shrink-0" />
                            <span className="text-[#d1d5db] text-sm">{result}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </RevealOnScroll>
          ))}
        </div>
      </Section>

      {/* CTA */}
      <Section padding="xl" background="panel" border="top">
        <RevealOnScroll>
          <div className="text-center max-w-2xl mx-auto">
            <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 mb-6">
              <Users className="h-7 w-7 text-indigo-400" />
            </div>
            <h2 className="text-title-1 font-semibold text-white mb-4">
              Join the best in the industry
            </h2>
            <p className="text-[#9ca3af] mb-8">
              Start your 14-day free trial and see why top 145 stations trust AeroManager.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Button
                variant="primary"
                size="lg"
                to="/register"
                icon={<ArrowRight className="h-4 w-4" />}
                iconPosition="right"
              >
                Start Free Trial
              </Button>
              <Button variant="ghost" size="lg" to="/contact">
                Talk to Sales
              </Button>
            </div>
          </div>
        </RevealOnScroll>
      </Section>
    </>
  );
};

export default Customers;
