import React, { useState } from 'react';
import { HeroSection, Section, RevealOnScroll } from '../components/layout';
import { Button, Card, CardContent, Badge } from '../components/ui';
import { Check, ArrowRight, ChevronDown, MessageCircle, Shield, Zap, Clock, HelpCircle } from 'lucide-react';

// FAQ Item Component
interface FAQItemProps {
  question: string;
  answer: string;
  isOpen: boolean;
  onToggle: () => void;
}

const FAQItem: React.FC<FAQItemProps> = ({ question, answer, isOpen, onToggle }) => (
  <div className="border-b border-white/[0.06]">
    <button
      onClick={onToggle}
      className="w-full flex items-center justify-between py-5 text-left group"
    >
      <span className="text-[15px] font-medium text-white group-hover:text-indigo-400 transition-colors">
        {question}
      </span>
      <ChevronDown
        className={`h-5 w-5 text-[#6b7280] transition-transform duration-200 ${
          isOpen ? 'rotate-180' : ''
        }`}
      />
    </button>
    <div
      className={`overflow-hidden transition-all duration-200 ${
        isOpen ? 'max-h-96 pb-5' : 'max-h-0'
      }`}
    >
      <p className="text-[#9ca3af] text-sm leading-relaxed">{answer}</p>
    </div>
  </div>
);

// Pricing Page - $200/mo or $2000/yr (save $400)
const Pricing: React.FC = () => {
  const [billingPeriod, setBillingPeriod] = useState<'monthly' | 'annual'>('monthly');
  const [openFAQ, setOpenFAQ] = useState<number | null>(0);

  const features = [
    'Unlimited users & seats',
    'Unlimited hangars & bays',
    'Visual Gantt scheduling',
    'Real-time financial tracking',
    'Capacity forecasting',
    'Professional quote builder',
    'Analytics dashboard',
    'Personnel management',
    'AOG priority handling',
    'Customer portal',
    'Priority email support',
    'API access',
    'Data export',
    'SSO (coming soon)',
  ];

  const highlights = [
    {
      icon: Shield,
      title: 'No per-seat fees',
      description: 'Add your entire team without worrying about costs scaling.',
    },
    {
      icon: Zap,
      title: 'All features included',
      description: 'Every feature, every tool. No tiers, no upsells.',
    },
    {
      icon: Clock,
      title: '14-day free trial',
      description: 'Test drive everything before you commit.',
    },
  ];

  const faqs = [
    {
      question: 'How does the 14-day free trial work?',
      answer: 'Sign up and get full access to all features for 14 days. No credit card required. At the end of your trial, you can choose to subscribe or your account will be paused (your data stays safe).',
    },
    {
      question: 'What happens if I need more than one hangar location?',
      answer: 'No problem! The single price covers unlimited hangar locations. Whether you have 1 hangar or 10, the pricing stays the same.',
    },
    {
      question: 'Is there a contract or can I cancel anytime?',
      answer: 'Monthly plans can be cancelled anytime with no penalties. Annual plans are billed upfront but can be cancelled at renewal. We don\'t do contracts or commitments.',
    },
    {
      question: 'Do you offer discounts for small operations?',
      answer: 'Our pricing is already designed to be accessible for operations of all sizes. That said, if you\'re just starting out, reach out to our team—we\'re happy to discuss options.',
    },
    {
      question: 'What kind of support is included?',
      answer: 'All plans include priority email support with typical response times under 4 hours during business hours. We also have extensive documentation and video tutorials.',
    },
    {
      question: 'Can I migrate my data from spreadsheets or other tools?',
      answer: 'Yes! We offer free migration assistance for new customers. Our team will help you import your existing jobs, customers, and historical data.',
    },
    {
      question: 'Is my data secure?',
      answer: 'Absolutely. We use bank-level encryption (AES-256), SOC 2 compliant infrastructure, and regular security audits. Your data is backed up daily and stored in secure US data centers.',
    },
  ];

  const price = billingPeriod === 'monthly' ? 200 : 2000;
  const period = billingPeriod === 'monthly' ? '/month' : '/year';

  return (
    <>
      <HeroSection>
        <div className="text-center max-w-3xl mx-auto">
          <RevealOnScroll>
            <Badge variant="secondary" className="mb-6">
              Pricing
            </Badge>
          </RevealOnScroll>
          <RevealOnScroll delay={100}>
            <h1 className="text-[2.75rem] sm:text-[3.5rem] lg:text-[4rem] font-semibold text-white mb-6 leading-[1.1] tracking-tight">
              Simple, transparent{' '}
              <span className="bg-gradient-to-r from-[#c8c8ff] via-[#a5b4fc] to-[#818cf8] bg-clip-text text-transparent">
                pricing
              </span>
            </h1>
          </RevealOnScroll>
          <RevealOnScroll delay={200}>
            <p className="text-lg text-[#9ca3af] max-w-2xl mx-auto">
              One plan, everything included. No hidden fees, no per-seat charges.
              Start with a 14-day free trial.
            </p>
          </RevealOnScroll>
        </div>
      </HeroSection>

      {/* Pricing Card */}
      <Section padding="xl" background="panel" border="top">
        <div className="max-w-4xl mx-auto">
          <RevealOnScroll>
            {/* Billing Toggle */}
            <div className="flex items-center justify-center gap-2 mb-10">
              <button
                onClick={() => setBillingPeriod('monthly')}
                className={`px-5 py-2.5 text-sm font-medium rounded-lg transition-all ${
                  billingPeriod === 'monthly'
                    ? 'bg-white/[0.1] text-white border border-white/[0.1]'
                    : 'text-[#9ca3af] hover:text-white'
                }`}
              >
                Monthly
              </button>
              <button
                onClick={() => setBillingPeriod('annual')}
                className={`px-5 py-2.5 text-sm font-medium rounded-lg transition-all flex items-center gap-2 ${
                  billingPeriod === 'annual'
                    ? 'bg-white/[0.1] text-white border border-white/[0.1]'
                    : 'text-[#9ca3af] hover:text-white'
                }`}
              >
                Annual
                <span className="px-2 py-0.5 text-xs bg-emerald-500/20 text-emerald-400 rounded-full">
                  Save $400
                </span>
              </button>
            </div>
          </RevealOnScroll>

          <div className="grid lg:grid-cols-5 gap-8 items-start">
            {/* Pricing Card */}
            <RevealOnScroll delay={100} className="lg:col-span-2">
              <Card variant="gradient" className="border-indigo-500/30 relative overflow-hidden sticky top-24">
                {/* Glow effect */}
                <div className="absolute inset-0 bg-gradient-to-b from-indigo-500/10 to-transparent pointer-events-none" />

                <CardContent className="p-8 relative">
                  {/* Popular badge */}
                  {billingPeriod === 'annual' && (
                    <div className="absolute -top-px left-1/2 -translate-x-1/2">
                      <span className="inline-flex px-3 py-1 text-xs font-medium bg-indigo-500 text-white rounded-b-lg">
                        Most Popular
                      </span>
                    </div>
                  )}

                  {/* Price */}
                  <div className="text-center mb-6 pt-2">
                    <div className="flex items-baseline justify-center gap-2">
                      <span className="text-5xl font-bold text-white">${price}</span>
                      <span className="text-[#9ca3af]">{period}</span>
                    </div>
                    {billingPeriod === 'annual' && (
                      <p className="text-sm text-emerald-400 mt-2">
                        That's only $167/month — 2 months free!
                      </p>
                    )}
                  </div>

                  {/* Trial Badge */}
                  <div className="text-center mb-6">
                    <span className="inline-flex items-center gap-2 px-4 py-2 bg-indigo-500/10 border border-indigo-500/20 rounded-full text-sm text-indigo-400">
                      <span className="relative flex h-2 w-2">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75" />
                        <span className="relative inline-flex rounded-full h-2 w-2 bg-indigo-500" />
                      </span>
                      14-day free trial included
                    </span>
                  </div>

                  {/* CTA */}
                  <Button
                    variant="primary"
                    size="lg"
                    fullWidth
                    to="/register"
                    icon={<ArrowRight className="h-4 w-4" />}
                    iconPosition="right"
                  >
                    Start Free Trial
                  </Button>

                  {/* Guarantee */}
                  <p className="text-center text-xs text-[#6b7280] mt-4">
                    No credit card required. Cancel anytime.
                  </p>
                </CardContent>
              </Card>
            </RevealOnScroll>

            {/* Features List */}
            <RevealOnScroll delay={200} className="lg:col-span-3">
              <div className="bg-[#0d0e10] border border-white/[0.06] rounded-xl p-8">
                <h3 className="text-lg font-semibold text-white mb-6">Everything included:</h3>
                <div className="grid sm:grid-cols-2 gap-4">
                  {features.map((feature, i) => (
                    <div key={i} className="flex items-center gap-3">
                      <div className="flex-shrink-0 w-5 h-5 rounded-full bg-emerald-500/20 flex items-center justify-center">
                        <Check className="h-3 w-3 text-emerald-400" />
                      </div>
                      <span className="text-[#d1d5db] text-sm">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>
            </RevealOnScroll>
          </div>
        </div>
      </Section>

      {/* Highlights */}
      <Section padding="lg" background="default" border="top">
        <div className="grid md:grid-cols-3 gap-6">
          {highlights.map((highlight, i) => (
            <RevealOnScroll key={i} delay={i * 100}>
              <div className="text-center p-6">
                <div className="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-indigo-500/10 border border-indigo-500/20 mb-4">
                  <highlight.icon className="h-6 w-6 text-indigo-400" />
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">{highlight.title}</h3>
                <p className="text-sm text-[#9ca3af]">{highlight.description}</p>
              </div>
            </RevealOnScroll>
          ))}
        </div>
      </Section>

      {/* FAQ Section */}
      <Section padding="xl" background="panel" border="top">
        <div className="max-w-3xl mx-auto">
          <RevealOnScroll>
            <div className="text-center mb-12">
              <Badge variant="secondary" className="mb-4">FAQ</Badge>
              <h2 className="text-title-1 font-semibold text-white mb-4">
                Frequently asked questions
              </h2>
              <p className="text-[#9ca3af]">
                Everything you need to know about pricing and subscriptions.
              </p>
            </div>
          </RevealOnScroll>

          <RevealOnScroll delay={100}>
            <div className="bg-[#0d0e10] border border-white/[0.06] rounded-xl px-6">
              {faqs.map((faq, i) => (
                <FAQItem
                  key={i}
                  question={faq.question}
                  answer={faq.answer}
                  isOpen={openFAQ === i}
                  onToggle={() => setOpenFAQ(openFAQ === i ? null : i)}
                />
              ))}
            </div>
          </RevealOnScroll>
        </div>
      </Section>

      {/* Contact Sales */}
      <Section padding="xl" background="default" border="top">
        <RevealOnScroll>
          <div className="max-w-2xl mx-auto text-center">
            <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 mb-6">
              <MessageCircle className="h-7 w-7 text-indigo-400" />
            </div>
            <h2 className="text-title-1 font-semibold text-white mb-4">
              Still have questions?
            </h2>
            <p className="text-[#9ca3af] mb-8">
              Our team is happy to walk you through the platform and answer any questions.
              Schedule a call or send us a message.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Button variant="primary" size="lg" to="/contact">
                Contact Sales
              </Button>
              <Button variant="ghost" size="lg" to="/features">
                Explore Features
              </Button>
            </div>
          </div>
        </RevealOnScroll>
      </Section>
    </>
  );
};

export default Pricing;
