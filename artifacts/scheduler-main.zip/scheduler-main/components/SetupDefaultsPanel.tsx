
import React, { useState, useEffect } from 'react';
import { GameState, Hangar, Personnel } from '../types';
import { X, Save, DollarSign, Warehouse, Users, Plus, Trash2, CheckCircle, Settings, AlertCircle } from 'lucide-react';
import { DOLLAR_SIGN as CURRENCY_SYMBOL } from '../App';
import { generateUUID } from '../utils';
import { HelpIcon } from './ui/Tooltip';
import { GLOSSARY } from '../constants';

interface SetupDefaultsPanelProps {
  gameState: GameState;
  onUpdateGameState: (updates: Partial<GameState>) => void;
  onClose: () => void;
}

const SetupDefaultsPanel: React.FC<SetupDefaultsPanelProps> = ({ gameState, onUpdateGameState, onClose }) => {
  // === BATCHED SAVE: Local state for buffering changes ===
  const [cash, setCash] = useState(gameState.cash);
  const [shopRate, setShopRate] = useState(gameState.shopRate);
  const [hangars, setHangars] = useState<Hangar[]>(gameState.hangars);
  const [personnel, setPersonnel] = useState<Personnel[]>(gameState.personnel);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);

  // Sync local state when gameState changes from outside (only if no pending changes)
  useEffect(() => {
    if (!hasUnsavedChanges) {
      setCash(gameState.cash);
      setShopRate(gameState.shopRate);
      setHangars(gameState.hangars);
      setPersonnel(gameState.personnel);
    }
  }, [gameState.cash, gameState.shopRate, gameState.hangars, gameState.personnel, hasUnsavedChanges]);

  // === BATCHED SAVE: Save and Discard handlers ===
  const handleSaveChanges = () => {
    onUpdateGameState({
      cash,
      shopRate,
      hangars,
      personnel
    });
    setHasUnsavedChanges(false);
  };

  const handleDiscardChanges = () => {
    setCash(gameState.cash);
    setShopRate(gameState.shopRate);
    setHangars(gameState.hangars);
    setPersonnel(gameState.personnel);
    setHasUnsavedChanges(false);
  };

  const handleCompleteSetup = () => {
    // Save any pending changes before closing
    if (hasUnsavedChanges) {
      handleSaveChanges();
    }
    onClose();
  };

  // -- Local state updaters (buffered, not auto-saved) --
  const updateCash = (val: number) => {
      setCash(val);
      setHasUnsavedChanges(true);
  };

  const updateShopRate = (val: number) => {
      setShopRate(val);
      setHasUnsavedChanges(true);
  };

  // Hangars
  const updateHangar = (id: string, field: keyof Hangar, val: any) => {
      const updated = hangars.map(h => h.id === id ? { ...h, [field]: val } : h);
      setHangars(updated);
      setHasUnsavedChanges(true);
  };

  const addHangar = () => {
      const newHangar: Hangar = {
          id: generateUUID(),
          name: 'New Hangar',
          size: 'Medium',
          // Default to supporting all known aircraft models
          supportedTypes: gameState.aircraftModels.map(m => m.id),
          baseId: gameState.bases[0]?.id || 'base-1'
      };
      const updated = [...hangars, newHangar];
      setHangars(updated);
      setHasUnsavedChanges(true);
  };

  const removeHangar = (id: string) => {
      const updated = hangars.filter(h => h.id !== id);
      setHangars(updated);
      setHasUnsavedChanges(true);
  };

  // Personnel
  const updatePersonnel = (id: string, field: keyof Personnel, val: any) => {
      const updated = personnel.map(p => p.id === id ? { ...p, [field]: val } : p);
      setPersonnel(updated);
      setHasUnsavedChanges(true);
  };

  const addPerson = () => {
      const newPerson: Personnel = {
          id: generateUUID(),
          name: 'New Tech',
          roleId: gameState.roles[0]?.id || 'tech',
          teamId: null,
          baseId: gameState.bases[0]?.id
      };
      const updated = [...personnel, newPerson];
      setPersonnel(updated);
      setHasUnsavedChanges(true);
  };

  const removePerson = (id: string) => {
      const updated = personnel.filter(p => p.id !== id);
      setPersonnel(updated);
      setHasUnsavedChanges(true);
  };

  return (
    <div className="fixed inset-0 bg-[#08090a] z-[200] flex flex-col overflow-hidden animate-in fade-in duration-300">
        {/* Header */}
        <div className="h-16 bg-[#0d0e10] border-b border-white/[0.06] flex justify-between items-center px-8 shrink-0">
            <div className="flex items-center gap-4">
                <div className="p-2 bg-[#5e6ad2]/10 rounded-lg border border-[#5e6ad2]/20">
                    <Settings className="text-[#6e79d6]" size={24} />
                </div>
                <div>
                    <h1 className="text-xl font-semibold text-[#e8e8e8] tracking-wide">Quick Shop Setup</h1>
                    <p className="text-xs text-[#6b7280]">Define your initial operating parameters.</p>
                </div>
            </div>
            <button
                onClick={handleCompleteSetup}
                className="px-6 py-2 bg-[#5e6ad2] hover:bg-[#7b86e0] text-white font-semibold rounded-lg transition-all flex items-center gap-2"
            >
                <CheckCircle size={18} /> Complete Setup
            </button>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto custom-scrollbar p-8 bg-[#08090a]">
            <div className="max-w-4xl mx-auto space-y-8 pb-20">
                
                {/* 1. Financials */}
                <section className="bg-[#0d0e10] border border-white/[0.08] rounded-2xl p-6">
                    <h2 className="text-lg font-semibold text-[#e8e8e8] mb-4 flex items-center gap-2 border-b border-white/[0.06] pb-2">
                        <DollarSign size={20} className="text-[#6e79d6]" /> Financial Baselines
                    </h2>
                    <div className="grid grid-cols-2 gap-8">
                        <div>
                            <label className="block text-xs font-semibold text-[#6b7280] uppercase mb-2">Cash on Hand</label>
                            <div className="relative">
                                <span className="absolute left-3 top-3 text-[#6b7280] font-mono font-semibold">{CURRENCY_SYMBOL}</span>
                                <input
                                    type="number"
                                    value={cash}
                                    onChange={(e) => updateCash(Number(e.target.value))}
                                    className="w-full bg-[#08090a] border border-white/[0.08] rounded-lg py-2.5 pl-8 pr-4 text-lg font-mono font-semibold text-white focus:border-[#5e6ad2] outline-none"
                                />
                            </div>
                            <p className="text-[10px] text-[#6b7280] mt-2">Starting treasury balance for operations.</p>
                        </div>
                        <div>
                            <label className="flex items-center gap-1.5 text-xs font-semibold text-[#6b7280] uppercase mb-2">
                                Standard Shop Rate
                                <HelpIcon tooltip={GLOSSARY.shopRate.definition} />
                            </label>
                            <div className="relative">
                                <span className="absolute left-3 top-3 text-[#6b7280] font-mono font-semibold">{CURRENCY_SYMBOL}</span>
                                <input
                                    type="number"
                                    value={shopRate}
                                    onChange={(e) => updateShopRate(Number(e.target.value))}
                                    className="w-full bg-[#08090a] border border-white/[0.08] rounded-lg py-2.5 pl-8 pr-4 text-lg font-mono font-semibold text-white focus:border-[#5e6ad2] outline-none"
                                />
                                <span className="absolute right-3 top-4 text-[10px] text-[#6b7280] font-semibold">/ HR</span>
                            </div>
                            <p className="text-[10px] text-[#6b7280] mt-2">Base billing rate for labor estimates.</p>
                        </div>
                    </div>
                </section>

                {/* 2. Facilities */}
                <section className="bg-[#0d0e10] border border-white/[0.08] rounded-2xl p-6">
                    <div className="flex justify-between items-center mb-4 border-b border-white/[0.06] pb-2">
                        <h2 className="text-lg font-semibold text-[#e8e8e8] flex items-center gap-2">
                            <Warehouse size={20} className="text-[#6e79d6]" /> Facilities (Hangars)
                            <HelpIcon tooltip={GLOSSARY.hangar.definition} />
                        </h2>
                        <button onClick={addHangar} className="text-xs bg-[#141517] hover:bg-[#1a1b1e] text-white border border-white/[0.08] px-3 py-1.5 rounded flex items-center gap-1 transition-colors">
                            <Plus size={14} /> Add Hangar
                        </button>
                    </div>
                    <div className="space-y-3">
                        {hangars.map(hangar => (
                            <div key={hangar.id} className="flex items-center gap-4 bg-[#08090a]/50 p-3 rounded-lg border border-white/[0.06] group">
                                <div className="flex-1">
                                    <label className="text-[9px] font-semibold text-[#6b7280] uppercase block mb-1">Hangar Name</label>
                                    <input
                                        type="text"
                                        value={hangar.name}
                                        onChange={(e) => updateHangar(hangar.id, 'name', e.target.value)}
                                        className="w-full bg-transparent text-sm font-semibold text-[#e8e8e8] border-b border-transparent hover:border-white/[0.08] focus:border-[#5e6ad2] outline-none pb-1"
                                    />
                                </div>
                                <div className="w-40">
                                    <label className="text-[9px] font-semibold text-[#6b7280] uppercase block mb-1">Size Class</label>
                                    <select
                                        value={hangar.size}
                                        onChange={(e) => updateHangar(hangar.id, 'size', e.target.value)}
                                        className="w-full bg-[#0d0e10] border border-white/[0.08] rounded px-2 py-1.5 text-xs text-[#e8e8e8] focus:border-[#5e6ad2] outline-none"
                                    >
                                        <option value="Small">Small</option>
                                        <option value="Medium">Medium</option>
                                        <option value="Large">Large</option>
                                    </select>
                                </div>
                                <div className="w-40">
                                    <label className="flex items-center gap-1 text-[9px] font-semibold text-[#6b7280] uppercase mb-1">
                                        Location
                                        <HelpIcon tooltip={GLOSSARY.base.definition} size={12} />
                                    </label>
                                    <select
                                        value={hangar.baseId}
                                        onChange={(e) => updateHangar(hangar.id, 'baseId', e.target.value)}
                                        className="w-full bg-[#0d0e10] border border-white/[0.08] rounded px-2 py-1.5 text-xs text-[#e8e8e8] focus:border-[#5e6ad2] outline-none"
                                    >
                                        {gameState.bases.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
                                    </select>
                                </div>
                                <div className="w-8 flex justify-center pt-3">
                                    <button onClick={() => removeHangar(hangar.id)} className="text-[#4b5563] hover:text-[#c4626a] p-1 transition-colors">
                                        <Trash2 size={16} />
                                    </button>
                                </div>
                            </div>
                        ))}
                        <div className="text-center text-xs text-[#4b5563] pt-2 italic">
                            New hangars support all aircraft by default. Fine-tune in Configuration.
                        </div>
                    </div>
                </section>

                {/* 3. Personnel */}
                <section className="bg-[#0d0e10] border border-white/[0.08] rounded-2xl p-6">
                    <div className="flex justify-between items-center mb-4 border-b border-white/[0.06] pb-2">
                        <h2 className="text-lg font-semibold text-[#e8e8e8] flex items-center gap-2">
                            <Users size={20} className="text-[#6e79d6]" /> Initial Staffing
                            <HelpIcon tooltip="Your maintenance technicians. Each person has a role that determines their hourly cost and efficiency rating." />
                        </h2>
                        <button onClick={addPerson} className="text-xs bg-[#141517] hover:bg-[#1a1b1e] text-white border border-white/[0.08] px-3 py-1.5 rounded flex items-center gap-1 transition-colors">
                            <Plus size={14} /> Add Staff
                        </button>
                    </div>

                    <div className="grid grid-cols-1 gap-3">
                        {personnel.map(p => (
                            <div key={p.id} className="flex items-center gap-4 bg-[#08090a]/50 p-3 rounded-lg border border-white/[0.06] group">
                                <div className="flex-1">
                                    <label className="text-[9px] font-semibold text-[#6b7280] uppercase block mb-1">Full Name</label>
                                    <input
                                        type="text"
                                        value={p.name}
                                        onChange={(e) => updatePersonnel(p.id, 'name', e.target.value)}
                                        className="w-full bg-transparent text-sm font-semibold text-[#e8e8e8] border-b border-transparent hover:border-white/[0.08] focus:border-[#5e6ad2] outline-none pb-1"
                                    />
                                </div>
                                <div className="w-48">
                                    <label className="text-[9px] font-semibold text-[#6b7280] uppercase block mb-1">Role</label>
                                    <select
                                        value={p.roleId}
                                        onChange={(e) => updatePersonnel(p.id, 'roleId', e.target.value)}
                                        className="w-full bg-[#0d0e10] border border-white/[0.08] rounded px-2 py-1.5 text-xs text-[#e8e8e8] focus:border-[#5e6ad2] outline-none"
                                    >
                                        {gameState.roles.map(r => <option key={r.id} value={r.id}>{r.name}</option>)}
                                    </select>
                                </div>
                                <div className="w-48">
                                    <label className="text-[9px] font-semibold text-[#6b7280] uppercase block mb-1">Base</label>
                                    <select
                                        value={p.baseId || ''}
                                        onChange={(e) => updatePersonnel(p.id, 'baseId', e.target.value || undefined)}
                                        className="w-full bg-[#0d0e10] border border-white/[0.08] rounded px-2 py-1.5 text-xs text-[#e8e8e8] focus:border-[#5e6ad2] outline-none"
                                    >
                                        <option value="">(Float / Unassigned)</option>
                                        {gameState.bases.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
                                    </select>
                                </div>
                                <div className="w-8 flex justify-center pt-3">
                                    <button onClick={() => removePerson(p.id)} className="text-[#4b5563] hover:text-[#c4626a] p-1 transition-colors">
                                        <Trash2 size={16} />
                                    </button>
                                </div>
                            </div>
                        ))}
                    </div>
                </section>

            </div>
        </div>

        {/* === BATCHED SAVE: Save/Discard Footer === */}
        {hasUnsavedChanges && (
            <div className="shrink-0 px-8 py-3 bg-[#141517] border-t border-white/[0.08] flex items-center justify-between">
                <div className="flex items-center gap-2 text-amber-400">
                    <AlertCircle size={16} />
                    <span className="text-sm font-medium">You have unsaved changes</span>
                </div>
                <div className="flex items-center gap-3">
                    <button
                        onClick={handleDiscardChanges}
                        className="px-4 py-2 text-sm font-semibold text-[#9ca3af] hover:text-white hover:bg-white/10 rounded-lg transition-colors"
                    >
                        Discard
                    </button>
                    <button
                        onClick={handleSaveChanges}
                        className="px-4 py-2 text-sm font-semibold bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg transition-colors flex items-center gap-2"
                    >
                        <Save size={14} />
                        Save Changes
                    </button>
                </div>
            </div>
        )}
    </div>
  );
};

export default React.memo(SetupDefaultsPanel);
