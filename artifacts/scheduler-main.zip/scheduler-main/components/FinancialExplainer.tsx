import React, { useState, useEffect, useCallback } from 'react';
import { X, ChevronLeft, ChevronRight, DollarSign, Calculator, TrendingUp, Wallet, ArrowRight, Info } from 'lucide-react';
import { GameState } from '../types';
import { HOURLY_COST_AVG } from '../constants';

interface FinancialExplainerProps {
  isOpen: boolean;
  onClose: () => void;
  initialPage?: number;
  gameState: GameState;
}

const DOLLAR_SIGN = '$';

const FinancialExplainer: React.FC<FinancialExplainerProps> = ({
  isOpen,
  onClose,
  initialPage = 0,
  gameState
}) => {
  const [currentPage, setCurrentPage] = useState(initialPage);

  const pages = [
    { id: 'pricing', title: 'The Pricing Model', icon: DollarSign },
    { id: 'costs', title: 'Understanding Costs', icon: Calculator },
    { id: 'margin', title: 'Margin Calculation', icon: TrendingUp },
    { id: 'cashflow', title: 'Cashflow Basics', icon: Wallet },
  ];

  // Keyboard navigation
  const handleKeyDown = useCallback((e: KeyboardEvent) => {
    if (!isOpen) return;

    if (e.key === 'Escape') {
      onClose();
    } else if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
      setCurrentPage(p => Math.min(p + 1, pages.length - 1));
    } else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
      setCurrentPage(p => Math.max(p - 1, 0));
    }
  }, [isOpen, onClose, pages.length]);

  useEffect(() => {
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleKeyDown]);

  useEffect(() => {
    setCurrentPage(initialPage);
  }, [initialPage, isOpen]);

  if (!isOpen) return null;

  // Calculate example values from gameState
  const shopRate = gameState.shopRate || 135;
  const avgLaborCost = HOURLY_COST_AVG;
  const laborMargin = ((shopRate - avgLaborCost) / shopRate * 100).toFixed(0);
  const dailyOverhead = Math.round(gameState.overheadDaily || 4500);
  const paymentTerms = gameState.paymentTerms ?? 7;

  // Example job values
  const exampleHours = 40;
  const exampleLaborRevenue = exampleHours * shopRate;
  const examplePartsCost = 800;
  const examplePartsMarkup = 1.30;
  const examplePartsRevenue = Math.round(examplePartsCost * examplePartsMarkup);
  const exampleTotalRevenue = exampleLaborRevenue + examplePartsRevenue;
  const exampleLaborCost = exampleHours * avgLaborCost;
  const exampleTotalCost = exampleLaborCost + examplePartsCost;
  const exampleGrossProfit = exampleTotalRevenue - exampleTotalCost;
  const exampleMargin = ((exampleGrossProfit / exampleTotalRevenue) * 100).toFixed(1);

  const renderPage = () => {
    switch (currentPage) {
      case 0: // Pricing Model
        return (
          <div className="space-y-6">
            <p className="text-[#9ca3af] text-sm leading-relaxed">
              Your revenue comes from two sources: <span className="text-[#6e79d6] font-medium">labor</span> and <span className="text-[#6e79d6] font-medium">parts/materials</span>. Here's how each is calculated:
            </p>

            {/* Labor Revenue */}
            <div className="bg-[#141517] rounded-lg p-4 border border-white/[0.06]">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-2 h-2 rounded-full bg-[#5e6ad2]" />
                <span className="text-sm font-semibold text-[#e8e8e8]">Labor Revenue</span>
              </div>
              <div className="flex items-center gap-3 text-sm font-mono">
                <span className="bg-[#0d0e10] px-3 py-2 rounded border border-white/[0.08] text-[#9ca3af]">
                  Hours
                </span>
                <span className="text-[#6b7280]">×</span>
                <span className="bg-[#0d0e10] px-3 py-2 rounded border border-white/[0.08] text-[#9ca3af]">
                  Shop Rate
                </span>
                <span className="text-[#6b7280]">=</span>
                <span className="bg-[#5e6ad2]/20 px-3 py-2 rounded border border-[#5e6ad2]/30 text-[#6e79d6] font-semibold">
                  Labor Revenue
                </span>
              </div>
              <div className="mt-3 text-xs text-[#6b7280]">
                Example: {exampleHours} hrs × {DOLLAR_SIGN}{shopRate}/hr = <span className="text-[#3dae6c] font-medium">{DOLLAR_SIGN}{exampleLaborRevenue.toLocaleString()}</span>
              </div>
            </div>

            {/* Parts Revenue */}
            <div className="bg-[#141517] rounded-lg p-4 border border-white/[0.06]">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-2 h-2 rounded-full bg-[#3dae6c]" />
                <span className="text-sm font-semibold text-[#e8e8e8]">Parts Revenue</span>
              </div>
              <div className="flex items-center gap-3 text-sm font-mono">
                <span className="bg-[#0d0e10] px-3 py-2 rounded border border-white/[0.08] text-[#9ca3af]">
                  Parts Cost
                </span>
                <span className="text-[#6b7280]">×</span>
                <span className="bg-[#0d0e10] px-3 py-2 rounded border border-white/[0.08] text-[#9ca3af]">
                  Markup
                </span>
                <span className="text-[#6b7280]">=</span>
                <span className="bg-[#3dae6c]/20 px-3 py-2 rounded border border-[#3dae6c]/30 text-[#3dae6c] font-semibold">
                  Parts Revenue
                </span>
              </div>
              <div className="mt-3 text-xs text-[#6b7280]">
                Example: {DOLLAR_SIGN}{examplePartsCost} × {examplePartsMarkup.toFixed(2)} = <span className="text-[#3dae6c] font-medium">{DOLLAR_SIGN}{examplePartsRevenue.toLocaleString()}</span>
              </div>
            </div>

            {/* Total */}
            <div className="bg-gradient-to-r from-[#5e6ad2]/10 to-[#3dae6c]/10 rounded-lg p-4 border border-[#5e6ad2]/20">
              <div className="text-sm font-semibold text-[#e8e8e8] mb-2">Total Revenue</div>
              <div className="flex items-center gap-2 text-sm font-mono text-[#9ca3af]">
                <span className="text-[#6e79d6]">{DOLLAR_SIGN}{exampleLaborRevenue.toLocaleString()}</span>
                <span className="text-[#6b7280]">+</span>
                <span className="text-[#3dae6c]">{DOLLAR_SIGN}{examplePartsRevenue.toLocaleString()}</span>
                <span className="text-[#6b7280]">=</span>
                <span className="text-[#e8e8e8] font-bold text-lg">{DOLLAR_SIGN}{exampleTotalRevenue.toLocaleString()}</span>
              </div>
            </div>

            {/* Markup Tiers */}
            <div className="bg-[#0d0e10] rounded-lg p-4 border border-white/[0.06]">
              <div className="flex items-center gap-2 mb-3">
                <Info size={14} className="text-[#6b7280]" />
                <span className="text-xs font-semibold text-[#6b7280] uppercase tracking-wide">Markup Tiers</span>
              </div>
              <div className="grid grid-cols-3 gap-2 text-xs">
                <div className="text-center p-2 bg-[#141517] rounded">
                  <div className="text-[#9ca3af]">&lt; $500</div>
                  <div className="text-[#3dae6c] font-bold">30%</div>
                </div>
                <div className="text-center p-2 bg-[#141517] rounded">
                  <div className="text-[#9ca3af]">&lt; $2,500</div>
                  <div className="text-[#f59e0b] font-bold">15%</div>
                </div>
                <div className="text-center p-2 bg-[#141517] rounded">
                  <div className="text-[#9ca3af]">&gt; $2,500</div>
                  <div className="text-[#6e79d6] font-bold">5%</div>
                </div>
              </div>
            </div>
          </div>
        );

      case 1: // Understanding Costs
        return (
          <div className="space-y-6">
            <p className="text-[#9ca3af] text-sm leading-relaxed">
              Your costs fall into three categories. Understanding each helps you price jobs profitably.
            </p>

            {/* Labor Cost */}
            <div className="bg-[#141517] rounded-lg p-4 border border-white/[0.06]">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-[#c4626a]" />
                  <span className="text-sm font-semibold text-[#e8e8e8]">Labor Cost</span>
                </div>
                <span className="text-xs text-[#6b7280] bg-[#0d0e10] px-2 py-1 rounded">Variable</span>
              </div>
              <div className="flex items-center gap-3 text-sm font-mono mb-3">
                <span className="bg-[#0d0e10] px-3 py-2 rounded border border-white/[0.08] text-[#9ca3af]">
                  Hours
                </span>
                <span className="text-[#6b7280]">×</span>
                <span className="bg-[#0d0e10] px-3 py-2 rounded border border-white/[0.08] text-[#9ca3af]">
                  Avg Hourly Cost
                </span>
                <span className="text-[#6b7280]">=</span>
                <span className="bg-[#c4626a]/20 px-3 py-2 rounded border border-[#c4626a]/30 text-[#c4626a] font-semibold">
                  Labor Cost
                </span>
              </div>
              <div className="text-xs text-[#6b7280]">
                Your average burdened labor cost: <span className="text-[#e8e8e8] font-medium">{DOLLAR_SIGN}{avgLaborCost}/hr</span>
                <br />
                <span className="text-[#4b5563]">(Includes wages + taxes + benefits + insurance)</span>
              </div>
            </div>

            {/* Overhead */}
            <div className="bg-[#141517] rounded-lg p-4 border border-white/[0.06]">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-[#f59e0b]" />
                  <span className="text-sm font-semibold text-[#e8e8e8]">Daily Overhead</span>
                </div>
                <span className="text-xs text-[#6b7280] bg-[#0d0e10] px-2 py-1 rounded">Fixed</span>
              </div>
              <div className="text-2xl font-bold text-[#f59e0b] mb-2">{DOLLAR_SIGN}{dailyOverhead.toLocaleString()}/day</div>
              <div className="text-xs text-[#6b7280] space-y-1">
                <div>Includes: Rent, utilities, insurance, admin staff, equipment</div>
                <div className="text-[#4b5563]">This cost is incurred daily regardless of job volume</div>
              </div>
            </div>

            {/* Overtime */}
            <div className="bg-[#141517] rounded-lg p-4 border border-white/[0.06]">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-[#a855f7]" />
                  <span className="text-sm font-semibold text-[#e8e8e8]">Overtime Premium</span>
                </div>
                <span className="text-xs text-[#a855f7] bg-[#a855f7]/10 px-2 py-1 rounded border border-[#a855f7]/30">1.5×</span>
              </div>
              <div className="text-xs text-[#6b7280] space-y-2">
                <div>When scheduled work <span className="text-[#c4626a]">exceeds daily capacity</span>, overtime kicks in:</div>
                <div className="bg-[#0d0e10] p-3 rounded font-mono text-[#9ca3af]">
                  OT Cost = (Load - Capacity) × Rate × <span className="text-[#a855f7]">1.5</span>
                </div>
                <div className="text-[#4b5563]">Tip: Use the capacity bar in the timeline to avoid overbooking</div>
              </div>
            </div>

            {/* Cost Summary */}
            <div className="bg-gradient-to-r from-[#c4626a]/10 to-[#f59e0b]/10 rounded-lg p-4 border border-[#c4626a]/20">
              <div className="text-sm font-semibold text-[#e8e8e8] mb-2">Example Job Cost</div>
              <div className="space-y-1 text-xs font-mono">
                <div className="flex justify-between text-[#9ca3af]">
                  <span>Labor: {exampleHours} hrs × {DOLLAR_SIGN}{avgLaborCost}/hr</span>
                  <span className="text-[#c4626a]">{DOLLAR_SIGN}{exampleLaborCost.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-[#9ca3af]">
                  <span>Parts (at cost)</span>
                  <span className="text-[#c4626a]">{DOLLAR_SIGN}{examplePartsCost.toLocaleString()}</span>
                </div>
                <div className="border-t border-white/[0.06] my-2" />
                <div className="flex justify-between text-[#e8e8e8] font-semibold">
                  <span>Total Direct Cost</span>
                  <span>{DOLLAR_SIGN}{exampleTotalCost.toLocaleString()}</span>
                </div>
              </div>
            </div>
          </div>
        );

      case 2: // Margin Calculation
        return (
          <div className="space-y-6">
            <p className="text-[#9ca3af] text-sm leading-relaxed">
              <span className="text-[#6e79d6] font-medium">Gross margin</span> shows how profitable a job is before accounting for overhead. It's the primary metric shown in quotes.
            </p>

            {/* Formula */}
            <div className="bg-[#141517] rounded-lg p-4 border border-white/[0.06]">
              <div className="text-sm font-semibold text-[#e8e8e8] mb-3">The Formula</div>
              <div className="bg-[#0d0e10] p-4 rounded-lg font-mono text-center">
                <div className="text-[#9ca3af] text-sm">
                  Gross Margin = <span className="text-[#3dae6c]">(Revenue - Direct Costs)</span> ÷ <span className="text-[#6e79d6]">Revenue</span> × 100
                </div>
              </div>
            </div>

            {/* Example Calculation */}
            <div className="bg-[#141517] rounded-lg p-4 border border-white/[0.06]">
              <div className="text-sm font-semibold text-[#e8e8e8] mb-3">Example Calculation</div>
              <div className="space-y-2 text-xs font-mono">
                <div className="flex justify-between text-[#9ca3af]">
                  <span>Total Revenue</span>
                  <span className="text-[#3dae6c]">{DOLLAR_SIGN}{exampleTotalRevenue.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-[#9ca3af]">
                  <span>- Direct Costs</span>
                  <span className="text-[#c4626a]">({DOLLAR_SIGN}{exampleTotalCost.toLocaleString()})</span>
                </div>
                <div className="border-t border-white/[0.06] my-2" />
                <div className="flex justify-between text-[#9ca3af]">
                  <span>= Gross Profit</span>
                  <span className="text-[#e8e8e8] font-bold">{DOLLAR_SIGN}{exampleGrossProfit.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-[#9ca3af] pt-2">
                  <span>÷ Revenue × 100</span>
                  <span className="text-[#3dae6c] font-bold text-lg">{exampleMargin}%</span>
                </div>
              </div>
            </div>

            {/* Color Thresholds */}
            <div className="bg-[#141517] rounded-lg p-4 border border-white/[0.06]">
              <div className="text-sm font-semibold text-[#e8e8e8] mb-3">Margin Health Indicators</div>
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <div className="w-16 h-2 rounded-full bg-[#3dae6c]" />
                  <span className="text-xs text-[#9ca3af]">≥ 30%</span>
                  <span className="text-xs text-[#3dae6c] font-medium">Healthy margin</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-16 h-2 rounded-full bg-[#f59e0b]" />
                  <span className="text-xs text-[#9ca3af]">15-30%</span>
                  <span className="text-xs text-[#f59e0b] font-medium">Acceptable, but tight</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-16 h-2 rounded-full bg-[#c4626a]" />
                  <span className="text-xs text-[#9ca3af]">&lt; 15%</span>
                  <span className="text-xs text-[#c4626a] font-medium">Risk of loss after overhead</span>
                </div>
              </div>
            </div>

            {/* Important Note */}
            <div className="bg-[#f59e0b]/10 rounded-lg p-4 border border-[#f59e0b]/30">
              <div className="flex items-start gap-3">
                <Info size={16} className="text-[#f59e0b] mt-0.5 shrink-0" />
                <div className="text-xs text-[#9ca3af]">
                  <span className="text-[#f59e0b] font-semibold">Important:</span> Gross margin does NOT include fixed overhead ({DOLLAR_SIGN}{dailyOverhead.toLocaleString()}/day).
                  A job with 30% margin may still lose money if overhead isn't covered by total volume.
                </div>
              </div>
            </div>

            {/* Your Labor Margin */}
            <div className="bg-gradient-to-r from-[#5e6ad2]/10 to-transparent rounded-lg p-4 border border-[#5e6ad2]/20">
              <div className="text-sm font-semibold text-[#e8e8e8] mb-2">Your Current Labor Margin</div>
              <div className="flex items-center gap-3">
                <span className="text-3xl font-bold text-[#6e79d6]">{laborMargin}%</span>
                <div className="text-xs text-[#6b7280]">
                  <div>Shop Rate: {DOLLAR_SIGN}{shopRate}/hr</div>
                  <div>Avg Cost: {DOLLAR_SIGN}{avgLaborCost}/hr</div>
                </div>
              </div>
            </div>
          </div>
        );

      case 3: // Cashflow Basics
        return (
          <div className="space-y-6">
            <p className="text-[#9ca3af] text-sm leading-relaxed">
              Cash doesn't arrive instantly when a job completes. Understanding the timing keeps your shop solvent.
            </p>

            {/* Timeline Visual */}
            <div className="bg-[#141517] rounded-lg p-4 border border-white/[0.06]">
              <div className="text-sm font-semibold text-[#e8e8e8] mb-4">The Cash Timeline</div>
              <div className="relative">
                {/* Timeline bar */}
                <div className="h-1 bg-white/[0.06] rounded-full relative">
                  <div className="absolute left-0 top-0 h-full w-1/3 bg-[#c4626a] rounded-l-full" />
                  <div className="absolute left-1/3 top-0 h-full w-1/3 bg-[#f59e0b]" />
                  <div className="absolute left-2/3 top-0 h-full w-1/3 bg-[#3dae6c] rounded-r-full" />
                </div>
                {/* Timeline markers */}
                <div className="flex justify-between mt-3 text-xs">
                  <div className="text-center">
                    <div className="w-3 h-3 rounded-full bg-[#c4626a] mx-auto mb-1" />
                    <div className="text-[#c4626a] font-medium">Day 1</div>
                    <div className="text-[#6b7280]">Work begins</div>
                    <div className="text-[#6b7280]">Costs start</div>
                  </div>
                  <div className="text-center">
                    <div className="w-3 h-3 rounded-full bg-[#f59e0b] mx-auto mb-1" />
                    <div className="text-[#f59e0b] font-medium">Job Complete</div>
                    <div className="text-[#6b7280]">Invoice sent</div>
                  </div>
                  <div className="text-center">
                    <div className="w-3 h-3 rounded-full bg-[#3dae6c] mx-auto mb-1" />
                    <div className="text-[#3dae6c] font-medium">+{paymentTerms} Days</div>
                    <div className="text-[#6b7280]">Payment received</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Cash In vs Cash Out */}
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-[#c4626a]/10 rounded-lg p-4 border border-[#c4626a]/30">
                <div className="flex items-center gap-2 mb-3">
                  <ArrowRight size={14} className="text-[#c4626a] rotate-180" />
                  <span className="text-sm font-semibold text-[#c4626a]">Cash Out</span>
                </div>
                <div className="text-xs text-[#9ca3af] space-y-1">
                  <div>✓ Daily labor costs</div>
                  <div>✓ Daily overhead ({DOLLAR_SIGN}{dailyOverhead.toLocaleString()})</div>
                  <div>✓ Overtime premiums</div>
                  <div className="text-[#6b7280] pt-1">Occurs immediately</div>
                </div>
              </div>
              <div className="bg-[#3dae6c]/10 rounded-lg p-4 border border-[#3dae6c]/30">
                <div className="flex items-center gap-2 mb-3">
                  <ArrowRight size={14} className="text-[#3dae6c]" />
                  <span className="text-sm font-semibold text-[#3dae6c]">Cash In</span>
                </div>
                <div className="text-xs text-[#9ca3af] space-y-1">
                  <div>✓ Job revenue</div>
                  <div>✓ Parts markup</div>
                  <div className="text-[#6b7280] pt-1">Delayed {paymentTerms} days</div>
                </div>
              </div>
            </div>

            {/* Warning */}
            <div className="bg-[#c4626a]/10 rounded-lg p-4 border border-[#c4626a]/30">
              <div className="text-sm font-semibold text-[#c4626a] mb-2">⚠️ Cash Warning</div>
              <div className="text-xs text-[#9ca3af]">
                The cashflow forecast shows a <span className="text-[#c4626a] font-medium">red warning</span> when your projected balance goes negative.
                This means you may run out of cash before payments arrive.
              </div>
            </div>

            {/* Tips */}
            <div className="bg-[#141517] rounded-lg p-4 border border-white/[0.06]">
              <div className="text-sm font-semibold text-[#e8e8e8] mb-3">💡 Cash Management Tips</div>
              <div className="text-xs text-[#9ca3af] space-y-2">
                <div className="flex items-start gap-2">
                  <span className="text-[#6e79d6]">1.</span>
                  <span>Keep a cash buffer of at least 2 weeks of operating costs</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-[#6e79d6]">2.</span>
                  <span>Request deposits on large jobs (reduces payment risk)</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-[#6e79d6]">3.</span>
                  <span>Avoid scheduling too many jobs with delayed payments simultaneously</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-[#6e79d6]">4.</span>
                  <span>Monitor the cashflow projection regularly in the Financial panel</span>
                </div>
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/70 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* Modal */}
      <div className="relative bg-[#0d0e10] border border-white/[0.08] rounded-xl shadow-2xl w-full max-w-2xl max-h-[85vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/[0.06] shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[#5e6ad2] to-[#3dae6c] flex items-center justify-center">
              <DollarSign size={20} className="text-white" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-[#e8e8e8]">How Pricing Works</h2>
              <p className="text-xs text-[#6b7280]">Understanding your financial model</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-[#6b7280] hover:text-[#e8e8e8] hover:bg-white/[0.05] rounded-lg transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        {/* Page Tabs */}
        <div className="flex border-b border-white/[0.06] px-6 shrink-0">
          {pages.map((page, i) => {
            const Icon = page.icon;
            return (
              <button
                key={page.id}
                onClick={() => setCurrentPage(i)}
                className={`
                  flex items-center gap-2 px-4 py-3 text-xs font-medium transition-colors relative
                  ${currentPage === i
                    ? 'text-[#6e79d6]'
                    : 'text-[#6b7280] hover:text-[#9ca3af]'}
                `}
              >
                <Icon size={14} />
                <span className="hidden sm:inline">{page.title}</span>
                {currentPage === i && (
                  <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#5e6ad2]" />
                )}
              </button>
            );
          })}
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto px-6 py-6 custom-scrollbar">
          <div className="mb-4">
            <h3 className="text-lg font-semibold text-[#e8e8e8] flex items-center gap-2">
              {React.createElement(pages[currentPage].icon, { size: 18, className: 'text-[#6e79d6]' })}
              {pages[currentPage].title}
            </h3>
          </div>
          {renderPage()}
        </div>

        {/* Footer Navigation */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-white/[0.06] bg-[#141517]/50 shrink-0">
          <button
            onClick={() => setCurrentPage(p => p - 1)}
            disabled={currentPage === 0}
            className={`
              flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors
              ${currentPage === 0
                ? 'text-[#4b5563] cursor-not-allowed'
                : 'text-[#9ca3af] hover:text-[#e8e8e8] hover:bg-white/[0.05]'}
            `}
          >
            <ChevronLeft size={16} />
            Previous
          </button>

          {/* Page Dots */}
          <div className="flex items-center gap-2">
            {pages.map((_, i) => (
              <button
                key={i}
                onClick={() => setCurrentPage(i)}
                className={`
                  w-2 h-2 rounded-full transition-colors
                  ${currentPage === i ? 'bg-[#5e6ad2]' : 'bg-white/[0.1] hover:bg-white/[0.2]'}
                `}
              />
            ))}
          </div>

          <button
            onClick={() => currentPage === pages.length - 1 ? onClose() : setCurrentPage(p => p + 1)}
            className={`
              flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors
              ${currentPage === pages.length - 1
                ? 'bg-[#5e6ad2] text-white hover:bg-[#7b86e0]'
                : 'text-[#9ca3af] hover:text-[#e8e8e8] hover:bg-white/[0.05]'}
            `}
          >
            {currentPage === pages.length - 1 ? 'Done' : 'Next'}
            {currentPage < pages.length - 1 && <ChevronRight size={16} />}
          </button>
        </div>

        {/* Keyboard hint */}
        <div className="text-center pb-3 text-[10px] text-[#4b5563]">
          Use ← → arrow keys to navigate • Esc to close
        </div>
      </div>
    </div>
  );
};

export default FinancialExplainer;
