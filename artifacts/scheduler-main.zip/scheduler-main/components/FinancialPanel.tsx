


import React, { useState, useMemo, useEffect } from 'react';
import { X, LayoutDashboard, TrendingDown, Calculator, Settings, TrendingUp, Maximize2, Plus, Trash2, Target, CreditCard, Building, Percent, HelpCircle } from 'lucide-react';
import FinancialExplainer from './FinancialExplainer';
import { GameState, MONTH_NAMES, ExpenseItem, CapexItem, MarkupTier } from '../types';
import { DOLLAR_SIGN } from '../App';
import { ResponsiveContainer, Area, Line, XAxis, YAxis, Tooltip as RechartsTooltip, CartesianGrid, ReferenceLine, ComposedChart, Bar } from 'recharts';
import { HOURLY_COST_AVG, START_YEAR } from '../constants';
import { Tooltip, HelpIcon } from './ui';
import { generateUUID } from '../utils';

interface FinancialPanelProps {
  gameState: GameState;
  onClose: () => void;
  onUpdateCash: (amount: number) => void;
  onUpdateShopRate: (rate: number) => void;
  onUpdateOverhead: (amount: number) => void;
  initialEditMode?: boolean;
  onExpand?: () => void;
  onUpdateState?: (newState: Partial<GameState>) => void;
  activeTabOverride?: 'general' | 'financial' | 'fpa' | null;
}

const MarkupTierEditor: React.FC<{
    title: string,
    tiers: MarkupTier[],
    onChange: (newTiers: MarkupTier[]) => void,
    tooltipText?: string
}> = ({ title, tiers, onChange, tooltipText }) => {

    const updateTier = (index: number, field: keyof MarkupTier, value: number) => {
        const newTiers = [...tiers];
        newTiers[index] = { ...newTiers[index], [field]: value };

        // Auto sort if maxLimit changes? Maybe better to just let user input.
        // But for tiered logic to work, they should be sequential.
        // For now, simple direct edit.
        onChange(newTiers);
    };

    return (
        <div className="bg-[#0d0e10] border border-white/[0.08] rounded-lg p-4">
            <h4 className="text-xs font-semibold text-[#9ca3af] uppercase mb-3 flex items-center gap-2">
                {title}
                {tooltipText && <HelpIcon tooltip={tooltipText} size={12} />}
            </h4>
            <div className="space-y-2">
                <div className="grid grid-cols-3 gap-2 text-[9px] text-[#6b7280] uppercase font-semibold mb-1">
                    <div className="col-span-2">Value Range</div>
                    <div className="text-right">Markup %</div>
                </div>
                {tiers.map((tier, index) => {
                    const prevLimit = index === 0 ? 0 : tiers[index - 1].maxLimit;
                    const isLast = index === tiers.length - 1;

                    return (
                        <div key={index} className="grid grid-cols-3 gap-2 items-center">
                            <div className="col-span-2 flex items-center gap-2 bg-[#08090a] border border-white/[0.08] rounded-md px-2 py-1.5 text-xs text-[#d1d5db]">
                                <span className="text-[#6b7280] min-w-[30px]">{DOLLAR_SIGN}{prevLimit}</span>
                                <span className="text-[#4b5563]">-</span>
                                {isLast ? (
                                    <span className="text-[#9ca3af] italic">Any</span>
                                ) : (
                                    <div className="flex items-center gap-0.5">
                                        <span className="text-[#6b7280] text-[10px]">$</span>
                                        <input
                                            type="number"
                                            value={tier.maxLimit}
                                            onChange={(e) => updateTier(index, 'maxLimit', parseInt(e.target.value))}
                                            className="bg-transparent w-16 outline-none font-mono text-white font-semibold focus:bg-[#141517] rounded px-1"
                                        />
                                    </div>
                                )}
                            </div>
                            <div className="flex items-center gap-1 bg-[#08090a] border border-white/[0.08] rounded-md px-2 py-1.5 justify-end">
                                <input
                                    type="number"
                                    step="1"
                                    value={Math.round((tier.markup - 1) * 100)}
                                    onChange={(e) => updateTier(index, 'markup', 1 + (parseInt(e.target.value) / 100))}
                                    className="bg-transparent w-10 text-right outline-none font-mono text-[#3dae6c] font-semibold focus:bg-[#141517] rounded px-1"
                                />
                                <span className="text-emerald-600 text-[10px] font-semibold">%</span>
                            </div>
                        </div>
                    );
                })}
            </div>
        </div>
    );
};

const FinancialPanel: React.FC<FinancialPanelProps> = ({ gameState, onClose, onUpdateCash, onUpdateShopRate, onUpdateOverhead, initialEditMode, onExpand, onUpdateState, activeTabOverride }) => {
    // Default to 'financial' (Projections) unless edit mode
    const [activeTab, setActiveTab] = useState<'general' | 'financial' | 'fpa'>('financial');
    const [projectionRange, setProjectionRange] = useState<30 | 90 | 365>(90);

    // Form State for Management Tabs
    const [localCash, setLocalCash] = useState(gameState.cash);
    const [localRate, setLocalRate] = useState(gameState.shopRate || 125);
    const [partMarkups, setPartMarkups] = useState<MarkupTier[]>(gameState.partMarkups || []);
    const [serviceMarkups, setServiceMarkups] = useState<MarkupTier[]>(gameState.serviceMarkups || []);
    const [localCapacityBuffer, setLocalCapacityBuffer] = useState(gameState.capacityBufferPercent ?? 15);
    const [localPaymentTerms, setLocalPaymentTerms] = useState<7 | 15 | 30 | 45 | 60>(gameState.paymentTerms ?? 7);

    // FP&A State
    const [expenses, setExpenses] = useState<ExpenseItem[]>(gameState.expenseItems || []);
    const [capex, setCapex] = useState<CapexItem[]>(gameState.capexItems || []);
    const [isDirty, setIsDirty] = useState(false);

    // Help Modal State
    const [showExplainer, setShowExplainer] = useState(false);
    
    // FP&A Year View State
    const [fpaYear, setFpaYear] = useState(START_YEAR); // Default 2024 (first year)

    // Sync state on open
    useEffect(() => {
        if (initialEditMode) {
            setActiveTab('general');
        }
        setLocalCash(gameState.cash);
        setLocalRate(gameState.shopRate || 125);
        setPartMarkups(gameState.partMarkups || []);
        setServiceMarkups(gameState.serviceMarkups || []);
        setLocalCapacityBuffer(gameState.capacityBufferPercent ?? 15);
        setLocalPaymentTerms(gameState.paymentTerms ?? 7);
        setExpenses(gameState.expenseItems || []);
        setCapex(gameState.capexItems || []);
    }, [gameState, initialEditMode]);

    useEffect(() => {
        if (activeTabOverride) {
            setActiveTab(activeTabOverride);
        }
    }, [activeTabOverride]);

    // Update dirty flag
    useEffect(() => {
        const expensesChanged = JSON.stringify(expenses) !== JSON.stringify(gameState.expenseItems);
        const capexChanged = JSON.stringify(capex) !== JSON.stringify(gameState.capexItems);
        setIsDirty(expensesChanged || capexChanged);
    }, [expenses, capex, gameState.expenseItems, gameState.capexItems]);

    // --- Helper: Calculate Labor Cost for a specific day ---
    const calculateLaborCostForDay = (dayIndex: number) => {
        const dayOfWeek = (dayIndex + 1) % 7; 
        
        let dailyCost = 0;
        
        gameState.personnel.forEach(p => {
            const team = gameState.teams.find(t => t.id === p.teamId);
            if (!team) return;

            const shift = gameState.shifts.find(s => s.id === team.shiftId);
            const role = gameState.roles.find(r => r.id === p.roleId);
            
            if (shift && shift.days.includes(dayOfWeek)) {
                const rate = role?.hourlyCost || HOURLY_COST_AVG;
                dailyCost += (shift.duration * rate);
            }
        });
        return dailyCost;
    };

    // --- Metrics Calculations ---
    const currentDayLaborCost = calculateLaborCostForDay(gameState.day);
    const dailyOverhead = gameState.overheadDaily; // Use current effective global overhead
    
    // Calculate projected monthly burn (next 30 days) - using static overhead assumption for quick metric
    const projectedMonthlyBurn = useMemo(() => {
        let sum = 0;
        for(let i=1; i<=30; i++) {
            sum += (calculateLaborCostForDay(gameState.day + i) + dailyOverhead);
        }
        return sum;
    }, [gameState.day, gameState.personnel, gameState.teams, gameState.shifts, gameState.roles, dailyOverhead]);
    
    // Weighted Average Hourly Cost for Margin Calc
    const avgHourlyCost = useMemo(() => {
        if (gameState.personnel.length === 0) return HOURLY_COST_AVG;
        const totalRate = gameState.personnel.reduce((acc, p) => {
             const role = gameState.roles.find(r => r.id === p.roleId);
             return acc + (role?.hourlyCost || HOURLY_COST_AVG);
        }, 0);
        return totalRate / gameState.personnel.length;
    }, [gameState.personnel, gameState.roles]);

    const grossMargin = gameState.shopRate > 0 
        ? ((gameState.shopRate - avgHourlyCost) / gameState.shopRate) * 100 
        : 0;

    // --- Projection Logic (Dynamic with Monthly Overrides) - MEMOIZED ---
    const projectionData = useMemo(() => {
        const data: Array<{
            day: number;
            label: string;
            balance: number;
            dailyBurn: number;
            expenseBar: number;
            laborCost: number;
            overheadCost: number;
            revenueEvent: number;
            cumulativeExpenses: number;
            changeFromStart: number;
            changePercent: number;
        }> = [];
        let projectedCash = gameState.cash;
        const startingCash = gameState.cash;
        let cumulativeExpenses = 0;

        // Helper to find revenue events
        const revenueEvents: Record<number, number> = {};
        gameState.schedule.forEach(job => {
            if (job.status === 'Scheduled' || job.status === 'In Progress') {
                const endDay = job.startDate + job.deadlineDays + 7;
                if (endDay > gameState.day) {
                    revenueEvents[endDay] = (revenueEvents[endDay] || 0) + job.revenue;
                }
            }
        });

        for (let i = 1; i <= projectionRange; i++) {
            const targetDay = gameState.day + i;
            const date = new Date(START_YEAR, 0, 1 + targetDay);
            const currentYear = date.getFullYear();
            const currentMonth = date.getMonth();

            // --- Dynamic Overhead Lookup ---
            let projectedDailyOverhead = 0;
            // 1. Recurring Expenses
            expenses.forEach(item => {
                const key = `${currentYear}-${currentMonth}`;
                const monthlyCost = item.overrides?.[key] ?? item.monthlyCost;
                projectedDailyOverhead += (monthlyCost / 30);
            });
            // 2. Amortized CapEx
            capex.forEach(item => {
                if (item.amortize && targetDay >= item.plannedDay && targetDay < item.plannedDay + 365) {
                    projectedDailyOverhead += (item.cost / 12 / 30);
                }
            });

            // Calculate labor cost
            const laborCost = calculateLaborCostForDay(targetDay);
            let dayBurn = laborCost + projectedDailyOverhead;

            // Non-amortized CapEx hit
            capex.forEach(item => {
                if (!item.amortize && item.plannedDay === targetDay) {
                    dayBurn += item.cost;
                }
            });

            cumulativeExpenses += dayBurn;
            projectedCash -= dayBurn;

            // Add Revenue
            const revenueAmount = revenueEvents[targetDay] || 0;
            if (revenueAmount) {
                projectedCash += revenueAmount;
            }

            const month = MONTH_NAMES[date.getMonth()];
            const dayNum = date.getDate();
            const label = `${month} ${dayNum}`;

            const changeFromStart = projectedCash - startingCash;
            const changePercent = startingCash !== 0 ? (changeFromStart / startingCash) * 100 : 0;

            data.push({
                day: i,
                label,
                balance: Math.round(projectedCash),
                dailyBurn: Math.round(dayBurn),
                expenseBar: -Math.round(dayBurn),
                laborCost: Math.round(laborCost),
                overheadCost: Math.round(projectedDailyOverhead),
                revenueEvent: Math.round(revenueAmount),
                cumulativeExpenses: Math.round(cumulativeExpenses),
                changeFromStart: Math.round(changeFromStart),
                changePercent: Math.round(changePercent * 10) / 10
            });
        }
        return data;
    }, [
        gameState.day,
        gameState.cash,
        gameState.schedule,
        gameState.personnel,
        gameState.teams,
        gameState.shifts,
        gameState.roles,
        projectionRange,
        expenses,
        capex
    ]);
    
    const gradientOffset = (() => {
        const balances = projectionData.map(d => d.balance);
        const max = Math.max(...balances);
        const min = Math.min(...balances);
        if (max <= 0) return 0;
        if (min >= 0) return 1;
        return max / (max - min);
    })();

    // Percent Change Calculation
    const startBalance = gameState.cash;
    const endBalance = projectionData[projectionData.length - 1]?.balance || startBalance;
    const percentChange = startBalance !== 0 ? ((endBalance - startBalance) / startBalance) * 100 : 0;

    // Find key data points for labels
    const keyPoints = useMemo(() => {
        if (projectionData.length === 0) return { minIndex: -1, maxIndex: -1, zeroCrossings: [] as number[] };

        let minIndex = 0;
        let maxIndex = 0;
        let minVal = projectionData[0].balance;
        let maxVal = projectionData[0].balance;
        const zeroCrossings: number[] = [];

        projectionData.forEach((d, i) => {
            if (d.balance < minVal) { minVal = d.balance; minIndex = i; }
            if (d.balance > maxVal) { maxVal = d.balance; maxIndex = i; }

            // Detect zero crossings
            if (i > 0) {
                const prev = projectionData[i - 1].balance;
                const curr = d.balance;
                if ((prev >= 0 && curr < 0) || (prev < 0 && curr >= 0)) {
                    zeroCrossings.push(i);
                }
            }
        });

        return { minIndex, maxIndex, zeroCrossings };
    }, [projectionData]);

    // Currency formatter for Y-axis
    const formatCurrency = (value: number): string => {
        const absVal = Math.abs(value);
        if (absVal >= 1000000) {
            return `${DOLLAR_SIGN}${(value / 1000000).toFixed(1)}M`;
        } else if (absVal >= 1000) {
            return `${DOLLAR_SIGN}${(value / 1000).toFixed(0)}k`;
        }
        return `${DOLLAR_SIGN}${value.toLocaleString()}`;
    };

    // Custom tooltip component for P&L-style hover data
    const ProjectionTooltip = ({ active, payload }: { active?: boolean; payload?: Array<{ payload: typeof projectionData[0] }> }) => {
        if (!active || !payload?.length) return null;
        const data = payload[0].payload;

        return (
            <div className="bg-[#141517] border border-white/10 rounded-lg p-3 shadow-xl min-w-[200px]">
                <div className="text-xs font-semibold text-white mb-2 pb-2 border-b border-white/10">{data.label}</div>
                <div className="space-y-1.5">
                    {/* Projected Balance */}
                    <div className="flex justify-between gap-4">
                        <span className="text-[10px] text-[#6b7280] uppercase">Balance</span>
                        <span className={`font-mono text-xs font-semibold ${data.balance >= 0 ? 'text-[#3dae6c]' : 'text-[#c4626a]'}`}>
                            {DOLLAR_SIGN}{data.balance.toLocaleString()}
                        </span>
                    </div>

                    {/* Daily Burn */}
                    <div className="flex justify-between gap-4">
                        <span className="text-[10px] text-[#6b7280] uppercase">Daily Burn</span>
                        <span className="font-mono text-xs text-[#c4626a]">
                            -{DOLLAR_SIGN}{data.dailyBurn.toLocaleString()}
                        </span>
                    </div>

                    {/* Labor vs Overhead breakdown */}
                    <div className="flex justify-between gap-4 pl-2">
                        <span className="text-[9px] text-[#4b5563]">Labor</span>
                        <span className="font-mono text-[10px] text-[#9ca3af]">
                            {DOLLAR_SIGN}{data.laborCost.toLocaleString()}
                        </span>
                    </div>
                    <div className="flex justify-between gap-4 pl-2">
                        <span className="text-[9px] text-[#4b5563]">Overhead</span>
                        <span className="font-mono text-[10px] text-[#9ca3af]">
                            {DOLLAR_SIGN}{data.overheadCost.toLocaleString()}
                        </span>
                    </div>

                    {/* Revenue Event (if any) */}
                    {data.revenueEvent > 0 && (
                        <div className="flex justify-between gap-4 pt-1 border-t border-white/5">
                            <span className="text-[10px] text-[#6b7280] uppercase">Revenue</span>
                            <span className="font-mono text-xs text-[#3dae6c] font-semibold">
                                +{DOLLAR_SIGN}{data.revenueEvent.toLocaleString()}
                            </span>
                        </div>
                    )}

                    {/* Change from Start */}
                    <div className="flex justify-between gap-4 pt-1 border-t border-white/5">
                        <span className="text-[10px] text-[#6b7280] uppercase">vs Start</span>
                        <span className={`font-mono text-xs font-semibold ${data.changeFromStart >= 0 ? 'text-[#3dae6c]' : 'text-[#c4626a]'}`}>
                            {data.changeFromStart >= 0 ? '+' : ''}{DOLLAR_SIGN}{data.changeFromStart.toLocaleString()} ({data.changePercent >= 0 ? '+' : ''}{data.changePercent}%)
                        </span>
                    </div>
                </div>
            </div>
        );
    };

    // Custom dot renderer for key points
    const renderKeyPointDot = (props: any) => {
        const { cx, cy, index, payload } = props;
        const isStart = index === 0;
        const isEnd = index === projectionData.length - 1;
        const isMin = index === keyPoints.minIndex && payload.balance < 0;
        const isZeroCrossing = keyPoints.zeroCrossings.includes(index);

        if (!isStart && !isEnd && !isMin && !isZeroCrossing) return null;

        const color = payload.balance >= 0 ? '#10b981' : '#ef4444';
        const labelOffset = isStart ? -50 : isEnd ? 50 : 0;

        return (
            <g key={`dot-${index}`}>
                {/* Dot */}
                <circle cx={cx} cy={cy} r={isMin ? 6 : 5} fill={color} stroke="#0d0e10" strokeWidth={2} />

                {/* Label for start/end points */}
                {(isStart || isEnd) && (
                    <g>
                        <text
                            x={cx + (isStart ? 8 : -8)}
                            y={cy - 12}
                            textAnchor={isStart ? 'start' : 'end'}
                            className="text-[10px] font-mono font-semibold"
                            fill={color}
                        >
                            {formatCurrency(payload.balance)}
                        </text>
                        <text
                            x={cx + (isStart ? 8 : -8)}
                            y={cy - 24}
                            textAnchor={isStart ? 'start' : 'end'}
                            className="text-[8px]"
                            fill="#6b7280"
                        >
                            {isStart ? 'START' : 'END'}
                        </text>
                    </g>
                )}

                {/* Label for minimum point */}
                {isMin && !isStart && !isEnd && (
                    <g>
                        <text
                            x={cx}
                            y={cy + 20}
                            textAnchor="middle"
                            className="text-[10px] font-mono font-semibold"
                            fill="#ef4444"
                        >
                            {formatCurrency(payload.balance)}
                        </text>
                        <text
                            x={cx}
                            y={cy + 32}
                            textAnchor="middle"
                            className="text-[8px]"
                            fill="#ef4444"
                        >
                            LOW
                        </text>
                    </g>
                )}
            </g>
        );
    };

    const handleSaveGeneral = () => {
        onUpdateCash(localCash);
        onUpdateShopRate(localRate);
        if (onUpdateState) {
            onUpdateState({
                partMarkups,
                serviceMarkups,
                capacityBufferPercent: localCapacityBuffer,
                paymentTerms: localPaymentTerms
            });
        }
    };

    const handleSaveFPA = () => {
        if (onUpdateState) {
            const todayDate = new Date(START_YEAR, 0, 1 + gameState.day);
            const currentYear = todayDate.getFullYear();
            const currentMonth = todayDate.getMonth();
            
            let newDailyOverhead = 0;
            expenses.forEach(item => {
                const key = `${currentYear}-${currentMonth}`;
                newDailyOverhead += (item.overrides?.[key] ?? item.monthlyCost);
            });
            
            capex.forEach(item => {
                if (item.amortize && gameState.day >= item.plannedDay && gameState.day < item.plannedDay + 365) {
                    newDailyOverhead += (item.cost / 12);
                }
            });
            newDailyOverhead /= 30;

            onUpdateState({
                expenseItems: expenses,
                capexItems: capex,
                overheadDaily: newDailyOverhead
            });
            setIsDirty(false);
        }
    };

    // FP&A Helpers
    const addExpense = (cat: ExpenseItem['category']) => {
        const newItem: ExpenseItem = {
            id: generateUUID(),
            category: cat,
            name: 'New Item',
            monthlyCost: 0,
            overrides: {}
        };
        setExpenses([...expenses, newItem]);
    };

    const updateExpenseBase = (id: string, field: keyof ExpenseItem, val: any) => {
        setExpenses(expenses.map(e => e.id === id ? { ...e, [field]: val } : e));
    };

    const updateExpenseOverride = (id: string, year: number, monthIndex: number, val: number) => {
        const key = `${year}-${monthIndex}`;
        setExpenses(expenses.map(e => {
            if (e.id !== id) return e;
            const currentOverrides = e.overrides || {};
            if (val === e.monthlyCost) {
                const { [key]: _, ...rest } = currentOverrides;
                return { ...e, overrides: rest };
            }
            return { ...e, overrides: { ...currentOverrides, [key]: val } };
        }));
    };

    const removeExpense = (id: string) => {
        setExpenses(expenses.filter(e => e.id !== id));
    };

    const getMonthlyTotal = (year: number, monthIndex: number) => {
        const key = `${year}-${monthIndex}`;
        return expenses.reduce((sum, item) => {
            return sum + (item.overrides?.[key] ?? item.monthlyCost);
        }, 0);
    };

    return (
        <div className="fixed inset-0 bg-[#08090a]/60 backdrop-blur-sm z-[80] flex items-center justify-center p-8">
            <div id="modal-financial" className="bg-[#0d0e10] w-full max-w-7xl h-[90vh] rounded-xl border border-white/[0.08] shadow-2xl flex flex-col overflow-hidden">
                {/* Header */}
                <div className="bg-[#0d0e10] p-6 border-b border-white/[0.06] flex justify-between items-center shrink-0">
                    <div className="flex items-center gap-3">
                        <div className="bg-[#141517] p-2 rounded-lg border border-white/[0.08]">
                            <LayoutDashboard className="text-zinc-300" size={24} />
                        </div>
                        <div>
                            <h2 className="text-xl font-semibold text-white">Financial Command</h2>
                            <p className="text-xs text-[#6b7280]">Shop Rates, Overhead & Cashflow Projections</p>
                        </div>
                    </div>
                    <div className="flex items-center gap-2">
                        <Tooltip content="How Pricing Works - Learn about revenue, costs, and margins" position="left">
                            <button
                                onClick={() => setShowExplainer(true)}
                                className="p-2 hover:bg-[#141517] rounded-lg text-[#6b7280] hover:text-white transition-colors"
                            >
                                <HelpCircle size={20} />
                            </button>
                        </Tooltip>
                        <button onClick={onClose} className="p-2 hover:bg-[#141517] rounded-lg text-[#6b7280] hover:text-[#d1d5db] transition-colors">
                            <X size={24} />
                        </button>
                    </div>
                </div>

                {/* Tabs */}
                <div className="flex border-b border-white/[0.06] bg-[#08090a] shrink-0">
                    <button
                        id="tab-financial-projections"
                        onClick={() => setActiveTab('financial')}
                        className={`px-6 py-4 text-sm font-semibold uppercase tracking-wide border-b-2 transition-colors flex items-center gap-2 ${activeTab === 'financial' ? 'border-white/40 text-white bg-[#0d0e10]' : 'border-transparent text-[#6b7280] hover:text-[#d1d5db]'}`}
                    >
                        <TrendingDown size={16} /> Projections
                    </button>
                    <button
                        id="tab-financial-fpa"
                        onClick={() => setActiveTab('fpa')}
                        className={`px-6 py-4 text-sm font-semibold uppercase tracking-wide border-b-2 transition-colors flex items-center gap-2 ${activeTab === 'fpa' ? 'border-white/40 text-white bg-[#0d0e10]' : 'border-transparent text-[#6b7280] hover:text-[#d1d5db]'}`}
                    >
                        <Calculator size={16} /> Annual Fixed Costs
                    </button>
                    <button
                        id="tab-financial-rates"
                        onClick={() => setActiveTab('general')}
                        className={`px-6 py-4 text-sm font-semibold uppercase tracking-wide border-b-2 transition-colors flex items-center gap-2 ${activeTab === 'general' ? 'border-white/40 text-white bg-[#0d0e10]' : 'border-transparent text-[#6b7280] hover:text-[#d1d5db]'}`}
                    >
                        <Settings size={16} /> Config & Rates
                    </button>
                </div>

                {/* Content */}
                <div className="flex-1 overflow-hidden p-0 bg-[#0d0e10]">
                    
                    {/* --- GENERAL CONFIG TAB --- */}
                    {activeTab === 'general' && (
                        <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in duration-300 h-full overflow-y-auto p-6 custom-scrollbar">

                            {/* Cash Management */}
                            <div className="bg-[#141517] p-6 rounded-xl border border-white/[0.08]">
                                <h3 className="text-lg font-semibold text-[#e8e8e8] mb-4 flex items-center gap-2">
                                    <CreditCard size={20} className="text-zinc-300" /> Treasury
                                </h3>
                                <div className="grid grid-cols-2 gap-6">
                                    <div>
                                        <label className="block text-xs font-semibold text-[#6b7280] uppercase mb-2 flex items-center gap-1.5">
                                            Cash on Hand ($)
                                            <HelpIcon tooltip="Current available cash balance. Updated as jobs complete (revenue arrives after payment terms) and daily expenses occur." size={12} />
                                        </label>
                                        <input
                                            type="number"
                                            value={localCash}
                                            onChange={(e) => setLocalCash(Number(e.target.value))}
                                            className="w-full bg-[#0d0e10] border border-white/[0.1] rounded-md p-3 text-white font-mono text-lg font-semibold focus:border-white/40 outline-none"
                                        />
                                        <p className="text-xs text-[#6b7280] mt-2">Adjust starting balance or inject capital.</p>
                                    </div>
                                    <div className="flex flex-col justify-center">
                                        <div className="bg-[#0d0e10]/50 p-4 rounded-lg border border-white/[0.08]">
                                            <div className="text-xs text-[#9ca3af] uppercase font-semibold mb-1 flex items-center gap-1.5">
                                                Projected Burn (30d)
                                                <HelpIcon tooltip="Estimated cash consumption over the next 30 days based on scheduled labor costs and fixed overhead expenses." size={12} />
                                            </div>
                                            <div className="text-2xl font-mono text-[#c4626a] font-semibold">{DOLLAR_SIGN}{Math.round(projectedMonthlyBurn).toLocaleString()}</div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            {/* Shop Rates */}
                            <div className="bg-[#141517] p-6 rounded-xl border border-white/[0.08]">
                                <h3 className="text-lg font-semibold text-[#e8e8e8] mb-4 flex items-center gap-2">
                                    <Building size={20} className="text-zinc-300" /> Operational Metrics
                                </h3>
                                <div className="grid grid-cols-2 gap-6">
                                    <div>
                                        <label className="block text-xs font-semibold text-[#6b7280] uppercase mb-2 flex items-center gap-1.5">
                                            Global Shop Rate ($/hr)
                                            <HelpIcon tooltip="Hourly rate charged to customers for labor. This is your billing rate, not your cost. Industry average for Part 145 MRO: $125-150/hr." size={12} />
                                        </label>
                                        <input
                                            type="number"
                                            value={localRate}
                                            onChange={(e) => setLocalRate(Number(e.target.value))}
                                            className="w-full bg-[#0d0e10] border border-white/[0.1] rounded-md p-3 text-white font-mono text-lg font-semibold focus:border-white/40 outline-none"
                                        />
                                    </div>
                                    <div className="flex items-end pb-1">
                                        <div className="grid grid-cols-2 gap-4 w-full">
                                            <div>
                                                <div className="text-xs text-[#6b7280] uppercase font-semibold mb-1 flex items-center gap-1.5">
                                                    Avg Labor Cost
                                                    <HelpIcon tooltip="Weighted average hourly cost across all personnel. Includes wages plus burden (taxes, benefits, insurance)." size={12} />
                                                </div>
                                                <div className="text-lg font-mono text-rose-300 font-semibold">{DOLLAR_SIGN}{Math.round(avgHourlyCost)}/hr</div>
                                            </div>
                                            <div>
                                                <div className="text-xs text-[#6b7280] uppercase font-semibold mb-1 flex items-center gap-1.5">
                                                    Labor Margin
                                                    <HelpIcon tooltip="Gross profit percentage on labor: (Shop Rate - Avg Cost) / Shop Rate. Does NOT include fixed overhead costs." size={12} />
                                                </div>
                                                <div className={`text-lg font-mono font-semibold text-[#3dae6c]`}>
                                                    {grossMargin.toFixed(1)}%
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                {/* Capacity Buffer Setting */}
                                <div className="mt-6 pt-6 border-t border-white/[0.08]">
                                    <label className="block text-xs font-semibold text-[#6b7280] uppercase mb-3 flex items-center gap-1.5">
                                        Capacity Warning Buffer
                                        <HelpIcon tooltip="Reserve capacity percentage. When scheduled load exceeds this threshold, the system shows warnings to prevent overbooking." size={12} />
                                    </label>
                                    <div className="flex items-center gap-4">
                                        <input
                                            type="range"
                                            min={0}
                                            max={30}
                                            value={localCapacityBuffer}
                                            onChange={(e) => setLocalCapacityBuffer(Number(e.target.value))}
                                            className="flex-1 h-2 bg-[#0d0e10] rounded-lg appearance-none cursor-pointer accent-white"
                                        />
                                        <div className="bg-[#0d0e10] border border-white/[0.08] rounded-md px-3 py-2 min-w-[80px] text-center">
                                            <span className="text-lg font-mono font-semibold text-amber-500">{localCapacityBuffer}%</span>
                                        </div>
                                    </div>
                                    <p className="text-xs text-[#6b7280] mt-2">
                                        Show capacity warnings when load exceeds <span className="text-amber-400 font-semibold">{100 - localCapacityBuffer}%</span> of available capacity.
                                    </p>
                                </div>

                                {/* Payment Terms Setting */}
                                <div className="mt-6 pt-6 border-t border-white/[0.08]">
                                    <label className="block text-xs font-semibold text-[#6b7280] uppercase mb-3 flex items-center gap-1.5">
                                        Payment Terms
                                        <HelpIcon tooltip="Number of days after job completion before revenue is received. Affects cashflow projections and receivables tracking." size={12} />
                                    </label>
                                    <div className="flex items-center gap-3">
                                        {([7, 15, 30, 45, 60] as const).map((term) => (
                                            <button
                                                key={term}
                                                onClick={() => setLocalPaymentTerms(term)}
                                                className={`px-4 py-2.5 rounded-lg text-sm font-medium transition-all ${
                                                    localPaymentTerms === term
                                                        ? 'bg-white/20 text-white border border-white/40'
                                                        : 'bg-[#0d0e10] text-[#9ca3af] border border-white/[0.08] hover:border-white/40/50 hover:text-white'
                                                }`}
                                            >
                                                Net {term}
                                            </button>
                                        ))}
                                    </div>
                                    <p className="text-xs text-[#6b7280] mt-2">
                                        Revenue from completed jobs arrives <span className="text-white font-semibold">{localPaymentTerms} days</span> after completion.
                                    </p>
                                </div>
                            </div>

                            {/* Markup Strategy */}
                            <div className="bg-[#141517] p-6 rounded-xl border border-white/[0.08]">
                                <h3 className="text-lg font-semibold text-[#e8e8e8] mb-4 flex items-center gap-2">
                                    <Percent size={20} className="text-zinc-300" /> Markup Strategy
                                    <HelpIcon tooltip="Tiered pricing automatically applies different markup percentages based on cost ranges. Higher markups on low-cost items, lower markups on expensive items." size={14} />
                                </h3>
                                <div className="grid grid-cols-2 gap-6">
                                    <MarkupTierEditor
                                        title="Parts Inventory"
                                        tiers={partMarkups}
                                        onChange={setPartMarkups}
                                        tooltipText="Markup applied to physical parts and materials you purchase and resell to customers."
                                    />
                                    <MarkupTierEditor
                                        title="Vendor Services"
                                        tiers={serviceMarkups}
                                        onChange={setServiceMarkups}
                                        tooltipText="Markup applied to third-party services (e.g., paint, upholstery, specialty repairs) that you coordinate for customers."
                                    />
                                </div>
                                <p className="text-xs text-[#6b7280] mt-4">
                                    These tiers automatically apply to line items in the Quote Builder based on cost.
                                </p>
                            </div>

                            <button
                                onClick={handleSaveGeneral}
                                className="w-full bg-white hover:bg-zinc-100 text-[#09090b] font-semibold py-4 rounded-lg transition-all flex items-center justify-center gap-2"
                            >
                                <Target size={20} /> Update Configuration
                            </button>
                        </div>
                    )}

                    {/* --- PROJECTIONS TAB --- */}
                    {activeTab === 'financial' && (
                        <div className="h-full flex flex-col gap-4 p-6">
                            {/* Controls */}
                            <div className="flex justify-between items-center shrink-0">
                                <h3 className="text-sm font-semibold text-[#e8e8e8] flex items-center gap-2">
                                    <TrendingUp size={16} className="text-zinc-300" /> Cashflow Forecaster
                                    <HelpIcon tooltip={`Projects your cash balance over time. Revenue arrives after payment terms (currently Net ${gameState.paymentTerms ?? 7} days after job completion). Shows daily burn from labor costs and fixed overhead.`} size={14} />
                                </h3>
                                <div className="flex items-center gap-3">
                                    <div className="flex items-center gap-2 text-xs bg-[#141517] px-2 py-1 rounded-md border border-white/[0.08]">
                                        <span className="text-[#9ca3af]">Change:</span>
                                        <span className={`font-semibold font-mono ${percentChange >= 0 ? 'text-[#3dae6c]' : 'text-[#c4626a]'}`}>
                                            {percentChange >= 0 ? '+' : ''}{percentChange.toFixed(1)}%
                                        </span>
                                    </div>
                                    <div className="flex bg-[#141517] rounded-md p-1 border border-white/[0.08]">
                                        <button onClick={() => setProjectionRange(30)} className={`px-3 py-1 text-[10px] font-semibold rounded-md transition-colors ${projectionRange === 30 ? 'bg-white/20 text-white' : 'text-[#9ca3af] hover:text-white'}`}>30 Days</button>
                                        <button onClick={() => setProjectionRange(90)} className={`px-3 py-1 text-[10px] font-semibold rounded-md transition-colors ${projectionRange === 90 ? 'bg-white/20 text-white' : 'text-[#9ca3af] hover:text-white'}`}>90 Days</button>
                                        <button onClick={() => setProjectionRange(365)} className={`px-3 py-1 text-[10px] font-semibold rounded-md transition-colors ${projectionRange === 365 ? 'bg-white/20 text-white' : 'text-[#9ca3af] hover:text-white'}`}>1 Year</button>
                                    </div>
                                    {onExpand && (
                                        <button
                                            onClick={onExpand}
                                            className="p-1.5 hover:bg-[#141517] text-[#6b7280] hover:text-white rounded-md border border-transparent hover:border-white/[0.08] transition-colors"
                                            title="Expand Chart"
                                        >
                                            <Maximize2 size={16} />
                                        </button>
                                    )}
                                </div>
                            </div>

                            {/* Chart */}
                            <div className="flex-1 min-h-0 bg-[#141517]/50 rounded-xl border border-white/[0.08] p-4 relative">
                                {/* Legend */}
                                <div className="absolute top-2 right-4 z-10 flex items-center gap-4 text-[10px]">
                                    <div className="flex items-center gap-1.5">
                                        <div className="w-3 h-3 rounded-sm bg-emerald-500/80" />
                                        <span className="text-[#9ca3af]">Revenue</span>
                                    </div>
                                    <div className="flex items-center gap-1.5">
                                        <div className="w-3 h-3 rounded-sm bg-rose-500/80" />
                                        <span className="text-[#9ca3af]">Expenses</span>
                                    </div>
                                    <div className="flex items-center gap-1.5">
                                        <div className="w-6 h-0.5 bg-indigo-400" />
                                        <span className="text-[#9ca3af]">Balance</span>
                                    </div>
                                </div>
                                <ResponsiveContainer width="100%" height="100%" minHeight={200}>
                                    <ComposedChart data={projectionData} margin={{ top: 40, right: 30, left: 10, bottom: 10 }}>
                                        <defs>
                                            <linearGradient id="splitColor" x1="0" y1="0" x2="0" y2="1">
                                                <stop offset={gradientOffset} stopColor="#10b981" stopOpacity={0.2} />
                                                <stop offset={gradientOffset} stopColor="#ef4444" stopOpacity={0.2} />
                                            </linearGradient>
                                        </defs>
                                        <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                                        <XAxis dataKey="label" stroke="#6b7280" fontSize={10} minTickGap={30} />
                                        <YAxis
                                            stroke="#6b7280"
                                            fontSize={10}
                                            tickFormatter={formatCurrency}
                                            width={65}
                                        />
                                        {/* Break-even reference line at $0 */}
                                        <ReferenceLine
                                            y={0}
                                            stroke="#6b7280"
                                            strokeDasharray="5 5"
                                            strokeWidth={1}
                                            label={{
                                                value: 'ZERO',
                                                position: 'right',
                                                fill: '#6b7280',
                                                fontSize: 9,
                                                fontWeight: 600
                                            }}
                                        />
                                        <RechartsTooltip content={<ProjectionTooltip />} />
                                        {/* Expense bars (red) - negative values go below zero */}
                                        <Bar
                                            dataKey="expenseBar"
                                            barSize={projectionRange <= 30 ? 8 : projectionRange <= 90 ? 4 : 2}
                                            fill="#ef4444"
                                            fillOpacity={0.7}
                                            isAnimationActive={true}
                                            animationDuration={200}
                                        />
                                        {/* Revenue bars (green) - positive values go above zero */}
                                        <Bar
                                            dataKey="revenueEvent"
                                            barSize={projectionRange <= 30 ? 8 : projectionRange <= 90 ? 4 : 2}
                                            fill="#10b981"
                                            fillOpacity={0.9}
                                            isAnimationActive={true}
                                            animationDuration={200}
                                        />
                                        {/* Cash balance area fill */}
                                        <Area
                                            type="monotone"
                                            dataKey="balance"
                                            stroke="transparent"
                                            fill="url(#splitColor)"
                                            strokeWidth={0}
                                            isAnimationActive={true}
                                            animationDuration={250}
                                            animationEasing="ease-out"
                                        />
                                        {/* Cash balance line */}
                                        <Line
                                            type="monotone"
                                            dataKey="balance"
                                            stroke="#818cf8"
                                            strokeWidth={2}
                                            dot={renderKeyPointDot}
                                            activeDot={{ r: 6, stroke: '#0d0e10', strokeWidth: 2 }}
                                            isAnimationActive={true}
                                            animationDuration={300}
                                            animationEasing="ease-out"
                                        />
                                    </ComposedChart>
                                </ResponsiveContainer>
                            </div>
                        </div>
                    )}
                    
                    {/* --- FP&A CALCULATOR TAB --- */}
                    {activeTab === 'fpa' && (
                        <div className="flex flex-col h-full bg-[#08090a] relative">

                            {/* Top Control Bar */}
                            <div className="p-4 border-b border-white/[0.06] flex justify-between items-center bg-[#0d0e10]/50 shrink-0">
                                <div className="flex items-center gap-6">
                                    <div className="flex bg-[#141517] rounded-lg p-1 border border-white/[0.08]">
                                        {[START_YEAR, START_YEAR+1, START_YEAR+2, START_YEAR+3].map(year => (
                                            <button
                                                key={year}
                                                onClick={() => setFpaYear(year)}
                                                className={`px-4 py-1.5 text-xs font-semibold rounded-md transition-colors ${fpaYear === year ? 'bg-white/20 text-white' : 'text-[#9ca3af] hover:text-white hover:bg-[#1a1b1e]'}`}
                                            >
                                                {year}
                                            </button>
                                        ))}
                                    </div>
                                    <div className="h-6 w-px bg-white/[0.08]" />
                                    <div className="flex gap-2">
                                        <button onClick={() => addExpense('Facility')} className="px-3 py-1.5 bg-[#141517] border border-white/[0.08] text-xs text-[#d1d5db] rounded-md hover:bg-[#1a1b1e] font-semibold flex items-center gap-1 transition-colors"><Plus size={12}/> Facility</button>
                                        <button onClick={() => addExpense('Personnel')} className="px-3 py-1.5 bg-[#141517] border border-white/[0.08] text-xs text-[#d1d5db] rounded-md hover:bg-[#1a1b1e] font-semibold flex items-center gap-1 transition-colors"><Plus size={12}/> Salary</button>
                                        <button onClick={() => addExpense('Admin')} className="px-3 py-1.5 bg-[#141517] border border-white/[0.08] text-xs text-[#d1d5db] rounded-md hover:bg-[#1a1b1e] font-semibold flex items-center gap-1 transition-colors"><Plus size={12}/> Admin</button>
                                    </div>
                                </div>

                                <div className="flex items-center gap-4">
                                    {isDirty && <span className="text-xs text-amber-500 animate-pulse font-semibold">Unsaved Changes</span>}
                                    <button
                                        onClick={handleSaveFPA}
                                        disabled={!isDirty}
                                        className={`px-6 py-2 rounded-lg font-semibold text-sm flex items-center gap-2 transition-all
                                            ${isDirty
                                                ? 'bg-white hover:bg-zinc-100 text-[#09090b]'
                                                : 'bg-[#141517] text-[#6b7280] cursor-not-allowed'}
                                        `}
                                    >
                                        <Target size={16} /> Apply Updates
                                    </button>
                                </div>
                            </div>

                            {/* Grid Area */}
                            <div className="flex-1 overflow-auto bg-[#08090a] relative">
                                <div className="min-w-[1400px] p-6 pb-20">

                                    {/* Table Header */}
                                    <div className="grid grid-cols-[250px_100px_repeat(12,1fr)_40px] gap-2 mb-4 border-b border-white/[0.08] pb-2 sticky top-0 bg-[#08090a] z-10">
                                        <div className="text-xs font-semibold text-[#6b7280] uppercase self-end">Expense Item</div>
                                        <div className="text-xs font-semibold text-white uppercase self-end text-right pr-2">Base Cost</div>
                                        {MONTH_NAMES.map((m, i) => (
                                            <div key={m} className={`text-xs font-semibold uppercase text-center py-1 rounded ${i % 2 === 0 ? 'bg-[#0d0e10]' : ''} text-[#9ca3af]`}>
                                                {m}
                                            </div>
                                        ))}
                                        <div></div>
                                    </div>

                                    {/* Expense Rows */}
                                    <div className="space-y-6">
                                        {['Facility', 'Personnel', 'Admin', 'IT', 'Marketing', 'Other'].map(cat => {
                                            const catItems = expenses.filter(e => e.category === cat);
                                            if (catItems.length === 0) return null;

                                            return (
                                                <div key={cat} className="mb-6">
                                                    <div className="flex items-center gap-2 mb-2 border-b border-white/[0.06] pb-1">
                                                        <span className="text-xs font-semibold text-[#d1d5db] uppercase bg-[#141517] px-2 py-0.5 rounded-md">{cat}</span>
                                                    </div>
                                                    <div className="space-y-1">
                                                        {catItems.map(item => (
                                                            <div key={item.id} className="grid grid-cols-[250px_100px_repeat(12,1fr)_40px] gap-2 items-center hover:bg-[#0d0e10]/50 rounded p-1 transition-colors group">
                                                                {/* Name Input */}
                                                                <div>
                                                                    <input
                                                                        type="text"
                                                                        value={item.name}
                                                                        onChange={(e) => updateExpenseBase(item.id, 'name', e.target.value)}
                                                                        className="w-full bg-transparent text-xs font-medium text-[#d1d5db] border-none focus:ring-0 p-0 placeholder-[#4b5563]"
                                                                    />
                                                                </div>

                                                                {/* Base Cost Input */}
                                                                <div className="relative flex items-center bg-[#141517] border border-white/[0.08] rounded focus-within:border-white/40">
                                                                    <span className="text-[10px] text-[#6b7280] pl-2 font-mono">{DOLLAR_SIGN}</span>
                                                                    <input
                                                                        type="text"
                                                                        value={item.monthlyCost.toLocaleString()}
                                                                        onChange={(e) => {
                                                                            const val = parseFloat(e.target.value.replace(/,/g, '')) || 0;
                                                                            updateExpenseBase(item.id, 'monthlyCost', val);
                                                                        }}
                                                                        className="w-full bg-transparent py-1 px-1 text-right text-xs text-white font-mono font-semibold outline-none"
                                                                    />
                                                                </div>

                                                                {/* Monthly Overrides Grid */}
                                                                {MONTH_NAMES.map((_, mIdx) => {
                                                                    const key = `${fpaYear}-${mIdx}`;
                                                                    const overrideVal = item.overrides?.[key];
                                                                    const displayVal = overrideVal !== undefined ? overrideVal : item.monthlyCost;
                                                                    const isOverridden = overrideVal !== undefined && overrideVal !== item.monthlyCost;

                                                                    return (
                                                                        <div key={mIdx} className="relative">
                                                                            <input
                                                                                type="text"
                                                                                value={`${DOLLAR_SIGN}${displayVal.toLocaleString()}`}
                                                                                onChange={(e) => {
                                                                                    const val = parseFloat(e.target.value.replace(/[$,]/g, '')) || 0;
                                                                                    updateExpenseOverride(item.id, fpaYear, mIdx, val);
                                                                                }}
                                                                                className={`
                                                                                    w-full py-1 px-1 text-center text-[11px] font-mono outline-none border rounded transition-colors
                                                                                    ${isOverridden
                                                                                        ? 'bg-amber-900/30 text-amber-400 border-amber-700/50 font-semibold'
                                                                                        : 'bg-transparent text-[#6b7280] border-transparent hover:bg-[#141517] hover:border-white/[0.08] focus:bg-[#141517] focus:border-white/[0.1] focus:text-[#e8e8e8]'}
                                                                                `}
                                                                            />
                                                                        </div>
                                                                    );
                                                                })}

                                                                {/* Delete Action */}
                                                                <div className="flex justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                                                    <button onClick={() => removeExpense(item.id)} className="text-[#4b5563] hover:text-[#c4626a] p-1">
                                                                        <Trash2 size={12} />
                                                                    </button>
                                                                </div>
                                                            </div>
                                                        ))}
                                                    </div>
                                                </div>
                                            );
                                        })}
                                    </div>
                                </div>
                            </div>

                            {/* Footer Totals (Sticky) */}
                            <div className="bg-[#0d0e10] border-t border-white/[0.08] p-4 shrink-0 z-20">
                                <div className="min-w-[1400px]">
                                    <div className="grid grid-cols-[250px_100px_repeat(12,1fr)_40px] gap-2 items-center">
                                        <div className="text-sm font-semibold text-white uppercase tracking-wide">Total Monthly OpEx</div>
                                        <div className="text-xs text-[#6b7280] text-right pr-2">Year: {fpaYear}</div>

                                        {MONTH_NAMES.map((_, mIdx) => {
                                            const total = getMonthlyTotal(fpaYear, mIdx);
                                            return (
                                                <div key={mIdx} className="text-center">
                                                    <div className="text-xs font-mono font-semibold text-[#c4626a]">{DOLLAR_SIGN}{Math.round(total / 1000)}k</div>
                                                    <div className="text-[9px] text-[#6b7280]">{DOLLAR_SIGN}{Math.round(total).toLocaleString()}</div>
                                                </div>
                                            );
                                        })}
                                        <div></div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    )}

                </div>
            </div>

            {/* Financial Explainer Modal */}
            <FinancialExplainer
                isOpen={showExplainer}
                onClose={() => setShowExplainer(false)}
                gameState={gameState}
            />
        </div>
    );
};

export default React.memo(FinancialPanel);