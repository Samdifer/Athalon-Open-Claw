
import React, { useState, useMemo, useEffect, useRef } from 'react';
import { GameState, Job, QuoteLineItem, StandardService, AircraftModel, ScheduledJob, MarkupTier } from '../types';
import { HOURLY_COST_AVG, START_YEAR, GLOSSARY } from '../constants';
import { DOLLAR_SIGN } from '../App';
import { X, Plus, Trash2, FileText, Calculator, CheckCircle, Plane, Wrench, Clock, Settings, ArrowLeft, Layers, PenTool, GripVertical, Download, ChevronDown, ChevronRight, Tag, Coins, AlertTriangle, AlertCircle, Save } from 'lucide-react';
import { generateUUID } from '../utils';
import { Tooltip, HelpIcon } from './ui';

interface QuoteBuilderProps {
  gameState: GameState;
  onClose: () => void;
  onSave: (job: Job | ScheduledJob) => void;
  onUpdateStandardServices: (services: StandardService[]) => void;
  existingJob?: Job | ScheduledJob | null;
}

// --- Helper Functions for Dates ---
const getDateStr = (dayIndex: number) => {
    const date = new Date(START_YEAR, 0, 1);
    date.setDate(dayIndex + 1);
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, '0');
    const d = String(date.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
};

const getDayIndex = (dateStr: string) => {
    if (!dateStr) return null;
    const [y, m, d] = dateStr.split('-').map(Number);
    const date = new Date(y, m - 1, d);
    const start = new Date(START_YEAR, 0, 1);
    const diff = date.getTime() - start.getTime();
    return Math.round(diff / (1000 * 60 * 60 * 24));
};

const formatDateUS = (dateStr: string) => {
    if (!dateStr) return '';
    const [y, m, d] = dateStr.split('-').map(Number);
    const date = new Date(y, m - 1, d);
    const month = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"][date.getMonth()];
    return `${month} ${date.getDate()}, ${date.getFullYear()}`;
};

// --- Extracted Settings Modal Component ---
interface QuoteSettingsModalProps {
  gameState: GameState;
  onUpdateStandardServices: (services: StandardService[]) => void;
  onClose: () => void;
}

const QuoteSettingsModal: React.FC<QuoteSettingsModalProps> = ({ gameState, onUpdateStandardServices, onClose }) => {
      const [selectedCat, setSelectedCat] = useState<string>('COMMON');
      const [editItem, setEditItem] = useState<StandardService | null>(null);
      const listRef = useRef<HTMLDivElement>(null);
      const itemRefs = useRef<Map<string, HTMLDivElement>>(new Map());

      // === BATCHED SAVE: Local state for buffering template changes ===
      const [pendingTemplates, setPendingTemplates] = useState<StandardService[]>(gameState.standardServices);
      const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);

      // Sync local state when gameState changes from outside (only if no pending changes)
      useEffect(() => {
        if (!hasUnsavedChanges) {
          setPendingTemplates(gameState.standardServices);
        }
      }, [gameState.standardServices, hasUnsavedChanges]);

      // === BATCHED SAVE: Save and Discard handlers ===
      const handleSaveChanges = () => {
        onUpdateStandardServices(pendingTemplates);
        setHasUnsavedChanges(false);
      };

      const handleDiscardChanges = () => {
        setPendingTemplates(gameState.standardServices);
        setHasUnsavedChanges(false);
        setEditItem(null);
      };

      const handleClose = () => {
        // Save any pending changes before closing
        if (hasUnsavedChanges) {
          handleSaveChanges();
        }
        onClose();
      };

      // Auto-scroll effect
      useEffect(() => {
        if (editItem) {
            const node = itemRefs.current.get(editItem.id);
            if (node) {
                node.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            }
        }
      }, [editItem?.id]);

      // Derived List (using pending templates so users see their edits)
      const filteredList = pendingTemplates.filter(s => {
          if (selectedCat === 'COMMON') return !s.applicableModelId;
          return s.applicableModelId === selectedCat;
      });

      const handleAddTemplate = () => {
          const newTemplate: StandardService = {
              id: generateUUID(),
              description: 'New Service Template',
              category: 'Labor',
              laborHours: 0,
              laborRate: 0, // Default to 0 to inherit global rate
              partsCost: 0,
              partsMarkup: 1.15,
              applicableModelId: selectedCat === 'COMMON' ? undefined : selectedCat
          };
          setPendingTemplates([...pendingTemplates, newTemplate]);
          setEditItem(newTemplate);
          setHasUnsavedChanges(true);
      };

      const handleDeleteTemplate = (id: string) => {
          setPendingTemplates(pendingTemplates.filter(s => s.id !== id));
          if (editItem?.id === id) setEditItem(null);
          setHasUnsavedChanges(true);
      };

      const handleUpdateTemplate = (updated: StandardService) => {
          const newList = pendingTemplates.map(s => s.id === updated.id ? updated : s);
          setPendingTemplates(newList);
          setEditItem(updated);
          setHasUnsavedChanges(true);
      };

      const selectedModelName = selectedCat === 'COMMON' 
        ? 'Common / All Aircraft' 
        : gameState.aircraftModels.find(m => m.id === selectedCat)?.name || selectedCat;

      const getEffectiveRate = (rate: number) => rate > 0 ? rate : gameState.shopRate;

      return (
        <div className="absolute inset-0 bg-[#0d0e10] z-50 flex flex-col animate-in fade-in slide-in-from-bottom-10">
            <div className="h-14 bg-[#0d0e10] border-b border-white/[0.06] flex justify-between items-center px-6 shrink-0">
                <div className="flex items-center gap-3">
                    <Settings className="text-[#6e79d6]" size={20} />
                    <h2 className="text-lg font-semibold text-[#e8e8e8]">Quote Builder Settings</h2>
                </div>
                <button
                    onClick={handleClose}
                    className="flex items-center gap-2 text-[#9ca3af] hover:text-white bg-[#141517] hover:bg-[#1a1b1e] px-4 py-2 rounded-md transition-colors"
                >
                    <ArrowLeft size={16} /> Back to Quote
                </button>
            </div>

            <div className="flex-1 flex overflow-hidden">
                {/* Category Sidebar */}
                <div className="w-64 bg-[#08090a] border-r border-white/[0.06] overflow-y-auto p-4">
                    <h3 className="text-xs font-semibold text-[#6b7280] uppercase mb-4">Service Categories</h3>
                    <div className="space-y-1">
                        <button
                            onClick={() => { setSelectedCat('COMMON'); setEditItem(null); }}
                            className={`w-full text-left px-3 py-2 rounded-md text-sm font-medium flex items-center gap-2 transition-colors ${selectedCat === 'COMMON' ? 'bg-[#5e6ad2] text-white' : 'text-[#9ca3af] hover:bg-[#141517]'}`}
                        >
                            <Layers size={14} /> Common Services
                        </button>
                        {gameState.aircraftModels.map(m => (
                            <button
                                key={m.id}
                                onClick={() => { setSelectedCat(m.id); setEditItem(null); }}
                                className={`w-full text-left px-3 py-2 rounded-md text-sm font-medium flex items-center gap-2 transition-colors ${selectedCat === m.id ? 'bg-[#5e6ad2] text-white' : 'text-[#9ca3af] hover:bg-[#141517]'}`}
                            >
                                <Plane size={14} /> {m.name}
                            </button>
                        ))}
                    </div>
                </div>

                {/* List & Editor */}
                <div className="flex-1 flex flex-col bg-[#0d0e10]">
                    <div className="p-4 border-b border-white/[0.06] flex justify-between items-center bg-[#0d0e10]">
                         <h3 className="font-semibold text-[#e8e8e8] flex items-center gap-2">
                             <Wrench size={16} /> Standard Services: <span className="text-[#6e79d6]">{selectedModelName}</span>
                         </h3>
                         <button
                            onClick={handleAddTemplate}
                            className="bg-emerald-600 hover:bg-emerald-500 text-white px-3 py-1.5 rounded-md text-xs font-semibold flex items-center gap-1 transition-colors"
                         >
                             <Plus size={14} /> Add Service Template
                         </button>
                    </div>

                    <div className="flex-1 flex overflow-hidden">
                        {/* List */}
                        <div className="w-1/2 overflow-y-auto p-4 space-y-2 border-r border-white/[0.06] bg-[#08090a]" ref={listRef}>
                            {filteredList.length === 0 && (
                                <div className="text-center text-[#6b7280] italic text-sm mt-10">
                                    No standard services defined for this category.
                                </div>
                            )}
                            {filteredList.map(item => {
                                const effectiveRate = getEffectiveRate(item.laborRate);
                                return (
                                <div
                                    key={item.id}
                                    ref={(el) => {
                                        if (el) itemRefs.current.set(item.id, el);
                                        else itemRefs.current.delete(item.id);
                                    }}
                                    onClick={() => setEditItem(item)}
                                    className={`p-3 rounded-lg border cursor-pointer transition-colors ${editItem?.id === item.id ? 'bg-[#141517] border-[#5e6ad2] ring-1 ring-[#5e6ad2]/30' : 'bg-[#0d0e10] border-white/[0.08] hover:border-[#5e6ad2]/50'}`}
                                >
                                    <div className="flex justify-between items-start">
                                        <div className="font-semibold text-sm text-[#e8e8e8]">{item.description}</div>
                                        <span className="text-xs font-mono text-[#9ca3af] bg-[#141517] px-1.5 rounded">{item.laborHours}h</span>
                                    </div>
                                    <div className="flex justify-between mt-2 text-xs text-[#6b7280]">
                                        <span>Parts: ${item.partsCost}</span>
                                        <span className="text-[#3dae6c] font-mono font-semibold">${(item.fixedPrice ?? ((item.laborHours * effectiveRate) + (item.partsCost * item.partsMarkup))).toFixed(0)}</span>
                                    </div>
                                </div>
                            )})}
                        </div>

                        {/* Editor Form */}
                        <div className="w-1/2 bg-[#0d0e10] p-6 overflow-y-auto">
                            {editItem ? (
                                <div className="space-y-4 animate-in fade-in zoom-in-95 duration-200">
                                    <div className="flex justify-between items-center mb-4 border-b border-white/[0.06] pb-2">
                                        <h4 className="text-sm font-semibold text-[#e8e8e8] flex items-center gap-2"><PenTool size={14}/> Edit Template</h4>
                                        <button onClick={() => handleDeleteTemplate(editItem.id)} className="text-[#c4626a] hover:text-[#d4727a] p-1 hover:bg-[#c4626a]/10 rounded-md">
                                            <Trash2 size={16} />
                                        </button>
                                    </div>

                                    <div>
                                        <label className="block text-xs font-semibold text-[#6b7280] uppercase mb-1">Description</label>
                                        <input
                                            type="text"
                                            value={editItem.description}
                                            onChange={(e) => handleUpdateTemplate({...editItem, description: e.target.value})}
                                            className="w-full bg-[#141517] border border-white/[0.08] rounded-md p-2 text-[#e8e8e8] focus:border-[#5e6ad2] outline-none"
                                        />
                                    </div>

                                    <div className="grid grid-cols-2 gap-4">
                                        <div>
                                            <label className="block text-xs font-semibold text-[#6b7280] uppercase mb-1">Labor Hours</label>
                                            <input
                                                type="number" step="0.5"
                                                value={editItem.laborHours}
                                                onChange={(e) => handleUpdateTemplate({...editItem, laborHours: parseFloat(e.target.value)})}
                                                className="w-full bg-[#141517] border border-white/[0.08] rounded-md p-2 text-[#e8e8e8] font-mono focus:border-[#5e6ad2] outline-none"
                                            />
                                        </div>
                                        <div>
                                            <label className="flex items-center gap-1.5 text-xs font-semibold text-[#6b7280] uppercase mb-1">
                                                Labor Rate ($/hr)
                                                <HelpIcon tooltip={GLOSSARY.shopRate.definition} size={12} />
                                            </label>
                                            <input
                                                type="number"
                                                value={editItem.laborRate === 0 ? '' : editItem.laborRate}
                                                placeholder={gameState.shopRate.toString()}
                                                onChange={(e) => handleUpdateTemplate({...editItem, laborRate: e.target.value === '' ? 0 : parseFloat(e.target.value)})}
                                                className={`w-full bg-[#141517] border border-white/[0.08] rounded-md p-2 font-mono focus:border-[#5e6ad2] outline-none ${editItem.laborRate === 0 ? 'text-[#9ca3af] italic' : 'text-[#e8e8e8]'}`}
                                            />
                                            {editItem.laborRate === 0 && <div className="text-[9px] text-[#6b7280] mt-1 text-right">Inherited from Shop Rate</div>}
                                        </div>
                                    </div>

                                    <div className="grid grid-cols-2 gap-4">
                                        <div>
                                            <label className="block text-xs font-semibold text-[#6b7280] uppercase mb-1">Parts Cost ($)</label>
                                            <input
                                                type="number"
                                                value={editItem.partsCost}
                                                onChange={(e) => handleUpdateTemplate({...editItem, partsCost: parseFloat(e.target.value)})}
                                                className="w-full bg-[#141517] border border-white/[0.08] rounded-md p-2 text-[#e8e8e8] font-mono focus:border-[#5e6ad2] outline-none"
                                            />
                                        </div>
                                        <div>
                                            <label className="flex items-center gap-1.5 text-xs font-semibold text-[#6b7280] uppercase mb-1">
                                                Fixed Price Override ($)
                                                <HelpIcon tooltip="A flat rate price that ignores labor hours and parts calculations. Use when you quote a fixed amount regardless of actual time spent." size={12} />
                                            </label>
                                            <input
                                                type="number"
                                                placeholder="Optional"
                                                value={editItem.fixedPrice || ''}
                                                onChange={(e) => handleUpdateTemplate({...editItem, fixedPrice: e.target.value ? parseFloat(e.target.value) : undefined})}
                                                className="w-full bg-[#141517] border border-white/[0.08] rounded-md p-2 text-[#e8e8e8] font-mono focus:border-[#5e6ad2] outline-none"
                                            />
                                        </div>
                                    </div>

                                    <div className="pt-4 border-t border-white/[0.06] mt-4">
                                        <div className="text-xs text-[#9ca3af] flex justify-between bg-[#141517] p-3 rounded-md border border-white/[0.08]">
                                            <span>Calculated Total:</span>
                                            <span className="text-[#3dae6c] font-mono font-semibold">
                                                 ${(editItem.fixedPrice ?? ((editItem.laborHours * getEffectiveRate(editItem.laborRate)) + (editItem.partsCost * editItem.partsMarkup))).toFixed(2)}
                                            </span>
                                        </div>
                                    </div>

                                </div>
                            ) : (
                                <div className="h-full flex flex-col items-center justify-center text-[#4b5563]">
                                    <Settings size={48} className="mb-4 opacity-20" />
                                    <p className="text-sm">Select a template to edit</p>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            </div>

            {/* === BATCHED SAVE: Save/Discard Footer === */}
            {hasUnsavedChanges && (
                <div className="shrink-0 px-6 py-3 bg-[#141517] border-t border-white/[0.08] flex items-center justify-between">
                    <div className="flex items-center gap-2 text-amber-400">
                        <AlertCircle size={16} />
                        <span className="text-sm font-medium">You have unsaved template changes</span>
                    </div>
                    <div className="flex items-center gap-3">
                        <button
                            onClick={handleDiscardChanges}
                            className="px-4 py-2 text-sm font-semibold text-[#9ca3af] hover:text-white hover:bg-white/10 rounded-lg transition-colors"
                        >
                            Discard
                        </button>
                        <button
                            onClick={handleSaveChanges}
                            className="px-4 py-2 text-sm font-semibold bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg transition-colors flex items-center gap-2"
                        >
                            <Save size={14} />
                            Save Templates
                        </button>
                    </div>
                </div>
            )}
        </div>
      );
};

const QuoteBuilder: React.FC<QuoteBuilderProps> = ({ gameState, onClose, onSave, onUpdateStandardServices, existingJob }) => {
  // --- Header State ---
  const [customer, setCustomer] = useState(existingJob?.customer || '');
  const [aircraftType, setAircraftType] = useState(existingJob?.aircraftType || gameState.aircraftModels[0]?.id || '');
  const [description, setDescription] = useState(existingJob?.description || '');
  const [isAOG, setIsAOG] = useState(existingJob?.isAOG || false);
  const [notes, setNotes] = useState(existingJob?.notes || '');
  
  // Initialize Dates
  const [targetStart, setTargetStart] = useState(() => {
    if (existingJob) {
         if ('startDate' in existingJob) return getDateStr((existingJob as ScheduledJob).startDate);
         return getDateStr(existingJob.arrivalDay || gameState.day);
    }
    return getDateStr(gameState.day); // Default to today for new quotes
  });

  const [targetEnd, setTargetEnd] = useState(() => {
    if (existingJob) {
        const start = 'startDate' in existingJob ? (existingJob as ScheduledJob).startDate : (existingJob.arrivalDay || gameState.day);
        return getDateStr(start + existingJob.deadlineDays);
    }
    return ''; // Optional end date by default
  });
  
  // --- Settings Mode State ---
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  
  // --- Layout Resizing State ---
  const [leftSidebarWidth, setLeftSidebarWidth] = useState(320); // Default w-80
  const [rightSidebarWidth, setRightSidebarWidth] = useState(288); // Default w-72
  const [resizeState, setResizeState] = useState<{
      panel: 'left' | 'right';
      startX: number;
      startWidth: number;
  } | null>(null);

  // --- Drag State ---
  const [isDraggingOver, setIsDraggingOver] = useState(false);
  const [draggedItemIndex, setDraggedItemIndex] = useState<number | null>(null);

  // --- Line Item State ---
  const [lineItems, setLineItems] = useState<QuoteLineItem[]>(() => {
    if (existingJob?.quoteLines && existingJob.quoteLines.length > 0) {
        return existingJob.quoteLines;
    }
    if (existingJob && (existingJob.revenue > 0 || existingJob.estimatedHours > 0)) {
        return [{
            id: generateUUID(),
            description: existingJob.description || 'Base Scope (Legacy)',
            laborHours: existingJob.estimatedHours,
            category: 'Labor',
            laborRate: 0, 
            partsCost: 0, 
            partsMarkup: 1.0, 
            fixedPrice: existingJob.revenue
        }];
    }
    return [];
  });

  // --- Expansion State ---
  const [expandedItemIds, setExpandedItemIds] = useState<Set<string>>(new Set());
  const [showMarginBreakdown, setShowMarginBreakdown] = useState(false);

  // --- Unsaved Changes State ---
  const [showCloseConfirm, setShowCloseConfirm] = useState(false);
  const initialValuesRef = useRef({
      customer: existingJob?.customer || '',
      aircraftType: existingJob?.aircraftType || gameState.aircraftModels[0]?.id || '',
      description: existingJob?.description || '',
      isAOG: existingJob?.isAOG || false,
      notes: existingJob?.notes || '',
      lineItemCount: existingJob?.quoteLines?.length ?? 0
  });

  // Compute isDirty by comparing current values to initial
  const isDirty = useMemo(() => {
      const init = initialValuesRef.current;
      return (
          customer !== init.customer ||
          aircraftType !== init.aircraftType ||
          description !== init.description ||
          isAOG !== init.isAOG ||
          notes !== init.notes ||
          lineItems.length !== init.lineItemCount ||
          lineItems.length > 0 // Any line items means changes made
      );
  }, [customer, aircraftType, description, isAOG, notes, lineItems]);

  // Handle close with confirmation if dirty
  const handleCloseAttempt = () => {
      if (isDirty) {
          setShowCloseConfirm(true);
      } else {
          onClose();
      }
  };

  // Initialize expansion on mount - Only for initial legacy items if needed, otherwise default collapsed
  useEffect(() => {
      if (lineItems.length > 0 && expandedItemIds.size === 0 && existingJob) {
          // Logic: Don't expand anything by default unless it's a single legacy import which might be confusing if hidden
          if (lineItems.length === 1 && lineItems[0].id.startsWith('legacy')) {
              setExpandedItemIds(new Set(lineItems.map(i => i.id)));
          }
      }
  }, []);

  // --- Resizing Effect ---
  useEffect(() => {
      const handleMouseMove = (e: MouseEvent) => {
          if (!resizeState) return;
          e.preventDefault();

          const delta = e.clientX - resizeState.startX;

          if (resizeState.panel === 'left') {
              const newW = Math.max(200, Math.min(600, resizeState.startWidth + delta));
              setLeftSidebarWidth(newW);
          } else {
              // Right panel resizing (drag left increases width)
              const newW = Math.max(200, Math.min(600, resizeState.startWidth - delta));
              setRightSidebarWidth(newW);
          }
      };

      const handleMouseUp = () => {
          setResizeState(null);
      };

      if (resizeState) {
          window.addEventListener('mousemove', handleMouseMove);
          window.addEventListener('mouseup', handleMouseUp);
          document.body.style.cursor = 'col-resize';
      } else {
          document.body.style.cursor = '';
      }

      return () => {
          window.removeEventListener('mousemove', handleMouseMove);
          window.removeEventListener('mouseup', handleMouseUp);
          document.body.style.cursor = '';
      };
  }, [resizeState]);

  const startResize = (e: React.MouseEvent, panel: 'left' | 'right') => {
      e.preventDefault();
      e.stopPropagation();
      setResizeState({
          panel,
          startX: e.clientX,
          startWidth: panel === 'left' ? leftSidebarWidth : rightSidebarWidth
      });
  };

  // --- Financial Calculations ---
  const financials = useMemo(() => {
    let totalHours = 0;
    let laborRevenue = 0;
    let partsCost = 0;
    let partsRevenue = 0;

    lineItems.forEach(item => {
        totalHours += item.laborHours;
        
        // Labor Rev
        const rate = item.laborRate > 0 ? item.laborRate : gameState.shopRate;
        const lineLaborRev = item.laborHours * rate;
            
        // Parts
        partsCost += item.partsCost;
        const linePartsRev = item.partsCost * item.partsMarkup;
        
        if (item.fixedPrice) {
            // Simple Fixed Price Model: Attribute all to "Revenue" bucket for display, but calculate pure profit diff later
            // For margin calc, we assume labor cost is incurred, parts cost incurred.
            // Revenue = Fixed Price.
            laborRevenue += item.fixedPrice; // Simplified bucket
        } else {
            laborRevenue += lineLaborRev;
            partsRevenue += linePartsRev;
        }
    });

    const totalRevenue = laborRevenue + partsRevenue; // Note: if fixed price, it's all in laborRev bucket above
    const estimatedLaborCost = totalHours * HOURLY_COST_AVG;
    const totalCost = estimatedLaborCost + partsCost;
    const grossProfit = totalRevenue - totalCost;
    const margin = totalRevenue > 0 ? (grossProfit / totalRevenue) * 100 : 0;

    return {
        totalHours,
        laborRevenue,
        partsCost,
        partsRevenue,
        totalRevenue,
        totalCost,
        grossProfit,
        margin
    };
  }, [lineItems, gameState.shopRate]);

  // --- Handlers ---

  const toggleExpand = (id: string) => {
      setExpandedItemIds(prev => {
          const next = new Set(prev);
          if (next.has(id)) next.delete(id);
          else next.add(id);
          return next;
      });
  };

  // Auto Markup Logic
  const getAutoMarkup = (cost: number, category: string) => {
      const tiers = category === 'Service' ? gameState.serviceMarkups : gameState.partMarkups;
      const tier = tiers.find(t => cost <= t.maxLimit);
      return tier ? tier.markup : 1.05; // Default fallback if tiers exhausted
  };

  const addLineItem = (template?: QuoteLineItem) => {
    const newItem: QuoteLineItem = template ? { ...template, id: generateUUID() } : {
        id: generateUUID(),
        description: 'New Service Item',
        category: 'Labor',
        laborHours: 0,
        laborRate: 0, // Default to 0 (inherited)
        partsCost: 0,
        partsMarkup: 1.15,
    };
    // Remove internal props if copying from StandardService
    if ('applicableModelId' in newItem) {
        delete (newItem as any).applicableModelId;
    }
    setLineItems([...lineItems, newItem]);
    // IMPORTANT: Do not expand by default
  };

  const updateLineItem = (id: string, field: keyof QuoteLineItem, value: any) => {
    setLineItems(prev => prev.map(item => {
        if (item.id !== id) return item;
        
        const updated = { ...item, [field]: value };
        
        // Auto-Markup Logic: If cost changes, update markup automatically unless user manually overrides? 
        // The prompt says "apply this logic to the prices which are inputted... also allow for the user to override"
        // We'll auto-update markup whenever cost or category changes.
        // But we need to know if it's an override. For simplicity, we'll always auto-calculate unless we track an 'isMarkupOverridden' flag.
        // Let's simplify: Just recalculate markup if cost changes. User can change markup after.
        if ((field === 'partsCost' || field === 'category') && updated.partsCost > 0 && updated.category !== 'Labor') {
            updated.partsMarkup = getAutoMarkup(updated.partsCost, updated.category || 'Part');
        }

        return updated;
    }));
  };

  const removeLineItem = (id: string) => {
    setLineItems(prev => prev.filter(item => item.id !== id));
  };

  // --- Drag & Drop Handlers ---

  const onDragStartItem = (e: React.DragEvent, index: number) => {
    const target = e.target as HTMLElement;
    // Prevent drag if interacting with inputs
    if (['INPUT', 'SELECT', 'BUTTON', 'TEXTAREA'].includes(target.tagName)) {
        e.preventDefault();
        return;
    }
    e.dataTransfer.setData('lineItemIndex', index.toString());
    e.dataTransfer.effectAllowed = 'move';
    setDraggedItemIndex(index);
  };

  const onDragOverItem = (e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
  };

  const onDropItem = (e: React.DragEvent, dropIndex: number) => {
    e.preventDefault();
    e.stopPropagation();
    
    const dragIndexStr = e.dataTransfer.getData('lineItemIndex');
    if (dragIndexStr) {
        const dragIndex = parseInt(dragIndexStr, 10);
        if (dragIndex === dropIndex) return;
        
        const newItems = [...lineItems];
        const [moved] = newItems.splice(dragIndex, 1);
        newItems.splice(dropIndex, 0, moved);
        setLineItems(newItems);
        setDraggedItemIndex(null);
        return;
    }
    
    // Handle template drop onto item (insert before)
    const srvId = e.dataTransfer.getData('serviceId');
    if (srvId) {
        const srv = gameState.standardServices.find(s => s.id === srvId);
        if (srv) {
             const newItem = { ...srv, id: generateUUID() };
             if ('applicableModelId' in newItem) delete (newItem as any).applicableModelId;
             
             const newItems = [...lineItems];
             newItems.splice(dropIndex, 0, newItem);
             setLineItems(newItems);
             // Do not expand
        }
    }
  };

  const onDropContainer = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDraggingOver(false);
    
    const dragIndexStr = e.dataTransfer.getData('lineItemIndex');
    if (dragIndexStr) {
        // Move to end
        const dragIndex = parseInt(dragIndexStr, 10);
        const newItems = [...lineItems];
        const [moved] = newItems.splice(dragIndex, 1);
        newItems.push(moved);
        setLineItems(newItems);
        setDraggedItemIndex(null);
        return;
    }

    const srvId = e.dataTransfer.getData('serviceId');
    if (srvId) {
        const srv = gameState.standardServices.find(s => s.id === srvId);
        if (srv) addLineItem(srv);
    }
  };

  const handleSaveInternal = () => {
    if (!customer || lineItems.length === 0) return;

    // Determine Hangar Size
    const compatibleHangars = gameState.hangars.filter(h => h.supportedTypes.includes(aircraftType));
    const sizeMap = { 'Small': 1, 'Medium': 2, 'Large': 3 };
    let maxSizeVal = 0;
    let reqSize: 'Small' | 'Medium' | 'Large' = 'Small';
    
    compatibleHangars.forEach(h => {
         if (sizeMap[h.size] > maxSizeVal) {
             maxSizeVal = sizeMap[h.size];
             reqSize = h.size;
         }
    });
    if (compatibleHangars.length === 0) reqSize = 'Large';

    const startIdx = getDayIndex(targetStart);
    const arrivalDay = startIdx !== null ? startIdx : gameState.day;

    // Calculate deadline based on work hours (approx 8h/day per person) + buffer
    // DO NOT override with calendar date difference to avoid "locking" duration to preference.
    let deadline = Math.max(3, Math.ceil(financials.totalHours / 8) + 5);

    const defaultColor = gameState.projectStages.length > 0 ? gameState.projectStages[0].color : 'bg-slate-500';

    // Append initial date request to notes if present and new quote, using US format
    let finalNotes = notes;
    if (!existingJob && (targetStart || targetEnd)) {
        const formattedStart = targetStart ? formatDateUS(targetStart) : 'ASAP';
        const formattedEnd = targetEnd ? formatDateUS(targetEnd) : 'TBD';
        const existingSystemNote = finalNotes?.includes('[System] Initial Request');
        
        // Avoid duplicate entries if user clicks save multiple times quickly before close (edge case)
        if (!existingSystemNote) {
             finalNotes = (notes || '') + `\n[System] Initial Request: ${formattedStart} to ${formattedEnd}`;
        }
    }

    const commonData = {
        customer: customer.toUpperCase(),
        aircraftType,
        description: description || lineItems[0].description + (lineItems.length > 1 ? ` + ${lineItems.length - 1} items` : ''),
        estimatedHours: financials.totalHours,
        revenue: financials.totalRevenue,
        partsRevenue: financials.partsRevenue,
        color: existingJob ? existingJob.color : defaultColor, 
        deadlineDays: deadline,
        requiredHangarSize: reqSize,
        isAOG,
        arrivalDay,
        quoteLines: lineItems,
        notes: finalNotes
    };

    let finalJob: Job | ScheduledJob;

    if (existingJob) {
        finalJob = {
            ...existingJob,
            ...commonData,
            ...('startDate' in existingJob ? { startDate: arrivalDay } : {}),
            id: existingJob.id
        };
    } else {
        finalJob = {
            ...commonData,
            id: generateUUID()
        };
    }

    onSave(finalJob);
    
    if (existingJob) {
        onClose();
    }
  };
  
  const availableServices = useMemo(() => {
      return gameState.standardServices.filter(s => 
         !s.applicableModelId || s.applicableModelId === aircraftType
      );
  }, [gameState.standardServices, aircraftType]);

  if (isSettingsOpen) {
      return (
        <QuoteSettingsModal 
            gameState={gameState} 
            onUpdateStandardServices={onUpdateStandardServices}
            onClose={() => setIsSettingsOpen(false)}
        />
      );
  }

  return (
    <div id="modal-quote-builder" className="fixed inset-0 bg-[#08090a]/60 backdrop-blur-sm z-[100] flex flex-col animate-in fade-in duration-200">
        <div className="flex-1 flex flex-col m-8 bg-[#0d0e10] rounded-xl overflow-hidden border border-white/[0.08]">
            {/* Top Bar */}
            <div className="h-14 bg-[#0d0e10] border-b border-white/[0.06] flex justify-between items-center px-6 shrink-0">
                <div className="flex items-center gap-3">
                    <div className="bg-[#5e6ad2]/10 border border-[#5e6ad2]/30 p-2 rounded-lg">
                        <FileText className="text-[#6e79d6]" size={20} />
                    </div>
                    <div>
                        <h2 className="text-lg font-semibold text-white">
                            {existingJob ? 'Edit Quote & Work Order' : 'Quote & Work Order Builder'}
                        </h2>
                        <p className="text-xs text-[#6b7280]">
                            {existingJob ? `Modifying project: ${existingJob.customer}` : 'Draft new project scope and pricing'}
                        </p>
                    </div>
                </div>
                <div className="flex items-center gap-4">
                    <button
                        onClick={() => setIsSettingsOpen(true)}
                        className="p-2 hover:bg-[#141517] rounded-lg text-[#6b7280] hover:text-[#6e79d6] transition-colors"
                        title="Settings & Templates"
                    >
                        <Settings size={20} />
                    </button>
                    <div className="h-8 w-px bg-white/[0.08] mx-2" />
                    <div className="text-right">
                        <div className="text-xs text-[#6b7280] font-semibold uppercase">Total Est. Value</div>
                        <div className="text-xl font-mono font-semibold text-[#3dae6c]">{DOLLAR_SIGN}{financials.totalRevenue.toLocaleString()}</div>
                    </div>
                    <div className="h-8 w-px bg-white/[0.08] mx-2" />
                    <div className="flex items-center gap-2">
                        {isDirty && (
                            <span className="text-[10px] text-amber-400 bg-amber-500/10 px-2 py-1 rounded border border-amber-500/20 flex items-center gap-1">
                                <span className="w-1.5 h-1.5 bg-amber-400 rounded-full animate-pulse" />
                                Unsaved
                            </span>
                        )}
                        <button onClick={handleCloseAttempt} className="p-2 hover:bg-[#141517] rounded-lg text-[#6b7280] hover:text-[#d1d5db] transition-colors">
                            <X size={24} />
                        </button>
                    </div>
                </div>
            </div>

            {/* Main Content */}
            <div className="flex-1 flex overflow-hidden">
                
                {/* Left Sidebar: Configuration (Resizable) */}
                <div
                    id="quote-sidebar"
                    className="bg-[#08090a] border-r border-white/[0.06] flex flex-col overflow-y-auto custom-scrollbar shrink-0"
                    style={{ width: leftSidebarWidth }}
                >
                    <div className="p-6 space-y-6">

                        {/* Section: Customer Info */}
                        <div id="quote-aircraft-info" className="space-y-4">
                            <h3 className="text-xs font-semibold text-[#6b7280] uppercase flex items-center gap-2">
                                <Plane size={12} /> Aircraft Information
                            </h3>
                            <div>
                                <label className="block text-xs text-[#6b7280] mb-1 font-semibold flex items-center gap-1.5">
                                    Customer / Tail #
                                    <HelpIcon tooltip="Aircraft registration number (e.g., N77NZ). In the US, tail numbers start with 'N' followed by up to 5 alphanumeric characters." size={11} />
                                </label>
                                <input
                                    type="text"
                                    value={customer}
                                    onChange={(e) => setCustomer(e.target.value)}
                                    placeholder="N-Number"
                                    className="w-full bg-[#0d0e10] border border-white/[0.08] rounded-md p-2 text-[#e8e8e8] font-semibold focus:border-[#5e6ad2] outline-none"
                                    autoFocus={!existingJob}
                                />
                            </div>
                            <div>
                                <label className="block text-xs text-[#6b7280] mb-1 font-semibold flex items-center gap-1.5">
                                    Aircraft Model
                                    <HelpIcon tooltip="Select the aircraft type. This filters available standard services and determines hangar requirements." size={11} />
                                </label>
                                <select
                                    value={aircraftType}
                                    onChange={(e) => setAircraftType(e.target.value)}
                                    className="w-full bg-[#0d0e10] border border-white/[0.08] rounded-md p-2 text-[#e8e8e8] text-sm focus:border-[#5e6ad2] outline-none"
                                >
                                    {gameState.aircraftModels.map(m => (
                                        <option key={m.id} value={m.id}>{m.name}</option>
                                    ))}
                                </select>
                            </div>
                            <div>
                                <label className="block text-xs text-[#6b7280] mb-1 font-semibold">Project Title (Optional)</label>
                                <input
                                    type="text"
                                    value={description}
                                    onChange={(e) => setDescription(e.target.value)}
                                    placeholder="e.g. 96 Month Inspection"
                                    className="w-full bg-[#0d0e10] border border-white/[0.08] rounded-md p-2 text-[#e8e8e8] text-sm focus:border-[#5e6ad2] outline-none"
                                />
                            </div>
                        </div>

                        <hr className="border-white/[0.06]" />

                        {/* Section: Logistics */}
                        <div className="space-y-4">
                            <h3 className="text-xs font-semibold text-[#6b7280] uppercase flex items-center gap-2">
                                <Clock size={12} /> Logistics & Priority
                            </h3>

                            <div className="flex items-center justify-between bg-[#0d0e10] p-3 rounded-md border border-white/[0.08]">
                                <span className="text-sm text-[#9ca3af] font-medium flex items-center gap-1.5">
                                    AOG Priority
                                    <HelpIcon tooltip="Aircraft On Ground - Mark as urgent priority. AOG aircraft cannot fly until repairs are complete. These jobs typically get expedited scheduling." size={11} />
                                </span>
                                <button
                                    onClick={() => setIsAOG(!isAOG)}
                                    className={`w-10 h-5 rounded-full relative transition-colors ${isAOG ? 'bg-[#c4626a]' : 'bg-[#1a1b1e]'}`}
                                >
                                    <div className={`absolute top-1 w-3 h-3 bg-white rounded-full transition-all ${isAOG ? 'left-6' : 'left-1'}`} />
                                </button>
                            </div>

                            <div className="grid grid-cols-2 gap-3">
                                <div>
                                    <label className="block text-xs text-[#6b7280] mb-1 font-semibold flex items-center gap-1.5">
                                        Start Date
                                        <HelpIcon tooltip="When the aircraft arrives or work begins. Used as the earliest scheduling date." size={11} />
                                    </label>
                                    <input
                                        type="date"
                                        value={targetStart}
                                        onChange={(e) => setTargetStart(e.target.value)}
                                        className="w-full bg-[#0d0e10] border border-white/[0.08] rounded-md p-1.5 text-xs text-[#d1d5db] font-mono focus:border-[#5e6ad2] outline-none"
                                    />
                                </div>
                                <div>
                                    <label className="block text-xs text-[#6b7280] mb-1 font-semibold flex items-center gap-1.5">
                                        End Date (Request)
                                        <HelpIcon tooltip="Customer's requested completion date. Jobs scheduled past this deadline show as 'Late' status." size={11} />
                                    </label>
                                    <input
                                        type="date"
                                        value={targetEnd}
                                        min={targetStart}
                                        onChange={(e) => setTargetEnd(e.target.value)}
                                        className="w-full bg-[#0d0e10] border border-white/[0.08] rounded-md p-1.5 text-xs text-[#d1d5db] font-mono focus:border-[#5e6ad2] outline-none"
                                    />
                                </div>
                            </div>
                        </div>

                        <hr className="border-white/[0.06]" />

                        {/* Section: Notes */}
                        <div className="space-y-2">
                            <h3 className="text-xs font-semibold text-[#6b7280] uppercase flex items-center gap-2">
                                <FileText size={12} /> Notes
                            </h3>
                            <textarea
                                value={notes}
                                onChange={(e) => setNotes(e.target.value)}
                                className="w-full bg-[#0d0e10] border border-white/[0.08] rounded-md p-2 text-xs text-[#d1d5db] h-24 focus:border-[#5e6ad2] outline-none resize-none font-mono"
                                placeholder="Internal remarks, constraints..."
                            />
                        </div>

                        <hr className="border-white/[0.06]" />

                        {/* Section: Service Library (Filtered) */}
                        <div id="quote-standard-services" className="space-y-3">
                            <div className="flex justify-between items-end mb-1">
                                <h3 className="text-xs font-semibold text-[#6b7280] uppercase flex items-center gap-2">
                                    <Wrench size={12} /> Standard Services
                                </h3>
                                <span className="text-[10px] text-[#6e79d6] font-semibold cursor-pointer hover:underline" onClick={() => setIsSettingsOpen(true)}>Manage</span>
                            </div>
                            <p className="text-[9px] text-[#4b5563] italic mb-2">Drag items to scope or click + to add</p>

                            <div className="grid grid-cols-1 gap-2">
                                {availableServices.length === 0 ? (
                                    <div className="text-xs text-[#6b7280] italic p-2">No standard services found for this aircraft type.</div>
                                ) : (
                                    availableServices.map(srv => (
                                        <div
                                            key={srv.id}
                                            draggable={true}
                                            onDragStart={(e) => {
                                                e.dataTransfer.setData('serviceId', srv.id);
                                                e.dataTransfer.effectAllowed = 'copy';
                                            }}
                                            onClick={() => addLineItem(srv)}
                                            className="text-left text-xs p-2 bg-[#0d0e10] hover:bg-[#141517] border border-white/[0.08] hover:border-[#5e6ad2]/50 rounded-md flex justify-between group transition-all cursor-grab active:cursor-grabbing select-none"
                                        >
                                            <div className="flex flex-col truncate pointer-events-none">
                                                <span className="text-[#d1d5db] group-hover:text-[#6e79d6] font-medium truncate">{srv.description}</span>
                                                {srv.applicableModelId === 'COMMON' || !srv.applicableModelId ? (
                                                    <span className="text-[9px] text-[#6b7280]">Common</span>
                                                ) : (
                                                    <span className="text-[9px] text-[#6e79d6]">{gameState.aircraftModels.find(m=>m.id===srv.applicableModelId)?.name}</span>
                                                )}
                                            </div>
                                            <Plus size={14} className="text-[#6b7280] group-hover:text-[#6e79d6] shrink-0 ml-2 mt-1 pointer-events-none" />
                                        </div>
                                    ))
                                )}
                            </div>
                        </div>
                    </div>
                </div>

                {/* Drag Handle Left */}
                <div
                    className="w-2 bg-[#08090a] hover:bg-[#5e6ad2]/20 cursor-col-resize flex items-center justify-center group transition-colors shrink-0 z-10 relative border-r border-white/[0.06]"
                    onMouseDown={(e) => startResize(e, 'left')}
                >
                    <div className="absolute top-0 bottom-0 w-px bg-transparent group-hover:bg-[#5e6ad2] transition-colors left-0" />
                    <div className="h-8 w-1 rounded-full bg-[#1a1b1e] group-hover:bg-[#6e79d6] transition-colors" />
                </div>

                {/* Center: Line Items */}
                <div id="quote-line-items" className="flex-1 bg-[#0d0e10] flex flex-col">
                    {/* Line Item Header */}
                    <div className="bg-[#0d0e10] border-b border-white/[0.06] p-4 flex justify-between items-center">
                        <div>
                            <h3 className="font-semibold text-[#e8e8e8] flex items-center gap-2 tracking-wide">
                                Scope of Work <span className="text-[#6b7280] text-xs font-normal">({lineItems.length} Items)</span>
                            </h3>
                            <p className="text-[9px] text-[#6b7280] mt-0.5 italic">Drag items to scope or click + to add. Reorder by dragging handle.</p>
                        </div>
                        <button
                            onClick={() => addLineItem()}
                            className="text-xs bg-[#141517] hover:bg-[#5e6ad2]/20 text-[#6e79d6] border border-[#5e6ad2]/30 px-3 py-1.5 rounded-md flex items-center gap-1 transition-colors font-semibold"
                        >
                            <Plus size={14} /> Add Custom Item
                        </button>
                    </div>

                    {/* Line Item List */}
                    <div
                        className={`flex-1 overflow-y-auto p-4 space-y-3 bg-[#0d0e10] transition-colors ${isDraggingOver ? 'bg-[#141517]/30 ring-1 ring-inset ring-[#5e6ad2]/30' : ''}`}
                        onDragOver={(e) => {
                            e.preventDefault();
                            if (!isDraggingOver) setIsDraggingOver(true);
                        }}
                        onDragLeave={() => setIsDraggingOver(false)}
                        onDrop={onDropContainer}
                    >
                        {lineItems.length === 0 && !isDraggingOver && (
                            <div className="h-full flex flex-col items-center justify-center text-[#4b5563] opacity-60">
                                <FileText size={48} className="mb-4 text-[#1a1b1e]" />
                                <p>No line items added.</p>
                                <p className="text-xs">Select a standard service, drag it here, or add a custom item to begin.</p>
                            </div>
                        )}

                        {isDraggingOver && lineItems.length === 0 && (
                            <div className="h-full flex flex-col items-center justify-center text-[#5e6ad2]/50 border-2 border-dashed border-[#5e6ad2]/20 rounded-lg">
                                <Download size={48} className="mb-4 animate-bounce" />
                                <p>Drop Service Here</p>
                            </div>
                        )}

                        {lineItems.map((item, idx) => {
                            const expanded = expandedItemIds.has(item.id);
                            const effectiveRate = item.laborRate > 0 ? item.laborRate : gameState.shopRate;
                            const laborCost = item.laborHours * effectiveRate;
                            const partsTotal = item.partsCost * item.partsMarkup;
                            const lineTotal = item.fixedPrice ?? (laborCost + partsTotal);
                            const isInheritedRate = item.laborRate === 0 || !item.laborRate;
                            const autoMarkup = getAutoMarkup(item.partsCost, item.category || 'Part');
                            const isMarkupOverride = item.category !== 'Labor' && Math.abs(item.partsMarkup - autoMarkup) > 0.001 && item.partsCost > 0;

                            return (
                            <div
                                key={item.id}
                                draggable={true}
                                onDragStart={(e) => onDragStartItem(e, idx)}
                                onDragOver={onDragOverItem}
                                onDrop={(e) => onDropItem(e, idx)}
                                className={`bg-[#141517]/50 border border-white/[0.08] rounded-lg hover:border-[#5e6ad2]/50 transition-all group
                                    ${draggedItemIndex === idx ? 'opacity-50 ring-2 ring-[#5e6ad2]' : ''}
                                `}
                            >
                                {/* Header / Summary Row */}
                                <div className="flex items-start p-3 gap-3">
                                    {/* Drag Handle */}
                                    <div className="text-[#4b5563] hover:text-[#9ca3af] cursor-grab active:cursor-grabbing pt-1.5 shrink-0" title="Drag to Reorder">
                                        <GripVertical size={16} />
                                    </div>

                                    {/* Collapse Toggle */}
                                    <button
                                        onClick={() => toggleExpand(item.id)}
                                        className="text-[#6b7280] hover:text-white pt-1.5 shrink-0 transition-colors"
                                    >
                                        {expanded ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
                                    </button>

                                    <div className="flex-1">
                                        <div className="flex justify-between items-start gap-4">
                                            <div className="flex-1">
                                                <label className="text-[9px] uppercase font-semibold text-[#6b7280] mb-0.5 flex items-center gap-2">
                                                    <span className={`px-1.5 rounded text-[8px] border ${item.category === 'Labor' ? 'bg-[#1a1b1e] border-white/[0.08] text-[#d1d5db]' : item.category === 'Service' ? 'bg-[#5e6ad2]/10 border-[#5e6ad2]/30 text-[#6e79d6]' : 'bg-amber-900/20 border-amber-500/30 text-amber-400'}`}>
                                                        {item.category || 'Part'}
                                                    </span>
                                                    Discrepancy / Service Description
                                                </label>
                                                <input
                                                    type="text"
                                                    value={item.description}
                                                    onChange={(e) => updateLineItem(item.id, 'description', e.target.value)}
                                                    className="w-full bg-transparent border-b border-transparent hover:border-white/[0.1] focus:border-[#5e6ad2] outline-none text-[#e8e8e8] font-semibold pb-0.5 text-sm transition-colors"
                                                />
                                            </div>

                                            {/* Quick Summary when Collapsed */}
                                            {!expanded && (
                                                <div className="flex items-center gap-6 pt-4 text-xs font-mono text-[#9ca3af] shrink-0">
                                                    {item.category === 'Labor' && <span>{item.laborHours}h</span>}
                                                    <span className="font-semibold text-[#3dae6c]">{DOLLAR_SIGN}{Math.round(lineTotal).toLocaleString()}</span>
                                                </div>
                                            )}

                                            {/* Delete */}
                                            <button onClick={() => removeLineItem(item.id)} className="text-[#4b5563] hover:text-[#c4626a] transition-colors p-1 hover:bg-[#c4626a]/10 rounded-md shrink-0 mt-1">
                                                <Trash2 size={14} />
                                            </button>
                                        </div>
                                    </div>
                                </div>

                                {/* Detailed Body - Refactored for Vertical Efficiency */}
                                {expanded && (
                                    <div className="px-3 pb-3 pt-1 border-t border-white/[0.04] animate-in slide-in-from-top-2 fade-in duration-200">
                                        {/* Compact Grid Layout */}
                                        <div className="grid grid-cols-2 gap-x-6 gap-y-3 mt-2">

                                            {/* Left Column: Labor Details */}
                                            <div className="space-y-2">
                                                <div className="grid grid-cols-2 gap-2">
                                                    <div>
                                                        <label className="text-[9px] uppercase font-semibold text-[#6b7280] mb-1 block">EST. HOURS</label>
                                                        <div className="relative">
                                                            <input
                                                                type="number" step="0.5"
                                                                value={item.laborHours}
                                                                onChange={(e) => updateLineItem(item.id, 'laborHours', parseFloat(e.target.value))}
                                                                className="w-full bg-[#0d0e10] border border-white/[0.08] rounded-md p-1.5 text-[#e8e8e8] text-sm font-mono text-right pr-6 focus:border-[#5e6ad2] outline-none"
                                                            />
                                                            <span className="absolute right-2 top-1.5 text-xs text-[#6b7280]">h</span>
                                                        </div>
                                                    </div>
                                                    <div className="relative">
                                                        <label className="text-[9px] uppercase font-semibold text-[#6b7280] mb-1 block">LABOR RATE</label>
                                                        <div className="relative">
                                                            <span className="absolute left-2 top-1.5 text-xs text-[#6b7280]">$</span>
                                                            <input
                                                                type="number"
                                                                placeholder={gameState.shopRate.toString()}
                                                                value={isInheritedRate ? '' : item.laborRate}
                                                                onChange={(e) => updateLineItem(item.id, 'laborRate', e.target.value === '' ? 0 : parseFloat(e.target.value))}
                                                                className={`w-full bg-[#0d0e10] border border-white/[0.08] rounded-md p-1.5 text-sm font-mono pl-5 focus:border-[#5e6ad2] outline-none ${isInheritedRate ? 'text-[#9ca3af] italic' : 'text-[#e8e8e8]'}`}
                                                            />
                                                        </div>
                                                        {isInheritedRate && (
                                                            <span className="absolute -top-0.5 right-0 text-[8px] font-semibold text-[#6e79d6]/80 uppercase bg-[#5e6ad2]/10 px-1 rounded">Inherited</span>
                                                        )}
                                                    </div>
                                                </div>

                                                {/* Calculated Labor Total Display */}
                                                <div className="flex justify-between items-center text-[10px] bg-[#141517]/50 px-2 py-1.5 rounded-md border border-white/[0.06]">
                                                    <span className="text-[#6b7280] font-semibold uppercase">Labor Subtotal</span>
                                                    <span className="text-[#d1d5db] font-mono font-semibold">{DOLLAR_SIGN}{Math.round(laborCost).toLocaleString()}</span>
                                                </div>
                                            </div>

                                            {/* Right Column: Parts & Line Total */}
                                            <div className="space-y-2">
                                                <div className="grid grid-cols-3 gap-2">
                                                    {/* Category Select */}
                                                    <div className="col-span-1">
                                                        <label className="text-[9px] uppercase font-semibold text-[#6b7280] mb-1 block">TYPE</label>
                                                        <select
                                                            value={item.category || 'Part'}
                                                            onChange={(e) => updateLineItem(item.id, 'category', e.target.value)}
                                                            className="w-full bg-[#0d0e10] border border-white/[0.08] rounded-md p-1.5 text-xs text-[#e8e8e8] outline-none focus:border-[#5e6ad2]"
                                                        >
                                                            <option value="Labor">Labor</option>
                                                            <option value="Part">Part</option>
                                                            <option value="Service">Vendor</option>
                                                        </select>
                                                    </div>

                                                    <div className="col-span-2 relative">
                                                        <label className="text-[9px] uppercase font-semibold text-[#6b7280] mb-1 block">DIRECT COST</label>
                                                        <div className="relative">
                                                            <span className="absolute left-2 top-1.5 text-xs text-[#6b7280]">$</span>
                                                            <input
                                                                type="number"
                                                                value={item.partsCost}
                                                                onChange={(e) => updateLineItem(item.id, 'partsCost', parseFloat(e.target.value))}
                                                                className="w-full bg-[#0d0e10] border border-white/[0.08] rounded-md p-1.5 text-[#e8e8e8] text-sm font-mono pl-5 focus:border-[#5e6ad2] outline-none"
                                                            />
                                                        </div>
                                                    </div>
                                                </div>

                                                <div className="flex items-center gap-2">
                                                    <div className="flex-1 relative group/markup">
                                                        <label className="text-[9px] uppercase font-semibold text-[#6b7280] mb-1 flex items-center gap-1">
                                                            MARKUP
                                                            {isMarkupOverride && <span className="text-[8px] text-amber-500 bg-amber-950/50 px-1 rounded">OVERRIDE</span>}
                                                        </label>
                                                        <div className="flex items-center bg-[#0d0e10] border border-white/[0.08] rounded-md overflow-hidden">
                                                            <input
                                                                type="number"
                                                                step="0.05"
                                                                value={item.partsMarkup}
                                                                onChange={(e) => updateLineItem(item.id, 'partsMarkup', parseFloat(e.target.value))}
                                                                className={`w-full bg-transparent p-1.5 text-sm font-mono outline-none pl-2 ${isMarkupOverride ? 'text-amber-400 font-semibold' : 'text-[#9ca3af]'}`}
                                                            />
                                                            <div className="bg-[#141517] px-2 py-1.5 border-l border-white/[0.08] text-xs text-[#6b7280] font-mono">
                                                                x
                                                            </div>
                                                        </div>
                                                        {!isMarkupOverride && item.partsCost > 0 && (
                                                            <div className="absolute -top-6 right-0 bg-[#141517] text-[9px] text-[#3dae6c] px-1.5 py-0.5 rounded border border-white/[0.1] opacity-0 group-hover/markup:opacity-100 transition-opacity pointer-events-none whitespace-nowrap">
                                                                Auto Tier Applied
                                                            </div>
                                                        )}
                                                    </div>

                                                    <div className="flex-1">
                                                        <label className="text-[9px] uppercase font-semibold text-[#6b7280] mb-1 block">FIXED PRICE</label>
                                                        <input
                                                            type="number"
                                                            placeholder="Auto"
                                                            value={item.fixedPrice || ''}
                                                            onChange={(e) => updateLineItem(item.id, 'fixedPrice', e.target.value ? parseFloat(e.target.value) : undefined)}
                                                            className={`w-full border rounded-md p-1.5 text-sm font-mono focus:border-[#5e6ad2] outline-none ${item.fixedPrice ? 'bg-[#5e6ad2]/10 border-[#5e6ad2]/50 text-[#6e79d6] font-semibold' : 'bg-[#0d0e10] border-white/[0.08] text-[#6b7280] italic'}`}
                                                        />
                                                    </div>
                                                </div>

                                                {/* Line Total Display */}
                                                <div className="flex justify-between items-center text-[10px] bg-[#141517] px-2 py-1.5 rounded-md border border-white/[0.08] mt-2">
                                                    <span className="text-[#3dae6c] font-semibold uppercase">Line Total</span>
                                                    <span className="text-[#3dae6c] font-mono font-semibold text-sm">{DOLLAR_SIGN}{Math.round(lineTotal).toLocaleString()}</span>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                )}
                            </div>
                        )})}
                    </div>
                </div>

                {/* Drag Handle Right */}
                <div
                    className="w-2 bg-[#0d0e10] hover:bg-[#5e6ad2]/10 cursor-col-resize flex items-center justify-center group transition-colors shrink-0 z-10 relative border-l border-white/[0.06]"
                    onMouseDown={(e) => startResize(e, 'right')}
                >
                    <div className="absolute top-0 bottom-0 w-px bg-transparent group-hover:bg-[#5e6ad2] transition-colors right-0" />
                    <div className="h-8 w-1 rounded-full bg-[#4b5563] group-hover:bg-[#6e79d6] transition-colors" />
                </div>

                {/* Right Sidebar: Financial Summary (Resizable) */}
                <div
                    id="quote-summary"
                    className="bg-[#0d0e10] border-l border-white/[0.06] p-6 flex flex-col shrink-0"
                    style={{ width: rightSidebarWidth }}
                >
                    <h3 className="text-xs font-semibold text-[#6b7280] uppercase flex items-center gap-2 mb-6 tracking-wide">
                        <Calculator size={12} className="text-[#6e79d6]" /> Profitability Analysis
                    </h3>

                    <div className="space-y-4 flex-1">
                        <div className="flex justify-between items-end border-b border-white/[0.06] pb-2">
                            <span className="text-sm text-[#6b7280] font-medium">Labor Revenue</span>
                            <span className="font-mono text-[#3dae6c] font-semibold">{DOLLAR_SIGN}{Math.round(financials.laborRevenue).toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between items-end border-b border-white/[0.06] pb-2">
                            <span className="text-sm text-[#6b7280] font-medium">Parts/Vendor Rev</span>
                            <span className="font-mono text-[#3dae6c] font-semibold">{DOLLAR_SIGN}{Math.round(financials.partsRevenue).toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between items-end border-b border-white/[0.06] pb-2 pt-2 bg-[#141517] p-2 rounded">
                            <span className="text-sm font-semibold text-[#e8e8e8]">Total Quote</span>
                            <span className="font-mono font-semibold text-emerald-400 text-lg">{DOLLAR_SIGN}{Math.round(financials.totalRevenue).toLocaleString()}</span>
                        </div>

                        <div className="py-4 space-y-2">
                            <div className="flex justify-between items-end text-xs">
                                <span className="text-[#6b7280]">Est. Labor Cost</span>
                                <span className="font-mono text-rose-400 font-semibold">{DOLLAR_SIGN}{Math.round(financials.totalCost - financials.partsCost).toLocaleString()}</span>
                            </div>
                            <div className="flex justify-between items-end text-xs">
                                <span className="text-[#6b7280]">Direct Costs (Parts)</span>
                                <span className="font-mono text-rose-400 font-semibold">{DOLLAR_SIGN}{Math.round(financials.partsCost).toLocaleString()}</span>
                            </div>
                        </div>

                        <div className="bg-[#141517] rounded-lg p-4 border border-white/[0.08]">
                            <div className="flex justify-between items-center mb-2">
                                <span className="text-xs font-semibold uppercase text-[#6b7280] flex items-center gap-1.5">
                                    Gross Margin
                                    <HelpIcon tooltip="Profit percentage before overhead: (Revenue - Direct Costs) / Revenue. Green ≥30% (healthy), Amber 15-30% (acceptable), Red <15% (low)." size={11} />
                                </span>
                                <span className={`text-xl font-semibold font-mono ${financials.margin >= 30 ? 'text-[#3dae6c]' : financials.margin >= 15 ? 'text-amber-400' : 'text-[#c4626a]'}`}>
                                    {financials.margin.toFixed(1)}%
                                </span>
                            </div>
                            <div className="w-full h-2 bg-[#08090a] rounded-full overflow-hidden border border-white/[0.06]">
                                <div
                                    className={`h-full transition-all ${financials.margin >= 30 ? 'bg-emerald-500' : 'bg-amber-500'}`}
                                    style={{ width: `${Math.min(financials.margin, 100)}%` }}
                                />
                            </div>
                            <div className="mt-2 text-[9px] text-[#6b7280] border-t border-white/[0.06] pt-2">
                                <span className="text-[#9ca3af]">Includes:</span> Labor &amp; parts costs • <span className="text-[#9ca3af]">Excludes:</span> Fixed overhead (~{DOLLAR_SIGN}{Math.round(gameState.overheadDaily).toLocaleString()}/day)
                            </div>
                            {financials.margin < 15 && (
                                <div className="mt-2 flex items-center gap-1.5 text-[9px] text-[#c4626a] bg-[#c4626a]/10 p-1.5 rounded border border-[#c4626a]/20">
                                    <AlertTriangle size={10} /> Low Margin: High Pass-Through Costs
                                </div>
                            )}

                            {/* Collapsible Breakdown Section */}
                            <button
                                onClick={() => setShowMarginBreakdown(!showMarginBreakdown)}
                                className="mt-3 w-full flex items-center justify-between text-[10px] text-[#6e79d6] hover:text-[#7b86e0] transition-colors py-1"
                            >
                                <span className="flex items-center gap-1.5">
                                    {showMarginBreakdown ? <ChevronDown size={12} /> : <ChevronRight size={12} />}
                                    View Full Breakdown
                                </span>
                                <span className="text-[#4b5563]">Revenue & Costs</span>
                            </button>

                            {showMarginBreakdown && (
                                <div className="mt-2 bg-[#08090a] rounded-lg border border-white/[0.06] p-3 space-y-3">
                                    {/* Revenue Section */}
                                    <div>
                                        <div className="text-[9px] font-semibold text-[#3dae6c] uppercase tracking-wide mb-2">Revenue Breakdown</div>
                                        <div className="space-y-1.5 text-xs font-mono">
                                            <div className="flex justify-between text-[#9ca3af]">
                                                <span>Labor: {financials.totalHours.toFixed(1)} hrs × {DOLLAR_SIGN}{gameState.shopRate || 135}/hr</span>
                                                <span className="text-[#3dae6c]">{DOLLAR_SIGN}{Math.round(financials.laborRevenue).toLocaleString()}</span>
                                            </div>
                                            <div className="flex justify-between text-[#9ca3af]">
                                                <span>Parts: {DOLLAR_SIGN}{Math.round(financials.partsCost).toLocaleString()} × markup</span>
                                                <span className="text-[#3dae6c]">{DOLLAR_SIGN}{Math.round(financials.partsRevenue).toLocaleString()}</span>
                                            </div>
                                            <div className="border-t border-white/[0.06] pt-1.5 flex justify-between font-semibold">
                                                <span className="text-[#e8e8e8]">Total Revenue</span>
                                                <span className="text-[#3dae6c]">{DOLLAR_SIGN}{Math.round(financials.totalRevenue).toLocaleString()}</span>
                                            </div>
                                        </div>
                                    </div>

                                    {/* Cost Section */}
                                    <div>
                                        <div className="text-[9px] font-semibold text-[#c4626a] uppercase tracking-wide mb-2">Cost Breakdown</div>
                                        <div className="space-y-1.5 text-xs font-mono">
                                            <div className="flex justify-between text-[#9ca3af]">
                                                <span>Labor Cost: {financials.totalHours.toFixed(1)} hrs × {DOLLAR_SIGN}{HOURLY_COST_AVG}/hr</span>
                                                <span className="text-[#c4626a]">({DOLLAR_SIGN}{Math.round(financials.totalHours * HOURLY_COST_AVG).toLocaleString()})</span>
                                            </div>
                                            <div className="flex justify-between text-[#9ca3af]">
                                                <span>Parts (at cost)</span>
                                                <span className="text-[#c4626a]">({DOLLAR_SIGN}{Math.round(financials.partsCost).toLocaleString()})</span>
                                            </div>
                                            <div className="border-t border-white/[0.06] pt-1.5 flex justify-between font-semibold">
                                                <span className="text-[#e8e8e8]">Total Direct Costs</span>
                                                <span className="text-[#c4626a]">({DOLLAR_SIGN}{Math.round(financials.totalCost).toLocaleString()})</span>
                                            </div>
                                        </div>
                                    </div>

                                    {/* Profit Section */}
                                    <div className="bg-gradient-to-r from-[#5e6ad2]/10 to-[#3dae6c]/10 rounded-lg p-3 border border-[#5e6ad2]/20">
                                        <div className="flex justify-between items-center text-sm font-mono">
                                            <span className="font-semibold text-[#e8e8e8]">Gross Profit</span>
                                            <span className={`font-bold ${financials.grossProfit >= 0 ? 'text-[#3dae6c]' : 'text-[#c4626a]'}`}>
                                                {DOLLAR_SIGN}{Math.round(financials.grossProfit).toLocaleString()}
                                            </span>
                                        </div>
                                        <div className="flex justify-between items-center text-xs font-mono mt-1">
                                            <span className="text-[#6b7280]">Gross Margin</span>
                                            <span className={`font-semibold ${financials.margin >= 30 ? 'text-[#3dae6c]' : financials.margin >= 15 ? 'text-amber-400' : 'text-[#c4626a]'}`}>
                                                {financials.margin.toFixed(1)}%
                                            </span>
                                        </div>
                                    </div>

                                    {/* Note */}
                                    <div className="text-[9px] text-[#4b5563] italic">
                                        Note: Excludes daily overhead (~{DOLLAR_SIGN}{Math.round(gameState.overheadDaily).toLocaleString()}/day). Actual net profit depends on shop utilization.
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>

                    <button
                        id="btn-save-quote"
                        onClick={handleSaveInternal}
                        disabled={!customer || lineItems.length === 0}
                        className="w-full bg-[#5e6ad2] hover:bg-[#7b86e0] disabled:opacity-50 disabled:cursor-not-allowed text-white font-semibold py-4 rounded-lg transition-all hover:scale-[1.01] active:scale-[0.99] flex flex-col items-center gap-1 mt-4"
                    >
                        <span className="flex items-center gap-2 text-lg"><CheckCircle size={20} /> {existingJob ? 'Update Quote' : 'Create Quote'}</span>
                        <span className="text-[10px] uppercase opacity-90 font-medium text-white/80">
                            {existingJob ? 'Apply Changes to Project' : 'Add to Quotes'}
                        </span>
                    </button>
                </div>

            </div>
        </div>

        {/* Unsaved Changes Confirmation Modal */}
        {showCloseConfirm && (
            <div className="fixed inset-0 bg-[#08090a]/80 backdrop-blur-sm z-[200] flex items-center justify-center p-4 animate-in fade-in duration-200">
                <div className="bg-[#0d0e10] border border-white/[0.08] rounded-xl p-6 max-w-sm w-full shadow-2xl">
                    <div className="flex items-start gap-4">
                        <div className="w-10 h-10 bg-amber-500/10 rounded-full flex items-center justify-center shrink-0">
                            <AlertTriangle size={20} className="text-amber-400" />
                        </div>
                        <div className="flex-1">
                            <h3 className="text-lg font-semibold text-white mb-1">Unsaved Changes</h3>
                            <p className="text-sm text-[#9ca3af] mb-4">
                                You have unsaved changes. Are you sure you want to close? Your changes will be lost.
                            </p>
                            <div className="flex gap-2">
                                <button
                                    onClick={() => setShowCloseConfirm(false)}
                                    className="flex-1 px-4 py-2 bg-[#141517] hover:bg-[#1a1b1e] text-[#e8e8e8] rounded-lg text-sm font-medium transition-colors border border-white/[0.08]"
                                >
                                    Keep Editing
                                </button>
                                <button
                                    onClick={onClose}
                                    className="flex-1 px-4 py-2 bg-rose-500/20 hover:bg-rose-500/30 text-rose-400 rounded-lg text-sm font-medium transition-colors border border-rose-500/30"
                                >
                                    Discard & Close
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )}
    </div>
  );
};

export default React.memo(QuoteBuilder);
