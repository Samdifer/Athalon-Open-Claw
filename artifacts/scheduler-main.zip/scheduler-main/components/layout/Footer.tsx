import React from 'react';
import { Link } from 'react-router-dom';
import { Plane } from 'lucide-react';

const Footer: React.FC = () => {
  const footerLinks = {
    product: {
      title: 'Product',
      links: [
        { label: 'Scheduling', href: '/features#scheduling' },
        { label: 'Quoting', href: '/features#quoting' },
        { label: 'Financials', href: '/features#financials' },
        { label: 'Capacity', href: '/features#capacity' },
        { label: 'Personnel', href: '/features#personnel' },
        { label: 'Pricing', href: '/pricing' },
      ],
    },
    resources: {
      title: 'Resources',
      links: [
        { label: 'Documentation', href: '/docs', external: true },
        { label: 'Changelog', href: '/changelog' },
        { label: 'Status', href: 'https://status.aeromanager.app', external: true },
        { label: 'API Reference', href: '/docs/api', external: true },
      ],
    },
    company: {
      title: 'Company',
      links: [
        { label: 'About', href: '/about' },
        { label: 'Customers', href: '/customers' },
        { label: 'Careers', href: '/careers' },
        { label: 'Contact', href: '/contact' },
      ],
    },
    legal: {
      title: 'Legal',
      links: [
        { label: 'Privacy Policy', href: '/privacy' },
        { label: 'Terms of Service', href: '/terms' },
        { label: 'Cookie Policy', href: '/cookies' },
      ],
    },
  };

  const renderLink = (link: { label: string; href: string; external?: boolean }) => {
    if (link.external) {
      return (
        <a
          key={link.label}
          href={link.href}
          target="_blank"
          rel="noopener noreferrer"
          className="block text-[14px] text-[#9ca3af] hover:text-white transition-colors duration-fast"
        >
          {link.label}
        </a>
      );
    }
    return (
      <Link
        key={link.label}
        to={link.href}
        className="block text-[14px] text-[#9ca3af] hover:text-white transition-colors duration-fast"
      >
        {link.label}
      </Link>
    );
  };

  return (
    <footer className="bg-[#08090a] border-t border-white/[0.04]">
      <div className="max-w-screen-xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main Footer Content */}
        <div className="py-12 lg:py-16">
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-8 lg:gap-12">
            {/* Brand Column */}
            <div className="col-span-2 md:col-span-4 lg:col-span-1 mb-8 lg:mb-0">
              <Link to="/" className="flex items-center gap-2 mb-4">
                <Plane className="h-6 w-6 text-indigo-400" strokeWidth={1.5} />
                <span className="text-white font-semibold text-[15px]">AeroManager</span>
              </Link>
              <p className="text-[13px] text-[#6b7280] leading-relaxed max-w-[240px]">
                The modern way to manage your Part 145 maintenance operation.
              </p>
            </div>

            {/* Product Links */}
            <div>
              <h4 className="text-[11px] font-semibold text-[#6b7280] uppercase tracking-wider mb-4">
                {footerLinks.product.title}
              </h4>
              <div className="space-y-3">
                {footerLinks.product.links.map(renderLink)}
              </div>
            </div>

            {/* Resources Links */}
            <div>
              <h4 className="text-[11px] font-semibold text-[#6b7280] uppercase tracking-wider mb-4">
                {footerLinks.resources.title}
              </h4>
              <div className="space-y-3">
                {footerLinks.resources.links.map(renderLink)}
              </div>
            </div>

            {/* Company Links */}
            <div>
              <h4 className="text-[11px] font-semibold text-[#6b7280] uppercase tracking-wider mb-4">
                {footerLinks.company.title}
              </h4>
              <div className="space-y-3">
                {footerLinks.company.links.map(renderLink)}
              </div>
            </div>

            {/* Legal Links */}
            <div>
              <h4 className="text-[11px] font-semibold text-[#6b7280] uppercase tracking-wider mb-4">
                {footerLinks.legal.title}
              </h4>
              <div className="space-y-3">
                {footerLinks.legal.links.map(renderLink)}
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="py-6 border-t border-white/[0.04]">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            {/* Copyright */}
            <p className="text-[13px] text-[#6b7280]">
              &copy; {new Date().getFullYear()} AeroManager. All rights reserved.
            </p>

            {/* Social Links */}
            <div className="flex items-center gap-4">
              <a
                href="https://twitter.com/aeromanager"
                target="_blank"
                rel="noopener noreferrer"
                className="text-[#6b7280] hover:text-white transition-colors duration-fast"
                aria-label="Twitter"
              >
                <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
                </svg>
              </a>
              <a
                href="https://linkedin.com/company/aeromanager"
                target="_blank"
                rel="noopener noreferrer"
                className="text-[#6b7280] hover:text-white transition-colors duration-fast"
                aria-label="LinkedIn"
              >
                <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
                </svg>
              </a>
              <a
                href="https://youtube.com/@aeromanager"
                target="_blank"
                rel="noopener noreferrer"
                className="text-[#6b7280] hover:text-white transition-colors duration-fast"
                aria-label="YouTube"
              >
                <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" />
                </svg>
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
