// Layout Component Library - Linear-inspired page structure
// Barrel export for all layout components

export { default as Header } from './Header';
export type { HeaderProps } from './Header';

export { default as Footer } from './Footer';

export { default as Section, HeroSection, PageLayout } from './Section';
export type { SectionProps, HeroSectionProps, PageLayoutProps } from './Section';

export { default as ScrollReveal, ScrollRevealGroup, RevealOnScroll } from './ScrollReveal';
export type { ScrollRevealProps, ScrollRevealGroupProps, RevealOnScrollProps } from './ScrollReveal';
