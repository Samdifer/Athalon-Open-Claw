import React from 'react';
import { Container } from '../ui';

export interface SectionProps {
  id?: string;
  background?: 'default' | 'panel' | 'elevated' | 'gradient';
  padding?: 'sm' | 'md' | 'lg' | 'xl' | 'hero';
  border?: 'top' | 'bottom' | 'both' | 'none';
  containerSize?: 'sm' | 'md' | 'lg' | 'xl' | '2xl' | 'full';
  children: React.ReactNode;
  className?: string;
}

const Section: React.FC<SectionProps> = ({
  id,
  background = 'default',
  padding = 'lg',
  border = 'none',
  containerSize = 'xl',
  children,
  className = '',
}) => {
  // Background classes
  const backgroundClasses = {
    default: 'bg-[#08090a]',
    panel: 'bg-[#0d0e10]',
    elevated: 'bg-[#141517]',
    gradient: 'bg-gradient-to-b from-[#0d0e10] to-[#08090a]',
  };

  // Padding classes
  const paddingClasses = {
    sm: 'py-8 lg:py-12',
    md: 'py-12 lg:py-16',
    lg: 'py-16 lg:py-24',
    xl: 'py-20 lg:py-32',
    hero: 'pt-24 pb-16 lg:pt-32 lg:pb-24', // Extra top padding for hero below fixed header
  };

  // Border classes
  const borderClasses = {
    none: '',
    top: 'border-t border-white/[0.04]',
    bottom: 'border-b border-white/[0.04]',
    both: 'border-t border-b border-white/[0.04]',
  };

  return (
    <section
      id={id}
      className={`
        relative
        ${backgroundClasses[background]}
        ${paddingClasses[padding]}
        ${borderClasses[border]}
        ${className}
      `.replace(/\s+/g, ' ').trim()}
    >
      <Container size={containerSize}>
        {children}
      </Container>
    </section>
  );
};

// Hero Section - special section for page heroes
export interface HeroSectionProps {
  children: React.ReactNode;
  className?: string;
  withGradient?: boolean;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  children,
  className = '',
  withGradient = true,
}) => {
  return (
    <section
      className={`
        relative
        pt-32 pb-16 lg:pt-40 lg:pb-24
        bg-[#08090a]
        overflow-hidden
        ${className}
      `.replace(/\s+/g, ' ').trim()}
    >
      {/* Background gradient */}
      {withGradient && (
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          {/* Top gradient glow */}
          <div
            className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[600px] opacity-30"
            style={{
              background: 'radial-gradient(ellipse at center, rgba(99, 102, 241, 0.15) 0%, transparent 70%)',
            }}
          />
          {/* Side gradient glows */}
          <div
            className="absolute top-1/4 -left-64 w-[500px] h-[500px] opacity-20"
            style={{
              background: 'radial-gradient(circle, rgba(139, 92, 246, 0.2) 0%, transparent 70%)',
            }}
          />
          <div
            className="absolute top-1/3 -right-64 w-[500px] h-[500px] opacity-20"
            style={{
              background: 'radial-gradient(circle, rgba(99, 102, 241, 0.2) 0%, transparent 70%)',
            }}
          />
        </div>
      )}

      <Container size="xl" className="relative z-10">
        {children}
      </Container>
    </section>
  );
};

// Page Layout - wrapper for marketing pages
export interface PageLayoutProps {
  children: React.ReactNode;
  className?: string;
}

export const PageLayout: React.FC<PageLayoutProps> = ({
  children,
  className = '',
}) => {
  return (
    <main className={`min-h-screen bg-[#08090a] ${className}`}>
      {children}
    </main>
  );
};

export default Section;
