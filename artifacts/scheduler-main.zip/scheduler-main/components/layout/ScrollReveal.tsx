import React from 'react';
import { useScrollReveal, getRevealClasses } from '../../hooks/useScrollReveal';

export interface ScrollRevealProps {
  children: React.ReactNode;
  animation?: 'fade-up' | 'fade-in' | 'scale' | 'slide-left' | 'slide-right';
  delay?: number;
  threshold?: number;
  className?: string;
  as?: keyof JSX.IntrinsicElements;
}

/**
 * ScrollReveal component - wraps content with scroll-triggered animations
 */
const ScrollReveal: React.FC<ScrollRevealProps> = ({
  children,
  animation = 'fade-up',
  delay = 0,
  threshold = 0.1,
  className = '',
  as: Component = 'div',
}) => {
  const { ref, isVisible } = useScrollReveal({
    threshold,
    delay,
    triggerOnce: true,
  });

  const animationClasses = getRevealClasses(isVisible, animation);

  return (
    <Component
      ref={ref as React.RefObject<any>}
      className={`${animationClasses} ${className}`}
    >
      {children}
    </Component>
  );
};

/**
 * ScrollRevealGroup - for staggered animations of child elements
 */
export interface ScrollRevealGroupProps {
  children: React.ReactNode;
  staggerDelay?: number;
  animation?: 'fade-up' | 'fade-in' | 'scale' | 'slide-left' | 'slide-right';
  threshold?: number;
  className?: string;
}

export const ScrollRevealGroup: React.FC<ScrollRevealGroupProps> = ({
  children,
  staggerDelay = 80,
  animation = 'fade-up',
  threshold = 0.1,
  className = '',
}) => {
  const { ref, isVisible } = useScrollReveal({
    threshold,
    triggerOnce: true,
  });

  return (
    <div
      ref={ref}
      className={`${isVisible ? 'reveal-stagger revealed' : 'reveal-stagger'} ${className}`}
    >
      {React.Children.map(children, (child, index) => {
        if (!React.isValidElement(child)) return child;

        return React.cloneElement(child as React.ReactElement<any>, {
          style: {
            ...(child.props.style || {}),
            transitionDelay: isVisible ? `${index * staggerDelay}ms` : '0ms',
          },
        });
      })}
    </div>
  );
};

/**
 * RevealOnScroll - simpler reveal component using CSS classes
 */
export interface RevealOnScrollProps {
  children: React.ReactNode;
  className?: string;
  delay?: number;
}

export const RevealOnScroll: React.FC<RevealOnScrollProps> = ({
  children,
  className = '',
  delay = 0,
}) => {
  const { ref, isVisible } = useScrollReveal({
    triggerOnce: true,
  });

  return (
    <div
      ref={ref}
      className={`
        transition-all duration-reveal ease-linear-smooth
        ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'}
        ${className}
      `}
      style={{ transitionDelay: `${delay}ms` }}
    >
      {children}
    </div>
  );
};

export default ScrollReveal;
