import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Plane, Menu, X } from 'lucide-react';

export interface HeaderProps {
  transparent?: boolean;
}

const Header: React.FC<HeaderProps> = ({ transparent = false }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();

  // Handle scroll for backdrop blur effect
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close mobile menu on route change
  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [location.pathname]);

  const navLinks = [
    { href: '/features', label: 'Features' },
    { href: '/pricing', label: 'Pricing' },
    { href: '/customers', label: 'Customers' },
    { href: '/about', label: 'About' },
    { href: '/contact', label: 'Contact' },
  ];

  const isActive = (href: string) => location.pathname === href;

  // Determine header background based on scroll and transparent prop
  const showBackground = isScrolled || !transparent;

  return (
    <header
      className={`
        fixed top-0 left-0 right-0 z-50 h-14
        transition-all duration-500 ease-out
        ${showBackground
          ? 'bg-[#0a0a0b]/60 backdrop-blur-2xl backdrop-saturate-150 border-b border-white/[0.08] shadow-[0_4px_30px_rgba(0,0,0,0.4)]'
          : 'bg-transparent backdrop-blur-none'
        }
      `}
      style={{
        WebkitBackdropFilter: showBackground ? 'blur(24px) saturate(1.5)' : 'none',
      }}
    >
      {/* Frosted glass gradient overlay */}
      <div
        className={`
          absolute inset-0 pointer-events-none
          transition-opacity duration-500
          ${showBackground ? 'opacity-100' : 'opacity-0'}
        `}
        style={{
          background: 'linear-gradient(to bottom, rgba(10,10,11,0.4) 0%, rgba(10,10,11,0.2) 100%)',
        }}
      />

      {/* Subtle top highlight for glass effect */}
      <div
        className={`
          absolute top-0 left-0 right-0 h-px pointer-events-none
          bg-gradient-to-r from-transparent via-white/10 to-transparent
          transition-opacity duration-500
          ${showBackground ? 'opacity-100' : 'opacity-0'}
        `}
      />

      <div className="relative max-w-screen-xl mx-auto h-full px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-full">
          {/* Logo */}
          <Link
            to="/"
            className="flex items-center gap-2 cursor-pointer"
          >
            <Plane
              className="h-6 w-6 text-[#6e79d6]"
              strokeWidth={1.5}
            />
            <span className="text-white font-semibold text-[15px] tracking-tight">
              AeroManager
            </span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-1">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                to={link.href}
                className={`
                  px-3 py-2 text-[14px] font-medium rounded-lg cursor-pointer
                  transition-colors duration-150
                  ${isActive(link.href)
                    ? 'text-white bg-white/[0.08]'
                    : 'text-[#9ca3af] hover:text-white hover:bg-white/[0.04]'
                  }
                `}
              >
                {link.label}
              </Link>
            ))}
          </nav>

          {/* Desktop CTAs */}
          <div className="hidden md:flex items-center gap-3">
            <Link
              to="/login"
              className="px-4 py-2 text-[14px] font-medium text-[#9ca3af] hover:text-white transition-colors duration-150 cursor-pointer"
            >
              Log in
            </Link>
            <Link
              to="/register"
              className="px-4 py-2 text-[14px] font-medium bg-white text-[#0a0a0b] rounded-lg hover:bg-zinc-200 transition-colors duration-150 cursor-pointer"
            >
              Start Free Trial
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button
            type="button"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="md:hidden p-2 text-[#9ca3af] hover:text-white transition-colors cursor-pointer"
            aria-label="Toggle menu"
          >
            {isMobileMenuOpen ? (
              <X className="h-5 w-5" />
            ) : (
              <Menu className="h-5 w-5" />
            )}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <div
        className={`
          md:hidden
          absolute top-full left-0 right-0
          bg-[#0a0a0b] border-b border-white/[0.08]
          transition-all duration-200
          ${isMobileMenuOpen
            ? 'opacity-100 visible'
            : 'opacity-0 invisible'
          }
        `}
      >
        <div className="px-4 py-4 space-y-1">
          {navLinks.map((link) => (
            <Link
              key={link.href}
              to={link.href}
              className={`
                block px-4 py-3 text-[15px] font-medium rounded-lg cursor-pointer
                transition-colors duration-150
                ${isActive(link.href)
                  ? 'text-white bg-white/[0.08]'
                  : 'text-[#9ca3af] hover:text-white hover:bg-white/[0.04]'
                }
              `}
            >
              {link.label}
            </Link>
          ))}
          <div className="pt-4 mt-4 border-t border-white/[0.08] space-y-2">
            <Link
              to="/login"
              className="block px-4 py-3 text-[15px] font-medium text-[#9ca3af] hover:text-white rounded-lg transition-colors duration-150 cursor-pointer"
            >
              Log in
            </Link>
            <Link
              to="/register"
              className="block px-4 py-3 text-[15px] font-medium bg-white text-[#0a0a0b] rounded-lg text-center hover:bg-zinc-200 transition-colors duration-150 cursor-pointer"
            >
              Start Free Trial
            </Link>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
