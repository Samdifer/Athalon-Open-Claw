
import React, { useMemo, useState } from 'react';
import { GameState, Team, MONTH_NAMES } from '../types';
import { Users, ChevronLeft, ChevronRight, Clock, Shield, Zap, AlertCircle, MapPin, CalendarOff, ExternalLink, LayoutGrid, List, CreditCard } from 'lucide-react';
import { START_YEAR } from '../constants';

interface RosterPanelProps {
  gameState: GameState;
  isOpen: boolean;
  onToggle: () => void;
  width?: number;
  selectedBaseId?: string;
  onPopOut: () => void;
}

type ViewMode = 'cards' | 'compact' | 'list';

const RosterPanel: React.FC<RosterPanelProps> = ({ gameState, isOpen, onToggle, width, selectedBaseId, onPopOut }) => {
  const [viewMode, setViewMode] = useState<ViewMode>('cards');

  // === PERFORMANCE: Pre-computed lookup maps for O(1) access ===
  const lookupMaps = useMemo(() => ({
    roles: new Map(gameState.roles.map(r => [r.id, r])),
    shifts: new Map(gameState.shifts.map(s => [s.id, s])),
    bases: new Map(gameState.bases.map(b => [b.id, b])),
    teams: new Map(gameState.teams.map(t => [t.id, t])),
    // Pre-group personnel by team for O(1) team member lookup
    personnelByTeam: gameState.personnel.reduce((acc, p) => {
      const teamId = p.teamId || 'unassigned';
      if (!acc.has(teamId)) acc.set(teamId, []);
      acc.get(teamId)!.push(p);
      return acc;
    }, new Map<string, typeof gameState.personnel>()),
    // Pre-compute enabled holidays as Set for O(1) lookup
    holidayDays: new Set(gameState.holidays.filter(h => h.enabled).map(h => h.dayIndex)),
    // Map for holiday name lookup
    holidayByDay: new Map(gameState.holidays.filter(h => h.enabled).map(h => [h.dayIndex, h]))
  }), [gameState.roles, gameState.shifts, gameState.bases, gameState.teams, gameState.personnel, gameState.holidays]);

  // Helper to determine if a shift is active today
  // gameState.day is the index from start of simulation
  const date = new Date(START_YEAR, 0, 1 + gameState.day);
  const currentDayOfWeek = date.getDay(); // 0=Sun, 1=Mon...

  // PERFORMANCE: Use Set lookup instead of .some()
  const isHoliday = lookupMaps.holidayDays.has(gameState.day);
  const holidayName = lookupMaps.holidayByDay.get(gameState.day)?.name;

  // PERFORMANCE: Use Map lookup instead of .find()
  const getRole = (roleId: string) => lookupMaps.roles.get(roleId);

  // Filter Teams based on Base Selection
  const visibleTeams = useMemo(() => gameState.teams.filter(t => {
      if (!selectedBaseId || selectedBaseId === 'ALL') return true;
      return t.baseId === selectedBaseId;
  }), [gameState.teams, selectedBaseId]);

  // Check if a team is active today - PERFORMANCE: Use Map lookup
  const isTeamActive = (team: Team) => {
      if (isHoliday) return false;
      const shift = lookupMaps.shifts.get(team.shiftId);
      return shift && shift.days.includes(currentDayOfWeek);
  };

  // PERFORMANCE: Use Map lookup instead of .find()
  const currentBaseName = selectedBaseId && selectedBaseId !== 'ALL'
    ? lookupMaps.bases.get(selectedBaseId)?.name
    : null;

  // PERFORMANCE: Use pre-computed personnelByTeam instead of nested filters
  const activePersonnelCount = useMemo(() => {
    let count = 0;
    visibleTeams.forEach(team => {
      if (isTeamActive(team)) {
        count += lookupMaps.personnelByTeam.get(team.id)?.length ?? 0;
      }
    });
    return count;
  }, [visibleTeams, lookupMaps.personnelByTeam, isHoliday, currentDayOfWeek]);

  const dateLabel = `${['Sun','Mon','Tue','Wed','Thu','Fri','Sat'][currentDayOfWeek]} ${MONTH_NAMES[date.getMonth()]} ${date.getDate()}`;

  return (
    <div
        className="bg-[#0d0e10] border-l border-white/[0.08] flex flex-col h-full shrink-0 shadow-xl z-30 transition-all duration-300 ease-in-out relative overflow-hidden"
        style={{ width: isOpen ? width : 40 }}
    >

        {/* Collapsed View Content (Absolute) */}
        <div
            onClick={onToggle}
            className={`absolute inset-0 w-10 flex flex-col items-center py-4 transition-opacity duration-300 ${!isOpen ? 'opacity-100 z-10 cursor-pointer hover:bg-[#141517]' : 'opacity-0 pointer-events-none z-0'}`}
            title="Click to expand Roster"
        >
             <button className="p-1 hover:bg-white/[0.06] rounded text-[#6e79d6] mb-4">
                <ChevronLeft size={20} />
             </button>
             <div className="[writing-mode:vertical-lr] text-xs font-bold text-[#6b7280] uppercase tracking-widest whitespace-nowrap flex items-center gap-4">
                <span className="text-[#6e79d6] flex items-center gap-2"><Users size={12} /> ACTIVE ROSTER</span>
             </div>
             <div className="mt-auto flex flex-col gap-2 mb-4">
                {visibleTeams.filter(isTeamActive).map(t => (
                    <div key={t.id} className={`w-2 h-2 rounded-full ${t.color}`} title={t.name} />
                ))}
             </div>
        </div>

        {/* Expanded View Content */}
        <div className={`flex flex-col h-full w-full transition-opacity duration-300 ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
            {/* Header */}
            <div
                onClick={onToggle}
                className="p-4 border-b border-white/[0.06] flex justify-between items-center bg-[#141517] cursor-pointer hover:bg-[#1a1b1e] transition-colors group shrink-0"
            >
                <div className="overflow-hidden">
                    <h2 className="text-sm font-semibold text-[#e8e8e8] uppercase tracking-wide flex items-center gap-2 whitespace-nowrap">
                        <Users size={16} className="text-[#6e79d6]" /> Station Roster
                    </h2>
                    <div className="text-[10px] text-[#6b7280] flex items-center gap-2 mt-1 font-mono whitespace-nowrap">
                        <span>{dateLabel}</span>
                        {currentBaseName && (
                            <>
                                <span>•</span>
                                <span className="flex items-center gap-1"><MapPin size={8} /> {currentBaseName}</span>
                            </>
                        )}
                    </div>
                </div>
                <div className="flex items-center gap-1 shrink-0">
                    {/* View Mode Toggles */}
                    <div className="flex items-center bg-[#08090a] rounded-md p-0.5 mr-1 border border-white/[0.06]">
                        <button
                            onClick={(e) => { e.stopPropagation(); setViewMode('cards'); }}
                            className={`p-1 rounded transition-colors ${viewMode === 'cards' ? 'bg-[#6e79d6] text-white' : 'text-[#6b7280] hover:text-[#d1d5db]'}`}
                            title="Card View"
                        >
                            <CreditCard size={12} />
                        </button>
                        <button
                            onClick={(e) => { e.stopPropagation(); setViewMode('compact'); }}
                            className={`p-1 rounded transition-colors ${viewMode === 'compact' ? 'bg-[#6e79d6] text-white' : 'text-[#6b7280] hover:text-[#d1d5db]'}`}
                            title="Compact View"
                        >
                            <LayoutGrid size={12} />
                        </button>
                        <button
                            onClick={(e) => { e.stopPropagation(); setViewMode('list'); }}
                            className={`p-1 rounded transition-colors ${viewMode === 'list' ? 'bg-[#6e79d6] text-white' : 'text-[#6b7280] hover:text-[#d1d5db]'}`}
                            title="List View"
                        >
                            <List size={12} />
                        </button>
                    </div>
                    <button onClick={(e) => { e.stopPropagation(); onPopOut(); }} className="p-1 hover:bg-white/[0.06] rounded text-[#6b7280] hover:text-[#6e79d6]" title="Pop Out">
                        <ExternalLink size={16} />
                    </button>
                    <button onClick={(e) => { e.stopPropagation(); onToggle(); }} className="p-1 hover:bg-white/[0.06] rounded text-[#6b7280] hover:text-[#6e79d6]">
                        <ChevronRight size={16} />
                    </button>
                </div>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto custom-scrollbar p-3 space-y-4 w-full bg-[#08090a]">

                {isHoliday ? (
                    <div className="flex flex-col items-center justify-center h-64 text-[#6b7280] opacity-80">
                        <CalendarOff size={48} className="mb-2 text-[#c4626a]/50" />
                        <h3 className="font-semibold text-[#e8e8e8]">Holiday Observed</h3>
                        <p className="text-xs text-[#c4626a] font-medium">{holidayName}</p>
                        <p className="text-[10px] mt-2">No active shifts scheduled.</p>
                    </div>
                ) : (
                    <>
                        {visibleTeams.length === 0 && (
                            <div className="text-center text-[#4b5563] text-xs italic py-10">
                                No teams found for this base.
                            </div>
                        )}

                        {/* Shifts Loop */}
                        {gameState.shifts.map(shift => {
                            if (!shift.days.includes(currentDayOfWeek)) return null;
                            const shiftTeams = visibleTeams.filter(t => t.shiftId === shift.id);
                            if (shiftTeams.length === 0) return null;

                            return (
                                <div key={shift.id} className="rounded-lg border border-white/[0.08] bg-[#141517] overflow-hidden">
                                    <div className="p-2 border-b border-white/[0.06] flex justify-between items-center bg-[#0d0e10]">
                                        <div className="flex flex-col overflow-hidden">
                                            <span className="text-xs font-semibold text-[#6e79d6] truncate">{shift.name}</span>
                                            <span className="text-[10px] text-[#6b7280] font-mono flex items-center gap-1">
                                                <Clock size={10} /> {shift.startHour}:00 - {shift.startHour + shift.duration}:00
                                            </span>
                                        </div>
                                        <div className="flex gap-0.5 shrink-0">
                                            {['S','M','T','W','T','F','S'].map((d, i) => (
                                                <span key={i} className={`text-[8px] w-3 h-3 flex items-center justify-center rounded-sm ${shift.days.includes(i) ? (i === currentDayOfWeek ? 'bg-[#5e6ad2] text-white font-bold' : 'bg-white/[0.08] text-[#9ca3af]') : 'text-[#4b5563] bg-[#08090a]'}`}>
                                                    {d}
                                                </span>
                                            ))}
                                        </div>
                                    </div>

                                    <div className="p-2 space-y-3">
                                        {shiftTeams.map(team => {
                                            // PERFORMANCE: Use pre-computed personnelByTeam instead of O(n) filter
                                            const members = lookupMaps.personnelByTeam.get(team.id) ?? [];
                                            const hasLead = members.some(m => lookupMaps.roles.get(m.roleId)?.id === 'lead');

                                            return (
                                                <div key={team.id} className="relative pl-3">
                                                    <div className={`absolute left-0 top-0 bottom-0 w-1 rounded-full ${team.color} opacity-70`} />

                                                    <div className="flex justify-between items-center mb-2">
                                                        <span className="text-[11px] font-semibold text-[#e8e8e8] uppercase tracking-wide truncate">{team.name}</span>
                                                        {!hasLead && members.length > 0 && (
                                                            <span className="text-[9px] text-amber-400 flex items-center gap-1 bg-amber-500/10 px-1 rounded border border-amber-500/20 whitespace-nowrap" title="No Lead Assigned">
                                                                <AlertCircle size={8} /> UNSUPERVISED
                                                            </span>
                                                        )}
                                                    </div>

                                                    {/* Personnel Views */}
                                                    {viewMode === 'cards' && (
                                                        <div className="space-y-1">
                                                            {members.map(person => {
                                                                const role = getRole(person.roleId);
                                                                const efficiency = person.efficiencyOverride ?? role?.baseEfficiency ?? 1.0;
                                                                return (
                                                                    <div key={person.id} className="flex items-center justify-between bg-[#1a1b1e] p-1.5 rounded border border-white/[0.06] hover:border-white/[0.12] transition-colors group">
                                                                        <div className="flex items-center gap-2 overflow-hidden">
                                                                            <div className={`w-5 h-5 shrink-0 rounded-full flex items-center justify-center text-[9px] font-bold text-[#08090a] ${team.color} shadow-sm`}>
                                                                                {person.name.substring(0,1)}
                                                                            </div>
                                                                            <div className="flex flex-col truncate">
                                                                                <span className="text-[10px] font-semibold text-[#e8e8e8] leading-none truncate">{person.name}</span>
                                                                                <span className="text-[9px] text-[#6b7280] leading-none mt-0.5 truncate">{role?.name}</span>
                                                                            </div>
                                                                        </div>
                                                                        <div className="flex items-center gap-2 shrink-0">
                                                                            {role?.id === 'lead' && <div title="Team Lead"><Shield size={10} className="text-[#6e79d6]" /></div>}
                                                                            <div className="flex flex-col items-end w-8">
                                                                                <span className={`text-[9px] font-mono font-bold ${efficiency >= 1.1 ? 'text-[#3dae6c]' : efficiency < 1.0 ? 'text-amber-400' : 'text-[#9ca3af]'}`}>
                                                                                    {(efficiency * 100).toFixed(0)}%
                                                                                </span>
                                                                                <div className="w-full h-0.5 bg-white/[0.08] rounded-full mt-0.5"><div className={`h-full rounded-full ${efficiency >= 1.0 ? 'bg-[#3dae6c]' : 'bg-amber-500'}`} style={{ width: `${Math.min(efficiency * 80, 100)}%` }} /></div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                );
                                                            })}
                                                            {members.length === 0 && <div className="text-[10px] text-[#4b5563] italic pl-1">No staff assigned</div>}
                                                        </div>
                                                    )}

                                                    {viewMode === 'compact' && (
                                                        <div className="flex flex-wrap gap-1.5">
                                                            {members.map(person => {
                                                                const role = getRole(person.roleId);
                                                                const isLead = role?.id === 'lead';
                                                                return (
                                                                    <div
                                                                        key={person.id}
                                                                        className={`relative w-8 h-8 rounded-md flex items-center justify-center text-[11px] font-bold text-[#08090a] ${team.color} shadow-sm hover:scale-110 transition-transform cursor-default ${isLead ? 'ring-2 ring-[#6e79d6] ring-offset-1 ring-offset-[#141517]' : ''}`}
                                                                        title={`${person.name} - ${role?.name || 'Unknown'}`}
                                                                    >
                                                                        {person.name.substring(0, 2).toUpperCase()}
                                                                        {isLead && (
                                                                            <div className="absolute -top-1 -right-1 w-3 h-3 bg-[#6e79d6] rounded-full flex items-center justify-center">
                                                                                <Shield size={7} className="text-white" />
                                                                            </div>
                                                                        )}
                                                                    </div>
                                                                );
                                                            })}
                                                            {members.length === 0 && <div className="text-[10px] text-[#4b5563] italic">No staff</div>}
                                                        </div>
                                                    )}

                                                    {viewMode === 'list' && (
                                                        <div className="space-y-0.5">
                                                            {members.map(person => {
                                                                const role = getRole(person.roleId);
                                                                const efficiency = person.efficiencyOverride ?? role?.baseEfficiency ?? 1.0;
                                                                const isLead = role?.id === 'lead';
                                                                return (
                                                                    <div key={person.id} className="flex items-center gap-2 py-0.5 px-1 rounded hover:bg-white/[0.04] transition-colors text-[10px]">
                                                                        <div className={`w-1.5 h-1.5 rounded-full ${team.color} shrink-0`} />
                                                                        <span className="text-[#e8e8e8] font-medium truncate flex-1">{person.name}</span>
                                                                        {isLead && <Shield size={8} className="text-[#6e79d6] shrink-0" />}
                                                                        <span className="text-[#6b7280] truncate">{role?.name}</span>
                                                                        <span className={`font-mono shrink-0 ${efficiency >= 1.1 ? 'text-[#3dae6c]' : efficiency < 1.0 ? 'text-amber-400' : 'text-[#6b7280]'}`}>
                                                                            {(efficiency * 100).toFixed(0)}%
                                                                        </span>
                                                                    </div>
                                                                );
                                                            })}
                                                            {members.length === 0 && <div className="text-[10px] text-[#4b5563] italic pl-1">No staff assigned</div>}
                                                        </div>
                                                    )}
                                                </div>
                                            );
                                        })}
                                    </div>
                                </div>
                            );
                        })}
                        {!isHoliday && gameState.shifts.every(s => !s.days.includes(currentDayOfWeek) || visibleTeams.filter(t => t.shiftId === s.id).length === 0) && visibleTeams.length > 0 && (
                             <div className="flex flex-col items-center justify-center h-40 text-[#6b7280]">
                                <Clock size={32} className="mb-2 opacity-50" />
                                <p className="text-xs">No active shifts for this day.</p>
                             </div>
                        )}
                    </>
                )}
            </div>

            {/* Footer Info */}
            <div className="p-3 border-t border-white/[0.06] bg-[#0d0e10] text-[10px] text-[#6b7280] flex justify-between shrink-0 whitespace-nowrap">
                <span>Filtered Staff: {activePersonnelCount}</span>
                <span className="flex items-center gap-1"><Zap size={10} className="text-amber-400"/> Shop Eff: {(gameState.efficiency * 100).toFixed(0)}%</span>
            </div>
        </div>
    </div>
  );
};

// PERFORMANCE: Wrap with React.memo to prevent unnecessary re-renders
export default React.memo(RosterPanel);
