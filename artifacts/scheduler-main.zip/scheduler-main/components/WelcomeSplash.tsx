
import React, { useState } from 'react';
import { Plane, Rocket, Zap, Database, Clock, BookOpen, AlertTriangle } from 'lucide-react';
import { TourType } from './OnboardingTour';

interface WelcomeSplashProps {
  onStartTour: (tourType: TourType) => void;
  onSkip: () => void;
  onLoadDemo?: () => void;
  userName?: string;
  hasExistingData?: boolean;
}

const WelcomeSplash: React.FC<WelcomeSplashProps> = ({ onStartTour, onSkip, onLoadDemo, userName, hasExistingData }) => {
  const firstName = userName?.split(' ')[0];
  const [showDemoConfirm, setShowDemoConfirm] = useState(false);

  const handleDemoClick = () => {
    if (hasExistingData) {
      setShowDemoConfirm(true);
    } else {
      onLoadDemo?.();
    }
  };

  const handleConfirmDemo = () => {
    onLoadDemo?.();
    setShowDemoConfirm(false);
  };

  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-[#08090a]/95">
      <div className="max-w-lg w-full bg-[#0d0e10] border border-white/[0.08] rounded-2xl p-10 relative overflow-hidden text-center shadow-2xl">

        {/* Decorative Background FX - Simplified for performance */}
        <div className="absolute top-0 left-0 w-full h-40 bg-gradient-to-b from-white/[0.03] to-transparent pointer-events-none" />

        <div className="relative z-10 flex flex-col items-center">
            <div className="w-24 h-24 bg-[#141517] rounded-full flex items-center justify-center mb-8 border border-white/[0.08] relative group">
                <div className="absolute inset-0 rounded-full border border-white/10"></div>
                <Plane size={48} className="text-white transform -rotate-45" />
            </div>

            <h1 className="text-3xl font-bold text-white tracking-wide mb-2 leading-tight">
                {firstName ? `Welcome, ${firstName}!` : 'Welcome to AeroManager!'}
            </h1>
            <p className="text-zinc-400 text-sm font-medium mb-6">Your maintenance scheduling system is ready.</p>

            <div className="text-[#9ca3af] text-base mb-10 leading-relaxed space-y-3">
                <p>
                    AeroManager helps you plan aircraft maintenance, track your team's capacity, and forecast revenue.
                </p>
                <p className="text-[#e8e8e8] font-medium">
                    How would you like to get started?
                </p>
            </div>

            <div className="flex flex-col gap-3 w-full max-w-xs">
                {/* Tour Options */}
                <div className="flex gap-2">
                    <button
                        onClick={() => onStartTour('quick')}
                        className="flex-1 py-4 bg-white hover:bg-zinc-100 text-[#09090b] font-semibold rounded-xl transition-colors flex flex-col items-center justify-center gap-1 border border-white/30"
                    >
                        <div className="flex items-center gap-2">
                            <Rocket size={18} />
                            <span className="uppercase tracking-wide text-xs">Quick Tour</span>
                        </div>
                        <span className="text-[10px] text-[#09090b]/60 flex items-center gap-1">
                            <Clock size={10} /> 2 min • 8 steps
                        </span>
                    </button>
                    <button
                        onClick={() => onStartTour('full')}
                        className="flex-1 py-4 bg-[#141517] hover:bg-[#1a1b1e] text-[#e8e8e8] font-semibold rounded-xl transition-colors flex flex-col items-center justify-center gap-1 border border-white/[0.08] hover:border-white/20"
                    >
                        <div className="flex items-center gap-2">
                            <BookOpen size={18} />
                            <span className="uppercase tracking-wide text-xs">Full Tour</span>
                        </div>
                        <span className="text-[10px] text-slate-500 flex items-center gap-1">
                            <Clock size={10} /> 5 min • 35 steps
                        </span>
                    </button>
                </div>

                {onLoadDemo && !showDemoConfirm && (
                    <button
                        onClick={handleDemoClick}
                        className="w-full py-3 bg-[#141517] hover:bg-[#1a1b1e] text-[#e8e8e8] font-semibold rounded-xl transition-colors border border-white/[0.08] hover:border-white/[0.12] flex items-center justify-center gap-2"
                    >
                        <Database size={16} />
                        <span className="uppercase tracking-wide text-xs">Load Demo Data</span>
                    </button>
                )}

                {showDemoConfirm && (
                    <div className="w-full p-4 bg-amber-950/40 border border-amber-500/30 rounded-xl space-y-3">
                        <div className="flex items-start gap-2 text-amber-400">
                            <AlertTriangle size={18} className="flex-shrink-0 mt-0.5" />
                            <p className="text-xs text-left leading-relaxed">
                                Loading demo data will <strong>overwrite your existing jobs and schedule</strong>. This action cannot be undone.
                            </p>
                        </div>
                        <div className="flex gap-2">
                            <button
                                onClick={() => setShowDemoConfirm(false)}
                                className="flex-1 py-2 bg-[#141517] hover:bg-[#1a1b1e] text-[#e8e8e8] font-semibold rounded-lg transition-colors border border-white/[0.08] hover:border-white/[0.12] text-xs"
                            >
                                Cancel
                            </button>
                            <button
                                onClick={handleConfirmDemo}
                                className="flex-1 py-2 bg-amber-600 hover:bg-amber-500 text-white font-semibold rounded-lg transition-colors text-xs"
                            >
                                Yes, Overwrite My Data
                            </button>
                        </div>
                    </div>
                )}

                <button
                    onClick={onSkip}
                    className="w-full py-3 bg-transparent hover:bg-[#141517] text-[#6b7280] hover:text-white font-semibold rounded-xl transition-colors border border-white/[0.08] hover:border-white/[0.12] flex items-center justify-center gap-2"
                >
                    <Zap size={16} />
                    <span className="uppercase tracking-wide text-xs">Kick the Tires, Light the Fires</span>
                </button>
            </div>
        </div>
      </div>
    </div>
  );
};

export default WelcomeSplash;
