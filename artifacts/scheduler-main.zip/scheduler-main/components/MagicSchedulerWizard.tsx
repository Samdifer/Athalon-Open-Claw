
import React, { useState, useEffect } from 'react';
import { X, Sparkles, ArrowRight, CheckCircle, Calendar, AlertCircle, MoveUp, MoveDown, GripVertical } from 'lucide-react';
import { Job, ScheduledJob, MONTH_NAMES } from '../types';
import { START_YEAR } from '../constants';

interface MagicSchedulerWizardProps {
  step: 'intro' | 'selecting' | 'prioritizing' | 'results';
  selectedJobs: (Job | ScheduledJob)[];
  results: { jobId: string; oldEnd: number; newEnd: number; daysAdded: number }[];
  onClose: () => void;
  onStartSelection: () => void;
  onConfirmSelection: () => void;
  onReorderSelectedJobs: (newOrderIds: string[]) => void;
  onRunOptimization: () => void;
}

const getDateStr = (dayIndex: number) => {
    const date = new Date(START_YEAR, 0, 1 + dayIndex);
    return `${MONTH_NAMES[date.getMonth()]} ${date.getDate()}`;
};

const MagicSchedulerWizard: React.FC<MagicSchedulerWizardProps> = ({
  step, selectedJobs, results, onClose, onStartSelection, onConfirmSelection, onReorderSelectedJobs, onRunOptimization
}) => {
  
  // Handlers for reordering
  const moveJob = (index: number, direction: 'up' | 'down') => {
      const newIndex = direction === 'up' ? index - 1 : index + 1;
      if (newIndex < 0 || newIndex >= selectedJobs.length) return;
      
      const newJobs = [...selectedJobs];
      const temp = newJobs[index];
      newJobs[index] = newJobs[newIndex];
      newJobs[newIndex] = temp;
      
      onReorderSelectedJobs(newJobs.map(j => j.id));
  };

  if (step === 'selecting') {
      return (
          <div className="fixed bottom-8 left-1/2 -translate-x-1/2 z-[200] bg-[#0d0e10] border border-[#7c6ebd]/50 rounded-full px-8 py-4 flex items-center gap-6 animate-in slide-in-from-bottom-10">
              <div className="flex flex-col">
                  <span className="text-white font-semibold uppercase tracking-wide flex items-center gap-2">
                      <Sparkles size={14} className="text-[#7c6ebd]" /> Magic Select Mode
                  </span>
                  <span className="text-xs text-[#9ca3af]">Click projects on board to include ({selectedJobs.length} selected)</span>
              </div>
              <div className="h-8 w-px bg-white/[0.08]" />
              <button
                  onClick={onConfirmSelection}
                  disabled={selectedJobs.length === 0}
                  className="bg-[#7c6ebd] hover:bg-[#8f82c9] disabled:opacity-50 disabled:cursor-not-allowed text-white font-semibold py-2 px-6 rounded-full transition-all flex items-center gap-2"
              >
                  Confirm Selections <ArrowRight size={16} />
              </button>
              <button onClick={onClose} className="p-2 hover:bg-[#141517] rounded-full text-[#6b7280] hover:text-white transition-colors">
                  <X size={20} />
              </button>
          </div>
      );
  }

  return (
    <div className="fixed inset-0 bg-[#08090a]/80 backdrop-blur-sm z-[200] flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="bg-[#0d0e10] w-full max-w-2xl border border-white/[0.08] rounded-2xl flex flex-col overflow-hidden relative max-h-[80vh]">

        {/* Header */}
        <div className="bg-[#08090a] p-6 border-b border-white/[0.06] flex justify-between items-center shrink-0">
            <div className="flex items-center gap-3">
                <div className="bg-[#7c6ebd]/10 border border-[#7c6ebd]/30 p-2 rounded-lg">
                    <Sparkles className="text-[#7c6ebd]" size={24} />
                </div>
                <div>
                    <h2 className="text-xl font-semibold text-[#e8e8e8] tracking-wide">Magic Scheduler</h2>
                    <p className="text-xs text-[#6b7280]">AI-Assisted Capacity Leveling</p>
                </div>
            </div>
            <button onClick={onClose} className="p-2 hover:bg-[#141517] rounded-full text-[#6b7280] hover:text-white">
                <X size={24} />
            </button>
        </div>

        {/* Content */}
        <div className="p-5 overflow-y-auto custom-scrollbar flex-1">
            
            {step === 'intro' && (
                <div className="text-center">
                    <div className="w-12 h-12 bg-[#7c6ebd]/10 rounded-full flex items-center justify-center mx-auto mb-3 border border-[#7c6ebd]/20">
                        <Calendar size={24} className="text-[#7c6ebd]" />
                    </div>
                    <h3 className="text-lg font-semibold text-white mb-2">Batch Optimization</h3>
                    <p className="text-sm text-[#9ca3af] mb-4 leading-relaxed max-w-md mx-auto">
                        Automatically schedule multiple projects based on priority, extending deadlines as needed to prevent workforce overload.
                    </p>

                    <div className="bg-[#141517]/50 rounded-lg p-3 border border-white/[0.08] text-left max-w-md mx-auto mb-4">
                        <h4 className="text-xs font-semibold text-[#e8e8e8] mb-1.5 flex items-center gap-2"><AlertCircle size={12} className="text-[#7c6ebd]" /> How it works:</h4>
                        <ul className="text-xs text-[#9ca3af] space-y-1 list-disc pl-4">
                            <li>Select projects from the board and rank by priority.</li>
                            <li>Higher priority jobs get first access to capacity; lower ones fill remaining gaps.</li>
                        </ul>
                    </div>

                    <button
                        onClick={onStartSelection}
                        className="bg-[#7c6ebd] hover:bg-[#8f82c9] text-white font-semibold py-2 px-6 rounded-lg transition-all flex items-center gap-2 mx-auto hover:scale-105 group text-sm"
                    >
                        Select Projects on Board <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform"/>
                    </button>
                </div>
            )}

            {step === 'prioritizing' && (
                <div>
                    <h3 className="text-lg font-semibold text-[#e8e8e8] mb-2">Set Execution Priority</h3>
                    <p className="text-sm text-[#6b7280] mb-6">
                        Reorder items to change priority. Top items get first access to labor capacity.
                        Lower items fill the gaps.
                    </p>

                    <div className="space-y-2">
                        {selectedJobs.map((job, index) => (
                            <div key={job.id} className="flex items-center justify-between bg-[#141517]/50 border border-white/[0.08] rounded-lg p-3 group transition-colors hover:border-[#7c6ebd]/30">
                                <div className="flex items-center gap-4">
                                    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-[#0d0e10] border border-white/[0.08] text-[#9ca3af] font-semibold font-mono text-sm">
                                        {index + 1}
                                    </div>
                                    <div className={`w-1 h-10 rounded-full ${job.color}`} />
                                    <div>
                                        <div className="font-semibold text-[#e8e8e8]">{job.customer}</div>
                                        <div className="text-xs text-[#6b7280]">{job.description}</div>
                                    </div>
                                </div>

                                <div className="flex items-center gap-1">
                                    <button
                                        onClick={() => moveJob(index, 'up')}
                                        disabled={index === 0}
                                        className="p-1.5 rounded hover:bg-[#1a1b1e] text-[#9ca3af] hover:text-white disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
                                        title="Increase Priority"
                                    >
                                        <MoveUp size={16} />
                                    </button>
                                    <button
                                        onClick={() => moveJob(index, 'down')}
                                        disabled={index === selectedJobs.length - 1}
                                        className="p-1.5 rounded hover:bg-[#1a1b1e] text-[#9ca3af] hover:text-white disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
                                        title="Decrease Priority"
                                    >
                                        <MoveDown size={16} />
                                    </button>
                                </div>
                            </div>
                        ))}
                        {selectedJobs.length === 0 && (
                            <div className="text-center text-[#6b7280] py-8 italic border-2 border-dashed border-white/[0.08] rounded-lg">
                                No projects selected. Go back and select some.
                            </div>
                        )}
                    </div>

                    <div className="mt-8 flex justify-end">
                        <button
                            onClick={onRunOptimization}
                            className="bg-[#3dae6c] hover:bg-[#4dc080] text-white font-semibold py-3 px-8 rounded-lg transition-all flex items-center gap-2 hover:scale-105"
                        >
                            <Sparkles size={18} /> Optimize Schedule
                        </button>
                    </div>
                </div>
            )}

            {step === 'results' && (
                <div className="text-center">
                    <div className="w-16 h-16 bg-[#3dae6c]/10 rounded-full flex items-center justify-center mx-auto mb-4 border border-[#3dae6c]/20">
                        <CheckCircle size={32} className="text-[#3dae6c]" />
                    </div>
                    <h3 className="text-2xl font-semibold text-white mb-6">Optimization Complete</h3>

                    <div className="bg-[#08090a] rounded-xl border border-white/[0.08] overflow-hidden mb-8">
                        <table className="w-full text-left text-sm">
                            <thead className="bg-[#0d0e10] text-[#6b7280] font-semibold uppercase text-xs">
                                <tr>
                                    <th className="p-4">Project</th>
                                    <th className="p-4">Old Finish</th>
                                    <th className="p-4">New Finish</th>
                                    <th className="p-4 text-right">Impact</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-white/[0.06] text-[#e8e8e8]">
                                {results.map((res) => {
                                    const job = selectedJobs.find(j => j.id === res.jobId);
                                    return (
                                        <tr key={res.jobId}>
                                            <td className="p-4 font-semibold text-white">{job?.customer}</td>
                                            <td className="p-4 text-[#6b7280]">{getDateStr(res.oldEnd)}</td>
                                            <td className="p-4 font-mono text-[#7c6ebd]">{getDateStr(res.newEnd)}</td>
                                            <td className="p-4 text-right">
                                                {res.daysAdded > 0 ? (
                                                    <span className="text-[#c4626a] font-semibold">+{res.daysAdded} Days</span>
                                                ) : (
                                                    <span className="text-[#3dae6c] font-semibold">No Change</span>
                                                )}
                                            </td>
                                        </tr>
                                    );
                                })}
                            </tbody>
                        </table>
                    </div>

                    <button
                        onClick={onClose}
                        className="bg-[#141517] hover:bg-[#1a1b1e] text-white font-semibold py-3 px-10 rounded-lg border border-white/[0.08] transition-colors"
                    >
                        Close & Review Board
                    </button>
                </div>
            )}

        </div>
      </div>
    </div>
  );
};

export default React.memo(MagicSchedulerWizard);
