
import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { User, SystemRole } from '../../types';
import { X, Shield, Search, UserPlus, MoreVertical, Mail, Clock, CheckCircle, XCircle, AlertTriangle, Trash2, Key, Edit2, Save, Hammer } from 'lucide-react';

interface UserManagementProps {
  onClose: () => void;
}

const UserManagement: React.FC<UserManagementProps> = ({ onClose }) => {
  const { allUsers, inviteUser, updateUser, deleteUser, user: currentUser } = useAuth();
  const [filter, setFilter] = useState('');
  
  // Invite Form State
  const [showInvite, setShowInvite] = useState(false);
  const [inviteEmail, setInviteEmail] = useState('');
  const [inviteName, setInviteName] = useState('');
  const [inviteRole, setInviteRole] = useState<SystemRole>('Technician');
  const [inviteError, setInviteError] = useState('');
  const [inviteSuccess, setInviteSuccess] = useState<string | null>(null);

  // Editing State
  const [editingId, setEditingId] = useState<string | null>(null);

  const filteredUsers = allUsers.filter(u => 
    u.name.toLowerCase().includes(filter.toLowerCase()) || 
    u.email.toLowerCase().includes(filter.toLowerCase())
  );

  const handleInviteSubmit = async (e: React.FormEvent) => {
      e.preventDefault();
      setInviteError('');
      setInviteSuccess(null);
      try {
          await inviteUser(inviteEmail, inviteName, inviteRole);
          setShowInvite(false);
          setInviteEmail('');
          setInviteName('');
          setInviteSuccess(`User "${inviteName}" invited successfully. Temporary password: password123`);
          // Auto-dismiss after 6 seconds
          setTimeout(() => setInviteSuccess(null), 6000);
      } catch (err: any) {
          setInviteError(err.message || "Failed to invite user");
      }
  };

  const handleDelete = async (id: string) => {
      if (window.confirm('Are you sure you want to delete this user? This cannot be undone.')) {
          await deleteUser(id);
      }
  };

  const toggleStatus = async (user: User) => {
      const newStatus = user.status === 'Active' ? 'Inactive' : 'Active';
      await updateUser(user.id, { status: newStatus });
  };

  return (
    <div className="fixed inset-0 bg-[#08090a]/80 backdrop-blur-sm z-[200] flex items-center justify-center p-8 animate-in fade-in duration-200">
      <div className="bg-[#0d0e10] w-full max-w-6xl h-[85vh] rounded-xl border border-white/[0.08] flex flex-col overflow-hidden relative">

        {/* Invite Modal Overlay */}
        {showInvite && (
            <div className="absolute inset-0 bg-[#08090a]/90 z-50 flex items-center justify-center p-4">
                <div className="bg-[#0d0e10] border border-white/[0.08] rounded-xl p-6 w-full max-w-md relative overflow-hidden">

                    {/* Construction Banner */}
                    <div className="mb-6 bg-amber-500/10 border border-amber-500/20 rounded-lg p-3 flex items-start gap-3">
                        <div className="p-2 bg-amber-500/10 rounded-full mt-0.5">
                            <Hammer size={16} className="text-amber-500" />
                        </div>
                        <div>
                            <h4 className="text-sm font-semibold text-amber-400 uppercase tracking-wide">Under Construction</h4>
                            <p className="text-xs text-amber-200/70 mt-1">This feature is not fully functional yet. Invitations are simulated.</p>
                        </div>
                    </div>

                    <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                        <UserPlus size={20} className="text-zinc-300"/> Invite New User
                    </h3>
                    <form onSubmit={handleInviteSubmit} className="space-y-4 opacity-80">
                        {inviteError && <div className="text-[#c4626a] text-xs bg-[#c4626a]/10 p-2 rounded border border-[#c4626a]/20">{inviteError}</div>}
                        <div>
                            <label className="block text-xs font-semibold text-[#6b7280] uppercase mb-1">Full Name</label>
                            <input
                                type="text"
                                required
                                value={inviteName}
                                onChange={e => setInviteName(e.target.value)}
                                className="w-full bg-[#08090a] border border-white/[0.08] rounded-lg py-2.5 px-3 text-sm text-[#e8e8e8] focus:border-white/40 outline-none transition-all"
                                placeholder="Jane Doe"
                            />
                        </div>
                        <div>
                            <label className="block text-xs font-semibold text-[#6b7280] uppercase mb-1">Email Address</label>
                            <input
                                type="email"
                                required
                                value={inviteEmail}
                                onChange={e => setInviteEmail(e.target.value)}
                                className="w-full bg-[#08090a] border border-white/[0.08] rounded-lg py-2.5 px-3 text-sm text-[#e8e8e8] focus:border-white/40 outline-none transition-all"
                                placeholder="jane@company.com"
                            />
                        </div>
                        <div>
                            <label className="block text-xs font-semibold text-[#6b7280] uppercase mb-1">System Role</label>
                            <select
                                value={inviteRole}
                                onChange={e => setInviteRole(e.target.value as SystemRole)}
                                className="w-full bg-[#08090a] border border-white/[0.08] rounded-lg py-2.5 px-3 text-sm text-[#e8e8e8] focus:border-white/40 outline-none transition-all"
                            >
                                <option value="Technician">Technician</option>
                                <option value="Manager">Manager</option>
                                <option value="Admin">Admin</option>
                            </select>
                        </div>
                        <div className="flex gap-3 mt-6">
                            <button type="button" onClick={() => setShowInvite(false)} className="flex-1 py-2 text-[#9ca3af] hover:bg-[#141517] rounded-lg font-semibold text-xs transition-colors border border-white/[0.08]">Cancel</button>
                            <button type="submit" className="flex-1 py-2 bg-white hover:bg-zinc-100 text-[#09090b] rounded-lg font-semibold text-xs transition-colors">Send Invite</button>
                        </div>
                    </form>
                </div>
            </div>
        )}

        {/* Header */}
        <div className="bg-[#0d0e10] p-6 border-b border-white/[0.06] flex justify-between items-center shrink-0">
          <div className="flex items-center gap-3">
            <div className="bg-[#141517] p-2 rounded-lg border border-white/[0.08]">
                <Shield className="text-zinc-300" size={24} />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-[#e8e8e8] tracking-wide">User Administration</h2>
              <p className="text-xs text-[#6b7280]">Manage system access, roles, and security.</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-[#141517] rounded-lg text-[#6b7280] hover:text-[#d1d5db] transition-colors">
            <X size={24} />
          </button>
        </div>

        {/* Success Message Toast */}
        {inviteSuccess && (
            <div className="mx-6 mt-4 px-4 py-3 bg-emerald-500/10 border border-emerald-500/20 rounded-lg flex items-center gap-3 animate-in slide-in-from-top-2 duration-200 shrink-0">
                <CheckCircle size={16} className="text-emerald-400 shrink-0" />
                <span className="text-sm text-emerald-300">{inviteSuccess}</span>
                <button onClick={() => setInviteSuccess(null)} className="ml-auto text-emerald-400 hover:text-emerald-300">
                    <X size={14} />
                </button>
            </div>
        )}

        {/* Toolbar */}
        <div className="p-4 border-b border-white/[0.06] bg-[#0d0e10]/50 flex justify-between items-center">
            <div className="relative w-64">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-[#6b7280]" size={14} />
                <input
                    type="text"
                    placeholder="Search users..."
                    value={filter}
                    onChange={(e) => setFilter(e.target.value)}
                    className="w-full bg-[#141517] border border-white/[0.08] rounded-lg pl-9 pr-3 py-2 text-sm text-[#e8e8e8] focus:border-white/40 outline-none"
                />
            </div>
            <button
                onClick={() => setShowInvite(true)}
                className="bg-[#141517] hover:bg-[#1a1b1e] border border-dashed border-amber-500/50 text-[#e8e8e8] px-4 py-2 rounded-lg text-sm font-semibold flex items-center gap-2 transition-colors"
                title="Feature Under Construction"
            >
                <UserPlus size={16} /> Invite User
                <span className="ml-1 text-[10px] text-amber-500 uppercase tracking-wide bg-amber-500/10 px-1.5 py-0.5 rounded border border-amber-500/20 flex items-center gap-1">
                    <Hammer size={10} /> Construction
                </span>
            </button>
        </div>

        {/* User Table */}
        <div className="flex-1 overflow-auto bg-[#0d0e10] custom-scrollbar">
            <table className="w-full text-left border-collapse">
                <thead className="bg-[#08090a] sticky top-0 z-10">
                    <tr>
                        <th className="p-4 text-xs font-semibold text-[#6b7280] uppercase tracking-wider border-b border-white/[0.06]">User</th>
                        <th className="p-4 text-xs font-semibold text-[#6b7280] uppercase tracking-wider border-b border-white/[0.06]">Role</th>
                        <th className="p-4 text-xs font-semibold text-[#6b7280] uppercase tracking-wider border-b border-white/[0.06]">Status</th>
                        <th className="p-4 text-xs font-semibold text-[#6b7280] uppercase tracking-wider border-b border-white/[0.06]">Last Active</th>
                        <th className="p-4 text-xs font-semibold text-[#6b7280] uppercase tracking-wider border-b border-white/[0.06] text-right">Actions</th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-white/[0.06]">
                    {filteredUsers.map(user => (
                        <tr key={user.id} className="hover:bg-[#141517]/30 transition-colors group">
                            <td className="p-4">
                                <div className="flex items-center gap-3">
                                    <div className="w-9 h-9 rounded-full bg-[#141517] flex items-center justify-center text-xs font-semibold text-[#e8e8e8] border border-white/[0.08]">
                                        {user.avatar}
                                    </div>
                                    <div>
                                        {editingId === user.id ? (
                                            <input
                                                value={user.name}
                                                onChange={e => updateUser(user.id, { name: e.target.value })}
                                                className="bg-[#141517] border border-white/[0.08] rounded px-1 text-sm text-white focus:border-white/40 outline-none mb-1 block w-32"
                                            />
                                        ) : (
                                            <div className="font-semibold text-[#e8e8e8] text-sm">{user.name}</div>
                                        )}
                                        <div className="text-xs text-[#6b7280] flex items-center gap-1">
                                            <Mail size={10} /> {user.email}
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td className="p-4">
                                {editingId === user.id ? (
                                    <select
                                        value={user.role}
                                        onChange={e => updateUser(user.id, { role: e.target.value as SystemRole })}
                                        className="bg-[#141517] border border-white/[0.08] rounded px-1 text-xs text-white focus:border-white/40 outline-none"
                                    >
                                        <option>Admin</option>
                                        <option>Manager</option>
                                        <option>Technician</option>
                                    </select>
                                ) : (
                                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${
                                        user.role === 'Admin' ? 'bg-purple-500/10 text-purple-400 border-purple-500/20' :
                                        user.role === 'Manager' ? 'bg-[#5e6ad2]/10 text-[#6e79d6] border-[#5e6ad2]/20' :
                                        'bg-[#141517] text-[#9ca3af] border-white/[0.08]'
                                    }`}>
                                        {user.role}
                                    </span>
                                )}
                            </td>
                            <td className="p-4">
                                <div className="flex items-center gap-1.5">
                                    {user.status === 'Active' && <CheckCircle size={14} className="text-[#3dae6c]" />}
                                    {user.status === 'Invited' && <Clock size={14} className="text-amber-500" />}
                                    {user.status === 'Inactive' && <XCircle size={14} className="text-[#6b7280]" />}
                                    <span className={`text-xs font-medium ${
                                        user.status === 'Active' ? 'text-[#3dae6c]' :
                                        user.status === 'Invited' ? 'text-amber-400' :
                                        'text-[#6b7280]'
                                    }`}>
                                        {user.status}
                                    </span>
                                </div>
                            </td>
                            <td className="p-4">
                                <span className="text-xs text-[#9ca3af] font-mono">
                                    {user.lastLogin ? new Date(user.lastLogin).toLocaleDateString() + ' ' + new Date(user.lastLogin).toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'}) : 'Never'}
                                </span>
                            </td>
                            <td className="p-4 text-right">
                                <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                    {editingId === user.id ? (
                                        <button onClick={() => setEditingId(null)} className="p-1.5 text-[#3dae6c] hover:bg-[#3dae6c]/10 rounded" title="Save">
                                            <Save size={16} />
                                        </button>
                                    ) : (
                                        <button onClick={() => setEditingId(user.id)} className="p-1.5 text-[#9ca3af] hover:text-white hover:bg-[#1a1b1e] rounded" title="Edit">
                                            <Edit2 size={16} />
                                        </button>
                                    )}

                                    {user.id !== currentUser?.id && (
                                        <>
                                            <button onClick={() => toggleStatus(user)} className="p-1.5 text-[#9ca3af] hover:text-amber-400 hover:bg-amber-500/10 rounded" title={user.status === 'Active' ? "Deactivate" : "Activate"}>
                                                <Key size={16} />
                                            </button>
                                            <button onClick={() => handleDelete(user.id)} className="p-1.5 text-[#9ca3af] hover:text-[#c4626a] hover:bg-[#c4626a]/10 rounded" title="Delete User">
                                                <Trash2 size={16} />
                                            </button>
                                        </>
                                    )}
                                </div>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-white/[0.06] bg-[#08090a] text-xs text-[#6b7280] flex justify-between items-center">
            <div className="flex items-center gap-2">
                <AlertTriangle size={12} className="text-amber-500" />
                <span>MFA Enforcement: <span className="text-[#e8e8e8] font-semibold">Optional</span></span>
            </div>
            <div>
                <span>Total Users: {allUsers.length}</span>
            </div>
        </div>

      </div>
    </div>
  );
};

export default UserManagement;
