
import React, { useState, useEffect, useRef } from 'react';
import { useVirtualizer } from '@tanstack/react-virtual';
import { Job, MONTH_NAMES } from '../types';
import { AlertCircle, Plane, Clock, ChevronsRight, ChevronsLeft, ExternalLink, Plus, LayoutGrid, List, Grid3X3, Archive } from 'lucide-react';
import { DOLLAR_SIGN } from '../App';
import { START_YEAR } from '../constants';
import { Tooltip, EmptyState } from './ui';

interface BacklogPanelProps {
  backlog: Job[];
  onDragStart: (e: React.DragEvent, job: Job) => void;
  onDragEnd: () => void;
  onJobClick: (job: Job) => void;
  isOpen: boolean;
  onToggle: () => void;
  isPoppedOut: boolean;
  onPopOut: () => void;
  onNewQuote: () => void;
  onOpenGraveyard?: () => void;
  width?: number;
  highlightedJobId?: string | null;
}

type ViewMode = 'list' | 'large' | 'small';

const BacklogPanel: React.FC<BacklogPanelProps> = ({
  backlog, onDragStart, onDragEnd, onJobClick, isOpen, onToggle, isPoppedOut, onPopOut, onNewQuote, onOpenGraveyard, width, highlightedJobId
}) => {
  const [viewMode, setViewMode] = useState<ViewMode>('list');

  // Ref to scroll to highlighted item
  const highlightRef = useRef<HTMLDivElement>(null);

  // === VIRTUALIZATION: Refs for virtual scrolling ===
  const sidebarScrollRef = useRef<HTMLDivElement>(null);
  const popoutScrollRef = useRef<HTMLDivElement>(null);

  // Estimate item heights for virtualizer (varies by view mode)
  const getItemHeight = (mode: ViewMode) => {
    switch(mode) {
      case 'list': return 76; // renderSidebarCard / renderListItem
      case 'large': return 96; // renderLargeCard
      case 'small': return 80; // renderSmallCard / renderTileCard
      default: return 80;
    }
  };

  // Sidebar virtualizer (for inline panel)
  const sidebarVirtualizer = useVirtualizer({
    count: backlog.length,
    getScrollElement: () => sidebarScrollRef.current,
    estimateSize: () => getItemHeight(viewMode === 'small' ? 'small' : 'list'),
    overscan: 5,
  });

  // Popout virtualizer (for popped out view in list mode)
  const popoutVirtualizer = useVirtualizer({
    count: backlog.length,
    getScrollElement: () => popoutScrollRef.current,
    estimateSize: () => getItemHeight(viewMode),
    overscan: 5,
  });

  useEffect(() => {
      if (highlightedJobId && highlightRef.current) {
          highlightRef.current.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
  }, [highlightedJobId]);

  // Helper to format arrival day index to date string
  const formatArrivalDate = (dayIndex: number) => {
      const date = new Date(START_YEAR, 0, 1 + dayIndex);
      return `${MONTH_NAMES[date.getMonth()]} ${date.getDate()}`;
  };

  const renderSidebarCard = (job: Job) => {
    const isHighlighted = job.id === highlightedJobId;

    return (
    <div
      key={job.id}
      ref={isHighlighted ? highlightRef : null}
      draggable={true}
      onDragStart={(e) => onDragStart(e, job)}
      onDragEnd={onDragEnd}
      onClick={() => onJobClick(job)}
      className={`
        relative group select-none flex-shrink-0 w-full bg-[#141517] rounded-md border p-2
        cursor-grab active:cursor-grabbing transition-all flex flex-col gap-1 mb-0
        ${isHighlighted
            ? 'border-white/40 ring-2 ring-white/20 bg-white/10'
            : 'border-white/[0.08] hover:border-white/[0.15] hover:bg-[#1a1b1e]'}
      `}
    >
        <div className={`absolute top-0 left-0 bottom-0 w-1 rounded-l-md ${job.color} opacity-80`}></div>
        <div className="pl-2 flex flex-col gap-0.5">
            <div className="flex justify-between items-start">
                <span className={`font-medium text-xs truncate ${isHighlighted ? 'text-white' : 'text-[#e8e8e8]'}`}>{job.customer}</span>
                {job.isAOG && (
                    <Tooltip content="AOG (Aircraft On Ground) - Urgent priority. Aircraft cannot fly until repairs complete." position="left">
                        <AlertCircle size={10} className="text-[#c4626a] animate-pulse shrink-0" />
                    </Tooltip>
                )}
            </div>
            <div className="text-[9px] text-[#6b7280] font-mono truncate">{job.aircraftType}</div>

            <div className="text-[10px] text-[#9ca3af] line-clamp-2 leading-tight" title={job.description}>{job.description}</div>

            <div className="flex justify-between items-end mt-1 pt-1 border-t border-white/[0.06]">
                <span className="text-[9px] text-[#6b7280]">{job.estimatedHours}h / {job.deadlineDays}d</span>
                <span className="text-[9px] text-[#3dae6c] font-mono font-medium">{DOLLAR_SIGN}{(job.revenue / 1000).toFixed(0)}k</span>
            </div>
            {job.arrivalDay && job.arrivalDay > 0 && (
                <div className="text-[9px] text-white flex items-center gap-1 justify-end">
                    <Clock size={8}/> {formatArrivalDate(job.arrivalDay)}
                </div>
            )}
        </div>
    </div>
  )};

  const renderTileCard = (job: Job) => {
      const isHighlighted = job.id === highlightedJobId;
      return (
      <div
        key={job.id}
        ref={isHighlighted ? highlightRef : null}
        draggable={true}
        onDragStart={(e) => onDragStart(e, job)}
        onDragEnd={onDragEnd}
        onClick={() => onJobClick(job)}
        className={`
            relative group select-none w-full bg-[#141517] rounded-md border p-2 cursor-grab active:cursor-grabbing transition-all flex flex-col justify-between min-h-[80px]
            ${isHighlighted
                ? 'border-white/40 ring-2 ring-white/20 bg-white/10'
                : 'border-white/[0.08] hover:border-white/[0.15] hover:bg-[#1a1b1e]'}
        `}
      >
          <div className={`absolute top-0 left-0 w-1 h-full rounded-l-md ${job.color} opacity-80`}></div>
          <div className="pl-2 h-full flex flex-col gap-1">
              <div className="flex justify-between items-start">
                  <span className={`font-medium text-[10px] truncate w-20 ${isHighlighted ? 'text-white' : 'text-[#e8e8e8]'}`} title={job.customer}>{job.customer}</span>
                  {job.isAOG && (
                      <Tooltip content="AOG - Urgent priority" position="left">
                          <AlertCircle size={8} className="text-[#c4626a] animate-pulse shrink-0" />
                      </Tooltip>
                  )}
              </div>
              <div className="text-[9px] text-[#6b7280] font-mono truncate">{job.aircraftType}</div>

              <div className="mt-auto flex justify-between items-end border-t border-white/[0.06] pt-1">
                  <span className="text-[9px] text-[#9ca3af]">{job.estimatedHours}h</span>
                  <span className="text-[9px] font-medium text-[#3dae6c]">{DOLLAR_SIGN}{(job.revenue/1000).toFixed(0)}k</span>
              </div>
          </div>
      </div>
  )};

  // Re-use existing renderers for popout mode (grid views)
  const renderLargeCard = (job: Job) => {
    const isHighlighted = job.id === highlightedJobId;
    return (
    <div
      key={job.id}
      ref={isHighlighted ? highlightRef : null}
      draggable={true}
      onDragStart={(e) => onDragStart(e, job)}
      onDragEnd={onDragEnd}
      onClick={() => onJobClick(job)}
      className={`
        relative group select-none flex-shrink-0 w-48 h-24 bg-[#141517] rounded-md border p-2 cursor-grab active:cursor-grabbing transition-all flex flex-col justify-between
        ${isHighlighted
            ? 'border-white/40 ring-2 ring-white/20 bg-white/10'
            : 'border-white/[0.08] hover:border-white/[0.15] hover:bg-[#1a1b1e]'}
      `}
    >
      <div className={`absolute top-0 left-0 w-1 h-full rounded-l-md ${job.color} opacity-80`}></div>
      <div className="pl-2 flex flex-col h-full">
        <div className="mb-1 shrink-0">
            <div className="flex justify-between items-center">
              <span className={`font-medium text-sm truncate ${isHighlighted ? 'text-white' : 'text-[#e8e8e8]'}`}>{job.customer}</span>
              <div className="flex gap-1">
                  {job.isAOG && (
                      <Tooltip content="AOG - Urgent priority" position="left">
                          <AlertCircle size={10} className="text-[#c4626a] animate-pulse" />
                      </Tooltip>
                  )}
              </div>
            </div>
            <div className="text-[9px] text-[#6b7280] font-mono leading-none mt-0.5">{job.aircraftType}</div>
        </div>
        <div className="text-[10px] text-[#9ca3af] leading-tight line-clamp-2 flex-1" title={job.description}>{job.description}</div>
        <div className="flex justify-between items-end border-t border-white/[0.06] pt-1 mt-1 shrink-0">
           <div className="flex gap-2 text-[9px] text-[#6b7280] font-mono">
              <span className="bg-[#0d0e10] px-1 rounded border border-white/[0.08]">{job.requiredHangarSize.substring(0, 1)}</span>
              <span className="text-[#9ca3af]">{job.estimatedHours}h</span>
           </div>
           <div className="text-[9px] text-[#6b7280] flex items-center gap-0.5"><Clock size={8} /> {job.deadlineDays}d</div>
        </div>
      </div>
    </div>
  )};

  const renderSmallCard = (job: Job) => {
    const isHighlighted = job.id === highlightedJobId;
    return (
    <div
      key={job.id}
      ref={isHighlighted ? highlightRef : null}
      draggable={true}
      onDragStart={(e) => onDragStart(e, job)}
      onDragEnd={onDragEnd}
      onClick={() => onJobClick(job)}
      className={`
        relative group select-none flex-shrink-0 w-32 h-16 bg-[#141517] rounded-md border p-1.5 cursor-grab active:cursor-grabbing transition-all flex flex-col justify-center
        ${isHighlighted
            ? 'border-white/40 ring-2 ring-white/20 bg-white/10'
            : 'border-white/[0.08] hover:border-white/[0.15] hover:bg-[#1a1b1e]'}
      `}
    >
      <div className={`absolute top-0 left-0 w-1 h-full rounded-l-md ${job.color} opacity-80`}></div>
      <div className="pl-2">
          <div className="flex justify-between items-center">
             <span className={`font-medium text-[10px] truncate ${isHighlighted ? 'text-white' : 'text-[#e8e8e8]'}`}>{job.customer}</span>
             {job.isAOG && (
                 <Tooltip content="AOG - Urgent" position="left">
                     <AlertCircle size={8} className="text-[#c4626a] animate-pulse" />
                 </Tooltip>
             )}
          </div>
          <div className="text-[9px] text-[#6b7280] font-mono truncate">{job.aircraftType}</div>
          <div className="flex justify-between mt-1 text-[8px] text-[#9ca3af]">
              <span>{job.estimatedHours}h</span>
              <span className="text-[#3dae6c] font-mono font-medium">${(job.revenue / 1000).toFixed(0)}k</span>
          </div>
      </div>
    </div>
  )};

  const renderListItem = (job: Job) => {
    const isHighlighted = job.id === highlightedJobId;
    return (
    <div
      key={job.id}
      ref={isHighlighted ? highlightRef : null}
      draggable={true}
      onDragStart={(e) => onDragStart(e, job)}
      onDragEnd={onDragEnd}
      onClick={() => onJobClick(job)}
      className={`
        relative group select-none w-full p-2 flex items-center gap-4 cursor-grab active:cursor-grabbing transition-colors
        ${isHighlighted
            ? 'bg-white/10 border border-white/40 ring-2 ring-white/20'
            : 'bg-[#141517]/50 hover:bg-[#141517] border-b border-white/[0.06]'}
      `}
    >
       <div className={`w-1 h-8 rounded-sm ${job.color} shrink-0 opacity-80`} />
       <div className="w-20 shrink-0">
          <div className={`font-medium text-xs truncate flex items-center gap-1 ${isHighlighted ? 'text-white' : 'text-[#e8e8e8]'}`}>
              {job.customer}
              {job.isAOG && (
                  <Tooltip content="AOG (Aircraft On Ground) - Urgent priority. Aircraft cannot fly until repairs complete." position="top">
                      <AlertCircle size={10} className="text-[#c4626a]" />
                  </Tooltip>
              )}
          </div>
          <div className="text-[10px] text-[#6b7280] font-mono">{job.aircraftType}</div>
       </div>
       <div className="flex-1 min-h-0">
          <div className="text-[11px] text-[#9ca3af] truncate font-medium group-hover:text-white transition-colors" title={job.description}>{job.description}</div>
          <div className="text-[9px] text-[#4b5563] flex gap-2">
             <span className="border border-white/[0.08] px-1 rounded bg-[#0d0e10]">{job.requiredHangarSize} Hangar</span>
          </div>
       </div>
       <div className="w-16 text-right shrink-0">
           <div className="text-[10px] text-[#9ca3af] font-mono">{job.estimatedHours} hrs</div>
           <div className="text-[10px] text-[#4b5563]">{job.deadlineDays} days</div>
       </div>
       <div className="w-20 text-right shrink-0">
           <div className="text-xs font-medium text-[#3dae6c] font-mono">{DOLLAR_SIGN}{job.revenue.toLocaleString()}</div>
           {job.arrivalDay && job.arrivalDay > 0 && (
               <div className="text-[9px] text-[#6b7280]">Arr: {formatArrivalDate(job.arrivalDay)}</div>
           )}
       </div>
    </div>
  )};

  if (isPoppedOut) {
      return (
        <div className="flex-1 h-full bg-[#0d0e10] flex flex-col z-20 shrink-0">
            <div className="px-3 py-2 bg-[#0d0e10] border-b border-white/[0.06] flex justify-between items-center shrink-0">
                <div className="flex bg-[#141517] rounded-md border border-white/[0.08] p-0.5">
                    <button onClick={() => setViewMode('list')} className={`p-1.5 rounded ${viewMode === 'list' ? 'bg-[#1a1b1e] text-white' : 'text-[#6b7280] hover:text-[#e8e8e8]'}`}><List size={14} /></button>
                    <button onClick={() => setViewMode('large')} className={`p-1.5 rounded ${viewMode === 'large' ? 'bg-[#1a1b1e] text-white' : 'text-[#6b7280] hover:text-[#e8e8e8]'}`}><LayoutGrid size={14} /></button>
                    <button onClick={() => setViewMode('small')} className={`p-1.5 rounded ${viewMode === 'small' ? 'bg-[#1a1b1e] text-white' : 'text-[#6b7280] hover:text-[#e8e8e8]'}`}><Grid3X3 size={14} /></button>
                </div>
                <button id="btn-new-quote" onClick={onNewQuote} className="bg-white hover:bg-zinc-100 text-[#09090b] px-3 py-1.5 rounded-md text-xs font-medium flex items-center gap-1.5 transition-colors">
                    <Plus size={14} /> Create New Quote
                </button>
            </div>
            <div
              ref={popoutScrollRef}
              className="flex-1 overflow-auto p-3 custom-scrollbar bg-[#08090a]"
            >
                {backlog.length === 0 && (
                    <EmptyState
                        icon={Plane}
                        title="No quotes yet"
                        description="Create your first quote to start scheduling jobs on the timeline."
                        action={{ label: 'Create Quote', onClick: onNewQuote }}
                        size="md"
                        className="w-full"
                    />
                )}
                {/* === VIRTUALIZATION: Virtual list for popout list view === */}
                {backlog.length > 0 && viewMode === 'list' && (
                  <div
                    style={{
                      height: `${popoutVirtualizer.getTotalSize()}px`,
                      width: '100%',
                      position: 'relative',
                    }}
                  >
                    {popoutVirtualizer.getVirtualItems().map((virtualItem) => {
                      const job = backlog[virtualItem.index];
                      return (
                        <div
                          key={job.id}
                          style={{
                            position: 'absolute',
                            top: 0,
                            left: 0,
                            width: '100%',
                            height: `${virtualItem.size}px`,
                            transform: `translateY(${virtualItem.start}px)`,
                          }}
                        >
                          {renderListItem(job)}
                        </div>
                      );
                    })}
                  </div>
                )}
                {/* Grid views - not virtualized due to flex-wrap complexity */}
                {backlog.length > 0 && viewMode === 'large' && (
                  <div className="flex flex-wrap gap-3 content-start">
                    {backlog.map(job => renderLargeCard(job))}
                  </div>
                )}
                {backlog.length > 0 && viewMode === 'small' && (
                  <div className="flex flex-wrap gap-2 content-start">
                    {backlog.map(job => renderSmallCard(job))}
                  </div>
                )}
            </div>
        </div>
      );
  }

  return (
    <div
        className="bg-[#0d0e10] border-r border-white/[0.06] flex flex-col z-20 shrink-0 transition-all duration-200 h-full relative overflow-hidden"
        style={{ width: isOpen ? width : 40 }}
    >
      {/* Collapsed State */}
      <div
        onClick={onToggle}
        className={`absolute inset-0 w-10 flex flex-col items-center py-4 transition-opacity duration-200 ${!isOpen ? 'opacity-100 z-10 cursor-pointer hover:bg-[#141517]' : 'opacity-0 pointer-events-none z-0'}`}
        title="Click to expand Quotes"
      >
            <button
                className="p-1 hover:bg-[#1a1b1e] rounded text-white mb-4"
            >
                <ChevronsRight size={20} />
            </button>
            <div className="[writing-mode:vertical-lr] text-xs font-medium text-[#6b7280] whitespace-nowrap flex items-center gap-4">
                <span className="text-white flex items-center gap-2"><Plane size={12} /> Quotes ({backlog.length})</span>
            </div>
            <button
                onClick={(e) => { e.stopPropagation(); onNewQuote(); }}
                className="mt-4 bg-white hover:bg-zinc-100 text-[#09090b] rounded-md p-1.5 transition-colors"
                title="New Quote"
            >
                <Plus size={14} />
            </button>
      </div>

      {/* Expanded State */}
      <div className={`flex flex-col h-full w-full transition-opacity duration-200 ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
        <div
            onClick={onToggle}
            className="px-3 py-3 bg-[#0d0e10] border-b border-white/[0.06] flex flex-col gap-3 shrink-0 cursor-pointer hover:bg-[#141517] transition-colors group/header"
        >
            <div className="flex justify-between items-center">
                <div className="flex items-center gap-3 overflow-hidden">
                     <h3 className="text-xs font-medium text-white flex items-center gap-2 whitespace-nowrap">
                        <Plane size={14} />
                        Quotes ({backlog.length})
                    </h3>
                    <div onClick={e => e.stopPropagation()} className="flex items-center bg-[#141517] rounded-md border border-white/[0.08] p-0.5">
                        <button onClick={() => setViewMode('list')} className={`p-1 rounded ${viewMode === 'list' ? 'bg-[#1a1b1e] text-white' : 'text-[#6b7280] hover:text-[#e8e8e8]'}`}><List size={12} /></button>
                        <button onClick={() => setViewMode('small')} className={`p-1 rounded ${viewMode === 'small' ? 'bg-[#1a1b1e] text-white' : 'text-[#6b7280] hover:text-[#e8e8e8]'}`}><LayoutGrid size={12} /></button>
                    </div>
                </div>
                <div className="flex items-center gap-1 shrink-0">
                    <button onClick={(e) => { e.stopPropagation(); onPopOut(); }} className="p-1 text-[#6b7280] hover:text-white rounded hover:bg-[#141517]"><ExternalLink size={14} /></button>
                    <button onClick={(e) => { e.stopPropagation(); onToggle(); }} className="p-1 text-[#6b7280] hover:text-white rounded hover:bg-[#141517]"><ChevronsLeft size={16} /></button>
                </div>
            </div>
            <div className="flex gap-2">
                <button
                    id="btn-new-quote"
                    onClick={(e) => { e.stopPropagation(); onNewQuote(); }}
                    className="flex-1 bg-white hover:bg-zinc-100 text-[#09090b] py-1.5 rounded-md text-[10px] font-medium flex items-center justify-center gap-1 transition-colors"
                >
                    <Plus size={12} /> New Quote
                </button>
            </div>
        </div>

        <div
          ref={sidebarScrollRef}
          className="flex-1 overflow-auto p-3 custom-scrollbar bg-[#08090a] w-full"
        >
             {backlog.length === 0 && (
                 <EmptyState
                     icon={Plane}
                     title="No quotes yet"
                     description="Click 'New Quote' to create your first quote."
                     size="sm"
                 />
             )}
             {/* === VIRTUALIZATION: Virtual list for sidebar === */}
             {backlog.length > 0 && viewMode === 'list' && (
               <div
                 style={{
                   height: `${sidebarVirtualizer.getTotalSize()}px`,
                   width: '100%',
                   position: 'relative',
                 }}
               >
                 {sidebarVirtualizer.getVirtualItems().map((virtualItem) => {
                   const job = backlog[virtualItem.index];
                   return (
                     <div
                       key={job.id}
                       style={{
                         position: 'absolute',
                         top: 0,
                         left: 0,
                         width: '100%',
                         height: `${virtualItem.size}px`,
                         transform: `translateY(${virtualItem.start}px)`,
                       }}
                     >
                       {renderSidebarCard(job)}
                     </div>
                   );
                 })}
               </div>
             )}
             {/* Grid view (small tiles) - not virtualized due to 2-column layout complexity */}
             {backlog.length > 0 && viewMode === 'small' && (
               <div className="grid grid-cols-2 gap-2">
                 {backlog.map(job => renderTileCard(job))}
               </div>
             )}
        </div>

        <div className="p-2 border-t border-white/[0.06] text-[9px] text-[#6b7280] bg-[#0d0e10] shrink-0 flex justify-between items-center">
            <span>Drag cards to schedule</span>
            {onOpenGraveyard && (
                <button
                    onClick={onOpenGraveyard}
                    className="flex items-center gap-1 text-[#4b5563] hover:text-[#9ca3af] transition-colors"
                >
                    <Archive size={10} /> Graveyard
                </button>
            )}
        </div>
      </div>
    </div>
  );
};

// PERFORMANCE: Wrap with React.memo to prevent unnecessary re-renders
export default React.memo(BacklogPanel);
