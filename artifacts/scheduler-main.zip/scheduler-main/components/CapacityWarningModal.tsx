
import React, { useEffect, useRef } from 'react';
import { AlertTriangle, Calendar, Clock, X, CheckCircle2, Search } from 'lucide-react';

export interface CapacityWarningData {
  jobId: string;
  jobName: string;
  hangarId: string;
  dayIndex: number;
  estimatedHours: number;
  deadlineDays: number;
  capacityInfo: {
    worstDayIndex: number;
    worstDayLoad: number;
    worstDayCapacity: number;
    worstDayUtilization: number;
    totalOverloadedDays: number;
    maxNewLoad: number;
    maxNewCapacity: number;
    maxNewUtilization: number;
  };
}

interface CapacityWarningModalProps {
  isOpen: boolean;
  data: CapacityWarningData | null;
  onCancel: () => void;
  onScheduleAnyway: () => void;
  onFindAvailable: () => void;
  nextAvailableDay: number | null;
}

const CapacityWarningModal: React.FC<CapacityWarningModalProps> = ({
  isOpen,
  data,
  onCancel,
  onScheduleAnyway,
  onFindAvailable,
  nextAvailableDay
}) => {
  const modalRef = useRef<HTMLDivElement>(null);
  const closeButtonRef = useRef<HTMLButtonElement>(null);

  // Handle escape key and focus trap
  useEffect(() => {
    if (!isOpen) return;

    // Focus the close button when modal opens
    closeButtonRef.current?.focus();

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onCancel();
      }
      // Focus trap
      if (e.key === 'Tab' && modalRef.current) {
        const focusableElements = modalRef.current.querySelectorAll(
          'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
        );
        const firstElement = focusableElements[0] as HTMLElement;
        const lastElement = focusableElements[focusableElements.length - 1] as HTMLElement;

        if (e.shiftKey && document.activeElement === firstElement) {
          e.preventDefault();
          lastElement?.focus();
        } else if (!e.shiftKey && document.activeElement === lastElement) {
          e.preventDefault();
          firstElement?.focus();
        }
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onCancel]);

  if (!isOpen || !data) return null;

  const { capacityInfo } = data;
  const utilizationPercent = Math.round(capacityInfo.maxNewUtilization);
  const isCritical = utilizationPercent > 120;

  const formatHours = (hours: number) => hours.toFixed(1);

  // Format date for display
  const formatDate = (dayIndex: number) => {
    const date = new Date(2024, 0, 1 + dayIndex);
    return date.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
  };

  return (
    <div
      className="fixed inset-0 bg-[#08090a]/80 backdrop-blur-sm z-[100] flex items-center justify-center p-4 animate-in fade-in duration-200"
      onClick={onCancel}
      role="presentation"
    >
      <div
        ref={modalRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby="capacity-warning-title"
        className="bg-[#0d0e10] border border-white/[0.08] rounded-2xl w-full max-w-md overflow-hidden relative"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className={`flex items-center gap-3 px-5 py-4 border-b border-white/[0.06] ${isCritical ? 'bg-rose-500/10' : 'bg-amber-500/10'}`}>
          <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${isCritical ? 'bg-rose-500/20' : 'bg-amber-500/20'}`}>
            <AlertTriangle size={20} className={isCritical ? 'text-rose-400' : 'text-amber-400'} />
          </div>
          <div className="flex-1">
            <h2 id="capacity-warning-title" className="text-lg font-semibold text-white">
              {isCritical ? 'Capacity Overload' : 'Capacity Warning'}
            </h2>
            <p className={`text-xs ${isCritical ? 'text-rose-400' : 'text-amber-400'}`}>
              {utilizationPercent}% utilization on worst day
            </p>
          </div>
          <button
            ref={closeButtonRef}
            onClick={onCancel}
            className="p-2 text-slate-500 hover:text-white hover:bg-white/[0.06] rounded-lg transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[#5e6ad2]"
            aria-label="Close dialog"
          >
            <X size={18} />
          </button>
        </div>

        {/* Content */}
        <div className="px-5 py-4 space-y-4">
          <p className="text-sm text-slate-300 leading-relaxed">
            Scheduling <span className="text-white font-medium">{data.jobName}</span> on this date will
            {isCritical ? ' significantly overload ' : ' exceed '}
            your team's available capacity.
            {utilizationPercent > 100 && ' This may require overtime.'}
          </p>

          {/* Capacity Details */}
          <div className="bg-[#141517] rounded-xl p-4 space-y-3 border border-white/[0.04]">
            <div className="flex items-center justify-between text-sm">
              <span className="text-slate-400">Worst day</span>
              <span className="text-white font-medium">{formatDate(capacityInfo.worstDayIndex)}</span>
            </div>

            <div className="flex items-center justify-between text-sm">
              <span className="text-slate-400">Current load</span>
              <span className="text-slate-300">{formatHours(capacityInfo.worstDayLoad)} hrs</span>
            </div>

            <div className="flex items-center justify-between text-sm">
              <span className="text-slate-400">Daily capacity</span>
              <span className="text-slate-300">{formatHours(capacityInfo.worstDayCapacity)} hrs</span>
            </div>

            <div className="flex items-center justify-between text-sm">
              <span className="text-slate-400">This job (avg/day)</span>
              <span className="text-amber-400">+{formatHours(data.estimatedHours / data.deadlineDays)} hrs</span>
            </div>

            <div className="border-t border-white/[0.06] pt-3 mt-3">
              <div className="flex items-center justify-between text-sm">
                <span className="text-slate-300 font-medium">New total</span>
                <span className={`font-semibold ${isCritical ? 'text-rose-400' : 'text-amber-400'}`}>
                  {formatHours(capacityInfo.maxNewLoad)} hrs ({utilizationPercent}%)
                </span>
              </div>
            </div>

            {/* Visual bar */}
            <div className="h-2 bg-white/[0.06] rounded-full overflow-hidden mt-2">
              <div
                className={`h-full transition-all ${isCritical ? 'bg-rose-500' : 'bg-amber-500'}`}
                style={{ width: `${Math.min(utilizationPercent, 100)}%` }}
              />
            </div>

            {capacityInfo.totalOverloadedDays > 1 && (
              <p className="text-xs text-slate-500 mt-2">
                {capacityInfo.totalOverloadedDays} days will be over capacity
              </p>
            )}
          </div>
        </div>

        {/* Actions */}
        <div className="px-5 py-4 border-t border-white/[0.06] flex flex-col gap-2">
          {nextAvailableDay !== null && (
            <button
              onClick={onFindAvailable}
              className="w-full py-3 px-4 bg-[#5e6ad2] hover:bg-[#7b86e0] text-white font-medium rounded-xl transition-colors flex items-center justify-center gap-2 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#5e6ad2] focus-visible:ring-offset-2 focus-visible:ring-offset-[#0d0e10]"
            >
              <Search size={16} aria-hidden="true" />
              <span>Find Available Slot ({formatDate(nextAvailableDay)})</span>
            </button>
          )}

          <div className="flex gap-2">
            <button
              onClick={onCancel}
              className="flex-1 py-3 px-4 bg-[#141517] hover:bg-[#1a1b1e] text-slate-300 font-medium rounded-xl transition-colors border border-white/[0.08] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#5e6ad2] focus-visible:ring-offset-2 focus-visible:ring-offset-[#0d0e10]"
            >
              Cancel
            </button>
            <button
              onClick={onScheduleAnyway}
              className={`flex-1 py-3 px-4 font-medium rounded-xl transition-colors flex items-center justify-center gap-2 focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-offset-[#0d0e10] ${
                isCritical
                  ? 'bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/30 focus-visible:ring-rose-500'
                  : 'bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/30 focus-visible:ring-amber-500'
              }`}
            >
              <CheckCircle2 size={16} aria-hidden="true" />
              <span>Schedule Anyway</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default React.memo(CapacityWarningModal);
