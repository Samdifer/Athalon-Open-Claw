
import React, { useMemo, RefObject, useState, useEffect, useRef, useCallback } from 'react';
import { useSyncedScroll } from '../contexts/TimelineSyncContext';
import { BarChart, Bar, Line, ComposedChart, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, ReferenceLine, Cell, LabelList } from 'recharts';
import { GameState, MONTH_NAMES, Shift, Team, Role } from '../types';
import { ExternalLink, TrendingUp, TrendingDown, Users, Warehouse, ChevronsUp, ChevronsDown, AlertTriangle, Clock } from 'lucide-react';
import { DOLLAR_SIGN } from '../App';
import { HOURLY_COST_AVG, STICKY_COL_WIDTH, TOTAL_DAYS, START_YEAR } from '../constants';

interface DailyFinancialTrackerProps {
  gameState: GameState;
  visibleDayStart: number;
  cellWidth: number;
  isPoppedOut: boolean;
  onPopOut: () => void;
  scrollRef?: RefObject<HTMLDivElement | null>;
  isOpen: boolean;
  onToggle: () => void;
  onScroll?: (e: React.UIEvent<HTMLDivElement>) => void;
  height?: number;
  selectedBaseId?: string;
}

const DailyFinancialTracker: React.FC<DailyFinancialTrackerProps> = ({ 
  gameState, visibleDayStart, cellWidth, isPoppedOut, onPopOut, scrollRef, isOpen, onToggle, onScroll, height, selectedBaseId
}) => {
  
  const VISIBLE_WINDOW_DAYS = 35;
  
  const [now, setNow] = useState(new Date());
  const [hoveredDay, setHoveredDay] = useState<number | null>(null);

  // PERFORMANCE: Virtualization - only render visible days + buffer
  const [visibleRange, setVisibleRange] = useState({ start: 0, end: 50 });
  const internalScrollRef = useRef<HTMLDivElement>(null);
  const rafUpdateRef = useRef<number | null>(null);

  // Ref to store the update callback - allows passing to context before it's defined
  const updateCallbackRef = useRef<() => void>(() => {});

  // Bi-directional scroll sync for popped-out windows
  // Pass a stable callback that calls the latest updateVisibleRangeRAF
  const { scrollRef: syncedScrollRef, handleScroll: syncedHandleScroll, state: syncState } = useSyncedScroll(
    'pnl',
    useCallback(() => updateCallbackRef.current(), [])
  );

  // Use context ref when popped out, prop ref when docked
  const effectiveScrollRef = isPoppedOut ? syncedScrollRef : (scrollRef || internalScrollRef);
  const effectiveCellWidth = isPoppedOut ? syncState.cellWidth : cellWidth;

  // PERFORMANCE: RAF-debounced visible range update for 60fps
  const updateVisibleRangeRAF = useCallback(() => {
    if (rafUpdateRef.current) return; // Already pending
    rafUpdateRef.current = requestAnimationFrame(() => {
      const ref = effectiveScrollRef;
      if (!ref?.current) {
        rafUpdateRef.current = null;
        return;
      }
      const scrollLeft = ref.current.scrollLeft;
      const clientWidth = ref.current.clientWidth;
      const start = Math.floor(scrollLeft / effectiveCellWidth);
      const visibleCount = Math.ceil(clientWidth / effectiveCellWidth);
      const buffer = 15;
      setVisibleRange({
        start: Math.max(0, start - buffer),
        end: Math.min(TOTAL_DAYS, start + visibleCount + buffer)
      });
      rafUpdateRef.current = null;
    });
  }, [effectiveScrollRef, effectiveCellWidth]);

  // Keep the callback ref updated
  useEffect(() => {
    updateCallbackRef.current = updateVisibleRangeRAF;
  }, [updateVisibleRangeRAF]);

  // Cleanup RAF on unmount
  useEffect(() => {
    return () => {
      if (rafUpdateRef.current) cancelAnimationFrame(rafUpdateRef.current);
    };
  }, []);

  // Update visible range on scroll - uses RAF for 60fps
  const handleInternalScroll = useCallback((e: React.UIEvent<HTMLDivElement>) => {
    updateVisibleRangeRAF();
    if (isPoppedOut) {
      syncedHandleScroll(e);
    } else if (onScroll) {
      onScroll(e);
    }
  }, [updateVisibleRangeRAF, isPoppedOut, syncedHandleScroll, onScroll]);

  // Sync visible range on mount and zoom change
  useEffect(() => {
    updateVisibleRangeRAF();
  }, [effectiveCellWidth, updateVisibleRangeRAF]);

  // PERFORMANCE: Pre-compute holiday set for O(1) lookup in render
  const holidaySet = useMemo(() =>
    new Set(gameState.holidays.filter(h => h.enabled).map(h => h.dayIndex)),
    [gameState.holidays]
  );

  useEffect(() => { const interval = setInterval(() => setNow(new Date()), 60000); return () => clearInterval(interval); }, []);
  const realTimeDayIndex = useMemo(() => {
    const startOfSim = new Date(START_YEAR, 0, 1);
    const diff = now.getTime() - startOfSim.getTime();
    return diff / (1000 * 60 * 60 * 24);
  }, [now]);

  const fullYearData = useMemo(() => {
      const { personnel, teams, shifts, roles, expenseItems, schedule, holidays, hangars } = gameState;
      const isGlobal = !selectedBaseId || selectedBaseId === 'ALL';
      const relevantPersonnel = isGlobal ? personnel : personnel.filter(p => p.baseId === selectedBaseId);
      const relevantHangarIds = isGlobal ? hangars.map(h => h.id) : hangars.filter(h => h.baseId === selectedBaseId).map(h => h.id);
      
      // 1. Calculate Base Labor Cost & Capacity Profile (Payroll)
      const dailyLaborProfileCost = new Float32Array(7);
      const dailyCapacityHours = new Float32Array(7);
      let totalAvgRate = 0;
      let staffWithRates = 0;

      const teamMap = new Map<string, Team>();
      teams.forEach(t => teamMap.set(t.id, t));

      const shiftMap = new Map<string, Shift>();
      shifts.forEach(s => shiftMap.set(s.id, s));

      const roleMap = new Map<string, Role>();
      roles.forEach(r => roleMap.set(r.id, r));

      // PERFORMANCE: Pre-compute holiday set for O(1) lookup
      const holidaySet = new Set(holidays.filter(h => h.enabled).map(h => h.dayIndex));

      relevantPersonnel.forEach(p => {
          const team = teamMap.get(p.teamId || '');
          const role = roleMap.get(p.roleId);
          const rate = role?.hourlyCost || HOURLY_COST_AVG;
          totalAvgRate += rate;
          staffWithRates++;

          if (team && role) {
              const shift = shiftMap.get(team.shiftId);
              if (shift) {
                  // Cost is based on shift duration
                  const dailyCost = shift.duration * rate;
                  
                  // Capacity is based on effective duration (minus breaks) * efficiency
                  const totalBreakMins = ((shift.breakCount || 0) * (shift.breakDuration || 0)) + (shift.meetingDuration || 0);
                  const effectiveDuration = Math.max(0, shift.duration - (totalBreakMins / 60));
                  const efficiency = p.efficiencyOverride ?? role.baseEfficiency ?? 1.0;
                  const dailyCap = effectiveDuration * efficiency;

                  for (const dayIndex of shift.days) { 
                      dailyLaborProfileCost[dayIndex] += dailyCost; 
                      dailyCapacityHours[dayIndex] += dailyCap;
                  }
              }
          }
      });

      const avgLaborRate = staffWithRates > 0 ? totalAvgRate / staffWithRates : HOURLY_COST_AVG;

      // 2. Overhead
      let overheadShare = 1.0;
      if (!isGlobal && personnel.length > 0) overheadShare = relevantPersonnel.length / personnel.length;
      const monthlyOverheadCache = new Map();
      const getDailyOverhead = (dayIndex: number) => {
          const date = new Date(START_YEAR, 0, 1 + dayIndex);
          const key = `${date.getFullYear()}-${date.getMonth()}`;
          if (monthlyOverheadCache.has(key)) return monthlyOverheadCache.get(key);
          let monthlyTotal = 0;
          expenseItems.forEach(item => { monthlyTotal += (item.overrides?.[key] ?? item.monthlyCost); });
          gameState.capexItems.forEach(item => { if (item.amortize && dayIndex >= item.plannedDay && dayIndex < item.plannedDay + 365) monthlyTotal += (item.cost / 12); });
          const daily = (monthlyTotal / 30) * overheadShare;
          monthlyOverheadCache.set(key, daily);
          return daily;
      };

      // 3. Initialize Arrays
      const income = new Float32Array(TOTAL_DAYS);
      const loadHours = new Float32Array(TOTAL_DAYS);
      const baseExpenses = new Float32Array(TOTAL_DAYS);
      const capacityHours = new Float32Array(TOTAL_DAYS);

      // 4. Populate Base Financials & Capacity
      for (let i = 0; i < TOTAL_DAYS; i++) {
          // PERFORMANCE: Use pre-computed Set instead of .some()
          const isHoliday = holidaySet.has(i);
          const dailyO = getDailyOverhead(i);
          
          if (isHoliday) {
              capacityHours[i] = 0;
              baseExpenses[i] = dailyO; // Still pay overhead, assume no labor cost if hourly? Or assume salary? Assuming salary for simplicity or holiday pay.
              // Let's keep base labor cost as paid holidays for this simulation
              const dayOfWeek = (i + 1) % 7;
              baseExpenses[i] += dailyLaborProfileCost[dayOfWeek];
          } else {
              const dayOfWeek = (i + 1) % 7;
              capacityHours[i] = dailyCapacityHours[dayOfWeek];
              baseExpenses[i] = dailyO + dailyLaborProfileCost[dayOfWeek];
          }

          if (isGlobal) { 
              gameState.capexItems.forEach(item => { 
                  if (!item.amortize && item.plannedDay === i) baseExpenses[i] += item.cost; 
              }); 
          }
      }

      // 5. Calculate Load & Revenue
      schedule.forEach(job => {
          if (!relevantHangarIds.includes(job.hangarId)) return;
          const start = job.startDate;
          const deadline = Math.max(1, job.deadlineDays);
          const revenue = job.revenue || 0;
          const totalEstHours = job.estimatedHours || 0;
          const end = start + deadline;
          
          // Calculate Weights
          let totalWeight = 0;
          const weights: number[] = [];
          for (let i = 0; i < deadline; i++) {
              let w = 1;
              if (job.dailyEffort && job.dailyEffort[i] !== undefined) {
                  w = job.dailyEffort[i];
              } else if (job.nonWorkDays?.includes(i)) {
                  w = 0;
              }
              weights[i] = w;
              totalWeight += w;
          }

          const loopStart = Math.max(0, start);
          const loopEnd = Math.min(TOTAL_DAYS, end);
          
          for (let d = loopStart; d < loopEnd; d++) {
              const offset = d - start;
              if (totalWeight > 0) {
                  const ratio = weights[offset] / totalWeight;
                  income[d] += ratio * revenue;
                  loadHours[d] += ratio * totalEstHours;
              }
          }
      });

      // 6. Final Merge: Calculate Overtime & Net P&L & Trend
      const data = new Array(TOTAL_DAYS);
      const netHistory: number[] = [];

      for (let i = 0; i < TOTAL_DAYS; i++) {
          const cap = capacityHours[i];
          const load = loadHours[i];
          
          let otHours = 0;
          let otCost = 0;

          if (load > cap) {
              otHours = load - cap;
              // Overtime is 1.5x rate
              otCost = otHours * avgLaborRate * 1.5;
          }

          const totalSpend = baseExpenses[i] + otCost;
          const net = income[i] - totalSpend;

          // Split Net for Visualization
          // If profit > 0, split into Standard Contribution vs Overtime Contribution based on volume
          let netStandard = net;
          let netOvertime = 0;

          if (net > 0 && load > 0 && otHours > 0) {
              const otRatio = otHours / load;
              netOvertime = net * otRatio;
              netStandard = net - netOvertime;
          }

          // Trend Logic: 7-day rolling average of Net Profit
          netHistory.push(net);
          if (netHistory.length > 7) netHistory.shift();
          const trend = netHistory.reduce((a, b) => a + b, 0) / netHistory.length;

          data[i] = { 
              day: i, 
              income: income[i], 
              spend: totalSpend, 
              net: net,
              netStandard,
              netOvertime,
              trend: trend, // Smoothed trend line
              baseSpend: baseExpenses[i],
              otCost: otCost,
              otHours: otHours,
              capacity: cap,
              load: load,
              otPercent: cap > 0 ? (otHours / cap) * 100 : (load > 0 ? 100 : 0)
          };
      }
      return data;
  }, [gameState.schedule, gameState.personnel, gameState.teams, gameState.shifts, gameState.roles, gameState.expenseItems, gameState.capexItems, gameState.holidays, selectedBaseId, gameState.hangars]); 

  const displayDayIndex = hoveredDay !== null ? hoveredDay : gameState.day;
  const currentStats = fullYearData[displayDayIndex] || { income: 0, spend: 0, net: 0, otHours: 0, otCost: 0, otPercent: 0 };

  const handleMouseMove = (e: any) => {
      if (e && e.activeLabel) {
          // Recharts activeLabel might not map directly if we used category axis, but here we map indices
          // Actually, we are using indices in fullYearData directly below
      }
      // For this specific custom implementation, Recharts tooltip gives us the payload index
      if (e && e.activeTooltipIndex !== undefined) {
          setHoveredDay(e.activeTooltipIndex);
      }
  };

  // Custom label renderer for bar chart - adapts to zoom level
  const renderCustomLabel = useCallback((props: any) => {
    const { x, y, width, payload } = props;
    if (!payload || payload.income === 0 && payload.spend === 0) return null;

    const formatCompact = (val: number) => {
      const absVal = Math.abs(val);
      if (absVal >= 1000) return `${(val / 1000).toFixed(1)}k`;
      return Math.round(val).toString();
    };

    const isZoomedIn = effectiveCellWidth >= 24;

    if (!isZoomedIn) {
      // Condensed: only show net profit
      return (
        <text
          x={x + width / 2}
          y={y - 4}
          textAnchor="middle"
          fontSize={7}
          fill={payload.net >= 0 ? '#10b981' : '#f43f5e'}
        >
          {formatCompact(payload.net)}
        </text>
      );
    }

    // Full display: income, expense, profit (stacked vertically)
    return (
      <g>
        <text x={x + width / 2} y={y - 26} textAnchor="middle" fontSize={8} fill="#10b981">
          {formatCompact(payload.income)}
        </text>
        <text x={x + width / 2} y={y - 17} textAnchor="middle" fontSize={8} fill="#f43f5e">
          {formatCompact(payload.spend)}
        </text>
        <text
          x={x + width / 2}
          y={y - 8}
          textAnchor="middle"
          fontSize={8}
          fill={payload.net >= 0 ? '#10b981' : '#f43f5e'}
        >
          {formatCompact(payload.net)}
        </text>
      </g>
    );
  }, [effectiveCellWidth]);

  return (
    <div
        className={`bg-[#0d0e10] flex flex-col shrink-0 select-none relative z-20 w-full transition-all duration-300 ease-in-out overflow-hidden
            ${isPoppedOut ? 'h-full flex-1 border-none' : 'border-t border-white/[0.06]'}
        `}
        style={isPoppedOut ? {} : { height: isOpen ? height : 32 }}
    >
        <div
            onClick={!isPoppedOut ? onToggle : undefined}
            className={`px-3 py-2 bg-[#141517] border-b border-white/[0.06] flex justify-between items-center shrink-0 z-30 transition-colors group h-8 ${!isPoppedOut ? 'cursor-pointer hover:bg-[#1a1b1e]' : ''}`}
        >
            <h3 className="text-[10px] font-semibold text-indigo-400 uppercase tracking-wide flex items-center gap-2">
                {isOpen ? <TrendingUp size={12} /> : null}
                <span>{isOpen ? 'Daily P&L (Net + Overtime)' : 'Daily P&L'}</span>
            </h3>
            <div className="flex items-center gap-2">
                {isOpen && <span className="text-[10px] text-[#6b7280] italic hidden sm:inline mr-2">Timeline Synced</span>}
                {isOpen && !isPoppedOut && <button onClick={(e) => { e.stopPropagation(); onPopOut(); }} className="text-[#6b7280] hover:text-indigo-400"><ExternalLink size={16} /></button>}
                {!isPoppedOut && (
                    <button onClick={(e) => { e.stopPropagation(); onToggle(); }} className="text-[#6b7280] hover:text-indigo-400">
                        {isOpen ? <ChevronsDown size={16} /> : <ChevronsUp size={16} />}
                    </button>
                )}
            </div>
        </div>

        <div className={`flex flex-1 min-h-0 relative transition-opacity duration-300 ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
            <div className="bg-[#0d0e10] border-r border-white/[0.08] shrink-0 flex flex-col px-2 py-2 justify-center gap-2 shadow-sm z-20" style={{ width: STICKY_COL_WIDTH, minWidth: STICKY_COL_WIDTH }}>

                 {/* Net Profit Display */}
                 <div>
                    <div className="flex items-center gap-1 text-[9px] font-semibold text-[#6b7280] uppercase mb-0.5">Daily Net Profit</div>
                    <div className={`text-lg font-mono font-bold leading-none ${currentStats.net >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                        {currentStats.net >= 0 ? '+' : ''}{DOLLAR_SIGN}{Math.round(currentStats.net).toLocaleString()}
                    </div>
                 </div>

                 {/* Overtime Display */}
                 <div className={`border-l-2 pl-2 ${currentStats.otHours > 0 ? 'border-amber-500' : 'border-white/[0.08] opacity-50'}`}>
                    <div className="flex items-center gap-1 text-[9px] font-semibold text-[#6b7280] uppercase mb-0.5">
                        {currentStats.otHours > 0 ? <AlertTriangle size={8} className="text-amber-400"/> : <Clock size={8} />} OT Impact
                    </div>
                    <div className="flex flex-col gap-0.5">
                        <div className={`text-xs font-mono font-bold ${currentStats.otHours > 0 ? 'text-amber-400' : 'text-[#4b5563]'}`}>
                            {currentStats.otHours.toFixed(1)}h <span className="text-[9px] opacity-70">({Math.round(currentStats.otPercent)}%)</span>
                        </div>
                        {currentStats.otCost > 0 && (
                            <div className="text-[9px] text-rose-400 font-mono">
                                -{DOLLAR_SIGN}{Math.round(currentStats.otCost).toLocaleString()} Cost
                            </div>
                        )}
                    </div>
                 </div>
            </div>

            <div className="flex-1 relative min-w-0 bg-[#08090a]">
                <div ref={effectiveScrollRef} onScroll={handleInternalScroll} className="absolute inset-0 overflow-x-auto custom-scrollbar z-10 overscroll-x-none" style={{ contain: 'strict' }}>
                    <div className="relative h-full" style={{ width: TOTAL_DAYS * effectiveCellWidth }}>
                        {/* PERFORMANCE: Virtualized grid - only render visible days + buffer */}
                        <div className="absolute inset-0 pointer-events-none">
                            {Array.from({ length: visibleRange.end - visibleRange.start }).map((_, idx) => {
                                const i = visibleRange.start + idx;
                                const isHoliday = holidaySet.has(i);
                                const isWeekend = (i + 1) % 7 === 6 || (i + 1) % 7 === 0;
                                let bgClass = '';
                                if (isHoliday) bgClass = 'bg-rose-900/20 pattern-diagonal-lines';
                                else if (isWeekend) bgClass = 'bg-white/[0.02]';
                                return (
                                    <div
                                        key={i}
                                        style={{ width: effectiveCellWidth, left: i * effectiveCellWidth, position: 'absolute', top: 0, bottom: 0 }}
                                        className={`border-r border-white/[0.02] ${bgClass}`}
                                    />
                                );
                            })}
                        </div>

                        {realTimeDayIndex >= 0 && realTimeDayIndex < TOTAL_DAYS && (
                           <div className="absolute top-0 bottom-0 z-20 pointer-events-none border-l-2 border-rose-500" style={{ left: realTimeDayIndex * effectiveCellWidth }}>
                              <div className="absolute top-0 left-0 -translate-x-1/2 bg-rose-500 text-white text-[8px] font-semibold px-1 py-0.5 rounded-sm shadow-sm whitespace-nowrap z-50">NOW</div>
                           </div>
                        )}

                        <div className="absolute top-0 bottom-0 border-l border-amber-500 z-10 pointer-events-none" style={{ left: (gameState.day * effectiveCellWidth) + (effectiveCellWidth / 2), transitionProperty: 'left', transitionDuration: gameState.paused ? '300ms' : `${gameState.speed}ms`, transitionTimingFunction: gameState.paused ? 'cubic-bezier(0.4, 0, 0.2, 1)' : 'linear' }} />

                        {/* Configurable Progress Cursors */}
                        {gameState.cursors && gameState.cursors.map(cursor => {
                            if (!cursor.enabled) return null;
                            const targetDay = Math.floor(realTimeDayIndex) + cursor.dayOffset;
                            if (targetDay < 0 || targetDay >= TOTAL_DAYS) return null;

                            return (
                                <div
                                    key={cursor.id}
                                    className={`absolute top-0 bottom-0 z-20 pointer-events-none border-l border-dashed opacity-60 ${cursor.color.replace('bg-', 'border-')}`}
                                    style={{
                                        left: (targetDay * effectiveCellWidth) + (effectiveCellWidth / 2)
                                    }}
                                />
                            );
                        })}

                        {/* Chart Implementation using Recharts for cleaner rendering, but mapped to manual width/scroll */}
                        <div className="absolute inset-0" style={{ width: TOTAL_DAYS * effectiveCellWidth }}>
                             <ResponsiveContainer width="100%" height="100%" minHeight={100}>
                                <ComposedChart data={fullYearData} onMouseMove={handleMouseMove} onMouseLeave={() => setHoveredDay(null)} barGap={0} barCategoryGap={0} margin={{ top: 35, right: 0, left: 0, bottom: 0 }}>
                                    <ReferenceLine y={0} stroke="rgba(255,255,255,0.08)" />

                                    {/* Stacked Bar for Standard Profit */}
                                    <Bar dataKey="netStandard" stackId="profit" isAnimationActive={false}>
                                        {fullYearData.map((entry, index) => (
                                            <Cell key={`cell-std-${index}`} fill={entry.net >= 0 ? '#10b981' : '#f43f5e'} />
                                        ))}
                                    </Bar>

                                    {/* Stacked Bar for Overtime Contribution (Yellow) */}
                                    <Bar dataKey="netOvertime" stackId="profit" fill="#eab308" isAnimationActive={false}>
                                        <LabelList content={renderCustomLabel} />
                                    </Bar>

                                    {/* OT Hours Line */}
                                    <Line type="step" dataKey="otHours" stroke="#f59e0b" strokeWidth={2} dot={false} isAnimationActive={false} />
                                    {/* Trend Line (Smoothed Moving Avg of Net P&L) */}
                                    <Line type="monotone" dataKey="trend" stroke="#818cf8" strokeWidth={2} dot={false} isAnimationActive={false} strokeOpacity={0.8} />
                                </ComposedChart>
                             </ResponsiveContainer>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  );
};

// PERFORMANCE: Wrap with React.memo to prevent unnecessary re-renders
export default React.memo(DailyFinancialTracker);
