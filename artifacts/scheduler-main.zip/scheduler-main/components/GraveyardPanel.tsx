
import React from 'react';
import { Job } from '../types';
import { ArchiveRestore, Trash2, AlertCircle, Skull } from 'lucide-react';
import { DOLLAR_SIGN } from '../App';

interface GraveyardPanelProps {
  graveyard: Job[];
  onRestore: (job: Job) => void;
  onPermanentDelete: (jobId: string) => void;
}

const GraveyardPanel: React.FC<GraveyardPanelProps> = ({ graveyard, onRestore, onPermanentDelete }) => {
  return (
    <div className="flex flex-col h-full bg-[#08090a] text-[#e8e8e8]">
      <div className="p-4 border-b border-white/[0.06] bg-[#141517] flex items-center justify-between shrink-0">
        <div className="flex items-center gap-3">
            <div className="bg-[#1a1b1e] p-2 rounded-lg border border-white/[0.08]">
                <Skull className="text-[#6b7280]" size={20} />
            </div>
            <div>
                <h2 className="text-sm font-semibold text-[#e8e8e8] uppercase tracking-wide">Project Graveyard</h2>
                <p className="text-xs text-[#6b7280]">Manage deleted and archived quotes.</p>
            </div>
        </div>
        <div className="text-xs font-semibold text-[#6b7280] bg-[#1a1b1e] px-2 py-1 rounded border border-white/[0.08]">
            {graveyard.length} Items
        </div>
      </div>

      <div className="flex-1 overflow-y-auto custom-scrollbar p-4 space-y-3">
        {graveyard.length === 0 && (
            <div className="flex flex-col items-center justify-center h-64 text-[#4b5563] opacity-50">
                <Skull size={48} className="mb-3" />
                <p className="text-xs font-mono">Graveyard is empty.</p>
            </div>
        )}

        {graveyard.map((job) => (
            <div
                key={job.id}
                className="bg-[#0d0e10] border border-white/[0.06] rounded-lg p-3 flex items-center justify-between group hover:border-white/[0.12] transition-colors relative overflow-hidden"
            >
                {/* Grayscale overlay to indicate inactive */}
                <div className="absolute inset-0 bg-[#08090a]/20 pointer-events-none" />

                <div className="flex items-center gap-4 relative z-10">
                    <div className={`w-1 h-10 rounded-full ${job.color} opacity-30 grayscale`} />
                    <div>
                        <div className="flex items-center gap-2">
                            <span className="font-semibold text-[#6b7280] text-sm line-through decoration-[#4b5563]">{job.customer}</span>
                            {job.isAOG && <AlertCircle size={10} className="text-rose-800" />}
                        </div>
                        <div className="text-[10px] text-[#4b5563] font-mono uppercase mt-0.5">{job.aircraftType} • {job.estimatedHours} hrs</div>
                        <div className="text-[10px] text-[#4b5563] font-mono mt-0.5">{DOLLAR_SIGN}{job.revenue.toLocaleString()}</div>
                    </div>
                </div>

                <div className="flex items-center gap-2 relative z-10">
                    <button
                        onClick={() => onRestore(job)}
                        className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/20 text-emerald-400 hover:text-emerald-300 rounded text-[10px] font-semibold uppercase transition-colors"
                        title="Restore to Quotes"
                    >
                        <ArchiveRestore size={12} /> Restore
                    </button>
                    <button
                        onClick={() => {
                            if(window.confirm("Are you sure? This will permanently delete the project history.")) {
                                onPermanentDelete(job.id);
                            }
                        }}
                        className="p-1.5 bg-[#1a1b1e] hover:bg-rose-500/10 border border-white/[0.08] hover:border-rose-500/30 text-[#6b7280] hover:text-rose-400 rounded transition-colors"
                        title="Delete Forever"
                    >
                        <Trash2 size={14} />
                    </button>
                </div>
            </div>
        ))}
      </div>
    </div>
  );
};

export default GraveyardPanel;
