
import React, { useState, useMemo, useEffect, useRef } from 'react';
import { useVirtualizer } from '@tanstack/react-virtual';
import { Users, UserPlus, Trash2, Briefcase, Shield, Clock, ChevronRight, ChevronDown, Activity, Settings, Edit2, X, Save, TrendingUp, PieChart as PieChartIcon, AlertCircle, AlertTriangle, Plus, GripVertical, Check, ArrowRight, UserCheck, Coffee, Calendar, ToggleLeft, ToggleRight, Layout, DollarSign, BarChart as BarChartIcon, Search, Package, Upload, Percent } from 'lucide-react';
import { GameState, Personnel, Role, RolePackage, Team, Shift, Holiday } from '../types';
import { MONTHLY_OVERHEAD, START_YEAR, ROLE_PACKAGES, DEFAULT_BURDEN_MULTIPLIER } from '../constants';
import { generateUUID } from '../utils';
import { BarChart, Bar, XAxis, YAxis, Tooltip as RechartsTooltip, ResponsiveContainer, Cell, PieChart, Pie, Legend } from 'recharts';
import { Tooltip, HelpIcon, EmptyState } from './ui';
import { useDebounce } from '../hooks';

const DOLLAR_SIGN_SYMBOL = "$";

// Temporary type for editable roles with a tracking ID
interface EditableRole extends Omit<Role, 'id'> {
  tempId: string;
}

interface PersonnelManagerProps {
  gameState: GameState;
  onUpdatePersonnel: (p: Personnel[]) => void;
  onUpdateTeams: (t: Team[]) => void;
  onUpdateShifts: (s: Shift[]) => void;
  onUpdateRoles: (r: Role[]) => void;
  onUpdateHolidays: (h: Holiday[]) => void;
  onClose: () => void;
  activeTabOverride?: 'roster' | 'assignments' | 'roles' | 'holidays' | 'analysis' | null;
}

const PersonnelManager: React.FC<PersonnelManagerProps> = ({ gameState, onUpdatePersonnel, onUpdateTeams, onUpdateShifts, onUpdateRoles, onUpdateHolidays, onClose, activeTabOverride }) => {
  const [activeTab, setActiveTab] = useState<'roster' | 'assignments' | 'roles' | 'holidays' | 'analysis'>('roster');

  useEffect(() => {
    if (activeTabOverride) {
      setActiveTab(activeTabOverride);
    }
  }, [activeTabOverride]);

  const [selectedPerson, setSelectedPerson] = useState<Personnel | null>(null);
  const [personnelFilter, setPersonnelFilter] = useState('');
  const debouncedPersonnelFilter = useDebounce(personnelFilter, 200);

  // === BATCHED SAVE: Local state for buffering changes ===
  const [pendingPersonnel, setPendingPersonnel] = useState<Personnel[]>(gameState.personnel);
  const [pendingRoles, setPendingRoles] = useState<Role[]>(gameState.roles);
  const [pendingTeams, setPendingTeams] = useState<Team[]>(gameState.teams);
  const [pendingShifts, setPendingShifts] = useState<Shift[]>(gameState.shifts);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);

  // Sync local state when gameState changes from outside (only if no pending changes)
  useEffect(() => {
    if (!hasUnsavedChanges) {
      setPendingPersonnel(gameState.personnel);
      setPendingRoles(gameState.roles);
      setPendingTeams(gameState.teams);
      setPendingShifts(gameState.shifts);
    }
  }, [gameState.personnel, gameState.roles, gameState.teams, gameState.shifts, hasUnsavedChanges]);
  
  // Shift Config Edit Mode State
  const [shiftConfigMode, setShiftConfigMode] = useState<Record<string, boolean>>({});
  
  // Team Name Edit Mode State
  const [teamEditMode, setTeamEditMode] = useState<Record<string, boolean>>({});

  // Analysis Scope State
  const [analysisScope, setAnalysisScope] = useState<string>('ALL');

  // Projection Period State (1 month, 3 months, 12 months)
  const [projectionPeriod, setProjectionPeriod] = useState<1 | 3 | 12>(1);

  // New Hire Config State
  const [selectedNewRole, setSelectedNewRole] = useState<string>(gameState.roles[0]?.id || '');

  // Role Drag & Drop State
  const [draggableRoleIndex, setDraggableRoleIndex] = useState<number | null>(null);

  // Inline Error Message State (replaces alerts)
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Auto-dismiss error messages after 4 seconds
  useEffect(() => {
      if (errorMessage) {
          const timer = setTimeout(() => setErrorMessage(null), 4000);
          return () => clearTimeout(timer);
      }
  }, [errorMessage]);

  // Role Packages State
  const [selectedPackageId, setSelectedPackageId] = useState<string>('');
  const [showPackageEditor, setShowPackageEditor] = useState(false);
  const [editablePackageRoles, setEditablePackageRoles] = useState<EditableRole[]>([]);

  // === PERFORMANCE: Pre-computed lookup maps for O(1) access ===
  const lookupMaps = useMemo(() => ({
    roles: new Map(gameState.roles.map(r => [r.id, r])),
    teams: new Map(gameState.teams.map(t => [t.id, t])),
    shifts: new Map(gameState.shifts.map(s => [s.id, s])),
    bases: new Map(gameState.bases.map(b => [b.id, b])),
    // Pre-group personnel by role for O(1) staff count lookup
    personnelByRole: gameState.personnel.reduce((acc, p) => {
      if (!acc.has(p.roleId)) acc.set(p.roleId, []);
      acc.get(p.roleId)!.push(p);
      return acc;
    }, new Map<string, Personnel[]>())
  }), [gameState.roles, gameState.teams, gameState.shifts, gameState.bases, gameState.personnel]);

  // === VIRTUALIZATION: Ref and virtualizer for personnel list ===
  const personnelListRef = useRef<HTMLDivElement>(null);

  // Filter personnel for display (using pending data so users see their edits)
  // PERFORMANCE: Uses debounced filter value to avoid filtering on every keystroke
  const filteredPersonnel = useMemo(() =>
    pendingPersonnel.filter(p => p.name.toLowerCase().includes(debouncedPersonnelFilter.toLowerCase())),
    [pendingPersonnel, debouncedPersonnelFilter]
  );

  const personnelVirtualizer = useVirtualizer({
    count: filteredPersonnel.length,
    getScrollElement: () => personnelListRef.current,
    estimateSize: () => 58, // Approximate height of each personnel card
    overscan: 5,
  });

  const handleAddPerson = (baseId?: string) => {
    const newPerson: Personnel = {
        id: generateUUID(),
        name: 'New Hire',
        roleId: selectedNewRole || gameState.roles[gameState.roles.length - 1].id,
        teamId: null,
        baseId: baseId // Assign to this base if provided, even without a team
    };
    onUpdatePersonnel([...gameState.personnel, newPerson]);
    setSelectedPerson(newPerson);
  };

  const handleDeletePerson = (id: string) => {
    onUpdatePersonnel(gameState.personnel.filter(p => p.id !== id));
    if (selectedPerson?.id === id) setSelectedPerson(null);
  };

  const handleUpdatePerson = (updated: Personnel) => {
    const newList = pendingPersonnel.map(p => p.id === updated.id ? updated : p);
    setPendingPersonnel(newList);
    setSelectedPerson(updated);
    setHasUnsavedChanges(true);
  };

  // --- Team Management ---
  const handleAddTeam = (shiftId: string) => {
    const newTeam: Team = {
        id: generateUUID(),
        name: 'New Team',
        color: 'bg-slate-500',
        shiftId: shiftId,
        baseId: gameState.bases[0]?.id
    };
    setPendingTeams([...pendingTeams, newTeam]);
    setHasUnsavedChanges(true);
  };

  const handleDeleteTeam = (id: string) => {
     // Unassign staff from this team in pending state
     const updatedPersonnel = pendingPersonnel.map(p =>
        p.teamId === id ? { ...p, teamId: null } : p
    );
    setPendingPersonnel(updatedPersonnel);

    // Remove the team from pending state
    const updatedTeams = pendingTeams.filter(t => t.id !== id);
    setPendingTeams(updatedTeams);
    setHasUnsavedChanges(true);
  };

  const handleUpdateTeam = (id: string, field: keyof Team, value: any) => {
      const newTeams = pendingTeams.map(t => t.id === id ? { ...t, [field]: value } : t);
      setPendingTeams(newTeams);
      setHasUnsavedChanges(true);
  };

  // --- Shift Management ---
  const handleAddShift = () => {
      const newShift: Shift = {
          id: generateUUID(),
          name: 'New Shift',
          days: [1,2,3,4,5],
          startHour: 9,
          duration: 8.0,
          breakCount: 1,
          breakDuration: 30,
          meetingDuration: 15
      };
      setPendingShifts([...pendingShifts, newShift]);
      setShiftConfigMode(prev => ({ ...prev, [newShift.id]: true }));
      setHasUnsavedChanges(true);
  };

  const handleDeleteShift = (id: string) => {
      // Check if any teams (in pending state) are assigned to this shift
      const assignedTeams = pendingTeams.filter(t => t.shiftId === id);
      if(assignedTeams.length > 0) {
          setErrorMessage("Cannot delete shift with assigned teams. Reassign teams first.");
          return;
      }
      const updatedShifts = pendingShifts.filter(s => s.id !== id);
      setPendingShifts(updatedShifts);
      setHasUnsavedChanges(true);
  };

  const handleUpdateShift = (id: string, field: keyof Shift, value: any) => {
      const newShifts = pendingShifts.map(s => s.id === id ? { ...s, [field]: value } : s);
      setPendingShifts(newShifts);
      setHasUnsavedChanges(true);
  };

  const toggleShiftDay = (shiftId: string, dayIndex: number) => {
     const shift = pendingShifts.find(s => s.id === shiftId);
     if (!shift) return;
     const newDays = shift.days.includes(dayIndex)
        ? shift.days.filter(d => d !== dayIndex)
        : [...shift.days, dayIndex].sort();
     handleUpdateShift(shiftId, 'days', newDays);
  };

  // --- Role Management ---
  const handleUpdateRole = (id: string, field: keyof Role, value: any) => {
      const newRoles = pendingRoles.map(r => r.id === id ? { ...r, [field]: value } : r);
      setPendingRoles(newRoles);
      setHasUnsavedChanges(true);
  };

  const handleAddRole = () => {
      const newRole: Role = {
          id: generateUUID(),
          name: 'New Role',
          baseEfficiency: 1.0,
          hourlyRate: 37,
          burdenMultiplier: DEFAULT_BURDEN_MULTIPLIER,
          hourlyCost: Math.round(37 * DEFAULT_BURDEN_MULTIPLIER)
      };
      onUpdateRoles([...gameState.roles, newRole]);
  };

  const handleDeleteRole = (id: string, staffCount: number) => {
      if (gameState.roles.length <= 1) {
          setErrorMessage("Cannot delete the last remaining role.");
          return;
      }

      if (staffCount > 0) {
          const fallbackRole = gameState.roles.find(r => r.id !== id);
          if (!fallbackRole) return; // Should not happen due to length check

          const confirmed = window.confirm(
              `This role is assigned to ${staffCount} personnel.\n\nDeleting it will reassign these staff members to "${fallbackRole.name}".\n\nAre you sure you want to proceed?`
          );
          if (!confirmed) return;

          const updatedPersonnel = gameState.personnel.map(p => 
              p.roleId === id ? { ...p, roleId: fallbackRole.id } : p
          );
          onUpdatePersonnel(updatedPersonnel);
      } else {
          if (!window.confirm("Are you sure you want to delete this role definition?")) return;
      }

      const updatedRoles = gameState.roles.filter(r => r.id !== id);
      onUpdateRoles(updatedRoles);
  };

  // --- Role Reordering Handlers ---
  const handleDragStartRole = (e: React.DragEvent, index: number) => {
      e.dataTransfer.setData('roleIndex', index.toString());
      e.dataTransfer.effectAllowed = 'move';
  };

  const handleDragOverRole = (e: React.DragEvent) => {
      e.preventDefault(); // Necessary to allow dropping
  };

  const handleDropRole = (e: React.DragEvent, dropIndex: number) => {
      e.preventDefault();
      const dragIndexStr = e.dataTransfer.getData('roleIndex');
      if (!dragIndexStr) return;
      const dragIndex = parseInt(dragIndexStr, 10);
      
      if (dragIndex === dropIndex) return;

      const newRoles = [...gameState.roles];
      const [movedRole] = newRoles.splice(dragIndex, 1);
      newRoles.splice(dropIndex, 0, movedRole);
      
      onUpdateRoles(newRoles);
      setDraggableRoleIndex(null);
  };

  // --- Role Package Handlers ---
  const handleSelectPackage = (packageId: string) => {
      setSelectedPackageId(packageId);
      const pkg = ROLE_PACKAGES.find(p => p.id === packageId);
      if (pkg) {
          setEditablePackageRoles(pkg.roles.map(role => ({ ...role, tempId: generateUUID() })));
      } else {
          setEditablePackageRoles([]);
      }
  };

  const handleEditPackages = () => {
      if (!selectedPackageId) return;
      setShowPackageEditor(true);
  };

  const handleUpdateEditableRole = (index: number, field: keyof Omit<Role, 'id'>, value: any) => {
      const updated = [...editablePackageRoles];
      updated[index] = { ...updated[index], [field]: value };
      // Auto-calculate hourlyCost when hourlyRate or burdenMultiplier changes
      if (field === 'hourlyRate' || field === 'burdenMultiplier') {
          const rate = field === 'hourlyRate' ? value : updated[index].hourlyRate;
          const multiplier = field === 'burdenMultiplier' ? value : updated[index].burdenMultiplier;
          updated[index].hourlyCost = Math.round(rate * multiplier);
      }
      setEditablePackageRoles(updated);
  };

  const handleDeleteEditableRole = (index: number) => {
      const updated = editablePackageRoles.filter((_, i) => i !== index);
      setEditablePackageRoles(updated);
  };

  const handleAddEditableRole = () => {
      setEditablePackageRoles([
          ...editablePackageRoles,
          { tempId: generateUUID(), name: 'New Role', baseEfficiency: 1.0, hourlyRate: 37, burdenMultiplier: DEFAULT_BURDEN_MULTIPLIER, hourlyCost: 50 }
      ]);
  };

  const handleLoadPackage = () => {
      if (editablePackageRoles.length === 0) return;

      // Convert editable roles to full roles with IDs
      const newRoles: Role[] = editablePackageRoles.map(role => ({
          ...role,
          id: generateUUID()
      }));

      // Replace existing roles with the package roles
      onUpdateRoles(newRoles);

      // Reset state
      setShowPackageEditor(false);
      setSelectedPackageId('');
      setEditablePackageRoles([]);
  };

  const handleCancelPackageEdit = () => {
      setShowPackageEditor(false);
      // Reset to original package roles
      const pkg = ROLE_PACKAGES.find(p => p.id === selectedPackageId);
      if (pkg) {
          setEditablePackageRoles(pkg.roles.map(role => ({ ...role, tempId: generateUUID() })));
      }
  };

  // --- Update role hourly cost when rate or multiplier changes ---
  const handleUpdateRoleWithCalc = (id: string, field: keyof Role, value: any) => {
      const role = pendingRoles.find(r => r.id === id);
      if (!role) return;

      let updates: Partial<Role> = { [field]: value };

      // Auto-calculate hourlyCost when hourlyRate or burdenMultiplier changes
      if (field === 'hourlyRate') {
          updates.hourlyCost = Math.round(value * role.burdenMultiplier);
      } else if (field === 'burdenMultiplier') {
          updates.hourlyCost = Math.round(role.hourlyRate * value);
      }

      const newRoles = pendingRoles.map(r => r.id === id ? { ...r, ...updates } : r);
      setPendingRoles(newRoles);
      setHasUnsavedChanges(true);
  };

  // === BATCHED SAVE: Save and Discard handlers ===
  const handleSaveChanges = () => {
      onUpdatePersonnel(pendingPersonnel);
      onUpdateRoles(pendingRoles);
      onUpdateTeams(pendingTeams);
      onUpdateShifts(pendingShifts);
      setHasUnsavedChanges(false);
  };

  const handleDiscardChanges = () => {
      setPendingPersonnel(gameState.personnel);
      setPendingRoles(gameState.roles);
      setPendingTeams(gameState.teams);
      setPendingShifts(gameState.shifts);
      setHasUnsavedChanges(false);
      // Reset selected person to original state if it was modified
      if (selectedPerson) {
          const original = gameState.personnel.find(p => p.id === selectedPerson.id);
          setSelectedPerson(original || null);
      }
  };

  // --- Analysis Logic ---
  const analysisData = useMemo(() => {
    const scope = analysisScope; // 'ALL' or baseId

    // Filter Personnel
    const relevantPersonnel = gameState.personnel.filter(p => {
        if (scope === 'ALL') return true;
        if (scope === 'Unassigned') return !p.baseId;
        return p.baseId === scope;
    });

    let totalHeadcount = relevantPersonnel.length;
    let totalMonthlyCapacity = 0;
    let totalMonthlyCost = 0;

    // Breakdown Data
    const roleCounts: Record<string, number> = {};
    const roleCosts: Record<string, number> = {};

    // For specific base view, show teams. For all view, show bases.
    const distribution: Record<string, { count: number, cost: number }> = {};

    relevantPersonnel.forEach(p => {
        // PERFORMANCE: Use lookup maps instead of .find() - O(1) vs O(n)
        const role = lookupMaps.roles.get(p.roleId);
        const team = p.teamId ? lookupMaps.teams.get(p.teamId) : undefined;
        const shift = team ? lookupMaps.shifts.get(team.shiftId) : undefined;

        // Cost & Capacity Logic
        // Default: 160h if no shift assigned (standard full time)
        // Or calculate exact shift hours
        let weeklyHours = 40;
        if (shift) {
            weeklyHours = shift.duration * shift.days.length;
        }

        const monthlyHours = weeklyHours * 4.33; // Average month
        const rate = role?.hourlyCost || 50;

        const cost = monthlyHours * rate;
        const capacity = monthlyHours * (p.efficiencyOverride ?? role?.baseEfficiency ?? 1.0);

        totalMonthlyCost += cost;
        totalMonthlyCapacity += capacity;

        // Role Breakdown
        const roleName = role?.name || 'Unknown';
        roleCounts[roleName] = (roleCounts[roleName] || 0) + 1;
        roleCosts[roleName] = (roleCosts[roleName] || 0) + cost;

        // Distribution Breakdown
        let groupKey = 'Unassigned';
        if (scope === 'ALL') {
            // PERFORMANCE: Use lookup map instead of .find()
            const base = p.baseId ? lookupMaps.bases.get(p.baseId) : undefined;
            groupKey = base ? base.name : 'Float / Unassigned';
        } else {
            groupKey = team ? team.name : 'No Team';
        }

        if (!distribution[groupKey]) distribution[groupKey] = { count: 0, cost: 0 };
        distribution[groupKey].count++;
        distribution[groupKey].cost += cost;
    });

    const roleChartData = Object.keys(roleCounts).map(r => ({ name: r, value: roleCounts[r] }));
    const distributionData = Object.keys(distribution).map(k => ({ name: k, count: distribution[k].count, cost: distribution[k].cost }));

    return {
        totalHeadcount,
        totalMonthlyCapacity,
        totalMonthlyCost,
        roleChartData,
        distributionData
    };
  // PERFORMANCE: Specific dependencies instead of entire gameState
  }, [gameState.personnel, gameState.bases, lookupMaps, analysisScope]);

  // --- Render ---

  return (
    <div className="fixed inset-0 bg-[#08090a]/80 backdrop-blur-sm z-[60] flex items-center justify-center p-8">
      <div id="modal-personnel" className="bg-[#0d0e10] w-full max-w-6xl h-[90vh] rounded-xl border border-white/[0.08] shadow-2xl flex flex-col overflow-hidden">

        {/* Header */}
        <div className="bg-[#0d0e10] p-6 border-b border-white/[0.06] flex justify-between items-center shrink-0">
          <div className="flex items-center gap-3">
            <Users className="text-zinc-300" size={24} />
            <div>
                <h2 className="text-xl font-semibold text-white">Personnel Command</h2>
                <p className="text-xs text-[#6b7280]">Manage Roster, Teams, Shifts & Roles</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-[#141517] rounded-lg text-[#6b7280] hover:text-[#d1d5db] transition-colors">
            <X size={24} />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-white/[0.06] bg-[#08090a] shrink-0">
           {(['roster', 'assignments', 'roles', 'holidays', 'analysis'] as const).map(tab => (
               <button
                  key={tab}
                  id={`tab-personnel-${tab}`}
                  onClick={() => setActiveTab(tab)}
                  className={`px-6 py-4 text-sm font-semibold uppercase tracking-wide border-b-2 transition-colors ${activeTab === tab ? 'border-white/40 text-white bg-[#0d0e10]' : 'border-transparent text-[#6b7280] hover:text-[#d1d5db]'}`}
               >
                  {tab}
               </button>
           ))}
        </div>

        {/* Error Message Toast */}
        {errorMessage && (
            <div className="mx-6 mt-4 px-4 py-3 bg-rose-500/10 border border-rose-500/20 rounded-lg flex items-center gap-3 animate-in slide-in-from-top-2 duration-200">
                <AlertTriangle size={16} className="text-rose-400 shrink-0" />
                <span className="text-sm text-rose-300">{errorMessage}</span>
                <button onClick={() => setErrorMessage(null)} className="ml-auto text-rose-400 hover:text-rose-300">
                    <X size={14} />
                </button>
            </div>
        )}

        {/* Tab Content */}
        <div className="flex-1 overflow-hidden bg-[#08090a]/50">
            
            {/* ROSTER TAB */}
            {activeTab === 'roster' && (
                <div className="flex h-full">
                    {/* List */}
                    <div className="w-1/3 border-r border-white/[0.06] bg-[#0d0e10] flex flex-col">
                        {/* Fixed Header */}
                        <div className="p-4 space-y-2 shrink-0">
                            <div className="flex justify-between items-center mb-4">
                                <h3 className="font-semibold text-[#9ca3af] uppercase text-xs">Staff List ({pendingPersonnel.length})</h3>
                                <button onClick={() => handleAddPerson()} className="bg-[#3dae6c] hover:bg-[#4dc080] text-white px-3 py-1 rounded-md text-xs font-semibold flex items-center gap-1 transition-colors">
                                    <UserPlus size={12} /> Add
                                </button>
                            </div>

                            {/* Search Box */}
                            <div className="relative">
                                <Search className="absolute left-2 top-1/2 -translate-y-1/2 text-[#6b7280]" size={14} />
                                <input
                                    type="text"
                                    placeholder="Filter personnel..."
                                    value={personnelFilter}
                                    onChange={(e) => setPersonnelFilter(e.target.value)}
                                    className="w-full bg-[#141517] border border-white/[0.08] rounded-md pl-8 pr-2 py-1.5 text-xs text-[#e8e8e8] focus:border-white/40 outline-none placeholder:text-[#4b5563]"
                                />
                            </div>
                        </div>

                        {/* === VIRTUALIZATION: Scrollable personnel list === */}
                        <div
                          ref={personnelListRef}
                          className="flex-1 overflow-y-auto px-4 pb-4"
                        >
                            {pendingPersonnel.length === 0 ? (
                                <EmptyState
                                    icon={Users}
                                    title="No personnel yet"
                                    description="Add team members to calculate your shop's labor capacity."
                                    action={{ label: 'Add Staff', onClick: () => handleAddPerson() }}
                                    size="sm"
                                />
                            ) : filteredPersonnel.length === 0 ? (
                                <div className="text-center text-[#6b7280] text-xs py-4">
                                    No personnel match your filter.
                                </div>
                            ) : (
                              <div
                                style={{
                                  height: `${personnelVirtualizer.getTotalSize()}px`,
                                  width: '100%',
                                  position: 'relative',
                                }}
                              >
                                {personnelVirtualizer.getVirtualItems().map((virtualItem) => {
                                  const p = filteredPersonnel[virtualItem.index];
                                  // PERFORMANCE: Use lookup maps instead of .find() - O(1) vs O(n)
                                  const role = lookupMaps.roles.get(p.roleId);
                                  const team = p.teamId ? lookupMaps.teams.get(p.teamId) : undefined;
                                  return (
                                    <div
                                      key={p.id}
                                      style={{
                                        position: 'absolute',
                                        top: 0,
                                        left: 0,
                                        width: '100%',
                                        height: `${virtualItem.size}px`,
                                        transform: `translateY(${virtualItem.start}px)`,
                                      }}
                                    >
                                      <div
                                        onClick={() => setSelectedPerson(p)}
                                        className={`p-3 rounded-lg border cursor-pointer transition-colors flex justify-between items-center mb-2 ${selectedPerson?.id === p.id ? 'bg-white/10 border-white/40' : 'bg-[#141517] border-white/[0.08] hover:border-white/[0.15]'}`}
                                      >
                                        <div>
                                          <div className="font-semibold text-[#e8e8e8] text-sm">{p.name}</div>
                                          <div className="text-xs text-[#6b7280] flex items-center gap-2">
                                            <span>{role?.name}</span>
                                            {team && <span className={`w-2 h-2 rounded-full ${team.color}`} />}
                                          </div>
                                        </div>
                                        <ChevronRight size={16} className="text-[#4b5563]" />
                                      </div>
                                    </div>
                                  );
                                })}
                              </div>
                            )}
                        </div>
                    </div>
                    
                    {/* Detail/Edit */}
                    <div className="flex-1 p-6 bg-[#08090a] overflow-y-auto">
                        {selectedPerson ? (
                            <div className="space-y-6 max-w-2xl">
                                <div className="flex justify-between items-start border-b border-white/[0.06] pb-4">
                                    <div>
                                        <h3 className="text-lg font-semibold text-white flex items-center gap-2">
                                            <Edit2 size={18} className="text-zinc-300"/> Edit Personnel
                                        </h3>
                                        <p className="text-xs text-[#6b7280] font-mono mt-1">ID: {selectedPerson.id}</p>
                                    </div>
                                    <button
                                        onClick={() => handleDeletePerson(selectedPerson.id)}
                                        className="text-[#c4626a] hover:bg-[#c4626a]/10 p-2 rounded-md flex items-center gap-1 text-xs font-semibold transition-colors"
                                    >
                                        <Trash2 size={14} /> Terminate
                                    </button>
                                </div>

                                <div className="grid grid-cols-2 gap-6">
                                    <div>
                                        <label className="block text-xs font-semibold text-[#6b7280] uppercase mb-1">Full Name</label>
                                        <input
                                            type="text"
                                            value={selectedPerson.name}
                                            onChange={(e) => handleUpdatePerson({...selectedPerson, name: e.target.value})}
                                            className="w-full bg-[#141517] border border-white/[0.08] rounded-md p-2 text-[#e8e8e8] focus:border-white/40 outline-none"
                                        />
                                    </div>
                                    <div>
                                        <label className="block text-xs font-semibold text-[#6b7280] uppercase mb-1">Role</label>
                                        <select
                                            value={selectedPerson.roleId}
                                            onChange={(e) => handleUpdatePerson({...selectedPerson, roleId: e.target.value})}
                                            className="w-full bg-[#141517] border border-white/[0.08] rounded-md p-2 text-[#e8e8e8] focus:border-white/40 outline-none"
                                        >
                                            {pendingRoles.map(r => (
                                                <option key={r.id} value={r.id}>{r.name}</option>
                                            ))}
                                        </select>
                                    </div>
                                    <div>
                                        <label className="block text-xs font-semibold text-[#6b7280] uppercase mb-1">Assigned Team</label>
                                        <select
                                            value={selectedPerson.teamId || ''}
                                            onChange={(e) => handleUpdatePerson({...selectedPerson, teamId: e.target.value || null})}
                                            className="w-full bg-[#141517] border border-white/[0.08] rounded-md p-2 text-[#e8e8e8] focus:border-white/40 outline-none"
                                        >
                                            <option value="">-- No Assignment --</option>
                                            {pendingTeams.map(t => (
                                                <option key={t.id} value={t.id}>{t.name}</option>
                                            ))}
                                        </select>
                                    </div>
                                    <div>
                                        <label className="block text-xs font-semibold text-[#6b7280] uppercase mb-1">Base Location</label>
                                        <select
                                            value={selectedPerson.baseId || ''}
                                            onChange={(e) => handleUpdatePerson({...selectedPerson, baseId: e.target.value || undefined})}
                                            className="w-full bg-[#141517] border border-white/[0.08] rounded-md p-2 text-[#e8e8e8] focus:border-white/40 outline-none"
                                        >
                                            <option value="">-- Float / Any --</option>
                                            {gameState.bases.map(b => (
                                                <option key={b.id} value={b.id}>{b.name}</option>
                                            ))}
                                        </select>
                                    </div>
                                </div>

                                {(() => {
                                    const selectedRole = pendingRoles.find(r => r.id === selectedPerson.roleId);
                                    const roleEfficiency = selectedRole?.baseEfficiency ?? 1.0;
                                    const effectiveEfficiency = selectedPerson.efficiencyOverride ?? roleEfficiency;
                                    const isOverridden = selectedPerson.efficiencyOverride !== undefined;
                                    return (
                                        <div className="bg-[#0d0e10] p-4 rounded-lg border border-white/[0.06]">
                                            <div className="flex justify-between items-center mb-2">
                                                <label className="text-xs font-semibold text-[#9ca3af] uppercase flex items-center gap-1.5">
                                                    Performance
                                                    <HelpIcon tooltip="Override this person's efficiency vs. their role default. Use for individuals who work faster or slower than typical for their role." size={10} />
                                                </label>
                                                <div className="flex items-center">
                                                    <span className="text-xs font-mono font-semibold text-white">
                                                        {(effectiveEfficiency * 100).toFixed(0)}%
                                                    </span>
                                                    {isOverridden && (
                                                        <span className="text-[10px] text-amber-500 ml-1.5">(Overridden)</span>
                                                    )}
                                                </div>
                                            </div>
                                            <input
                                                type="range"
                                                min="50"
                                                max="150"
                                                step="5"
                                                value={Math.round(effectiveEfficiency * 100)}
                                                onChange={(e) => handleUpdatePerson({...selectedPerson, efficiencyOverride: parseInt(e.target.value) / 100})}
                                                className="w-full accent-white"
                                            />
                                            <div className="flex justify-between text-[9px] text-[#4b5563] mt-1">
                                                <span>50% (Trainee)</span>
                                                <span>100% (Std)</span>
                                                <span>150% (Elite)</span>
                                            </div>
                                            {isOverridden && (
                                                <div className="mt-2 text-right">
                                                    <button
                                                        onClick={() => handleUpdatePerson({...selectedPerson, efficiencyOverride: undefined})}
                                                        className="text-[10px] text-white hover:underline"
                                                    >
                                                        Reset to Role Default ({(roleEfficiency * 100).toFixed(0)}%)
                                                    </button>
                                                </div>
                                            )}
                                        </div>
                                    );
                                })()}

                            </div>
                        ) : (
                            <div className="h-full flex flex-col items-center justify-center text-[#4b5563]">
                                <Users size={48} className="mb-4 opacity-20" />
                                <p>Select a staff member to view details</p>
                            </div>
                        )}
                    </div>
                </div>
            )}

            {/* ASSIGNMENTS TAB (Teams, Shifts) */}
            {activeTab === 'assignments' && (
                <div className="flex h-full">
                    {/* Column 1: Teams */}
                    <div className="w-1/2 border-r border-white/[0.06] bg-[#0d0e10] overflow-y-auto p-4 space-y-6">
                        {/* Teams */}
                        <div>
                            <div className="flex justify-between items-center mb-2">
                                <h3 className="font-semibold text-[#9ca3af] uppercase text-xs flex items-center gap-2"><Briefcase size={12}/> Teams</h3>
                                <button onClick={() => handleAddTeam(pendingShifts[0]?.id)} className="p-1 hover:bg-[#141517] rounded-md text-[#3dae6c] transition-colors"><Plus size={14}/></button>
                            </div>
                            <div className="space-y-2">
                                {pendingTeams.map(team => (
                                    <div key={team.id} className="bg-[#141517] border border-white/[0.08] rounded-lg p-3 space-y-2">
                                        <div className="flex justify-between items-center">
                                            {teamEditMode[team.id] ? (
                                                <input
                                                    autoFocus
                                                    value={team.name}
                                                    onChange={(e) => handleUpdateTeam(team.id, 'name', e.target.value)}
                                                    onBlur={() => setTeamEditMode({...teamEditMode, [team.id]: false})}
                                                    className="bg-[#0d0e10] border border-white/[0.1] text-xs text-white px-1 py-0.5 rounded w-32"
                                                />
                                            ) : (
                                                <div className="flex items-center gap-2">
                                                    <div className={`w-3 h-3 rounded-full ${team.color}`} />
                                                    <span className="text-sm font-semibold text-[#e8e8e8]">{team.name}</span>
                                                </div>
                                            )}
                                            <div className="flex items-center gap-1">
                                                <button onClick={() => setTeamEditMode({...teamEditMode, [team.id]: true})} className="p-1 text-[#9ca3af] hover:text-white"><Edit2 size={12}/></button>
                                                <button onClick={() => handleDeleteTeam(team.id)} className="p-1 text-[#9ca3af] hover:text-[#c4626a]"><Trash2 size={12}/></button>
                                            </div>
                                        </div>
                                        <div className="grid grid-cols-2 gap-2 text-xs">
                                            <div>
                                                <label className="text-[#6b7280] block text-[9px] uppercase">Shift</label>
                                                <select
                                                    value={team.shiftId}
                                                    onChange={(e) => handleUpdateTeam(team.id, 'shiftId', e.target.value)}
                                                    className="w-full bg-[#0d0e10] border border-white/[0.08] rounded px-1 py-0.5 text-[#d1d5db]"
                                                >
                                                    {pendingShifts.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                                                </select>
                                            </div>
                                            <div>
                                                <label className="text-[#6b7280] block text-[9px] uppercase">Base</label>
                                                <select
                                                    value={team.baseId || ''}
                                                    onChange={(e) => handleUpdateTeam(team.id, 'baseId', e.target.value || undefined)}
                                                    className="w-full bg-[#0d0e10] border border-white/[0.08] rounded px-1 py-0.5 text-[#d1d5db]"
                                                >
                                                    {gameState.bases.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>

                    {/* Column 2: Shifts Config */}
                    <div className="flex-1 p-6 bg-[#08090a] overflow-y-auto">
                        <div className="flex justify-between items-center mb-4">
                            <h3 className="font-semibold text-[#e8e8e8] uppercase text-sm flex items-center gap-2"><Clock size={16}/> Shift Configurations</h3>
                            <button onClick={handleAddShift} className="bg-white hover:bg-zinc-100 text-[#09090b] px-3 py-1.5 rounded-md text-xs font-semibold flex items-center gap-1 transition-colors">
                                <Plus size={14} /> New Shift Profile
                            </button>
                        </div>

                        <div className="grid grid-cols-1 gap-4">
                            {pendingShifts.map(shift => (
                                <div key={shift.id} className="bg-[#0d0e10] border border-white/[0.08] rounded-lg p-4">
                                    <div className="flex justify-between items-start mb-4 border-b border-white/[0.06] pb-2">
                                        <div className="flex-1">
                                            {shiftConfigMode[shift.id] ? (
                                                <input
                                                    value={shift.name}
                                                    onChange={(e) => handleUpdateShift(shift.id, 'name', e.target.value)}
                                                    className="bg-[#141517] border border-white/[0.1] text-sm font-semibold text-white px-2 py-1 rounded w-48 mb-1"
                                                />
                                            ) : (
                                                <h4 className="font-semibold text-[#e8e8e8] text-sm">{shift.name}</h4>
                                            )}
                                        </div>
                                        <div className="flex gap-2">
                                            <button
                                                onClick={() => setShiftConfigMode(prev => ({...prev, [shift.id]: !prev[shift.id]}))}
                                                className={`p-1.5 rounded-md transition-colors ${shiftConfigMode[shift.id] ? 'bg-white/20 text-white' : 'text-[#9ca3af] hover:bg-[#141517]'}`}
                                            >
                                                <Edit2 size={14}/>
                                            </button>
                                            <button onClick={() => handleDeleteShift(shift.id)} className="p-1.5 text-[#9ca3af] hover:text-[#c4626a] hover:bg-[#141517] rounded-md transition-colors">
                                                <Trash2 size={14}/>
                                            </button>
                                        </div>
                                    </div>

                                    <div className="grid grid-cols-2 gap-6 mb-4">
                                        <div>
                                            <label className="text-[10px] font-semibold text-[#6b7280] uppercase mb-1 block">Work Days</label>
                                            <div className="flex gap-1">
                                                {['S','M','T','W','T','F','S'].map((d, idx) => (
                                                    <button
                                                        key={idx}
                                                        onClick={() => toggleShiftDay(shift.id, idx)}
                                                        className={`w-6 h-6 rounded-md flex items-center justify-center text-[10px] font-semibold transition-colors ${shift.days.includes(idx) ? 'bg-white/20 text-white' : 'bg-[#141517] text-[#4b5563] hover:bg-[#1a1b1e]'}`}
                                                    >
                                                        {d}
                                                    </button>
                                                ))}
                                            </div>
                                        </div>
                                        <div className="grid grid-cols-2 gap-2">
                                            <div>
                                                <label className="text-[10px] font-semibold text-[#6b7280] uppercase mb-1 block">Start Hour (0-23)</label>
                                                <input
                                                    type="number" min="0" max="23"
                                                    value={shift.startHour}
                                                    onChange={(e) => handleUpdateShift(shift.id, 'startHour', parseInt(e.target.value))}
                                                    className="w-full bg-[#141517] border border-white/[0.1] rounded px-2 py-1 text-xs text-white font-mono"
                                                />
                                            </div>
                                            <div>
                                                <label className="text-[10px] font-semibold text-[#6b7280] uppercase mb-1 block">Duration (Hrs)</label>
                                                <input
                                                    type="number" step="0.5"
                                                    value={shift.duration}
                                                    onChange={(e) => handleUpdateShift(shift.id, 'duration', parseFloat(e.target.value))}
                                                    className="w-full bg-[#141517] border border-white/[0.1] rounded px-2 py-1 text-xs text-white font-mono"
                                                />
                                            </div>
                                        </div>
                                    </div>

                                    <div className="bg-[#141517]/50 p-2 rounded-md border border-white/[0.06] flex items-center flex-wrap gap-4 text-xs text-[#e8e8e8]">
                                        <div className="flex items-center gap-1.5">
                                            <Coffee size={14} className="text-amber-500" />
                                            <span>Breaks:</span>
                                            <input
                                                type="number" min="0"
                                                value={shift.breakCount}
                                                onChange={(e) => handleUpdateShift(shift.id, 'breakCount', parseInt(e.target.value))}
                                                className="w-10 bg-[#0d0e10] border border-white/[0.08] rounded px-1 text-center font-mono"
                                            />
                                        </div>
                                        <div className="flex items-center gap-1">
                                            <span>Mins/Break:</span>
                                            <input
                                                type="number" step="5"
                                                value={shift.breakDuration}
                                                onChange={(e) => handleUpdateShift(shift.id, 'breakDuration', parseInt(e.target.value))}
                                                className="w-12 bg-[#0d0e10] border border-white/[0.08] rounded px-1 text-center font-mono"
                                            />
                                        </div>
                                        <div className="flex items-center gap-1">
                                            <span>Daily Meeting:</span>
                                            <input
                                                type="number" step="5" min="0"
                                                value={shift.meetingDuration || 0}
                                                onChange={(e) => handleUpdateShift(shift.id, 'meetingDuration', parseInt(e.target.value))}
                                                className="w-12 bg-[#0d0e10] border border-white/[0.08] rounded px-1 text-center font-mono"
                                            />
                                            <span className="text-[10px] text-[#6b7280]">mins</span>
                                        </div>
                                        <div className="ml-auto text-[#6b7280] font-semibold border-l border-white/[0.08] pl-3">
                                            Eff. Hours: {(shift.duration - (((shift.breakCount || 0) * (shift.breakDuration || 0)) + (shift.meetingDuration || 0)) / 60).toFixed(1)}h
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            )}

            {/* ROLES TAB */}
            {activeTab === 'roles' && (
                <div className="flex flex-col h-full">
                    {/* Header with Role Definitions title and Package Selector */}
                    <div className="p-6 border-b border-white/[0.06] bg-[#0d0e10] shrink-0">
                        <div className="flex justify-between items-start">
                            <div>
                                 <h3 className="text-lg font-semibold text-[#e8e8e8] flex items-center gap-2">
                                    <Shield size={18} className="text-zinc-300"/> Role Definitions
                                 </h3>
                                 <p className="text-[#6b7280] text-sm">Base values automatically apply to all staff with the role unless manually overridden.</p>
                            </div>
                            {/* Role Packages Section */}
                            <div className="flex items-center gap-3">
                                <div className="flex items-center gap-2">
                                    <Package size={16} className="text-amber-500" />
                                    <select
                                        value={selectedPackageId}
                                        onChange={(e) => handleSelectPackage(e.target.value)}
                                        className="bg-[#141517] border border-white/[0.08] rounded-md px-3 py-1.5 text-sm text-[#e8e8e8] focus:border-white/40 outline-none min-w-[200px]"
                                    >
                                        <option value="">Select Role Package...</option>
                                        {ROLE_PACKAGES.map(pkg => (
                                            <option key={pkg.id} value={pkg.id}>{pkg.name}</option>
                                        ))}
                                    </select>
                                </div>
                                <button
                                    onClick={handleEditPackages}
                                    disabled={!selectedPackageId}
                                    className={`px-3 py-1.5 rounded-md text-xs font-semibold flex items-center gap-1 transition-colors ${
                                        selectedPackageId
                                            ? 'bg-amber-600 hover:bg-amber-500 text-white'
                                            : 'bg-[#141517] text-[#4b5563] cursor-not-allowed'
                                    }`}
                                >
                                    <Edit2 size={12} /> Edit & Load
                                </button>
                            </div>
                        </div>
                        {selectedPackageId && !showPackageEditor && (
                            <div className="mt-3 p-3 bg-amber-500/10 border border-amber-500/30 rounded-lg">
                                <p className="text-xs text-amber-400">
                                    <span className="font-semibold">{ROLE_PACKAGES.find(p => p.id === selectedPackageId)?.name}:</span>{' '}
                                    {ROLE_PACKAGES.find(p => p.id === selectedPackageId)?.description}
                                </p>
                            </div>
                        )}
                    </div>

                    {/* Package Editor Modal */}
                    {showPackageEditor && (
                        <div className="p-6 bg-[#141517] border-b border-white/[0.06] space-y-4">
                            <div className="flex justify-between items-center">
                                <h4 className="text-sm font-semibold text-amber-400 flex items-center gap-2">
                                    <Package size={16} /> Editing: {ROLE_PACKAGES.find(p => p.id === selectedPackageId)?.name}
                                </h4>
                                <div className="flex gap-2">
                                    <button
                                        onClick={handleAddEditableRole}
                                        className="bg-[#3dae6c] hover:bg-[#4dc080] text-white px-3 py-1 rounded-md text-xs font-semibold flex items-center gap-1 transition-colors"
                                    >
                                        <Plus size={12} /> Add Role
                                    </button>
                                    <button
                                        onClick={handleCancelPackageEdit}
                                        className="bg-[#0d0e10] hover:bg-[#1a1b1e] text-[#9ca3af] px-3 py-1 rounded-md text-xs font-semibold transition-colors"
                                    >
                                        Cancel
                                    </button>
                                    <button
                                        onClick={handleLoadPackage}
                                        className="bg-white hover:bg-zinc-100 text-[#09090b] px-3 py-1 rounded-md text-xs font-semibold flex items-center gap-1 transition-colors"
                                    >
                                        <Upload size={12} /> Load Package
                                    </button>
                                </div>
                            </div>
                            <p className="text-[10px] text-[#6b7280]">Modify roles below before loading. Loading will replace all current roles.</p>

                            {/* Editable Package Roles Table */}
                            <div className="bg-[#0d0e10] rounded-lg border border-white/[0.08] overflow-hidden">
                                <div className="flex text-[10px] font-semibold text-[#6b7280] uppercase border-b border-white/[0.08] p-2 gap-2">
                                    <div className="flex-1">Role Name</div>
                                    <div className="w-20 text-center flex items-center justify-center gap-1">
                                        Efficiency
                                        <HelpIcon tooltip="Performance multiplier. 1.0 = standard, 1.2 = 20% faster." size={9} />
                                    </div>
                                    <div className="w-24 text-center flex items-center justify-center gap-1">
                                        Hourly Rate
                                        <HelpIcon tooltip="Base wage before burden costs." size={9} />
                                    </div>
                                    <div className="w-20 text-center flex items-center justify-center gap-1">
                                        Burden %
                                        <HelpIcon tooltip="Employer cost multiplier (taxes, benefits)." size={9} />
                                    </div>
                                    <div className="w-28 text-center">Burdened Cost</div>
                                    <div className="w-8"></div>
                                </div>
                                <div className="max-h-48 overflow-y-auto">
                                    {editablePackageRoles.map((role, index) => (
                                        <div key={role.tempId} className="flex items-center p-2 gap-2 border-b border-white/[0.04] hover:bg-white/[0.02]">
                                            <input
                                                type="text"
                                                value={role.name}
                                                onChange={(e) => handleUpdateEditableRole(index, 'name', e.target.value)}
                                                className="flex-1 bg-[#141517] border border-white/[0.08] rounded px-2 py-1 text-xs text-[#e8e8e8] focus:border-white/40 outline-none"
                                            />
                                            <div className="w-20 relative">
                                                <input
                                                    type="number" step="5" min="50" max="200"
                                                    value={Math.round(role.baseEfficiency * 100)}
                                                    onChange={(e) => handleUpdateEditableRole(index, 'baseEfficiency', parseInt(e.target.value) / 100)}
                                                    className="w-full bg-[#141517] border border-white/[0.08] rounded px-2 py-1 text-xs text-center text-[#e8e8e8] font-mono focus:border-white/40 outline-none"
                                                />
                                                <span className="absolute -right-2 top-1/2 -translate-y-1/2 text-[#6b7280] text-[10px]">%</span>
                                            </div>
                                            <div className="w-24 relative">
                                                <span className="absolute left-2 top-1/2 -translate-y-1/2 text-[#6b7280] text-[10px]">$</span>
                                                <input
                                                    type="number" step="1"
                                                    value={role.hourlyRate}
                                                    onChange={(e) => handleUpdateEditableRole(index, 'hourlyRate', parseFloat(e.target.value))}
                                                    className="w-full bg-[#141517] border border-white/[0.08] rounded pl-4 pr-1 py-1 text-xs text-center text-[#e8e8e8] font-mono focus:border-white/40 outline-none"
                                                />
                                            </div>
                                            <div className="w-20 relative">
                                                <input
                                                    type="number" step="0.01" min="1" max="3"
                                                    value={role.burdenMultiplier}
                                                    onChange={(e) => handleUpdateEditableRole(index, 'burdenMultiplier', parseFloat(e.target.value))}
                                                    className="w-full bg-[#141517] border border-white/[0.08] rounded px-1 py-1 text-xs text-center text-[#e8e8e8] font-mono focus:border-white/40 outline-none"
                                                />
                                            </div>
                                            <div className="w-28 text-center text-xs text-[#3dae6c] font-mono font-semibold">
                                                ${role.hourlyCost}
                                            </div>
                                            <button
                                                onClick={() => handleDeleteEditableRole(index)}
                                                className="w-8 text-[#6b7280] hover:text-[#c4626a] p-1 rounded hover:bg-[#c4626a]/10 transition-colors"
                                            >
                                                <Trash2 size={12} />
                                            </button>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>
                    )}

                    {/* Role Definitions Card */}
                    <div className="flex-1 overflow-y-auto p-6 bg-[#08090a]/50">
                        <div className="bg-[#0d0e10] rounded-xl border border-white/[0.08] overflow-hidden">
                            {/* Card Header with Add Role Button */}
                            <div className="flex justify-between items-center p-4 border-b border-white/[0.06] bg-[#141517]/50">
                                <span className="text-xs font-semibold text-[#9ca3af] uppercase tracking-wide">Active Roles ({pendingRoles.length})</span>
                                <button
                                    onClick={handleAddRole}
                                    className="bg-white hover:bg-zinc-100 text-[#09090b] px-3 py-1.5 rounded-md text-xs font-semibold flex items-center gap-1 transition-colors"
                                >
                                    <Plus size={14} /> Add Role
                                </button>
                            </div>

                            {/* Column Headers */}
                            <div className="flex text-[10px] font-semibold text-[#6b7280] uppercase border-b border-white/[0.08] py-2 px-2 gap-3 pl-10">
                                <div className="flex-1 pl-2">Role Name</div>
                                <div className="w-24 text-center flex items-center justify-center gap-1">
                                    Efficiency
                                    <HelpIcon tooltip="Performance multiplier. 1.0 = standard, 1.2 = 20% faster work, 0.8 = 20% slower. Affects capacity calculations." size={10} />
                                </div>
                                <div className="w-28 text-center flex items-center justify-center gap-1">
                                    Hourly Rate
                                    <HelpIcon tooltip="Base wage per hour before burden (taxes, benefits, insurance) is added." size={10} />
                                </div>
                                <div className="w-24 text-center flex items-center justify-center gap-1">
                                    Burden %
                                    <HelpIcon tooltip="Multiplier for employer costs (payroll taxes, health insurance, retirement). 1.35 = 35% added to base wage." size={10} />
                                </div>
                                <div className="w-32 text-center flex items-center justify-center gap-1">
                                    Burdened Cost
                                    <HelpIcon tooltip="True hourly cost = Base Rate × Burden Multiplier. This is what each hour actually costs your business." size={10} />
                                </div>
                                <div className="w-20 text-center">Staff</div>
                                <div className="w-10"></div>
                            </div>

                            {/* Role Rows */}
                            <div className="divide-y divide-white/[0.04]">
                                {pendingRoles.map((role, index) => {
                                    // PERFORMANCE: Use pre-computed map instead of O(n) filter
                                    const staffCount = lookupMaps.personnelByRole.get(role.id)?.length ?? 0;
                                    return (
                                        <div
                                            key={role.id}
                                            draggable={draggableRoleIndex === index}
                                            onDragStart={(e) => handleDragStartRole(e, index)}
                                            onDragOver={handleDragOverRole}
                                            onDrop={(e) => handleDropRole(e, index)}
                                            className={`flex items-center p-2 hover:bg-white/[0.02] transition-colors group gap-3 ${draggableRoleIndex === index ? 'opacity-50 bg-white/10' : ''}`}
                                        >
                                            {/* Drag Handle */}
                                            <div
                                                className="text-[#4b5563] hover:text-[#d1d5db] p-1 cursor-grab active:cursor-grabbing flex items-center justify-center"
                                                onMouseEnter={() => setDraggableRoleIndex(index)}
                                                onMouseLeave={() => setDraggableRoleIndex(null)}
                                            >
                                                <GripVertical size={16} />
                                            </div>

                                            {/* Role Name */}
                                            <div className="flex-1 pl-2">
                                                <input
                                                    type="text"
                                                    value={role.name}
                                                    onChange={(e) => handleUpdateRole(role.id, 'name', e.target.value)}
                                                    className="w-full bg-transparent border-b border-transparent hover:border-white/[0.1] focus:border-white/40 outline-none text-[#e8e8e8] font-semibold text-sm py-1 transition-colors"
                                                    placeholder="Role Name"
                                                />
                                            </div>

                                            {/* Base Efficiency */}
                                            <div className="w-24 flex justify-center">
                                                <div className="relative">
                                                    <input
                                                        type="number" step="5" min="50" max="200"
                                                        value={Math.round(role.baseEfficiency * 100)}
                                                        onChange={(e) => handleUpdateRole(role.id, 'baseEfficiency', parseInt(e.target.value) / 100)}
                                                        className="w-16 bg-[#08090a] border border-white/[0.08] rounded px-2 py-1 text-center text-[#e8e8e8] font-mono text-xs focus:border-white/40 outline-none"
                                                    />
                                                    <span className="absolute -right-3 top-1/2 -translate-y-1/2 text-[#6b7280] text-[10px]">%</span>
                                                </div>
                                            </div>

                                            {/* Hourly Rate */}
                                            <div className="w-28 flex justify-center">
                                                <div className="relative">
                                                    <span className="absolute left-2 top-1/2 -translate-y-1/2 text-[#6b7280] text-[10px]">$</span>
                                                    <input
                                                        type="number" step="1"
                                                        value={role.hourlyRate || 0}
                                                        onChange={(e) => handleUpdateRoleWithCalc(role.id, 'hourlyRate', parseFloat(e.target.value))}
                                                        className="w-20 bg-[#08090a] border border-white/[0.08] rounded pl-4 pr-2 py-1 text-center text-[#e8e8e8] font-mono text-xs focus:border-white/40 outline-none"
                                                    />
                                                </div>
                                            </div>

                                            {/* Burden Multiplier */}
                                            <div className="w-24 flex justify-center">
                                                <div className="relative">
                                                    <input
                                                        type="number" step="0.01" min="1" max="3"
                                                        value={role.burdenMultiplier || DEFAULT_BURDEN_MULTIPLIER}
                                                        onChange={(e) => handleUpdateRoleWithCalc(role.id, 'burdenMultiplier', parseFloat(e.target.value))}
                                                        className="w-16 bg-[#08090a] border border-white/[0.08] rounded px-2 py-1 text-center text-[#e8e8e8] font-mono text-xs focus:border-white/40 outline-none"
                                                    />
                                                    <span className="absolute right-1 top-1/2 -translate-y-1/2 text-[#6b7280] text-[10px]">×</span>
                                                </div>
                                            </div>

                                            {/* Fully Burdened Hourly Cost (calculated, read-only display) */}
                                            <div className="w-32 text-center">
                                                <span className="bg-emerald-500/20 text-[#3dae6c] px-3 py-1 rounded text-xs font-mono font-semibold border border-emerald-500/30">
                                                    ${role.hourlyCost || 0}
                                                </span>
                                            </div>

                                            {/* Staff Count */}
                                            <div className="w-20 text-center">
                                                <span className="bg-[#141517] text-[#9ca3af] px-2 py-1 rounded text-xs font-mono border border-white/[0.08]">
                                                    {staffCount}
                                                </span>
                                            </div>

                                            {/* Delete Button */}
                                            <div className="w-10 flex justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                                <button
                                                    onClick={() => handleDeleteRole(role.id, staffCount)}
                                                    className="text-[#6b7280] hover:text-[#c4626a] p-1.5 rounded-md hover:bg-[#c4626a]/10 transition-colors"
                                                    title="Delete Role"
                                                >
                                                    <Trash2 size={14} />
                                                </button>
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {/* HOLIDAYS TAB */}
            {activeTab === 'holidays' && (
                <div className="p-8 h-full overflow-y-auto bg-[#08090a]">
                     <h3 className="text-sm font-semibold text-[#9ca3af] uppercase mb-4 flex items-center gap-2"><Calendar size={16}/> Observed Holidays</h3>
                     <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {/* Group by Year */}
                        {[START_YEAR, START_YEAR+1, START_YEAR+2, START_YEAR+3].map(year => (
                            <div key={year} className="bg-[#0d0e10] border border-white/[0.08] rounded-lg overflow-hidden">
                                <div className="bg-[#141517] px-4 py-2 font-semibold text-[#d1d5db] text-sm border-b border-white/[0.06] flex justify-between items-center">
                                    <span>{year}</span>
                                    <span className="text-xs font-normal text-[#6b7280]">
                                        {gameState.holidays.filter(h => h.date.startsWith(`${year}-`) && h.enabled).length} Active
                                    </span>
                                </div>
                                <div className="p-2 space-y-1">
                                    {gameState.holidays
                                        .filter(h => h.date.startsWith(`${year}-`))
                                        .map(h => (
                                            <div key={h.id} className="flex items-center justify-between p-2 hover:bg-[#141517]/50 rounded-md transition-colors">
                                                <div className={`flex flex-col ${!h.enabled && 'opacity-50 grayscale'}`}>
                                                    <span className="text-xs font-semibold text-[#d1d5db]">{h.name}</span>
                                                    <span className="text-[10px] text-[#6b7280]">{h.date}</span>
                                                </div>
                                                <button
                                                    onClick={() => {
                                                        const updated = gameState.holidays.map(hol => hol.id === h.id ? { ...hol, enabled: !hol.enabled } : hol);
                                                        onUpdateHolidays(updated);
                                                    }}
                                                    className={`w-8 h-4 rounded-full relative transition-colors ${h.enabled ? 'bg-emerald-600' : 'bg-[#1a1b1e]'}`}
                                                >
                                                    <div className={`absolute top-0.5 w-3 h-3 bg-white rounded-full transition-all ${h.enabled ? 'left-4.5' : 'left-0.5'}`} />
                                                </button>
                                            </div>
                                        ))}
                                </div>
                            </div>
                        ))}
                     </div>
                </div>
            )}

            {/* ANALYSIS TAB */}
            {activeTab === 'analysis' && (
                <div className="flex flex-col h-full bg-[#08090a] overflow-hidden">
                    {/* Controls Bar */}
                    <div className="p-4 bg-[#0d0e10] border-b border-white/[0.06] flex justify-between items-center shrink-0">
                        <div className="flex items-center gap-4">
                            <h3 className="text-sm font-semibold text-[#d1d5db] flex items-center gap-2 uppercase tracking-wide">
                                <Activity size={16} className="text-zinc-300" /> Operational Analysis
                            </h3>
                            <div className="h-4 w-px bg-white/[0.08]" />
                            <div className="flex items-center gap-2">
                                <span className="text-xs text-[#6b7280] font-semibold uppercase">View Scope:</span>
                                <select
                                    value={analysisScope}
                                    onChange={(e) => setAnalysisScope(e.target.value)}
                                    className="bg-[#141517] border border-white/[0.1] text-xs text-white rounded-md px-2 py-1 focus:border-white/40 outline-none"
                                >
                                    <option value="ALL">Whole Company</option>
                                    <option value="Unassigned">Unassigned / Float</option>
                                    {gameState.bases.map(b => (
                                        <option key={b.id} value={b.id}>{b.name}</option>
                                    ))}
                                </select>
                            </div>
                        </div>

                        {/* Projection Period Toggle */}
                        <div className="flex items-center gap-2">
                            <span className="text-xs text-[#6b7280] font-semibold uppercase">Projection:</span>
                            <div className="flex gap-1">
                                {([1, 3, 12] as const).map(period => (
                                    <button
                                        key={period}
                                        onClick={() => setProjectionPeriod(period)}
                                        className={`px-3 py-1 rounded-md text-xs font-semibold transition-colors ${
                                            projectionPeriod === period
                                                ? 'bg-white/20 text-white'
                                                : 'bg-[#141517] text-[#4b5563] hover:bg-[#1a1b1e]'
                                        }`}
                                    >
                                        {period === 1 ? '1 Mo' : period === 3 ? '3 Mo' : '1 Yr'}
                                    </button>
                                ))}
                            </div>
                        </div>
                    </div>

                    {/* Dashboard Content */}
                    <div className="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar">
                        {/* KPI Row */}
                        <div className="grid grid-cols-4 gap-4">
                            <div className="bg-[#0d0e10] p-4 rounded-xl border border-white/[0.08]">
                                <div className="text-xs font-semibold text-[#6b7280] uppercase mb-1 flex items-center gap-1">
                                    <Users size={12} /> Headcount
                                </div>
                                <div className="text-2xl font-semibold text-[#e8e8e8]">{analysisData.totalHeadcount}</div>
                                <div className="text-[10px] text-[#6b7280] mt-1">Active Personnel in Scope</div>
                            </div>

                            <div className="bg-[#0d0e10] p-4 rounded-xl border border-white/[0.08]">
                                <div className="text-xs font-semibold text-[#6b7280] uppercase mb-1 flex items-center gap-1">
                                    <Clock size={12} /> {projectionPeriod === 1 ? 'Monthly' : projectionPeriod === 3 ? 'Quarterly' : 'Annual'} Capacity
                                </div>
                                <div className="text-2xl font-semibold text-amber-500 font-mono">{Math.round(analysisData.totalMonthlyCapacity * projectionPeriod).toLocaleString()}</div>
                                <div className="text-[10px] text-[#6b7280] mt-1">Billable Hours / {projectionPeriod === 1 ? 'Month' : projectionPeriod === 3 ? 'Quarter' : 'Year'}</div>
                            </div>

                            <div className="bg-[#0d0e10] p-4 rounded-xl border border-white/[0.08]">
                                <div className="text-xs font-semibold text-[#6b7280] uppercase mb-1 flex items-center gap-1">
                                    <DollarSign size={12} /> Est. Labor Cost
                                </div>
                                <div className="text-2xl font-semibold text-rose-400 font-mono">{DOLLAR_SIGN_SYMBOL}{Math.round(analysisData.totalMonthlyCost * projectionPeriod).toLocaleString()}</div>
                                <div className="text-[10px] text-[#6b7280] mt-1">{projectionPeriod === 1 ? 'Monthly' : projectionPeriod === 3 ? 'Quarterly' : 'Annual'} Payroll (Approx)</div>
                            </div>

                            <div className="bg-[#0d0e10] p-4 rounded-xl border border-white/[0.08]">
                                <div className="text-xs font-semibold text-[#6b7280] uppercase mb-1 flex items-center gap-1">
                                    <TrendingUp size={12} /> Efficiency Avg
                                </div>
                                <div className="text-2xl font-semibold text-white font-mono">
                                    {analysisData.totalHeadcount > 0
                                        ? Math.round((analysisData.totalMonthlyCapacity / (analysisData.totalHeadcount * 160)) * 100)
                                        : 0}%
                                </div>
                                <div className="text-[10px] text-[#6b7280] mt-1">Weighted Team Performance</div>
                            </div>
                        </div>

                        {/* Charts Row */}
                        <div className="grid grid-cols-2 gap-6 h-64">
                            <div className="bg-[#0d0e10] p-4 rounded-xl border border-white/[0.08] flex flex-col">
                                <h4 className="text-xs font-semibold text-[#9ca3af] uppercase mb-4 flex items-center gap-2"><PieChartIcon size={14}/> Role Distribution</h4>
                                <div className="flex-1 min-h-0">
                                    <ResponsiveContainer width="100%" height="100%" minHeight={150}>
                                        <PieChart>
                                            <Pie
                                                data={analysisData.roleChartData}
                                                cx="50%"
                                                cy="50%"
                                                innerRadius={40}
                                                outerRadius={70}
                                                paddingAngle={5}
                                                dataKey="value"
                                                isAnimationActive={true}
                                                animationDuration={250}
                                            >
                                                {analysisData.roleChartData.map((entry, index) => (
                                                    <Cell key={`cell-${index}`} fill={['#818cf8', '#22c55e', '#eab308', '#f43f5e'][index % 4]} />
                                                ))}
                                            </Pie>
                                            <RechartsTooltip contentStyle={{ backgroundColor: '#141517', borderColor: 'rgba(255,255,255,0.1)', fontSize: '12px' }} itemStyle={{ color: '#f8fafc' }} />
                                            <Legend wrapperStyle={{ fontSize: '10px' }} />
                                        </PieChart>
                                    </ResponsiveContainer>
                                </div>
                            </div>

                            <div className="bg-[#0d0e10] p-4 rounded-xl border border-white/[0.08] flex flex-col">
                                <h4 className="text-xs font-semibold text-[#9ca3af] uppercase mb-4 flex items-center gap-2">
                                    <BarChartIcon size={14}/> {projectionPeriod === 1 ? 'Monthly' : projectionPeriod === 3 ? 'Quarterly' : 'Annual'} Cost Distribution
                                </h4>
                                <div className="flex-1 min-h-0">
                                    <ResponsiveContainer width="100%" height="100%" minHeight={150}>
                                        <BarChart data={analysisData.distributionData.map(d => ({ ...d, cost: d.cost * projectionPeriod }))} layout="vertical" margin={{ left: 20 }}>
                                            <XAxis type="number" hide />
                                            <YAxis type="category" dataKey="name" width={80} tick={{ fontSize: 10, fill: '#9ca3af' }} />
                                            <RechartsTooltip cursor={{fill: 'transparent'}} contentStyle={{ backgroundColor: '#141517', borderColor: 'rgba(255,255,255,0.1)', fontSize: '12px' }} formatter={(val: number) => `${DOLLAR_SIGN_SYMBOL}${Math.round(val).toLocaleString()}`} />
                                            <Bar dataKey="cost" fill="#4b5563" radius={[0, 4, 4, 0]} barSize={20} isAnimationActive={true} animationDuration={200}>
                                                {analysisData.distributionData.map((entry, index) => (
                                                    <Cell key={`cell-${index}`} fill={index % 2 === 0 ? '#3f3f46' : '#27272a'} />
                                                ))}
                                            </Bar>
                                        </BarChart>
                                    </ResponsiveContainer>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            )}

        </div>

        {/* === BATCHED SAVE: Save/Discard Footer === */}
        {hasUnsavedChanges && (
            <div className="shrink-0 px-6 py-3 bg-[#141517] border-t border-white/[0.08] flex items-center justify-between">
                <div className="flex items-center gap-2 text-amber-400">
                    <AlertCircle size={16} />
                    <span className="text-sm font-medium">You have unsaved changes</span>
                </div>
                <div className="flex items-center gap-3">
                    <button
                        onClick={handleDiscardChanges}
                        className="px-4 py-2 text-sm font-semibold text-[#9ca3af] hover:text-white hover:bg-white/10 rounded-lg transition-colors"
                    >
                        Discard
                    </button>
                    <button
                        onClick={handleSaveChanges}
                        className="px-4 py-2 text-sm font-semibold bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg transition-colors flex items-center gap-2"
                    >
                        <Save size={14} />
                        Save Changes
                    </button>
                </div>
            </div>
        )}
      </div>
    </div>
  );
};

// PERFORMANCE: Wrap with React.memo to prevent unnecessary re-renders
export default React.memo(PersonnelManager);
