import React, { useMemo } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { GameState } from '../types';
import { DOLLAR_SIGN } from '../App';
import { ChevronsUp, ChevronsDown, ExternalLink, Calendar, Target, TrendingUp, TrendingDown, Users, Warehouse, MousePointerClick, Filter, AlertTriangle, Clock } from 'lucide-react';
import { START_YEAR, HOURLY_COST_AVG } from '../constants';

interface AnalyticsPanelProps {
  gameState: GameState;
  isOpen: boolean;
  onToggle: () => void;
  isPoppedOut: boolean;
  onPopOut: () => void;
  scenarioStart: number;
  scenarioEnd: number;
  setScenarioStart: (day: number) => void;
  setScenarioEnd: (day: number) => void;
  onEditCash?: () => void;
  height?: number;
  selectedBaseId?: string;
}

// --- Date Helpers ---
const getDateStr = (dayIndex: number) => {
    const date = new Date(START_YEAR, 0, 1);
    date.setDate(dayIndex + 1);
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, '0');
    const d = String(date.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
};

const getDayIndex = (dateStr: string) => {
    if (!dateStr) return 0;
    const [y, m, d] = dateStr.split('-').map(Number);
    const date = new Date(y, m - 1, d);
    const start = new Date(START_YEAR, 0, 1);
    const diff = date.getTime() - start.getTime();
    return Math.round(diff / (1000 * 60 * 60 * 24));
};

const AnalyticsPanel: React.FC<AnalyticsPanelProps> = ({
  gameState, isOpen, onToggle, isPoppedOut, onPopOut, scenarioStart, scenarioEnd, setScenarioStart, setScenarioEnd, onEditCash, height, selectedBaseId
}) => {

  // === PERFORMANCE: Pre-computed lookup maps for O(1) access ===
  const lookupMaps = useMemo(() => ({
    roles: new Map(gameState.roles.map(r => [r.id, r])),
    teams: new Map(gameState.teams.map(t => [t.id, t])),
    shifts: new Map(gameState.shifts.map(s => [s.id, s])),
    holidaySet: new Set(gameState.holidays.filter(h => h.enabled).map(h => h.dayIndex))
  }), [gameState.roles, gameState.teams, gameState.shifts, gameState.holidays]);

  const reportingStart = scenarioStart;
  const reportingEnd = scenarioEnd;

  const { periodCapacity, periodSoldHours, plannedRevenue, plannedLabor, plannedOverhead, receivables, periodOvertimeHours, periodOvertimeCost } = useMemo(() => {
      let cap = 0, sold = 0, pRev = 0, pLabor = 0, pOverhead = 0, rec = 0;
      const dailyOvertimeHours = new Float32Array(3000); // Arbitrary large buffer for simplicity or map
      const dailyCapacity = new Float32Array(3000);
      const dailyLoad = new Float32Array(3000);

      const isGlobal = !selectedBaseId || selectedBaseId === 'ALL';
      const relevantPersonnel = isGlobal ? gameState.personnel : gameState.personnel.filter(p => p.baseId === selectedBaseId);
      const relevantHangars = isGlobal ? gameState.hangars : gameState.hangars.filter(h => h.baseId === selectedBaseId);
      const relevantHangarIds = relevantHangars.map(h => h.id);
      
      // 1. Calculate Capacity per day in range
      const dailyLaborCostByWeekday = new Float32Array(7);
      let totalAvgRate = 0;
      let staffCount = 0;

      relevantPersonnel.forEach(p => {
          // PERFORMANCE: Use lookup maps instead of .find() - O(1) vs O(n)
          const team = p.teamId ? lookupMaps.teams.get(p.teamId) : undefined;
          const role = lookupMaps.roles.get(p.roleId);
          const rate = role?.hourlyCost || HOURLY_COST_AVG;
          totalAvgRate += rate;
          staffCount++;

          if (team) {
              const shift = lookupMaps.shifts.get(team.shiftId);
              if (shift && role) {
                  const dailyCost = shift.duration * rate;
                  shift.days.forEach(dayIdx => { dailyLaborCostByWeekday[dayIdx] += dailyCost; });
                  
                  // Capacity
                  const totalBreakHours = (((shift.breakCount || 0) * (shift.breakDuration || 0)) + (shift.meetingDuration || 0)) / 60;
                  // eslint-disable-next-line @typescript-eslint/no-unused-vars
                  const effectiveDuration = Math.max(0, shift.duration - totalBreakHours);
                  // eslint-disable-next-line @typescript-eslint/no-unused-vars
                  const efficiency = p.efficiencyOverride ?? role.baseEfficiency ?? 1.0;
                  
                  /* 
                  shift.days.forEach(dayOfWeek => {
                      // Note: We need to map dayOfWeek to actual day indices in the loop below
                  });
                  */
              }
          }
      });
      
      const avgLaborRate = staffCount > 0 ? totalAvgRate / staffCount : HOURLY_COST_AVG;

      for (let d = reportingStart; d <= reportingEnd; d++) {
          const date = new Date(START_YEAR, 0, 1 + d);
          const dayOfWeek = date.getDay(); 
          // PERFORMANCE: Use pre-computed Set instead of .some()
          const isHoliday = lookupMaps.holidaySet.has(d);
          let overheadShare = 1.0;
          if (!isGlobal && gameState.personnel.length > 0) overheadShare = relevantPersonnel.length / gameState.personnel.length;
          pOverhead += (gameState.overheadDaily * overheadShare);
          
          if (!isHoliday) {
              pLabor += dailyLaborCostByWeekday[dayOfWeek];
              
              // Recalculate explicit capacity for this specific day to handle the array properly
              relevantPersonnel.forEach(p => {
                  // PERFORMANCE: Use lookup maps instead of .find() - O(1) vs O(n)
                  const team = p.teamId ? lookupMaps.teams.get(p.teamId) : undefined;
                  if (team) {
                      const shift = lookupMaps.shifts.get(team.shiftId);
                      if (shift && shift.days.includes(dayOfWeek)) {
                          const role = lookupMaps.roles.get(p.roleId);
                          const efficiency = p.efficiencyOverride ?? role?.baseEfficiency ?? 1.0;
                          const totalBreakHours = (((shift.breakCount || 0) * (shift.breakDuration || 0)) + (shift.meetingDuration || 0)) / 60;
                          const effectiveDuration = Math.max(0, shift.duration - totalBreakHours);
                          dailyCapacity[d] += (effectiveDuration * efficiency);
                      }
                  }
              });
              cap += dailyCapacity[d];
          }
      }

      // 2. Calculate Load per day
      gameState.schedule.forEach(job => {
          if (!relevantHangarIds.includes(job.hangarId)) return;
          const jobStart = job.startDate;
          const jobLastActiveDay = jobStart + job.deadlineDays - 1;
          const overlapStart = Math.max(jobStart, reportingStart);
          const overlapEnd = Math.min(jobLastActiveDay, reportingEnd);
          
          // Also need to populate dailyLoad for OT calc even if outside report window?
          // For accuracy, we only care about overlap for the report metrics.
          
          if (overlapStart <= overlapEnd) {
               let totalWeight = 0;
               const weights: number[] = [];
               for (let i = 0; i < job.deadlineDays; i++) {
                   let w = 1;
                   if (job.dailyEffort && job.dailyEffort[i] !== undefined) w = job.dailyEffort[i];
                   else if (job.nonWorkDays?.includes(i)) w = 0;
                   weights[i] = w;
                   totalWeight += w;
               }

               for (let d = overlapStart; d <= overlapEnd; d++) {
                   const relativeDay = d - jobStart;
                   let dailyEffort = 0;
                   let dailyRev = 0;
                   if (totalWeight > 0) {
                       const weight = weights[relativeDay];
                       dailyEffort = (weight / totalWeight) * job.estimatedHours;
                       dailyRev = (weight / totalWeight) * job.revenue;
                   }
                   sold += dailyEffort;
                   dailyLoad[d] += dailyEffort;
                   pRev += dailyRev;
               }
          }
          const isRelevantToPeriod = (jobStart <= reportingEnd && jobLastActiveDay >= reportingStart);
          if (isRelevantToPeriod) {
              const isPaid = job.status === 'Completed' && job.paymentReceived;
              if (!isPaid) rec += job.revenue;
          }
      });

      // 3. Calculate OT
      let otHoursTotal = 0;
      let otCostTotal = 0;
      for (let d = reportingStart; d <= reportingEnd; d++) {
          if (dailyLoad[d] > dailyCapacity[d]) {
              const ot = dailyLoad[d] - dailyCapacity[d];
              otHoursTotal += ot;
              otCostTotal += (ot * avgLaborRate * 1.5);
          }
      }
      
      // Add OT Cost to Planned Labor
      pLabor += otCostTotal;

      return { periodCapacity: cap, periodSoldHours: sold, plannedRevenue: pRev, plannedLabor: pLabor, plannedOverhead: pOverhead, receivables: rec, periodOvertimeHours: otHoursTotal, periodOvertimeCost: otCostTotal };
  // PERFORMANCE: Using lookupMaps for O(1) lookups; dependencies updated accordingly
  }, [gameState.day, gameState.personnel, gameState.schedule, reportingStart, reportingEnd, gameState.overheadDaily, selectedBaseId, gameState.hangars, lookupMaps]);

  const utilization = periodCapacity > 0 ? (periodSoldHours / periodCapacity) * 100 : 0;
  const otPercent = periodCapacity > 0 ? (periodOvertimeHours / periodCapacity) * 100 : 0;
  const isOverburdened = utilization > 100;
  const plannedExpenses = plannedLabor + plannedOverhead;
  const netPlan = plannedRevenue - plannedExpenses;
  const laborData = [ { name: 'Sold', hours: Math.round(periodSoldHours), fill: isOverburdened ? '#f43f5e' : '#06b6d4' }, { name: 'Cap', hours: Math.round(periodCapacity), fill: '#334155' } ];
  const currentBaseName = useMemo(() => { if (!selectedBaseId || selectedBaseId === 'ALL') return 'Global'; const base = gameState.bases.find(b => b.id === selectedBaseId); return base ? base.name : 'Unknown Base'; }, [selectedBaseId, gameState.bases]);

  // Break-Even Analysis Calculations
  const breakEvenData = useMemo(() => {
    const periodDays = reportingEnd - reportingStart + 1;
    const monthlyMultiplier = 30 / periodDays; // Scale to monthly

    // Monthly fixed costs
    const monthlyOverhead = plannedOverhead * monthlyMultiplier;
    const monthlyLabor = plannedLabor * monthlyMultiplier;
    const monthlyFixedCosts = monthlyOverhead + monthlyLabor;

    // Break-even calculations
    const shopRate = gameState.shopRate || 125;
    const breakEvenRevenue = monthlyFixedCosts;
    const breakEvenHours = shopRate > 0 ? monthlyFixedCosts / shopRate : 0;
    const monthlyCapacity = periodCapacity * monthlyMultiplier;
    const breakEvenUtilization = monthlyCapacity > 0 ? (breakEvenHours / monthlyCapacity) * 100 : 0;

    // Current vs break-even
    const currentMonthlyRevenue = plannedRevenue * monthlyMultiplier;
    const revenueBuffer = currentMonthlyRevenue - breakEvenRevenue;
    const revenueBufferPercent = breakEvenRevenue > 0 ? (revenueBuffer / breakEvenRevenue) * 100 : 0;

    return {
      monthlyFixedCosts,
      monthlyOverhead,
      monthlyLabor,
      breakEvenRevenue,
      breakEvenHours,
      breakEvenUtilization,
      currentMonthlyRevenue,
      revenueBuffer,
      revenueBufferPercent,
      shopRate
    };
  }, [plannedOverhead, plannedLabor, plannedRevenue, periodCapacity, gameState.shopRate, reportingStart, reportingEnd]);

  if (isPoppedOut) {
      return (
        <div className="flex-1 w-full bg-slate-900 flex flex-col overflow-y-auto select-none transition-all duration-300 relative h-full text-slate-200">
          {/* ... (Existing Popout Render Code - Keeping largely same structure, just adding OT block) ... */}
          <div className="p-4 bg-slate-900 border-b border-slate-700/50 flex flex-col gap-2">
               {/* ... Header Controls ... */}
               <div className="flex justify-between items-center">
                   <h3 className="text-[10px] font-bold text-slate-500 uppercase">Reporting Range</h3>
                   {selectedBaseId !== 'ALL' && ( <span className="text-[10px] font-bold text-cyan-500 bg-slate-800 px-2 py-1 rounded border border-slate-600"> Scope: {currentBaseName} </span> )}
               </div>
               <div className="flex gap-4">
                   <div className="flex items-center gap-2">
                       <button onClick={() => setScenarioStart(gameState.day)} className="text-[9px] font-bold text-slate-400 uppercase w-8 hover:text-cyan-400 text-left">Start</button>
                       <input type="date" value={getDateStr(scenarioStart)} onChange={(e) => setScenarioStart(getDayIndex(e.target.value))} className="bg-slate-800 border border-slate-600 rounded p-1 text-xs text-cyan-100 focus:border-cyan-500 outline-none w-32" />
                   </div>
                   <div className="flex items-center gap-2">
                       <button onClick={() => setScenarioEnd(gameState.day)} className="text-[9px] font-bold text-slate-400 uppercase w-8 hover:text-cyan-400 text-left">End</button>
                       <input type="date" value={getDateStr(scenarioEnd)} onChange={(e) => setScenarioEnd(getDayIndex(e.target.value))} className="bg-slate-800 border border-slate-600 rounded p-1 text-xs text-cyan-100 focus:border-cyan-500 outline-none w-32" />
                   </div>
               </div>
          </div>
          <div className="p-6 border-b border-slate-700/50 relative overflow-hidden">
            {/* ... Gauge ... */}
            <div className="absolute top-0 right-0 p-4 opacity-5 pointer-events-none"><Calendar size={64} /></div>
            <div className="flex justify-between items-start mb-3 relative z-10"><h3 className="text-slate-400 text-xs uppercase font-bold tracking-wider">Period Utilization</h3><span className="text-[9px] bg-slate-800 px-1.5 py-0.5 rounded text-cyan-500 border border-slate-600 flex items-center gap-1 font-mono shadow-sm"><Calendar size={8}/> D{reportingStart}-{reportingEnd}</span></div>
            <div className="flex flex-col items-center justify-center relative z-10">
              <div className="relative w-32 h-32 flex items-center justify-center">
                 <svg className="w-full h-full" viewBox="0 0 36 36">
                    <path className="text-slate-800" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke="currentColor" strokeWidth="3" />
                    <path className={`${isOverburdened ? 'text-[#c4626a]' : 'text-cyan-500'} transition-all duration-1000 ease-out`} strokeDasharray={`${Math.min(utilization, 100)}, 100`} d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
                 </svg>
                 <div className="absolute flex flex-col items-center"><span className={`text-3xl font-bold font-mono ${isOverburdened ? 'text-[#c4626a]' : 'text-cyan-400'}`}>{Math.round(utilization)}%</span><span className="text-[10px] text-slate-500 uppercase tracking-widest">Load</span></div>
              </div>
              <div className="mt-4 w-full flex justify-between text-xs border-t border-slate-700/50 pt-2">
                 <div className="text-center w-1/2 border-r border-slate-700/50"><div className="text-slate-500 text-[10px] uppercase">Sold Hrs</div><div className="font-mono text-slate-200 font-bold">{Math.round(periodSoldHours).toLocaleString()}</div></div>
                 <div className="text-center w-1/2"><div className="text-slate-500 text-[10px] uppercase">Cap Hrs</div><div className="font-mono text-slate-200 font-bold">{Math.round(periodCapacity).toLocaleString()}</div></div>
              </div>
            </div>
          </div>
          <div className="p-4 border-b border-slate-700/50">
            <h3 className="text-slate-400 text-xs uppercase mb-2 font-bold tracking-wider">Planned Financials (Period)</h3>
            <div className="space-y-3">
               <div className="bg-slate-800 p-3 rounded border border-slate-700 shadow-sm relative">
                 <div className="text-xs text-[#3dae6c] font-bold flex justify-between items-center mb-1"><div className="flex items-center gap-1"><TrendingUp size={12}/> Planned Revenue</div></div>
                 <div className="text-xl font-mono font-bold text-[#3dae6c]">{DOLLAR_SIGN}{Math.round(plannedRevenue).toLocaleString()}</div>
               </div>
               <div className="bg-slate-800 p-3 rounded border border-slate-700 shadow-sm relative">
                 <div className="text-xs text-[#c4626a] font-bold flex justify-between items-center mb-1"><div className="flex items-center gap-1"><TrendingDown size={12}/> Planned Expenses</div></div>
                 <div className="text-xl font-mono font-bold text-[#c4626a]">{DOLLAR_SIGN}{Math.round(plannedExpenses).toLocaleString()}</div>
                 <div className="flex gap-4 mt-2 pt-2 border-t border-slate-700/50">
                     <div><div className="text-[9px] text-slate-500 uppercase">Labor (Inc. OT)</div><div className="text-xs font-mono text-slate-300">{DOLLAR_SIGN}{Math.round(plannedLabor).toLocaleString()}</div></div>
                     <div><div className="text-[9px] text-slate-500 uppercase">Overhead (Est)</div><div className="text-xs font-mono text-slate-300">{DOLLAR_SIGN}{Math.round(plannedOverhead).toLocaleString()}</div></div>
                 </div>
               </div>
               {periodOvertimeHours > 0 && (
                   <div className="bg-amber-900/20 p-3 rounded border border-amber-700/50 shadow-sm relative">
                     <div className="text-xs text-amber-500 font-bold flex justify-between items-center mb-1"><div className="flex items-center gap-1"><AlertTriangle size={12}/> Overtime Impact</div></div>
                     <div className="flex justify-between items-end">
                         <div><div className="text-[9px] text-amber-400/70 uppercase">Hours</div><div className="text-sm font-mono text-amber-400 font-bold">{Math.round(periodOvertimeHours)} hrs</div></div>
                         <div><div className="text-[9px] text-amber-400/70 uppercase">Extra Cost</div><div className="text-sm font-mono text-[#c4626a] font-bold">{DOLLAR_SIGN}{Math.round(periodOvertimeCost).toLocaleString()}</div></div>
                         <div><div className="text-[9px] text-amber-400/70 uppercase">% Cap</div><div className="text-sm font-mono text-amber-400 font-bold">{otPercent.toFixed(1)}%</div></div>
                     </div>
                   </div>
               )}

               {/* Break-Even Analysis */}
               <div className={`p-3 rounded border shadow-sm relative ${
                   breakEvenData.revenueBuffer >= 0
                       ? 'bg-emerald-900/20 border-emerald-700/50'
                       : 'bg-rose-900/20 border-rose-700/50'
               }`}>
                 <div className="text-xs text-slate-300 font-bold flex justify-between items-center mb-2">
                     <div className="flex items-center gap-1"><Target size={12}/> Break-Even Analysis (Monthly)</div>
                 </div>
                 <div className="grid grid-cols-2 gap-3">
                     <div>
                         <div className="text-[9px] text-slate-500 uppercase">Fixed Costs</div>
                         <div className="text-sm font-mono text-slate-300 font-bold">{DOLLAR_SIGN}{Math.round(breakEvenData.monthlyFixedCosts).toLocaleString()}</div>
                         <div className="text-[8px] text-slate-600 mt-1">
                             Labor: {DOLLAR_SIGN}{(breakEvenData.monthlyLabor / 1000).toFixed(0)}k | OH: {DOLLAR_SIGN}{(breakEvenData.monthlyOverhead / 1000).toFixed(0)}k
                         </div>
                     </div>
                     <div>
                         <div className="text-[9px] text-slate-500 uppercase">Min Revenue</div>
                         <div className="text-sm font-mono text-slate-300 font-bold">{DOLLAR_SIGN}{Math.round(breakEvenData.breakEvenRevenue).toLocaleString()}</div>
                         <div className="text-[8px] text-slate-600 mt-1">
                             {Math.round(breakEvenData.breakEvenHours)} hrs @ {DOLLAR_SIGN}{breakEvenData.shopRate}/hr
                         </div>
                     </div>
                 </div>
                 <div className="flex justify-between items-center mt-3 pt-3 border-t border-slate-700/50">
                     <div className="text-[9px] text-slate-500">
                         Min Utilization: <span className="text-slate-300 font-bold">{breakEvenData.breakEvenUtilization.toFixed(0)}%</span>
                     </div>
                     <div className={`text-sm font-mono font-bold ${
                         breakEvenData.revenueBuffer >= 0 ? 'text-emerald-400' : 'text-rose-400'
                     }`}>
                         {breakEvenData.revenueBuffer >= 0 ? '+' : ''}{DOLLAR_SIGN}{Math.round(breakEvenData.revenueBuffer).toLocaleString()} buffer
                     </div>
                 </div>
               </div>
            </div>
          </div>
        </div>
      );
  }

  // Horizontal Docked Layout
  return (
    <div
        className="bg-[#0d0e10] border-t border-white/[0.06] flex flex-col shrink-0 select-none relative z-20 w-full transition-all duration-300 ease-in-out overflow-hidden"
        style={{ height: isOpen ? height : 32 }}
    >
        <div
            onClick={onToggle}
            className="px-3 py-2 bg-[#141517] border-b border-white/[0.06] flex justify-between items-center shrink-0 z-30 cursor-pointer hover:bg-[#1a1b1e] transition-colors group h-8"
        >
            <div className="flex items-center gap-4">
                <h3 className="text-[10px] font-semibold text-[#6e79d6] uppercase tracking-wide flex items-center gap-2">
                    {isOpen ? 'Station Performance & KPIs' : 'Station KPIs'}
                    {!isOpen && (
                        <span className="text-[#6b7280] font-normal group-hover:text-[#9ca3af]">({currentBaseName})</span>
                    )}
                </h3>
                {isOpen && selectedBaseId !== 'ALL' && (
                    <span className="text-[9px] bg-[#1a1b1e] px-1.5 rounded border border-white/[0.08] text-[#e8e8e8] flex items-center gap-1">
                        <Filter size={8} /> {currentBaseName}
                    </span>
                )}

                {!isOpen && (
                    <div className="flex items-center gap-4 text-xs font-mono ml-4">
                        <span className={netPlan < 0 ? 'text-[#c4626a]' : 'text-[#3dae6c]'}>
                             Plan P&L: {netPlan < 0 ? '-' : '+'}{DOLLAR_SIGN}{Math.abs(Math.round(netPlan)).toLocaleString()}
                        </span>
                        <span className="text-[#6b7280] group-hover:text-[#9ca3af] transition-colors">
                             Util: {Math.round(utilization)}%
                        </span>
                    </div>
                )}

                {isOpen && (
                    <div onClick={e => e.stopPropagation()} className="flex items-center gap-3 border-l border-white/[0.08] pl-4">
                         <div className="flex items-center gap-1">
                           <button onClick={() => setScenarioStart(gameState.day)} className="text-[9px] font-semibold text-[#6b7280] hover:text-[#6e79d6] uppercase flex items-center gap-1 transition-colors" title="Set Start to Selected Date">START <MousePointerClick size={8} /></button>
                           <div className="flex items-center gap-0.5"><input type="date" value={getDateStr(scenarioStart)} onChange={(e) => setScenarioStart(getDayIndex(e.target.value))} className="bg-[#1a1b1e] border border-white/[0.08] rounded-sm px-1.5 py-0.5 text-[10px] text-[#e8e8e8] focus:border-[#5e6ad2] outline-none hover:border-white/[0.15] cursor-pointer w-24" /></div>
                         </div>
                         <div className="flex items-center gap-1">
                           <button onClick={() => setScenarioEnd(gameState.day)} className="text-[9px] font-semibold text-[#6b7280] hover:text-[#6e79d6] uppercase flex items-center gap-1 transition-colors" title="Set End to Selected Date">END <MousePointerClick size={8} /></button>
                           <div className="flex items-center gap-0.5"><input type="date" value={getDateStr(scenarioEnd)} onChange={(e) => setScenarioEnd(getDayIndex(e.target.value))} className="bg-[#1a1b1e] border border-white/[0.08] rounded-sm px-1.5 py-0.5 text-[10px] text-[#e8e8e8] focus:border-[#5e6ad2] outline-none hover:border-white/[0.15] cursor-pointer w-24" /></div>
                         </div>
                    </div>
                )}
            </div>

            <div className="flex items-center gap-2">
                {isOpen && <button onClick={(e) => { e.stopPropagation(); onPopOut(); }} className="text-[#6b7280] hover:text-[#6e79d6]"><ExternalLink size={16} /></button>}
                <button onClick={(e) => { e.stopPropagation(); onToggle(); }} className="text-[#6b7280] hover:text-[#6e79d6]">
                    {isOpen ? <ChevronsDown size={16} /> : <ChevronsUp size={16} />}
                </button>
            </div>
        </div>

        <div className={`flex-1 flex min-w-0 bg-[#08090a] p-4 gap-6 overflow-x-auto custom-scrollbar items-center transition-opacity duration-300 overscroll-x-none ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>

            {/* 1. Utilization Gauge */}
            <div className="w-48 shrink-0 flex items-center gap-4 border-r border-white/[0.08] pr-6">
                <div className="relative w-24 h-24 flex items-center justify-center shrink-0">
                     <svg className="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
                        <path className="text-white/[0.08]" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke="currentColor" strokeWidth="3" />
                        <path className={`${isOverburdened ? 'text-[#c4626a]' : 'text-[#5e6ad2]'} transition-all duration-1000 ease-out`} strokeDasharray={`${Math.min(utilization, 100)}, 100`} d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
                     </svg>
                     <div className="absolute flex flex-col items-center"><span className={`text-xl font-bold font-mono ${isOverburdened ? 'text-[#c4626a]' : 'text-[#6e79d6]'}`}>{Math.round(utilization)}%</span><span className="text-[8px] text-[#6b7280] uppercase tracking-wide">Util</span></div>
                </div>
                <div className="flex flex-col gap-2 min-w-[80px]"><div><div className="text-[9px] text-[#6b7280] uppercase font-semibold">Sold Hrs</div><div className="font-mono text-[#e8e8e8] font-bold">{Math.round(periodSoldHours).toLocaleString()}</div></div><div><div className="text-[9px] text-[#6b7280] uppercase font-semibold">Cap Hrs</div><div className="font-mono text-[#9ca3af] font-bold">{Math.round(periodCapacity).toLocaleString()}</div></div></div>
            </div>

            {/* 2. Planned Financials Cards */}
            <div className="flex gap-4 border-r border-white/[0.08] pr-6 shrink-0">
                 <div className="bg-[#141517] rounded border border-white/[0.08] p-3 w-36 flex flex-col justify-between shadow-sm group"><div className="text-[10px] text-[#3dae6c] uppercase font-semibold flex items-center gap-1"><TrendingUp size={10} /> Planned Rev</div><div className="text-lg font-mono font-bold text-[#3dae6c]">{DOLLAR_SIGN}{(plannedRevenue / 1000).toFixed(1)}k</div><div className="text-[9px] text-[#4b5563]">Accrued in Period</div></div>
                 <div className="bg-[#141517] rounded border border-white/[0.08] p-3 w-40 flex flex-col justify-between shadow-sm"><div className="text-[10px] text-[#c4626a] uppercase font-semibold flex items-center gap-1"><TrendingDown size={10} /> Planned Exp</div><div className="text-lg font-mono font-bold text-[#c4626a]">{DOLLAR_SIGN}{(plannedExpenses / 1000).toFixed(1)}k</div><div className="flex justify-between border-t border-white/[0.06] pt-1 mt-1"><div className="flex items-center gap-1 text-[9px] text-[#6b7280]" title="Labor (Inc OT)"><Users size={8} /> {DOLLAR_SIGN}{(plannedLabor/1000).toFixed(1)}k</div><div className="flex items-center gap-1 text-[9px] text-[#6b7280]" title="Overhead (Est)"><Warehouse size={8} /> {DOLLAR_SIGN}{(plannedOverhead/1000).toFixed(1)}k</div></div></div>
            </div>

            {/* 3. Overtime KPI */}
            {periodOvertimeHours > 0 && (
                <div className="flex gap-4 border-r border-white/[0.08] pr-6 shrink-0">
                    <div className="bg-amber-500/5 rounded border border-amber-500/20 p-3 w-44 flex flex-col justify-between shadow-sm relative overflow-hidden">
                        <div className="text-[10px] text-amber-400 uppercase font-semibold flex items-center gap-1"><Clock size={10} /> Overtime Impact</div>
                        <div className="flex justify-between items-end mt-2">
                            <div>
                                <div className="text-lg font-mono font-bold text-amber-400">{Math.round(periodOvertimeHours)} <span className="text-xs text-amber-600">hrs</span></div>
                                <div className="text-[9px] text-[#c4626a] font-bold">-{DOLLAR_SIGN}{Math.round(periodOvertimeCost).toLocaleString()}</div>
                            </div>
                            <div className="text-right">
                                <div className="text-xs font-bold text-amber-400">{otPercent.toFixed(1)}%</div>
                                <div className="text-[8px] text-amber-600 uppercase">of Cap</div>
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {/* 4. Load Balance Chart */}
            <div className="w-64 h-full flex flex-col justify-center border-r border-white/[0.08] pr-6 shrink-0">
                 <h4 className="text-[9px] text-[#6b7280] uppercase font-semibold mb-2">Sold vs Capacity</h4>
                 <div className="h-20 w-full">
                    <ResponsiveContainer width="100%" height="100%" minHeight={50}>
                        <BarChart data={laborData} layout="vertical" margin={{left: 0, right: 20}}>
                                            <XAxis type="number" hide />
                                            <YAxis dataKey="name" type="category" width={30} tick={{fill: '#6b7280', fontSize: 9, fontWeight: '500'}} />
                                            <Tooltip cursor={{fill: '#1a1b1e', opacity: 0.5}} contentStyle={{backgroundColor: '#0d0e10', border: '1px solid rgba(255,255,255,0.08)', fontSize: '11px', color: '#e8e8e8'}} />
                                            <Bar dataKey="hours" radius={[0, 2, 2, 0]} barSize={12} isAnimationActive={true} animationDuration={200}>
                                                {laborData.map((entry, index) => (<Cell key={`cell-${index}`} fill={entry.fill} />))}
                                            </Bar>
                                        </BarChart>
                    </ResponsiveContainer>
                 </div>
            </div>

            {/* 5. Break-Even Analysis */}
            <div className="flex gap-3 border-r border-white/[0.08] pr-6 shrink-0">
                <div className={`rounded border p-3 w-48 flex flex-col justify-between shadow-sm ${
                    breakEvenData.revenueBuffer >= 0
                        ? 'bg-emerald-500/5 border-emerald-500/20'
                        : 'bg-rose-500/5 border-rose-500/20'
                }`}>
                    <div className="text-[10px] text-[#9ca3af] uppercase font-semibold flex items-center gap-1">
                        <Target size={10} /> Break-Even (Monthly)
                    </div>
                    <div className="flex justify-between items-end mt-2">
                        <div>
                            <div className="text-[9px] text-[#6b7280] uppercase">Min Revenue</div>
                            <div className="text-sm font-mono font-bold text-[#e8e8e8]">
                                {DOLLAR_SIGN}{(breakEvenData.breakEvenRevenue / 1000).toFixed(0)}k
                            </div>
                        </div>
                        <div className="text-right">
                            <div className="text-[9px] text-[#6b7280] uppercase">Min Hours</div>
                            <div className="text-sm font-mono font-bold text-[#e8e8e8]">
                                {Math.round(breakEvenData.breakEvenHours)}
                            </div>
                        </div>
                    </div>
                    <div className="flex justify-between items-center mt-2 pt-2 border-t border-white/[0.06]">
                        <div className="text-[9px] text-[#6b7280]">
                            @{DOLLAR_SIGN}{breakEvenData.shopRate}/hr = {breakEvenData.breakEvenUtilization.toFixed(0)}% util
                        </div>
                        <div className={`text-[10px] font-bold ${
                            breakEvenData.revenueBuffer >= 0 ? 'text-[#3dae6c]' : 'text-[#c4626a]'
                        }`}>
                            {breakEvenData.revenueBuffer >= 0 ? '+' : ''}{(breakEvenData.revenueBuffer / 1000).toFixed(0)}k
                        </div>
                    </div>
                </div>
            </div>

            {/* 6. Project Counts */}
            <div className="flex flex-col gap-2 shrink-0 min-w-[120px]">
                <h4 className="text-[9px] text-[#6b7280] uppercase font-semibold">Project Status</h4>
                <div className="flex items-center justify-between text-xs bg-[#141517] px-2 py-1 rounded border border-white/[0.08]"><span className="text-[#9ca3af]">Scheduled</span><span className="font-mono font-bold text-[#e8e8e8]">{gameState.schedule.filter(j => j.status === 'Scheduled' && (!selectedBaseId || selectedBaseId === 'ALL' || gameState.hangars.find(h => h.id === j.hangarId)?.baseId === selectedBaseId)).length}</span></div>
                <div className="flex items-center justify-between text-xs bg-indigo-500/10 px-2 py-1 rounded border border-indigo-500/20"><span className="text-[#6e79d6]">Active</span><span className="font-mono font-bold text-[#6e79d6]">{gameState.schedule.filter(j => j.status === 'In Progress' && (!selectedBaseId || selectedBaseId === 'ALL' || gameState.hangars.find(h => h.id === j.hangarId)?.baseId === selectedBaseId)).length}</span></div>
            </div>

        </div>
    </div>
  );
};

// PERFORMANCE: Wrap with React.memo to prevent unnecessary re-renders
export default React.memo(AnalyticsPanel);