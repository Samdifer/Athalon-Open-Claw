
import React, { useLayoutEffect, useState, useEffect, useRef } from 'react';
import { ChevronRight, ChevronLeft, X, LayoutTemplate, Users, DollarSign, Settings, Plane, CheckCircle, BarChart3, BatteryCharging, PieChart, FileText, Calendar, Warehouse, TrendingUp, Calculator, Wrench, FilePlus } from 'lucide-react';

export type TourType = 'quick' | 'full';

interface OnboardingTourProps {
  active: boolean;
  step: number;
  tourType?: TourType;
  onNext: () => void;
  onPrev: () => void;
  onClose: () => void;
  onSetup?: () => void;
  onSkipSection?: () => void;
}

// Full Tour Steps with inline term definitions (bold = defined term)
export const TOUR_STEPS = [
  {
    title: "Welcome to AeroManager",
    content: "Let's get your **MRO (Maintenance, Repair & Overhaul)** shop set up. This app helps you schedule aircraft maintenance, manage staff, and track finances.",
    icon: <Plane size={16} className="text-[#6e79d6]" />,
    targetId: null
  },
  {
    title: "The Gantt Board",
    content: "This timeline shows all scheduled work. Each bar represents a job in a **hangar** (maintenance bay). Drag jobs to reschedule.",
    icon: <LayoutTemplate size={16} className="text-[#6e79d6]" />,
    targetId: "board-main"
  },
  // Roster
  {
    title: "Roster Access",
    content: "The sidebar shows your team roster - who's working today and their assigned roles.",
    icon: <Users size={16} className="text-purple-400" />,
    targetId: "panel-roster"
  },
  {
    title: "Active Roster Details",
    content: "See exactly who is on **shift** (their work schedule) and which **team** they belong to.",
    icon: <Users size={16} className="text-purple-400" />,
    targetId: "panel-roster"
  },
  // Capacity
  {
    title: "Capacity Monitor",
    content: "**Capacity** = your available work hours. Based on how many staff are scheduled.",
    icon: <BatteryCharging size={16} className="text-blue-400" />,
    targetId: "panel-capacity"
  },
  {
    title: "Capacity Analysis",
    content: "Compare **capacity** (available hours) against **workload** (scheduled hours). Green = good, Red = overbooked.",
    icon: <BatteryCharging size={16} className="text-blue-400" />,
    targetId: "panel-capacity"
  },
  // P&L
  {
    title: "Financial Tracker",
    content: "**P&L (Profit & Loss)** tracks daily money in vs. money out. Revenue arrives when jobs complete.",
    icon: <BarChart3 size={16} className="text-[#c4626a]" />,
    targetId: "panel-pnl"
  },
  {
    title: "Daily P&L Details",
    content: "See income (job revenue), expenses (labor + overhead), and net profit for each day.",
    icon: <BarChart3 size={16} className="text-[#c4626a]" />,
    targetId: "panel-pnl"
  },
  // Analytics
  {
    title: "Performance Metrics",
    content: "Quick view of **utilization** (% of capacity sold) and revenue metrics.",
    icon: <PieChart size={16} className="text-[#3dae6c]" />,
    targetId: "panel-analytics"
  },
  {
    title: "Shop Analytics",
    content: "Track utilization, revenue, and margin trends. Higher utilization = better profitability.",
    icon: <PieChart size={16} className="text-[#3dae6c]" />,
    targetId: "panel-analytics"
  },
  // Config Button
  {
    title: "Configuration",
    content: "Set up your facilities, aircraft types you can service, and workflow stages.",
    icon: <Settings size={16} className="text-slate-300" />,
    targetId: "btn-config"
  },
  // Config Modal Steps
  {
    title: "Station Configuration",
    content: "Define your operational constraints - what aircraft you can handle and where.",
    icon: <Settings size={16} className="text-slate-300" />,
    targetId: "modal-config"
  },
  {
    title: "Aircraft Profiles",
    content: "Add aircraft models your shop can service. Each model has different **hangar size** requirements.",
    icon: <Plane size={16} className="text-[#6e79d6]" />,
    targetId: "tab-config-fleet"
  },
  {
    title: "Facilities & Bases",
    content: "**Hangars** are your maintenance bays. Configure how many slots you have at each **base** (location).",
    icon: <Warehouse size={16} className="text-amber-400" />,
    targetId: "tab-config-hangars"
  },
  {
    title: "Project Stages",
    content: "Customize job status labels (Quoted, In Progress, Complete) and their timeline colors.",
    icon: <CheckCircle size={16} className="text-[#3dae6c]" />,
    targetId: "tab-config-stages"
  },

  // Personnel
  {
    title: "Workforce Access",
    content: "Manage your mechanics, teams, and work schedules here.",
    icon: <Users size={16} className="text-purple-400" />,
    targetId: "btn-personnel"
  },
  // Personnel Modal Steps
  {
    title: "Staff Management",
    content: "Hire **A&P technicians** (Airframe & Powerplant certified mechanics) and build teams.",
    icon: <Users size={16} className="text-purple-400" />,
    targetId: "modal-personnel"
  },
  {
    title: "Roster View",
    content: "See all staff members. Click anyone to edit their role, team, or efficiency rating.",
    icon: <Users size={16} className="text-slate-300" />,
    targetId: "tab-personnel-roster"
  },
  {
    title: "Assignments",
    content: "Create **Teams** (work groups), configure **Shifts** (work hours), and assign to bases.",
    icon: <Settings size={16} className="text-slate-300" />,
    targetId: "tab-personnel-assignments"
  },
  {
    title: "Role Definitions",
    content: "Set **hourly cost** (wages + benefits) and **efficiency** (productivity multiplier) for each role.",
    icon: <CheckCircle size={16} className="text-slate-300" />,
    targetId: "tab-personnel-roles"
  },
  {
    title: "Holiday Calendar",
    content: "Mark non-working days. The system automatically reduces capacity on holidays.",
    icon: <Calendar size={16} className="text-slate-300" />,
    targetId: "tab-personnel-holidays"
  },
  {
    title: "Workforce Analysis",
    content: "Charts showing headcount, total capacity hours, and labor cost breakdown.",
    icon: <BarChart3 size={16} className="text-slate-300" />,
    targetId: "tab-personnel-analysis"
  },

  // Financials
  {
    title: "Financial Controls",
    content: "Configure **shop rate** (hourly billing rate), expenses, and view cash projections.",
    icon: <DollarSign size={16} className="text-[#3dae6c]" />,
    targetId: "btn-financials"
  },
  // Financial Modal Steps
  {
    title: "Financial Planning",
    content: "**Shop Rate** = what you charge customers per labor hour (industry average: $125-150/hr).",
    icon: <DollarSign size={16} className="text-[#3dae6c]" />,
    targetId: "modal-financial"
  },
  {
    title: "Projections",
    content: "Forecast **cash flow** - when money comes in vs. goes out. Helps avoid cash crunches.",
    icon: <TrendingUp size={16} className="text-[#6e79d6]" />,
    targetId: "tab-financial-projections"
  },
  {
    title: "Annual Fixed Costs",
    content: "**Overhead** = fixed costs (rent, utilities, insurance) that occur regardless of job volume.",
    icon: <Calculator size={16} className="text-slate-300" />,
    targetId: "tab-financial-fpa"
  },
  {
    title: "Config & Rates",
    content: "Set your **shop rate** and **markup tiers** (% added to parts cost: 30% under $500, 15% under $2500, 5% above).",
    icon: <Settings size={16} className="text-slate-300" />,
    targetId: "tab-financial-rates"
  },

  // Backlog
  {
    title: "Quotes Access",
    content: "The **backlog** (left sidebar) shows all unscheduled quotes waiting to be assigned to the timeline.",
    icon: <LayoutTemplate size={16} className="text-amber-400" />,
    targetId: "panel-backlog"
  },
  {
    title: "Managing Quotes",
    content: "Drag any quote from the backlog onto a hangar row to schedule it. Red pulse = **AOG (Aircraft On Ground)** priority.",
    icon: <LayoutTemplate size={16} className="text-amber-400" />,
    targetId: "panel-backlog"
  },
  // Quote
  {
    title: "Creating Quotes",
    content: "Click '+' to create a new quote for incoming work.",
    icon: <FileText size={16} className="text-[#6e79d6]" />,
    targetId: "btn-new-quote"
  },
  {
    title: "Work Order Builder",
    content: "Build quotes with labor hours, parts costs, and customer details.",
    icon: <FileText size={16} className="text-[#6e79d6]" />,
    targetId: "quote-sidebar"
  },
  {
    title: "Aircraft Details",
    content: "Enter the **tail number** (registration like N77NZ) and select the aircraft model.",
    icon: <Plane size={16} className="text-slate-300" />,
    targetId: "quote-aircraft-info"
  },
  {
    title: "Standard Services",
    content: "Click pre-configured service packages to quickly add common work items.",
    icon: <Wrench size={16} className="text-[#6e79d6]" />,
    targetId: "quote-standard-services"
  },
  {
    title: "Scope of Work",
    content: "Review line items. **Margin** = (Revenue - Cost) / Revenue. Green ≥30% is healthy.",
    icon: <FilePlus size={16} className="text-[#3dae6c]" />,
    targetId: "quote-line-items"
  },
  {
    title: "Finalize Quote",
    content: "Save the quote to add it to your backlog, ready for scheduling.",
    icon: <CheckCircle size={16} className="text-[#3dae6c]" />,
    targetId: "btn-save-quote"
  },
  // Exec
  {
    title: "Scheduling Execution",
    content: "Drag quotes from the backlog onto hangar rows to schedule. Resize job bars to adjust duration.",
    icon: <Calendar size={16} className="text-amber-500" />,
    targetId: "board-main"
  },
  {
    title: "Setup Defaults?",
    content: "Would you like to configure your shop defaults (rates, staff, hangars)?",
    icon: <Settings size={16} className="text-[#3dae6c]" />,
    targetId: null
  }
];

// Quick Tour Steps (8 steps for fast onboarding)
export const QUICK_TOUR_STEPS = [
  {
    title: "Welcome to AeroManager",
    content: "This is a quick 2-minute tour of the essentials. You can take the full tour anytime from the Help menu.",
    icon: <Plane size={16} className="text-[#6e79d6]" />,
    targetId: null
  },
  {
    title: "The Scheduling Timeline",
    content: "This **Gantt board** shows all your scheduled work. Each row is a hangar, each bar is a job.",
    icon: <LayoutTemplate size={16} className="text-[#6e79d6]" />,
    targetId: "board-main"
  },
  {
    title: "Create a Quote",
    content: "Click '+' to create quotes. Enter customer info, add line items, and set pricing.",
    icon: <FileText size={16} className="text-[#6e79d6]" />,
    targetId: "btn-new-quote"
  },
  {
    title: "Schedule Work",
    content: "Drag quotes from the **backlog** (left) onto the timeline to schedule them.",
    icon: <Calendar size={16} className="text-amber-500" />,
    targetId: "panel-backlog"
  },
  {
    title: "Track Finances",
    content: "The **P&L panel** shows daily profit/loss. The **Financial** button opens detailed cash projections.",
    icon: <DollarSign size={16} className="text-[#3dae6c]" />,
    targetId: "btn-financials"
  },
  {
    title: "Manage Your Team",
    content: "Add **A&P technicians** (certified mechanics), create teams, and set work schedules.",
    icon: <Users size={16} className="text-purple-400" />,
    targetId: "btn-personnel"
  },
  {
    title: "Configure Settings",
    content: "Set up hangars, aircraft types, and **shop rate** (your hourly billing rate) here.",
    icon: <Settings size={16} className="text-slate-300" />,
    targetId: "btn-config"
  },
  {
    title: "Get Help Anytime",
    content: "Click the 📖 icon for the **Glossary** of aviation terms. Press Cmd+? for quick access. Full tour available in Help.",
    icon: <CheckCircle size={16} className="text-[#3dae6c]" />,
    targetId: null
  }
];

// Tour sections for grouping steps
export const TOUR_SECTIONS = [
  {
    id: 'overview',
    name: 'Overview',
    startStep: 0,
    endStep: 1,
    description: 'Introduction to your dashboard'
  },
  {
    id: 'panels',
    name: 'Dashboard Panels',
    startStep: 2,
    endStep: 9,
    description: 'Roster, capacity, financials, and analytics'
  },
  {
    id: 'config',
    name: 'Configuration',
    startStep: 10,
    endStep: 14,
    description: 'Aircraft, hangars, and workflow stages'
  },
  {
    id: 'personnel',
    name: 'Personnel',
    startStep: 15,
    endStep: 21,
    description: 'Staff, teams, shifts, and roles'
  },
  {
    id: 'financials',
    name: 'Financials',
    startStep: 22,
    endStep: 26,
    description: 'Rates, projections, and expenses'
  },
  {
    id: 'quoting',
    name: 'Quoting & Scheduling',
    startStep: 27,
    endStep: 36,
    description: 'Create quotes and schedule work'
  },
];

// Helper functions for section navigation
export const getCurrentSection = (step: number) => {
  return TOUR_SECTIONS.find(s => step >= s.startStep && step <= s.endStep);
};

export const getSectionIndex = (step: number) => {
  return TOUR_SECTIONS.findIndex(s => step >= s.startStep && step <= s.endStep);
};

// Custom easing for "tactical" feel - starts fast, snaps into place
const TACTICAL_EASING = "cubic-bezier(0.16, 1, 0.3, 1)"; 

// --- Hook to Track Element Rect Smoothly ---
const useTargetRect = (targetId: string | null, stepTrigger: number) => {
  const [rect, setRect] = useState<DOMRect | null>(null);

  useLayoutEffect(() => {
    if (!targetId) {
        setRect(null);
        return;
    }

    const update = () => {
        const el = document.getElementById(targetId);
        if (el) {
            const newRect = el.getBoundingClientRect();
            setRect(prev => {
                // STRICT equality check to ensure we catch every pixel update during animations
                if (prev && 
                    prev.top === newRect.top && 
                    prev.left === newRect.left && 
                    prev.width === newRect.width && 
                    prev.height === newRect.height) {
                    return prev;
                }
                return newRect;
            });
        } else {
            setRect(null);
        }
    };

    // Immediate update
    update();

    // Poll continuously for animations (e.g., CSS transitions on drawers)
    let rafId: number;
    const startTime = performance.now();
    const loop = () => {
        update();
        // Run for 1.5s which covers most transition durations (usually 300-500ms)
        if (performance.now() - startTime < 1500) {
            rafId = requestAnimationFrame(loop);
        }
    };
    loop();

    window.addEventListener('resize', update);
    window.addEventListener('scroll', update, true); // Capture phase for nested scrolls

    return () => {
        cancelAnimationFrame(rafId);
        window.removeEventListener('resize', update);
        window.removeEventListener('scroll', update, true);
    };
  }, [targetId, stepTrigger]); 

  return rect;
};

// --- Highlighter Component ---
interface HighlighterProps {
    rect: DOMRect | null;
    isTransitioning: boolean;
}

const Highlighter: React.FC<HighlighterProps> = ({ rect, isTransitioning }) => {
    // If no rect, show full screen fade
    if (!rect) {
        return <div className="fixed inset-0 bg-black/50 z-[9998] transition-opacity duration-700 ease-in-out" />;
    }

    const PAD = 8;
    
    // During "swoop" (step change), we use CSS transition.
    // During "stick" (tracking moving drawer), we disable transition to prevent lag.
    const transitionStyle: React.CSSProperties = {
        transitionProperty: 'top, left, width, height',
        transitionDuration: isTransitioning ? '500ms' : '0ms',
        transitionTimingFunction: TACTICAL_EASING
    };

    return (
        <>
            {/* Dark Overlay with Cutout (Reduced Opacity) */}
            <div 
                className="fixed z-[9998] pointer-events-none rounded-lg"
                style={{
                    ...transitionStyle,
                    left: rect.left - PAD,
                    top: rect.top - PAD,
                    width: rect.width + (PAD * 2),
                    height: rect.height + (PAD * 2),
                    boxShadow: '0 0 0 9999px rgba(0, 0, 0, 0.5)', // Reduced from 0.75 to 0.5
                }}
            />

            {/* HUD Brackets / Tactical Border */}
            <div
                className="fixed pointer-events-none z-[10000]"
                style={{
                    ...transitionStyle,
                    left: rect.left - PAD,
                    top: rect.top - PAD,
                    width: rect.width + (PAD * 2),
                    height: rect.height + (PAD * 2),
                }}
            >
                {/* Glow Effect */}
                <div className="absolute inset-0 rounded-lg ring-1 ring-[#5e6ad2]/30 animate-pulse" />

                {/* Top Left Corner */}
                <div className="absolute top-0 left-0 w-3 h-3 border-t-2 border-l-2 border-[#6e79d6] rounded-tl-md" />
                {/* Top Right Corner */}
                <div className="absolute top-0 right-0 w-3 h-3 border-t-2 border-r-2 border-[#6e79d6] rounded-tr-md" />
                {/* Bottom Left Corner */}
                <div className="absolute bottom-0 left-0 w-3 h-3 border-b-2 border-l-2 border-[#6e79d6] rounded-bl-md" />
                {/* Bottom Right Corner */}
                <div className="absolute bottom-0 right-0 w-3 h-3 border-b-2 border-r-2 border-[#6e79d6] rounded-br-md" />

                {/* Center Crosshairs (Subtle) */}
                <div className="absolute top-1/2 left-0 w-1 h-0.5 bg-indigo-500/50 -translate-y-1/2" />
                <div className="absolute top-1/2 right-0 w-1 h-0.5 bg-indigo-500/50 -translate-y-1/2" />
                <div className="absolute top-0 left-1/2 h-1 w-0.5 bg-indigo-500/50 -translate-x-1/2" />
                <div className="absolute bottom-0 left-1/2 h-1 w-0.5 bg-indigo-500/50 -translate-x-1/2" />
            </div>
        </>
    );
};

const OnboardingTour: React.FC<OnboardingTourProps> = ({ active, step, tourType = 'full', onNext, onPrev, onClose, onSetup, onSkipSection }) => {
  // Select the appropriate steps based on tour type
  const steps = tourType === 'quick' ? QUICK_TOUR_STEPS : TOUR_STEPS;
  const currentStepData = steps[step] || steps[0];
  const isLastStep = step === steps.length - 1;
  
  // Track target
  const targetRect = useTargetRect(active ? currentStepData.targetId : null, step);
  
  const cardRef = useRef<HTMLDivElement>(null);
  
  // State to handle the "Swoop" vs "Stick" logic
  const [isTransitioningStep, setIsTransitioningStep] = useState(false);

  useEffect(() => {
      if (active) {
          setIsTransitioningStep(true);
          // Match transition duration (500ms) + slight buffer
          const timer = setTimeout(() => setIsTransitioningStep(false), 550); 
          return () => clearTimeout(timer);
      }
  }, [step, active]);

  // Auto-scroll effect
  useEffect(() => {
      if (active && currentStepData.targetId) {
          // Delay slightly to allow DOM to render if modal just opened
          const timer = setTimeout(() => {
              const el = document.getElementById(currentStepData.targetId!);
              if (el) {
                  el.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'nearest' });
              }
          }, 100);
          return () => clearTimeout(timer);
      }
  }, [step, active, currentStepData.targetId]);

  if (!active) return null;

  // Intelligent Card Positioning
  const getCardStyle = () => {
      const baseStyle: React.CSSProperties = { position: 'fixed', margin: 0, zIndex: 10001 };
      const CARD_WIDTH = 360;
      const GAP = 16;
      const MARGIN = 24; // Safe edge distance

      if (!targetRect) {
          return { 
              ...baseStyle, 
              top: '50%', 
              left: '50%', 
              transform: 'translate(-50%, -50%)', 
              width: CARD_WIDTH 
          };
      }

      const vpW = window.innerWidth;
      const vpH = window.innerHeight;
      
      // Available space around target
      const spaceBottom = vpH - targetRect.bottom;
      const spaceTop = targetRect.top;
      const spaceRight = vpW - targetRect.right;
      const spaceLeft = targetRect.left;

      // Estimation
      const EST_HEIGHT = 220;

      let pos = 'bottom';

      // Decision Logic:
      // 1. If tall vertical target (sidebar), prefer Side placement.
      // 2. Otherwise, prefer Bottom/Top.
      
      const isTall = targetRect.height > vpH * 0.5;
      
      if (isTall) {
          // Prefer side with more space
          if (spaceLeft > spaceRight && spaceLeft > CARD_WIDTH + MARGIN) pos = 'left';
          else if (spaceRight > CARD_WIDTH + MARGIN) pos = 'right';
          else pos = 'center'; 
      } else {
          // Prefer bottom, then top
          if (spaceBottom > EST_HEIGHT + GAP) pos = 'bottom';
          else if (spaceTop > EST_HEIGHT + GAP) pos = 'top';
          else if (spaceRight > CARD_WIDTH + MARGIN) pos = 'right';
          else if (spaceLeft > CARD_WIDTH + MARGIN) pos = 'left';
          else pos = 'center';
      }

      let top = 0;
      let left = 0;
      let transform = '';

      switch (pos) {
          case 'bottom':
              top = targetRect.bottom + GAP;
              left = targetRect.left + (targetRect.width / 2);
              transform = 'translateX(-50%)';
              break;
          case 'top':
              top = targetRect.top - GAP;
              left = targetRect.left + (targetRect.width / 2);
              transform = 'translate(-50%, -100%)';
              break;
          case 'right':
              top = targetRect.top + Math.min(60, targetRect.height / 2);
              left = targetRect.right + GAP;
              transform = 'translateY(-20%)';
              break;
          case 'left':
              top = targetRect.top + Math.min(60, targetRect.height / 2);
              left = targetRect.left - GAP;
              transform = 'translate(-100%, -20%)';
              break;
          case 'center':
          default:
              top = vpH / 2;
              left = vpW / 2;
              transform = 'translate(-50%, -50%)';
              break;
      }

      // Edge Clamping
      if (pos === 'top' || pos === 'bottom') {
          const halfCard = CARD_WIDTH / 2;
          const minLeft = MARGIN + halfCard;
          const maxLeft = vpW - MARGIN - halfCard;
          left = Math.max(minLeft, Math.min(left, maxLeft));
      }
      // Vertical Clamping for side placement
      if (pos === 'left' || pos === 'right') {
          const estHalfH = EST_HEIGHT / 2;
          const minTop = MARGIN + estHalfH;
          const maxTop = vpH - MARGIN - estHalfH;
          top = Math.max(minTop, Math.min(top, maxTop));
      }
      
      return {
          ...baseStyle,
          top: `${top}px`,
          left: `${left}px`,
          transform,
          width: CARD_WIDTH,
      };
  };

  const cardStyle = getCardStyle();
  const progressPercent = ((step + 1) / TOUR_STEPS.length) * 100;

  // Combined transition style for the card
  const cardTransitionStyle: React.CSSProperties = {
      ...cardStyle,
      transitionProperty: 'top, left, transform',
      transitionDuration: isTransitioningStep ? '500ms' : '0ms',
      transitionTimingFunction: TACTICAL_EASING
  };

  return (
    <>
        <div className="fixed inset-0 z-[9999] pointer-events-none">
        
        <Highlighter rect={targetRect} isTransitioning={isTransitioningStep} />

        {/* Tour Card */}
        <div
            ref={cardRef}
            className="pointer-events-auto bg-[#0d0e10]/95 border border-white/[0.08] rounded-xl p-5 z-[10001] backdrop-blur-xl flex flex-col ring-1 ring-white/5"
            style={cardTransitionStyle}
        >
            {/* Header Step Indicator */}
            <div className="flex justify-between items-center mb-3">
                <div className="flex items-center gap-2">
                    <div className="text-[10px] font-semibold text-[#6e79d6] uppercase tracking-wide border border-indigo-500/20 bg-indigo-500/10 px-2 py-1 rounded">
                        {getCurrentSection(step)?.name || 'Tour'}
                    </div>
                    <div className="text-[10px] text-[#4b5563]">
                        Section {getSectionIndex(step) + 1}/{TOUR_SECTIONS.length}
                    </div>
                </div>
                <button
                    onClick={onClose}
                    className="text-[#6b7280] hover:text-white transition-colors hover:bg-[#141517] rounded p-1"
                >
                    <X size={14} />
                </button>
            </div>

            {/* Section Progress Dots */}
            <div className="flex gap-1 mb-4">
                {TOUR_SECTIONS.map((section, idx) => (
                    <div
                        key={section.id}
                        className={`h-1 flex-1 rounded-full transition-colors ${
                            idx < getSectionIndex(step) ? 'bg-[#3dae6c]' :
                            idx === getSectionIndex(step) ? 'bg-[#6e79d6]' :
                            'bg-white/[0.08]'
                        }`}
                        title={section.name}
                    />
                ))}
            </div>

            <div className="flex items-start gap-4 mb-6">
                <div className="p-3 bg-[#141517] rounded-lg border border-white/[0.08] shrink-0">
                    {currentStepData.icon}
                </div>
                <div>
                    <h3 className="text-sm font-semibold text-white mb-2 tracking-wide leading-none">{currentStepData.title}</h3>
                    <p className="text-xs text-[#9ca3af] leading-relaxed font-medium">
                        {currentStepData.content}
                    </p>
                </div>
            </div>

            {/* Controls Footer */}
            <div className="flex justify-between items-center pt-4 border-t border-white/[0.06] mt-auto">
                <button
                    onClick={onPrev}
                    disabled={step === 0}
                    className={`
                        px-3 py-1.5 rounded-md border border-white/[0.08] text-[#9ca3af] text-[10px] font-semibold flex items-center gap-1 transition-colors
                        ${step === 0 ? 'opacity-30 cursor-not-allowed' : 'hover:bg-[#141517] hover:text-white hover:border-white/[0.12]'}
                    `}
                >
                    <ChevronLeft size={12} /> BACK
                </button>

                {/* Middle Section - Skip Section or Progress */}
                {!isLastStep && (
                    <div className="flex items-center gap-2 flex-1 mx-4">
                        {onSkipSection && (
                            <button
                                onClick={onSkipSection}
                                className="px-3 py-1.5 rounded-md border border-white/[0.08] text-[#6b7280] text-[10px] font-semibold flex items-center gap-1 transition-colors hover:bg-[#141517] hover:text-white hover:border-white/[0.12]"
                            >
                                Skip Section <ChevronRight size={12} />
                            </button>
                        )}
                        <div className="flex-1 h-1 bg-[#141517] rounded-full overflow-hidden">
                            <div
                                className="h-full bg-indigo-500 transition-all duration-500 ease-out"
                                style={{ width: `${progressPercent}%` }}
                            />
                        </div>
                    </div>
                )}

                {isLastStep ? (
                    <div className="flex gap-3 ml-auto">
                        <button
                            onClick={onClose}
                            className="px-4 py-2 rounded-md border border-white/[0.08] hover:bg-[#141517] text-[#e8e8e8] text-[10px] font-semibold transition-colors uppercase"
                        >
                            Close
                        </button>
                        <button
                            onClick={onSetup}
                            className="px-5 py-2 rounded-md bg-emerald-600 hover:bg-emerald-500 text-white text-[10px] font-semibold flex items-center gap-1 transition-all uppercase tracking-wide hover:scale-[1.02] active:scale-[0.98] border border-emerald-500/30"
                        >
                            Run Setup <Settings size={12} />
                        </button>
                    </div>
                ) : (
                    <button
                        onClick={onNext}
                        className="px-5 py-2 rounded-md bg-indigo-500 hover:bg-indigo-400 text-white text-[10px] font-semibold flex items-center gap-1 transition-all uppercase tracking-wide hover:scale-[1.02] active:scale-[0.98] border border-[#6e79d6]/30"
                    >
                        NEXT <ChevronRight size={12} />
                    </button>
                )}
            </div>
        </div>
        </div>
    </>
  );
};

export default OnboardingTour;
