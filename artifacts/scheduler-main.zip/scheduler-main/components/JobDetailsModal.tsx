
import React, { useState, useEffect, useRef } from 'react';
import { Job, ScheduledJob, AircraftModel, ProjectStage, PaymentStatus } from '../types';
import { X, Plane, Clock, DollarSign, Calendar, Trash2, ArrowRight, PenTool, Sparkles, FileText, Archive, AlertTriangle, CreditCard, CheckCircle, AlertCircle, Receipt } from 'lucide-react';
import { DOLLAR_SIGN } from '../App';
import { START_YEAR } from '../constants';

interface JobDetailsModalProps {
  job: Job | ScheduledJob;
  aircraftModels: AircraftModel[];
  projectStages: ProjectStage[];
  onClose: () => void;
  onSave: (updatedJob: Job | ScheduledJob) => void;
  onDelete: (jobId: string, permanent?: boolean) => void; // Updated signature
  onEditQuote: () => void;
  onAutoSchedule?: (jobId: string, startDateIndex: number) => { deadlineDays: number, dailyEffort: Record<number, number> } | undefined;
}

// --- Date Helpers ---
const getDateStr = (dayIndex: number) => {
    const date = new Date(START_YEAR, 0, 1);
    date.setDate(dayIndex + 1);
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, '0');
    const d = String(date.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
};

const getDayIndex = (dateStr: string) => {
    if (!dateStr) return 0;
    const [y, m, d] = dateStr.split('-').map(Number);
    const date = new Date(y, m - 1, d);
    const start = new Date(START_YEAR, 0, 1);
    const diff = date.getTime() - start.getTime();
    return Math.round(diff / (1000 * 60 * 60 * 24));
};

const formatDateDisplay = (dateStr: string) => {
    if (!dateStr) return '—';
    const [y, m, d] = dateStr.split('-').map(Number);
    const date = new Date(y, m - 1, d);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
};

const JobDetailsModal: React.FC<JobDetailsModalProps> = ({ job, aircraftModels, projectStages, onClose, onSave, onDelete, onEditQuote, onAutoSchedule }) => {
  const modalRef = useRef<HTMLDivElement>(null);
  const closeButtonRef = useRef<HTMLButtonElement>(null);

  // Determine initial dates
  const isScheduled = 'status' in job;
  const initialStartDay = isScheduled ? (job as ScheduledJob).startDate : (job.arrivalDay || 0);

  // Form State
  const [formData, setFormData] = useState<Job | ScheduledJob>(job);
  const [startDateStr, setStartDateStr] = useState(getDateStr(initialStartDay));
  const [endDateStr, setEndDateStr] = useState(getDateStr(initialStartDay + job.deadlineDays - 1)); // Fix off-by-one for visual end date
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [doubleConfirmDelete, setDoubleConfirmDelete] = useState(false);

  // Handle escape key and focus trap
  useEffect(() => {
    // Focus close button on mount
    closeButtonRef.current?.focus();

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (showDeleteConfirm) {
          setShowDeleteConfirm(false);
        } else {
          onClose();
        }
      }
      // Focus trap
      if (e.key === 'Tab' && modalRef.current) {
        const focusableElements = modalRef.current.querySelectorAll(
          'button:not([disabled]), [href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'
        );
        const firstElement = focusableElements[0] as HTMLElement;
        const lastElement = focusableElements[focusableElements.length - 1] as HTMLElement;

        if (e.shiftKey && document.activeElement === firstElement) {
          e.preventDefault();
          lastElement?.focus();
        } else if (!e.shiftKey && document.activeElement === lastElement) {
          e.preventDefault();
          firstElement?.focus();
        }
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [onClose, showDeleteConfirm]);

  // Sync state if prop changes
  useEffect(() => {
    setFormData(job);
    const start = isScheduled ? (job as ScheduledJob).startDate : (job.arrivalDay || 0);
    setStartDateStr(getDateStr(start));
    setEndDateStr(getDateStr(start + job.deadlineDays - 1));
  }, [job]);

  // Handle Date Changes
  const handleStartDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const newDate = e.target.value;
      setStartDateStr(newDate);
      
      const sIdx = getDayIndex(newDate);
      
      if (sIdx !== null) {
          // Preserve duration when moving start date
          const currentDuration = formData.deadlineDays;
          const newEndDay = sIdx + currentDuration - 1;
          setEndDateStr(getDateStr(newEndDay));

          setFormData(prev => ({ 
              ...prev, 
              ...(isScheduled ? { startDate: sIdx } : { arrivalDay: sIdx })
          }));
      }
  };

  const handleEndDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const newDate = e.target.value;
      setEndDateStr(newDate);
      
      const sIdx = getDayIndex(startDateStr);
      const eIdx = getDayIndex(newDate);
      
      if (sIdx !== null && eIdx !== null) {
          if (eIdx < sIdx) {
              // Invalid range, reset to minimum 1 day
              const clampedEnd = sIdx;
              setEndDateStr(getDateStr(clampedEnd));
              setFormData(prev => ({ ...prev, deadlineDays: 1 }));
          } else {
              // Calculate inclusive duration
              setFormData(prev => ({ 
                  ...prev, 
                  deadlineDays: (eIdx - sIdx) + 1
              }));
          }
      }
  };

  const handleAutoScheduleClick = () => {
      if (!onAutoSchedule) return;
      const sIdx = getDayIndex(startDateStr);
      // Ensure valid index
      if (sIdx === null || isNaN(sIdx)) return;

      const result = onAutoSchedule(job.id, sIdx);
      if (result) {
          // Prepare final object
          const updatedJob = {
              ...formData,
              deadlineDays: result.deadlineDays,
              dailyEffort: result.dailyEffort,
              nonWorkDays: [],
              // Strictly enforce the start date from the picker
              ...(isScheduled ? { startDate: sIdx } : { arrivalDay: sIdx }),
              notes: (formData.notes || '') + `\n[System] Auto-Scheduled: Duration adjusted to ${result.deadlineDays} days`
          };
          
          // Save and close - success feedback via UI update and job notes
          onSave(updatedJob);
          onClose();
      }
  };

  const handleInputChange = (field: keyof Job, value: any) => {
     setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSave = () => {
      onSave(formData);
      onClose();
  };

  const currentStage = projectStages.find(s => s.color === formData.color);

  return (
    <div
      className="fixed inset-0 bg-[#08090a]/80 backdrop-blur-sm z-[100] flex items-center justify-center p-4 animate-in fade-in duration-200"
      onClick={onClose}
      role="presentation"
    >
      <div
        ref={modalRef}
        role="dialog"
        aria-modal="true"
        aria-label={`Job details for ${job.customer}`}
        className="bg-[#0d0e10] border border-white/[0.08] rounded-2xl w-full max-w-3xl overflow-hidden flex flex-col max-h-[90vh] relative"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Delete Confirmation Overlay */}
        {showDeleteConfirm && (
             <div className="absolute inset-0 bg-[#08090a]/95 z-[110] flex items-center justify-center p-6 backdrop-blur-sm animate-in fade-in duration-200">
                  <div className="flex flex-col items-center text-center max-w-sm bg-[#0d0e10] p-8 rounded-2xl border border-white/[0.08] relative">
                        <button
                            onClick={() => { setShowDeleteConfirm(false); setDoubleConfirmDelete(false); }}
                            className="absolute top-3 right-3 text-[#6b7280] hover:text-white"
                        >
                            <X size={20} />
                        </button>

                        <div className="w-16 h-16 bg-[#c4626a]/10 rounded-full flex items-center justify-center mb-4 border border-[#c4626a]/20">
                            <Trash2 size={32} className="text-[#c4626a]" />
                        </div>

                        <h3 className="text-xl font-semibold text-[#e8e8e8] mb-2 tracking-wide">Delete Project?</h3>
                        <p className="text-sm text-[#9ca3af] mb-8 leading-relaxed">
                            You are removing <span className="font-semibold text-white">{formData.customer}</span>. Choose an action:
                        </p>

                        {!doubleConfirmDelete ? (
                            <div className="flex flex-col gap-3 w-full">
                                <button
                                    onClick={() => onDelete(job.id, false)}
                                    className="flex-1 py-3 rounded-lg bg-[#141517] border border-white/[0.08] text-[#e8e8e8] font-semibold hover:bg-[#1a1b1e] transition-colors flex items-center justify-center gap-2 group"
                                >
                                    <Archive size={16} className="group-hover:text-[#6e79d6] transition-colors" /> Send to Graveyard (Archive)
                                </button>
                                <button
                                    onClick={() => setDoubleConfirmDelete(true)}
                                    className="flex-1 py-3 rounded-lg bg-[#c4626a]/10 border border-[#c4626a]/20 text-[#c4626a] font-semibold hover:bg-[#c4626a]/20 hover:text-white transition-colors flex items-center justify-center gap-2"
                                >
                                    <Trash2 size={16} /> Permanently Delete
                                </button>
                            </div>
                        ) : (
                            <div className="w-full animate-in fade-in slide-in-from-bottom-2 duration-200">
                                <div className="bg-[#c4626a]/10 border border-[#c4626a]/20 p-3 rounded mb-4 text-xs text-[#c4626a] flex items-center gap-2 text-left">
                                    <AlertTriangle className="shrink-0 text-[#c4626a]" size={16}/>
                                    <span><strong>Warning:</strong> This cannot be undone. History and financials will be lost.</span>
                                </div>
                                <div className="flex gap-3 w-full">
                                    <button
                                        onClick={() => setDoubleConfirmDelete(false)}
                                        className="flex-1 py-2.5 rounded-lg bg-[#141517] border border-white/[0.08] text-[#9ca3af] font-semibold hover:text-white hover:bg-[#1a1b1e] transition-colors"
                                    >
                                        Cancel
                                    </button>
                                    <button
                                        onClick={() => onDelete(job.id, true)}
                                        className="flex-1 py-2.5 rounded-lg bg-[#c4626a] hover:bg-[#d4727a] text-white font-semibold transition-colors"
                                    >
                                        Yes, Delete Forever
                                    </button>
                                </div>
                            </div>
                        )}
                  </div>
             </div>
        )}

        {/* Banner Header */}
        <div className={`relative h-32 ${formData.color} flex items-end p-5 overflow-hidden`}>
            {/* Decorative Background Elements */}
            <div className="absolute inset-0 bg-gradient-to-b from-transparent to-[#0d0e10]/90" />
            <div className="absolute -right-10 -top-10 opacity-20">
                <Plane size={180} className="text-white transform -rotate-12" />
            </div>

            <div className="relative z-10 flex justify-between items-end w-full">
                <div className="flex-1 mr-4">
                    <div className="flex items-center gap-3 mb-1 mt-8">
                        <span className="bg-white/10 backdrop-blur-md text-white px-2 py-0.5 rounded text-[10px] font-semibold uppercase tracking-wider border border-white/20">
                            {aircraftModels.find(m => m.id === formData.aircraftType)?.name || formData.aircraftType}
                        </span>
                        {formData.isAOG && (
                            <span className="bg-[#c4626a] text-white px-2 py-0.5 rounded text-[10px] font-semibold uppercase tracking-wider animate-pulse">
                                AOG Priority
                            </span>
                        )}
                    </div>
                    <input
                        type="text"
                        value={formData.customer}
                        onChange={(e) => handleInputChange('customer', e.target.value)}
                        className="text-3xl font-bold text-white bg-transparent border-none outline-none placeholder-white/50 w-full focus:ring-0 p-0 uppercase tracking-wide"
                        placeholder="TAIL #"
                    />
                    <input
                        type="text"
                        value={formData.description}
                        onChange={(e) => handleInputChange('description', e.target.value)}
                        className="w-full bg-transparent text-xs font-medium text-white/80 border-none outline-none focus:ring-0 placeholder-white/40 p-0"
                        placeholder="Project Description..."
                    />
                </div>

                {/* Schedule Stats - Prominent Display */}
                <div className="flex items-end gap-5 mr-4">
                    <div className="text-right">
                        <div className="text-[10px] font-semibold text-white/60 uppercase tracking-wider">Duration</div>
                        <div className="text-3xl font-bold text-white tabular-nums">{formData.deadlineDays}<span className="text-lg ml-1 font-normal text-white/70">days</span></div>
                    </div>
                    <div className="text-right">
                        <div className="text-[10px] font-semibold text-white/60 uppercase tracking-wider">Start</div>
                        <div className="text-lg font-semibold text-white">{formatDateDisplay(startDateStr)}</div>
                    </div>
                    <div className="text-right">
                        <div className="text-[10px] font-semibold text-white/60 uppercase tracking-wider">End</div>
                        <div className="text-lg font-semibold text-white">{formatDateDisplay(endDateStr)}</div>
                    </div>
                </div>

                <div className="flex gap-2 mb-1">
                    <button
                        onClick={() => setShowDeleteConfirm(true)}
                        className="p-2 bg-white/10 hover:bg-rose-500/80 text-white rounded-full transition-colors backdrop-blur-sm focus:outline-none focus-visible:ring-2 focus-visible:ring-white"
                        aria-label="Delete job"
                    >
                        <Trash2 size={16} aria-hidden="true" />
                    </button>
                    <button
                        ref={closeButtonRef}
                        onClick={onClose}
                        className="p-2 bg-white/10 hover:bg-white/20 text-white rounded-full transition-colors backdrop-blur-sm focus:outline-none focus-visible:ring-2 focus-visible:ring-white"
                        aria-label="Close dialog"
                    >
                        <X size={16} aria-hidden="true" />
                    </button>
                </div>
            </div>
        </div>

        {/* Main Body */}
        <div className="flex-1 overflow-y-auto bg-[#0d0e10] p-5 space-y-5 custom-scrollbar">

            {/* Stage Selection */}
            <div className="bg-[#141517]/50 border border-white/[0.08] rounded-xl p-3 flex items-center justify-between">
                <div className="flex items-center gap-3">
                    <span className="text-[10px] font-semibold text-[#6b7280] uppercase tracking-wide">Project Status</span>
                    <div className="px-2 py-0.5 rounded text-[10px] font-semibold uppercase bg-[#0d0e10] border border-white/[0.08] text-[#e8e8e8] flex items-center gap-2">
                        <div className={`w-2 h-2 rounded-full ${formData.color}`} />
                        {currentStage?.label || 'Unknown'}
                    </div>
                </div>
                <div className="flex gap-2">
                    {projectStages.map((stage) => (
                        <button
                            key={stage.id}
                            onClick={() => handleInputChange('color', stage.color)}
                            title={stage.label}
                            className={`
                                w-6 h-6 rounded-full transition-all ring-1 ring-white/[0.1]
                                ${stage.color}
                                ${formData.color === stage.color ? 'scale-125 ring-2 ring-white z-10' : 'opacity-50 hover:opacity-100 hover:scale-110'}
                            `}
                        />
                    ))}
                </div>
            </div>

            {/* Stats Cards (4 Columns Grid) */}
            <div className="grid grid-cols-4 gap-3">
                {/* Workload */}
                <div className="col-span-1 bg-[#141517] p-3 rounded-xl border border-white/[0.08] relative group hover:border-white/[0.12] transition-colors">
                    <div className="text-[9px] font-semibold text-[#6b7280] uppercase mb-1 flex items-center gap-2">
                        <Clock size={10} /> Est. Workload
                    </div>
                    <div className="flex items-baseline gap-1">
                        <input
                            type="number"
                            value={formData.estimatedHours}
                            onChange={(e) => handleInputChange('estimatedHours', Number(e.target.value))}
                            className="w-full bg-transparent text-2xl font-mono font-semibold text-[#e8e8e8] outline-none border-none p-0 focus:ring-0"
                        />
                        <span className="text-[10px] font-semibold text-[#4b5563]">hrs</span>
                    </div>
                </div>

                {/* Revenue */}
                <div className="col-span-1 bg-[#141517] p-3 rounded-xl border border-white/[0.08] group hover:border-white/[0.12] transition-colors">
                    <div className="text-[9px] font-semibold text-[#6b7280] uppercase mb-1 flex items-center gap-2">
                        <DollarSign size={10} /> Revenue
                    </div>
                    <div className="flex items-baseline gap-0.5">
                        <span className="text-lg text-[#3dae6c] font-semibold">$</span>
                        <input
                            type="number"
                            value={formData.revenue}
                            onChange={(e) => handleInputChange('revenue', Number(e.target.value))}
                            className="w-full bg-transparent text-2xl font-mono font-semibold text-[#3dae6c] outline-none border-none p-0 focus:ring-0"
                        />
                    </div>
                </div>

                {/* Schedule / Dates */}
                <div className="col-span-2 bg-[#141517] p-3 rounded-xl border border-white/[0.08] flex flex-col justify-between hover:border-white/[0.12] transition-colors relative">
                    <div className="text-[9px] font-semibold text-[#6b7280] uppercase mb-1 flex items-center gap-2">
                        <Calendar size={10} /> Schedule ({formData.deadlineDays}d)
                    </div>
                    <div className="flex items-end gap-3 h-full">
                        <div className="flex flex-col gap-1.5 flex-1">
                            <div className="flex items-center gap-2">
                                <span className="text-[9px] text-[#6b7280] w-6 uppercase font-semibold">Start</span>
                                <input
                                    type="date"
                                    value={startDateStr}
                                    onChange={handleStartDateChange}
                                    className="bg-[#0d0e10] border border-white/[0.08] rounded px-1 py-0 text-[10px] text-[#e8e8e8] w-full h-5 focus:border-[#5e6ad2] outline-none"
                                />
                            </div>
                            <div className="flex items-center gap-2">
                                <span className="text-[9px] text-[#6b7280] w-6 uppercase font-semibold">End</span>
                                <input
                                    type="date"
                                    value={endDateStr}
                                    onChange={handleEndDateChange}
                                    className="bg-[#0d0e10] border border-white/[0.08] rounded px-1 py-0 text-[10px] text-[#e8e8e8] w-full h-5 focus:border-[#5e6ad2] outline-none"
                                />
                            </div>
                        </div>

                        <button
                            onClick={handleAutoScheduleClick}
                            disabled={!onAutoSchedule}
                            className="flex flex-col items-center justify-center px-3 py-1 bg-[#7c6ebd] hover:bg-[#8f82c9] text-white rounded-lg transition-all hover:scale-[1.02] active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed border border-[#7c6ebd]/30 h-full min-w-[80px] group/btn"
                            title="Automatically fit to capacity"
                        >
                            <Sparkles size={14} className={onAutoSchedule ? "text-amber-200 group-hover/btn:animate-pulse mb-0.5" : "mb-0.5"} />
                            <span className="text-[8px] font-semibold uppercase tracking-wide text-white/90 text-center leading-none">Auto-Fit<br/>Capacity</span>
                        </button>
                    </div>
                </div>
            </div>

            {/* Notes Section */}
            <div className="bg-[#141517]/50 border border-white/[0.06] rounded-xl p-4">
                <h4 className="text-xs font-semibold text-[#6b7280] uppercase mb-2 flex items-center gap-2">
                    <FileText size={12} /> Project Notes
                </h4>
                <textarea
                    value={formData.notes || ''}
                    onChange={(e) => handleInputChange('notes', e.target.value)}
                    className="w-full bg-[#0d0e10] border border-white/[0.08] rounded-lg p-3 text-xs text-[#e8e8e8] focus:border-[#5e6ad2] outline-none min-h-[80px] font-mono resize-y"
                    placeholder="Add internal notes, scheduling constraints, or customer requests..."
                />
            </div>

            {/* Work Scope Compact */}
            <div className="bg-[#141517]/30 border border-white/[0.06] rounded-xl p-4 flex items-center justify-between hover:bg-[#141517]/50 transition-colors">
                <div>
                    <h4 className="text-xs font-semibold text-[#6e79d6] uppercase mb-0.5">Work Scope & Pricing</h4>
                    <p className="text-[10px] text-[#9ca3af]">
                        {formData.quoteLines?.length ? `${formData.quoteLines.length} Line Items Configured` : 'Configure pricing and work items'}
                    </p>
                </div>

                <button
                    onClick={onEditQuote}
                    className="group flex items-center gap-2 bg-[#5e6ad2]/10 hover:bg-[#5e6ad2]/20 text-[#6e79d6] border border-[#5e6ad2]/20 hover:text-white px-3 py-1.5 rounded-lg transition-all"
                >
                    <PenTool size={12} />
                    <span className="text-xs font-semibold">Edit Quote</span>
                    <ArrowRight size={12} className="group-hover:translate-x-0.5 transition-transform opacity-50" />
                </button>
            </div>

            {/* Payment Status - Only show for completed jobs */}
            {isScheduled && ((formData as ScheduledJob).status === 'Completed' || (formData as ScheduledJob).progress >= (formData as ScheduledJob).estimatedHours) && (
                <div className="bg-[#141517]/50 border border-white/[0.06] rounded-xl p-4">
                    <h4 className="text-xs font-semibold text-[#6b7280] uppercase mb-3 flex items-center gap-2">
                        <CreditCard size={12} /> Payment Status
                    </h4>
                    <div className="flex gap-2">
                        {(['pending', 'invoiced', 'paid', 'overdue'] as PaymentStatus[]).map((status) => {
                            const statusConfig = {
                                pending: { icon: <Clock size={14} />, label: 'Pending', color: 'text-amber-400', bg: 'bg-amber-500/10 border-amber-500/30', activeBg: 'bg-amber-500 border-amber-500' },
                                invoiced: { icon: <Receipt size={14} />, label: 'Invoiced', color: 'text-blue-400', bg: 'bg-blue-500/10 border-blue-500/30', activeBg: 'bg-blue-500 border-blue-500' },
                                paid: { icon: <CheckCircle size={14} />, label: 'Paid', color: 'text-emerald-400', bg: 'bg-emerald-500/10 border-emerald-500/30', activeBg: 'bg-emerald-500 border-emerald-500' },
                                overdue: { icon: <AlertCircle size={14} />, label: 'Overdue', color: 'text-rose-400', bg: 'bg-rose-500/10 border-rose-500/30', activeBg: 'bg-rose-500 border-rose-500' }
                            }[status];
                            const currentStatus = (formData as ScheduledJob).paymentStatus || 'pending';
                            const isActive = currentStatus === status;

                            return (
                                <button
                                    key={status}
                                    onClick={() => handleInputChange('paymentStatus', status)}
                                    className={`flex-1 flex flex-col items-center gap-1 py-2.5 px-2 rounded-lg border transition-all ${
                                        isActive
                                            ? `${statusConfig.activeBg} text-white`
                                            : `${statusConfig.bg} ${statusConfig.color} hover:opacity-80`
                                    }`}
                                >
                                    {statusConfig.icon}
                                    <span className="text-[10px] font-semibold uppercase">{statusConfig.label}</span>
                                </button>
                            );
                        })}
                    </div>
                    {(formData as ScheduledJob).paymentStatus === 'paid' && (
                        <p className="text-[10px] text-emerald-400 mt-2 flex items-center gap-1">
                            <CheckCircle size={10} /> Payment received
                        </p>
                    )}
                    {(formData as ScheduledJob).paymentStatus === 'overdue' && (
                        <p className="text-[10px] text-rose-400 mt-2 flex items-center gap-1">
                            <AlertCircle size={10} /> Payment is past due
                        </p>
                    )}
                </div>
            )}

        </div>

        {/* Footer */}
        <div className="p-4 border-t border-white/[0.06] bg-[#08090a] flex justify-between items-center">
            <div className="text-[10px] text-[#4b5563] font-mono">
                ID: {job.id}
            </div>
            <button
                onClick={handleSave}
                className="bg-[#5e6ad2] hover:bg-[#7b86e0] text-white font-semibold py-2.5 px-8 rounded-lg transition-all hover:scale-[1.02] text-xs uppercase tracking-wide"
            >
                Save Changes
            </button>
        </div>

      </div>
    </div>
  );
};

export default React.memo(JobDetailsModal);
