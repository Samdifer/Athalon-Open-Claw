

import React, { useState, useEffect, useMemo } from 'react';
import { Settings, Plus, Trash2, Wrench, CheckSquare, X, Square, Warehouse, GripVertical, MapPin, CheckCircle, Clock, Flag, Package, Download, AlertTriangle, FolderCog, ChevronDown, List, LayoutGrid, Grid3x3, Search, ArrowUpDown, Filter, Layers, Milestone } from 'lucide-react';
import { GameState, AircraftModel, Hangar, ProjectStage, ProgressCursor, AircraftPackage, AircraftConflict, Base, FacilityPackage, FacilityPackageHangar } from '../types';
import { DOLLAR_SIGN } from '../App';
import { TAILWIND_COLORS, AIRCRAFT_PACKAGES, FACILITY_PACKAGES, STAGE_PRESETS, CURSOR_PRESETS, StagePreset, CursorPreset } from '../constants';
import { generateUUID } from '../utils';
import AircraftDuplicateModal from './AircraftDuplicateModal';
import AircraftPackageManager from './AircraftPackageManager';
import { EmptyState } from './ui';

interface ConfigurationPanelProps {
  gameState: GameState;
  onUpdateHangars: (hangars: Hangar[]) => void;
  onUpdateBases: (bases: Base[]) => void;
  onUpdateAircraft: (models: AircraftModel[]) => void;
  onUpdateCustomPackages: (packages: AircraftPackage[]) => void;
  onUpdateProjectStages: (stages: ProjectStage[]) => void;
  onUpdateCursors: (cursors: ProgressCursor[]) => void;
  onClose: () => void;
  activeTabOverride?: 'fleet' | 'hangars' | 'stages' | 'cursors' | null;
}

const ConfigurationPanel: React.FC<ConfigurationPanelProps> = ({
  gameState, onUpdateHangars, onUpdateBases, onUpdateAircraft, onUpdateCustomPackages, onUpdateProjectStages, onUpdateCursors, onClose, activeTabOverride
}) => {
  const [activeTab, setActiveTab] = useState<'fleet' | 'hangars' | 'stages' | 'cursors'>('fleet');

  useEffect(() => {
    if (activeTabOverride) {
      setActiveTab(activeTabOverride);
    }
  }, [activeTabOverride]);

  // --- Error Message State (replaces alerts) ---
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Auto-dismiss error messages after 4 seconds
  useEffect(() => {
      if (errorMessage) {
          const timer = setTimeout(() => setErrorMessage(null), 4000);
          return () => clearTimeout(timer);
      }
  }, [errorMessage]);

  // --- Fleet State ---
  const [newModelName, setNewModelName] = useState('');
  const [newModelHangarIds, setNewModelHangarIds] = useState<string[]>([]);

  // Default to all hangars when component mounts or hangars change
  useEffect(() => {
      setNewModelHangarIds(gameState.hangars.map(h => h.id));
  }, [gameState.hangars]);

  // --- Package Import State ---
  const [selectedPackageId, setSelectedPackageId] = useState<string>('');
  const [showPackageManager, setShowPackageManager] = useState(false);
  const [showDuplicateModal, setShowDuplicateModal] = useState(false);
  const [showImportWarning, setShowImportWarning] = useState(false);
  const [pendingImport, setPendingImport] = useState<{
    package: AircraftPackage;
    conflicts: AircraftConflict[];
    nonConflicting: Omit<AircraftModel, 'id'>[];
    currentConflictIndex: number;
  } | null>(null);

  // Combined packages (built-in + custom)
  const allPackages = useMemo(() => [
    ...AIRCRAFT_PACKAGES,
    ...(gameState.customAircraftPackages || [])
  ], [gameState.customAircraftPackages]);

  // Get selected package preview
  const selectedPackage = useMemo(() =>
    allPackages.find(p => p.id === selectedPackageId),
    [allPackages, selectedPackageId]
  );

  // --- View Mode, Filter, and Sort State ---
  type ViewMode = 'list' | 'small' | 'large';
  type SortField = 'name' | 'manufacturer' | 'hangarCount';
  type SortDirection = 'asc' | 'desc';

  const [viewMode, setViewMode] = useState<ViewMode>('large');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedManufacturers, setSelectedManufacturers] = useState<string[]>([]);
  const [selectedHangarIds, setSelectedHangarIds] = useState<string[]>([]);
  const [sortField, setSortField] = useState<SortField>('name');
  const [sortDirection, setSortDirection] = useState<SortDirection>('asc');
  const [showManufacturerDropdown, setShowManufacturerDropdown] = useState(false);
  const [showHangarDropdown, setShowHangarDropdown] = useState(false);
  const [showSortDropdown, setShowSortDropdown] = useState(false);

  // Unique manufacturers list
  const uniqueManufacturers = useMemo(() =>
    [...new Set(gameState.aircraftModels.map(m => m.manufacturer))].filter(Boolean).sort(),
    [gameState.aircraftModels]
  );

  // Filtered aircraft
  const filteredAircraft = useMemo(() => {
    return gameState.aircraftModels.filter(model => {
      // Name/manufacturer search (case-insensitive)
      const matchesSearch = !searchTerm ||
        model.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (model.manufacturer && model.manufacturer.toLowerCase().includes(searchTerm.toLowerCase()));

      // Manufacturer filter (if any selected, must match one)
      const matchesManufacturer = selectedManufacturers.length === 0 ||
        selectedManufacturers.includes(model.manufacturer);

      // Hangar filter - show aircraft that can fit in ANY selected hangar
      const matchesHangar = selectedHangarIds.length === 0 ||
        selectedHangarIds.some(hangarId => {
          const hangar = gameState.hangars.find(h => h.id === hangarId);
          return hangar?.supportedTypes.includes(model.id);
        });

      return matchesSearch && matchesManufacturer && matchesHangar;
    });
  }, [gameState.aircraftModels, gameState.hangars, searchTerm, selectedManufacturers, selectedHangarIds]);

  // Sorted aircraft
  const sortedAircraft = useMemo(() => {
    return [...filteredAircraft].sort((a, b) => {
      let comparison = 0;

      if (sortField === 'name') {
        comparison = a.name.localeCompare(b.name);
      } else if (sortField === 'manufacturer') {
        comparison = (a.manufacturer || '').localeCompare(b.manufacturer || '');
      } else if (sortField === 'hangarCount') {
        const aCount = gameState.hangars.filter(h => h.supportedTypes.includes(a.id)).length;
        const bCount = gameState.hangars.filter(h => h.supportedTypes.includes(b.id)).length;
        comparison = aCount - bCount;
      }

      return sortDirection === 'asc' ? comparison : -comparison;
    });
  }, [filteredAircraft, sortField, sortDirection, gameState.hangars]);

  // Helper to get hangar count for a model
  const getHangarCount = (modelId: string) => {
    return gameState.hangars.filter(h => h.supportedTypes.includes(modelId)).length;
  };

  // --- Hangar Local State ---
  const [localHangars, setLocalHangars] = useState<Hangar[]>(gameState.hangars);
  const [hangarUnsaved, setHangarUnsaved] = useState(false);
  const [draggedHangarIndex, setDraggedHangarIndex] = useState<number | null>(null);

  // --- New Hangar Form State ---
  const [newHangarName, setNewHangarName] = useState('');
  const [newHangarBaseId, setNewHangarBaseId] = useState(gameState.bases[0]?.id || '');
  const [newHangarSize, setNewHangarSize] = useState<'Small' | 'Medium' | 'Large'>('Medium');

  // --- Base Local State ---
  const [localBases, setLocalBases] = useState<Base[]>(gameState.bases);
  const [basesUnsaved, setBasesUnsaved] = useState(false);
  const [newBaseName, setNewBaseName] = useState('');
  const [newBaseLocation, setNewBaseLocation] = useState('');

  // --- Facility Package State ---
  const [selectedFacilityPackageId, setSelectedFacilityPackageId] = useState<string>('');
  const [editableFacilityPackage, setEditableFacilityPackage] = useState<{
    bases: Omit<Base, 'id'>[];
    hangars: FacilityPackageHangar[];
  } | null>(null);
  const [showFacilityPackageEdit, setShowFacilityPackageEdit] = useState(false);

  // Get selected facility package
  const selectedFacilityPackage = useMemo(() =>
    FACILITY_PACKAGES.find(p => p.id === selectedFacilityPackageId),
    [selectedFacilityPackageId]
  );

  // --- Stages Local State ---
  const [localStages, setLocalStages] = useState<ProjectStage[]>(gameState.projectStages);
  const [stageUnsaved, setStageUnsaved] = useState(false);
  const [draggedStageIndex, setDraggedStageIndex] = useState<number | null>(null);

  // --- Cursors Local State ---
  const [localCursors, setLocalCursors] = useState<ProgressCursor[]>(gameState.cursors);
  const [cursorsUnsaved, setCursorsUnsaved] = useState(false);

  // --- Preset Selection State ---
  const [selectedStagePresetId, setSelectedStagePresetId] = useState<string>('');
  const [selectedCursorPresetId, setSelectedCursorPresetId] = useState<string>('');

  // Use global shop rate
  const shopRate = gameState.shopRate || 125;

  // --- Fleet Management ---

  const handleAddAircraft = () => {
    if (!newModelName) return;
    const newModel: AircraftModel = {
      id: generateUUID(),
      name: newModelName,
    };
    
    onUpdateAircraft([...gameState.aircraftModels, newModel]);
    
    const updatedHangars = gameState.hangars.map(h => {
        if (newModelHangarIds.includes(h.id)) {
            return { ...h, supportedTypes: [...h.supportedTypes, newId] };
        }
        return h;
    });
    onUpdateHangars(updatedHangars);
    
    setNewModelName('');
    setNewModelHangarIds(gameState.hangars.map(h => h.id)); // Reset to all checked
  };

  const handleUpdateModelName = (id: string, name: string) => {
      const updatedModels = gameState.aircraftModels.map(m => 
          m.id === id ? { ...m, name } : m
      );
      onUpdateAircraft(updatedModels);
  };

  const handleToggleHangarForModel = (modelId: string, hangarId: string) => {
      const currentHangar = gameState.hangars.find(h => h.id === hangarId);
      if (!currentHangar) return;

      const isSupported = currentHangar.supportedTypes.includes(modelId);
      
      const updatedHangars = gameState.hangars.map(h => {
          if (h.id === hangarId) {
              const newTypes = isSupported 
                  ? h.supportedTypes.filter(t => t !== modelId)
                  : [...h.supportedTypes, modelId];
              return { ...h, supportedTypes: newTypes };
          }
          return h;
      });
      onUpdateHangars(updatedHangars);
  };

  const handleDeleteModel = (id: string) => {
    onUpdateAircraft(gameState.aircraftModels.filter(m => m.id !== id));
  };

  // --- Package Import Handlers ---

  const detectDuplicates = (incoming: Omit<AircraftModel, 'id'>[]): {
    conflicts: AircraftConflict[];
    nonConflicting: Omit<AircraftModel, 'id'>[];
  } => {
    const conflicts: AircraftConflict[] = [];
    const nonConflicting: Omit<AircraftModel, 'id'>[] = [];

    incoming.forEach(incomingAircraft => {
      const existing = gameState.aircraftModels.find(
        m => m.name.toLowerCase() === incomingAircraft.name.toLowerCase()
      );
      if (existing) {
        conflicts.push({ incoming: incomingAircraft, existing, resolution: null });
      } else {
        nonConflicting.push(incomingAircraft);
      }
    });

    return { conflicts, nonConflicting };
  };

  const handleStartPackageImport = () => {
    if (!selectedPackage) return;

    const { conflicts, nonConflicting } = detectDuplicates(selectedPackage.aircraft);

    if (conflicts.length > 0) {
      setPendingImport({
        package: selectedPackage,
        conflicts,
        nonConflicting,
        currentConflictIndex: 0
      });
      setShowDuplicateModal(true);
    } else {
      executeImport(nonConflicting, []);
    }
  };

  const executeImport = (
    newAircraft: Omit<AircraftModel, 'id'>[],
    resolvedConflicts: AircraftConflict[]
  ) => {
    const aircraftToAdd: AircraftModel[] = [];
    const aircraftToUpdate: AircraftModel[] = [];

    // Process non-conflicting aircraft
    newAircraft.forEach(a => {
      aircraftToAdd.push({
        id: generateUUID(),
        name: a.name,
      });
    });

    // Process resolved conflicts
    resolvedConflicts.forEach(conflict => {
      switch (conflict.resolution) {
        case 'overwrite':
          aircraftToUpdate.push({
            ...conflict.existing,
            name: conflict.incoming.name,
          });
          break;
        case 'keep_both':
          aircraftToAdd.push({
            id: generateUUID(),
            name: conflict.incoming.name,
          });
          break;
        case 'skip':
        default:
          // Do nothing
          break;
      }
    });

    // Build new aircraft list
    let updatedModels = gameState.aircraftModels.map(m => {
      const update = aircraftToUpdate.find(u => u.id === m.id);
      return update || m;
    });
    updatedModels = [...updatedModels, ...aircraftToAdd];

    // Auto-assign new aircraft to all hangars
    const newIds = aircraftToAdd.map(a => a.id);
    const updatedHangars = gameState.hangars.map(h => ({
      ...h,
      supportedTypes: [...new Set([...h.supportedTypes, ...newIds])]
    }));

    onUpdateAircraft(updatedModels);
    onUpdateHangars(updatedHangars);

    // Show warning banner if aircraft were added
    if (aircraftToAdd.length > 0) {
      setShowImportWarning(true);
    }

    // Cleanup state
    setPendingImport(null);
    setShowDuplicateModal(false);
    setSelectedPackageId('');
  };

  const handleResolveConflict = (resolution: 'overwrite' | 'skip' | 'keep_both') => {
    if (!pendingImport) return;

    const updatedConflicts = [...pendingImport.conflicts];
    updatedConflicts[pendingImport.currentConflictIndex].resolution = resolution;

    const nextIndex = pendingImport.currentConflictIndex + 1;

    if (nextIndex < pendingImport.conflicts.length) {
      // Move to next conflict
      setPendingImport({
        ...pendingImport,
        conflicts: updatedConflicts,
        currentConflictIndex: nextIndex
      });
    } else {
      // All conflicts resolved, execute import
      setShowDuplicateModal(false);
      executeImport(pendingImport.nonConflicting, updatedConflicts);
    }
  };

  const handleApplyToAllConflicts = (resolution: 'overwrite' | 'skip' | 'keep_both') => {
    if (!pendingImport) return;

    const updatedConflicts = pendingImport.conflicts.map(c => ({
      ...c,
      resolution
    }));

    setShowDuplicateModal(false);
    executeImport(pendingImport.nonConflicting, updatedConflicts);
  };

  const handleCancelImport = () => {
    setPendingImport(null);
    setShowDuplicateModal(false);
  };

  // --- Hangar Bulk Management & DnD ---

  const handleHangarNameChange = (hangarId: string, name: string) => {
    const updatedHangars = localHangars.map(h => 
      h.id === hangarId ? { ...h, name } : h
    );
    setLocalHangars(updatedHangars);
    setHangarUnsaved(true);
  };

  const handleHangarBaseChange = (hangarId: string, baseId: string) => {
    const updatedHangars = localHangars.map(h => 
      h.id === hangarId ? { ...h, baseId } : h
    );
    setLocalHangars(updatedHangars);
    setHangarUnsaved(true);
  };

  const handleHangarSizeChange = (hangarId: string, size: any) => {
    const updatedHangars = localHangars.map(h => 
      h.id === hangarId ? { ...h, size } : h
    );
    setLocalHangars(updatedHangars);
    setHangarUnsaved(true);
  };

  const handleSaveHangars = () => {
      onUpdateHangars(localHangars);
      setHangarUnsaved(false);
  };

  const handleResetHangars = () => {
      setLocalHangars(gameState.hangars);
      setHangarUnsaved(false);
  };

  const handleAddHangar = () => {
      if (!newHangarName.trim()) return;

      const newHangar: Hangar = {
          id: generateUUID(),
          name: newHangarName.trim(),
          baseId: newHangarBaseId || gameState.bases[0]?.id,
          size: newHangarSize,
          supportedTypes: gameState.aircraftModels.map(m => m.id) // Support all aircraft by default
      };

      setLocalHangars([...localHangars, newHangar]);
      setHangarUnsaved(true);

      // Reset form
      setNewHangarName('');
      setNewHangarSize('Medium');
  };

  const handleDeleteHangar = (hangarId: string) => {
      // Check if hangar has scheduled jobs
      const hasScheduledJobs = gameState.schedule.some(job => job.hangarId === hangarId);

      if (hasScheduledJobs) {
          setErrorMessage('Cannot delete hangar with scheduled jobs. Please reassign or complete jobs first.');
          return;
      }

      setLocalHangars(localHangars.filter(h => h.id !== hangarId));
      setHangarUnsaved(true);
  };

  const onDragStartHangar = (e: React.DragEvent, index: number) => {
      setDraggedHangarIndex(index);
      e.dataTransfer.effectAllowed = "move";
  };

  const onDragOverHangar = (e: React.DragEvent, index: number) => {
      e.preventDefault();
  };

  const onDropHangar = (e: React.DragEvent, dropIndex: number) => {
      if (draggedHangarIndex === null || draggedHangarIndex === dropIndex) return;

      const newHangars = [...localHangars];
      const [removed] = newHangars.splice(draggedHangarIndex, 1);
      newHangars.splice(dropIndex, 0, removed);

      setLocalHangars(newHangars);
      setHangarUnsaved(true);
      setDraggedHangarIndex(null);
  };

  // --- Base Management ---
  const handleBaseNameChange = (baseId: string, name: string) => {
    const updated = localBases.map(b => b.id === baseId ? { ...b, name } : b);
    setLocalBases(updated);
    setBasesUnsaved(true);
  };

  const handleBaseLocationChange = (baseId: string, location: string) => {
    const updated = localBases.map(b => b.id === baseId ? { ...b, location } : b);
    setLocalBases(updated);
    setBasesUnsaved(true);
  };

  const handleAddBase = () => {
    if (!newBaseName.trim()) return;

    const newBase: Base = {
      id: generateUUID(),
      name: newBaseName.trim(),
      location: newBaseLocation.trim() || 'Location TBD'
    };

    setLocalBases([...localBases, newBase]);
    setBasesUnsaved(true);
    setNewBaseName('');
    setNewBaseLocation('');
  };

  const handleDeleteBase = (baseId: string) => {
    // Check if any hangars are assigned to this base
    const assignedHangars = localHangars.filter(h => h.baseId === baseId);
    if (assignedHangars.length > 0) {
      setErrorMessage(`Cannot delete base: ${assignedHangars.length} hangar(s) are assigned. Reassign hangars first.`);
      return;
    }

    // Check if any personnel are assigned to this base
    const assignedPersonnel = gameState.personnel.filter(p => p.baseId === baseId);
    if (assignedPersonnel.length > 0) {
      setErrorMessage(`Cannot delete base: ${assignedPersonnel.length} personnel are assigned. Reassign personnel first.`);
      return;
    }

    // Check if any teams are assigned to this base
    const assignedTeams = gameState.teams.filter(t => t.baseId === baseId);
    if (assignedTeams.length > 0) {
      setErrorMessage(`Cannot delete base: ${assignedTeams.length} team(s) are assigned. Reassign teams first.`);
      return;
    }

    setLocalBases(localBases.filter(b => b.id !== baseId));
    setBasesUnsaved(true);
  };

  const handleSaveBases = () => {
    onUpdateBases(localBases);
    setBasesUnsaved(false);
  };

  const handleResetBases = () => {
    setLocalBases(gameState.bases);
    setBasesUnsaved(false);
  };

  // --- Facility Package Handlers ---
  const handleSelectFacilityPackage = (packageId: string) => {
    setSelectedFacilityPackageId(packageId);
    const pkg = FACILITY_PACKAGES.find(p => p.id === packageId);
    if (pkg) {
      setEditableFacilityPackage({
        bases: [...pkg.bases],
        hangars: [...pkg.hangars]
      });
    } else {
      setEditableFacilityPackage(null);
    }
    setShowFacilityPackageEdit(false);
  };

  const handleEditFacilityPackage = () => {
    if (selectedFacilityPackage && editableFacilityPackage) {
      setShowFacilityPackageEdit(true);
    }
  };

  const handleUpdateEditableBase = (index: number, field: 'name' | 'location', value: string) => {
    if (!editableFacilityPackage) return;
    const updated = [...editableFacilityPackage.bases];
    updated[index] = { ...updated[index], [field]: value };
    setEditableFacilityPackage({ ...editableFacilityPackage, bases: updated });
  };

  const handleUpdateEditableHangar = (index: number, field: keyof FacilityPackageHangar, value: any) => {
    if (!editableFacilityPackage) return;
    const updated = [...editableFacilityPackage.hangars];
    updated[index] = { ...updated[index], [field]: value };
    setEditableFacilityPackage({ ...editableFacilityPackage, hangars: updated });
  };

  const handleLoadFacilityPackage = () => {
    if (!editableFacilityPackage) return;

    // Generate IDs for bases
    const newBases: Base[] = editableFacilityPackage.bases.map((b, index) => ({
      id: `base-pkg-${generateUUID()}`,
      name: b.name,
      location: b.location
    }));

    // Generate IDs for hangars, linking to the new base IDs
    const newHangars: Hangar[] = editableFacilityPackage.hangars.map(h => ({
      id: `hangar-pkg-${generateUUID()}`,
      name: h.name,
      size: h.size,
      supportedTypes: h.supportedTypes.length > 0 ? h.supportedTypes : gameState.aircraftModels.map(a => a.id),
      baseId: newBases[h.baseIndex]?.id || newBases[0]?.id || ''
    }));

    // Update local state
    setLocalBases([...localBases, ...newBases]);
    setLocalHangars([...localHangars, ...newHangars]);
    setBasesUnsaved(true);
    setHangarUnsaved(true);

    // Reset package selection
    setSelectedFacilityPackageId('');
    setEditableFacilityPackage(null);
    setShowFacilityPackageEdit(false);
  };

  // --- Stage Management & DnD ---
  const handleUpdateStage = (id: string, field: keyof ProjectStage, value: any) => {
      const updated = localStages.map(s => s.id === id ? { ...s, [field]: value } : s);
      setLocalStages(updated);
      setStageUnsaved(true);
  };

  const handleAddStage = () => {
      const newStage: ProjectStage = {
          id: generateUUID(),
          label: 'New Stage',
          description: 'Description here',
          color: 'bg-slate-500'
      };
      setLocalStages([...localStages, newStage]);
      setStageUnsaved(true);
  };

  const handleDeleteStage = (id: string) => {
      setLocalStages(localStages.filter(s => s.id !== id));
      setStageUnsaved(true);
  };

  const handleSaveStages = () => {
      onUpdateProjectStages(localStages);
      setStageUnsaved(false);
  };

  const handleResetStages = () => {
      setLocalStages(gameState.projectStages);
      setStageUnsaved(false);
  };

  const onDragStartStage = (e: React.DragEvent, index: number) => {
      setDraggedStageIndex(index);
      e.dataTransfer.effectAllowed = "move";
  };

  const onDragOverStage = (e: React.DragEvent) => {
      e.preventDefault();
  };

  const onDropStage = (e: React.DragEvent, dropIndex: number) => {
      e.preventDefault();
      if (draggedStageIndex === null || draggedStageIndex === dropIndex) return;
      
      const newStages = [...localStages];
      const [removed] = newStages.splice(draggedStageIndex, 1);
      newStages.splice(dropIndex, 0, removed);
      
      setLocalStages(newStages);
      setStageUnsaved(true);
      setDraggedStageIndex(null);
  };

  // --- Cursor Management ---
  const handleUpdateCursor = (id: string, field: keyof ProgressCursor, value: any) => {
      const updated = localCursors.map(c => c.id === id ? { ...c, [field]: value } : c);
      setLocalCursors(updated);
      setCursorsUnsaved(true);
  };

  const handleAddCursor = () => {
      const newCursor: ProgressCursor = {
          id: generateUUID(),
          label: 'New Cursor',
          dayOffset: 7,
          color: 'bg-slate-500',
          enabled: true
      };
      setLocalCursors([...localCursors, newCursor]);
      setCursorsUnsaved(true);
  };

  const handleDeleteCursor = (id: string) => {
      setLocalCursors(localCursors.filter(c => c.id !== id));
      setCursorsUnsaved(true);
  };

  const handleSaveCursors = () => {
      onUpdateCursors(localCursors);
      setCursorsUnsaved(false);
  };

  const handleResetCursors = () => {
      setLocalCursors(gameState.cursors);
      setCursorsUnsaved(false);
  };

  // --- Preset Loading Handlers ---
  const handleLoadStagePreset = () => {
      const preset = STAGE_PRESETS.find(p => p.id === selectedStagePresetId);
      if (!preset) return;

      const newStages: ProjectStage[] = preset.stages.map(s => ({
          id: generateUUID(),
          label: s.label,
          description: s.description,
          color: s.color
      }));

      setLocalStages(newStages);
      setStageUnsaved(true);
      setSelectedStagePresetId('');
  };

  const handleAddStageFromPreset = () => {
      const preset = STAGE_PRESETS.find(p => p.id === selectedStagePresetId);
      if (!preset) return;

      const newStages: ProjectStage[] = preset.stages.map(s => ({
          id: generateUUID(),
          label: s.label,
          description: s.description,
          color: s.color
      }));

      setLocalStages([...localStages, ...newStages]);
      setStageUnsaved(true);
      setSelectedStagePresetId('');
  };

  const handleLoadCursorPreset = () => {
      const preset = CURSOR_PRESETS.find(p => p.id === selectedCursorPresetId);
      if (!preset) return;

      const newCursors: ProgressCursor[] = preset.cursors.map(c => ({
          id: generateUUID(),
          label: c.label,
          dayOffset: c.dayOffset,
          color: c.color,
          enabled: c.enabled
      }));

      setLocalCursors(newCursors);
      setCursorsUnsaved(true);
      setSelectedCursorPresetId('');
  };

  const handleAddCursorsFromPreset = () => {
      const preset = CURSOR_PRESETS.find(p => p.id === selectedCursorPresetId);
      if (!preset) return;

      const newCursors: ProgressCursor[] = preset.cursors.map(c => ({
          id: generateUUID(),
          label: c.label,
          dayOffset: c.dayOffset,
          color: c.color,
          enabled: c.enabled
      }));

      setLocalCursors([...localCursors, ...newCursors]);
      setCursorsUnsaved(true);
      setSelectedCursorPresetId('');
  };

  // Get selected presets for preview
  const selectedStagePreset = useMemo(() =>
      STAGE_PRESETS.find(p => p.id === selectedStagePresetId),
      [selectedStagePresetId]
  );

  const selectedCursorPreset = useMemo(() =>
      CURSOR_PRESETS.find(p => p.id === selectedCursorPresetId),
      [selectedCursorPresetId]
  );

  return (
    <div className="fixed inset-0 bg-[#08090a]/60 z-[60] flex items-center justify-center p-8 overflow-hidden backdrop-blur-sm">
      <div id="modal-config" className="bg-[#0d0e10] w-full max-w-6xl h-[90vh] rounded-xl border border-white/[0.08] shadow-2xl flex flex-col overflow-hidden">

        {/* Header */}
        <div className="bg-[#0d0e10] p-6 border-b border-white/[0.06] flex justify-between items-center shrink-0">
          <div className="flex items-center gap-3">
            <Settings className="text-[#6e79d6]" size={24} />
            <h2 className="text-xl font-semibold text-white">Station Configuration</h2>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-[#141517] rounded-lg text-[#6b7280] hover:text-[#d1d5db] transition-colors">
            <X size={24} />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-white/[0.06] bg-[#08090a] shrink-0 justify-between pr-6">
          <div className="flex">
            <button
              id="tab-config-fleet"
              onClick={() => setActiveTab('fleet')}
              className={`px-6 py-4 text-sm font-semibold uppercase tracking-wide border-b-2 transition-colors ${activeTab === 'fleet' ? 'border-[#5e6ad2] text-white bg-[#0d0e10]' : 'border-transparent text-[#6b7280] hover:text-[#d1d5db]'}`}
            >
              Aircraft Profiles
            </button>
            <button
              id="tab-config-hangars"
              onClick={() => setActiveTab('hangars')}
              className={`px-6 py-4 text-sm font-semibold uppercase tracking-wide border-b-2 transition-colors ${activeTab === 'hangars' ? 'border-[#5e6ad2] text-white bg-[#0d0e10]' : 'border-transparent text-[#6b7280] hover:text-[#d1d5db]'}`}
            >
              Facilities & Bases
            </button>
            <button
              id="tab-config-stages"
              onClick={() => setActiveTab('stages')}
              className={`px-6 py-4 text-sm font-semibold uppercase tracking-wide border-b-2 transition-colors ${activeTab === 'stages' ? 'border-[#5e6ad2] text-white bg-[#0d0e10]' : 'border-transparent text-[#6b7280] hover:text-[#d1d5db]'}`}
            >
              Project Stages
            </button>
            <button
              id="tab-config-cursors"
              onClick={() => setActiveTab('cursors')}
              className={`px-6 py-4 text-sm font-semibold uppercase tracking-wide border-b-2 transition-colors ${activeTab === 'cursors' ? 'border-[#5e6ad2] text-white bg-[#0d0e10]' : 'border-transparent text-[#6b7280] hover:text-[#d1d5db]'}`}
            >
              Timeline Cursors
            </button>
          </div>

          {/* Global Configs in Tab Bar - READ ONLY */}
          <div className="flex items-center gap-2 text-xs">
              <span className="text-[#6b7280] font-semibold uppercase">Global Shop Rate:</span>
              <div className="relative flex items-center bg-[#0d0e10] border border-white/[0.08] rounded-md py-1 pl-3 pr-3 text-white font-mono cursor-not-allowed" title="Manage in Financials Panel">
                  <span>{DOLLAR_SIGN}{shopRate}/hr</span>
              </div>
          </div>
        </div>

        {/* Error Message Toast */}
        {errorMessage && (
            <div className="mx-6 mt-4 px-4 py-3 bg-rose-500/10 border border-rose-500/20 rounded-lg flex items-center gap-3 animate-in slide-in-from-top-2 duration-200 shrink-0">
                <AlertTriangle size={16} className="text-rose-400 shrink-0" />
                <span className="text-sm text-rose-300">{errorMessage}</span>
                <button onClick={() => setErrorMessage(null)} className="ml-auto text-rose-400 hover:text-rose-300">
                    <X size={14} />
                </button>
            </div>
        )}

        {/* Content */}
        <div className="flex-1 overflow-hidden p-0 bg-[#08090a]/50">
          
          {/* --- CURSORS --- */}
          {activeTab === 'cursors' && (
              <div className="flex flex-col h-full">
                {/* Action Header */}
                <div className="p-3 border-b border-white/[0.06] bg-[#0d0e10] flex justify-between items-center shrink-0 h-12">
                    <div>
                        <h3 className="text-sm font-semibold text-[#e8e8e8] flex items-center gap-2"><Clock size={14}/> Timeline Progress Cursors</h3>
                        <p className="text-[#6b7280] text-[10px]">Vertical lines locked to today's progress. Useful for "2 Weeks Out" markers.</p>
                    </div>
                    <div className="flex gap-2">
                         <button
                            onClick={handleAddCursor}
                            className="px-3 py-1 rounded-md font-semibold text-[10px] flex items-center gap-1 bg-[#141517] text-white border border-white/[0.1] hover:bg-[#1a1b1e] transition-colors"
                        >
                            <Plus size={12} /> Add Cursor
                        </button>
                        <div className="w-px h-6 bg-white/[0.08] mx-1" />
                        <button
                            onClick={handleResetCursors}
                            disabled={!cursorsUnsaved}
                            className={`px-3 py-1 rounded-md font-semibold text-[10px] flex items-center gap-1 transition-colors
                                ${cursorsUnsaved ? 'text-[#9ca3af] hover:bg-[#141517]' : 'text-[#4b5563] cursor-not-allowed'}
                            `}
                        >
                            <Wrench size={12} /> Reset
                        </button>
                        <button
                            onClick={handleSaveCursors}
                            disabled={!cursorsUnsaved}
                            className={`px-4 py-1 rounded-md font-semibold text-[10px] flex items-center gap-1 transition-all
                                ${cursorsUnsaved
                                    ? 'bg-[#5e6ad2] text-white hover:bg-[#7b86e0]'
                                    : 'bg-[#141517] text-[#6b7280] cursor-not-allowed'}
                            `}
                        >
                            <CheckSquare size={12} /> Save Changes
                        </button>
                    </div>
                </div>

                <div className="p-4 space-y-4 overflow-y-auto h-full custom-scrollbar bg-[#08090a]">
                    {/* Preset Loader */}
                    <div className="bg-[#0d0e10] p-4 rounded-lg border border-white/[0.08]">
                        <h4 className="text-xs font-semibold text-[#e8e8e8] mb-3 flex items-center gap-2">
                            <Milestone size={14} className="text-[#6e79d6]" /> Load Cursor Preset
                        </h4>
                        <div className="flex gap-3 items-end">
                            <div className="flex-1">
                                <label className="block text-[9px] font-semibold text-[#6b7280] mb-1 uppercase">Select Preset</label>
                                <select
                                    value={selectedCursorPresetId}
                                    onChange={(e) => setSelectedCursorPresetId(e.target.value)}
                                    className="w-full text-xs bg-[#08090a] border border-white/[0.08] rounded-md px-3 py-2 text-[#e8e8e8] focus:border-[#5e6ad2] outline-none"
                                >
                                    <option value="">Choose a preset...</option>
                                    {CURSOR_PRESETS.map(preset => (
                                        <option key={preset.id} value={preset.id}>{preset.name}</option>
                                    ))}
                                </select>
                            </div>
                            <button
                                onClick={handleAddCursorsFromPreset}
                                disabled={!selectedCursorPresetId}
                                className={`px-3 py-2 rounded-md text-[10px] font-semibold flex items-center gap-1 transition-colors whitespace-nowrap
                                    ${selectedCursorPresetId ? 'bg-[#141517] text-white border border-white/[0.1] hover:bg-[#1a1b1e]' : 'bg-[#141517] text-[#4b5563] cursor-not-allowed'}`}
                            >
                                <Plus size={12} /> Add to Existing
                            </button>
                            <button
                                onClick={handleLoadCursorPreset}
                                disabled={!selectedCursorPresetId}
                                className={`px-3 py-2 rounded-md text-[10px] font-semibold flex items-center gap-1 transition-colors whitespace-nowrap
                                    ${selectedCursorPresetId ? 'bg-[#5e6ad2] text-white hover:bg-[#7b86e0]' : 'bg-[#141517] text-[#4b5563] cursor-not-allowed'}`}
                            >
                                <Download size={12} /> Replace All
                            </button>
                        </div>
                        {selectedCursorPreset && (
                            <div className="mt-3 pt-3 border-t border-white/[0.06]">
                                <p className="text-[10px] text-[#6b7280] mb-2">{selectedCursorPreset.description}</p>
                                <div className="flex flex-wrap gap-2">
                                    {selectedCursorPreset.cursors.map((cursor, idx) => (
                                        <div key={idx} className="flex items-center gap-1.5 bg-[#08090a] px-2 py-1 rounded text-[10px]">
                                            <div className={`w-2.5 h-2.5 rounded-full ${cursor.color}`} />
                                            <span className="text-[#9ca3af]">{cursor.label}</span>
                                            <span className="text-[#6b7280]">({cursor.dayOffset > 0 ? '+' : ''}{cursor.dayOffset}d)</span>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}
                    </div>

                    {/* Cursor List */}
                    <div className="space-y-1">
                        {localCursors.length === 0 && (
                            <div className="text-center py-10 text-[#6b7280] italic text-xs">
                                No custom cursors defined. Add one to track key dates relative to today, or load a preset above.
                            </div>
                        )}

                        {localCursors.map((cursor) => (
                        <div
                            key={cursor.id}
                            className="bg-[#0d0e10]/80 px-2 py-2 rounded-lg border border-white/[0.08] flex items-center gap-4 hover:border-white/[0.15] transition-colors group"
                        >
                            {/* Enabled Toggle */}
                            <div
                                className={`w-8 h-4 rounded-full relative cursor-pointer transition-colors shrink-0 ${cursor.enabled ? 'bg-emerald-600' : 'bg-[#1a1b1e]'}`}
                                onClick={() => handleUpdateCursor(cursor.id, 'enabled', !cursor.enabled)}
                            >
                                <div className={`absolute top-0.5 w-3 h-3 bg-white rounded-full transition-all ${cursor.enabled ? 'left-4.5' : 'left-0.5'}`} />
                            </div>

                            {/* Color Picker */}
                            <div className="group/color relative shrink-0">
                                <div className={`w-4 h-4 rounded-full ${cursor.color} border border-white/[0.1] cursor-pointer ring-1 ring-white/[0.06] hover:scale-110 transition-transform`} />
                                <div className="absolute top-full left-0 mt-1 bg-[#141517] border border-white/[0.08] p-2 rounded-lg shadow-xl grid grid-cols-6 gap-1.5 z-50 w-48 opacity-0 invisible group-hover/color:opacity-100 group-hover/color:visible transition-all">
                                    {TAILWIND_COLORS.map(c => (
                                        <button
                                            key={c}
                                            className={`w-5 h-5 rounded-full ${c} hover:scale-125 transition-transform ${cursor.color === c ? 'ring-1 ring-white' : ''}`}
                                            onClick={() => handleUpdateCursor(cursor.id, 'color', c)}
                                        />
                                    ))}
                                </div>
                            </div>

                            {/* Inputs */}
                            <div className="flex-1 grid grid-cols-4 gap-4 items-center">
                                <div className="col-span-2">
                                    <label className="text-[9px] text-[#6b7280] uppercase font-semibold block mb-0.5">Label</label>
                                    <input
                                        type="text"
                                        value={cursor.label}
                                        onChange={(e) => handleUpdateCursor(cursor.id, 'label', e.target.value)}
                                        className="w-full text-xs font-semibold text-[#e8e8e8] bg-transparent border-b border-transparent hover:border-white/[0.1] focus:border-[#5e6ad2] outline-none pb-0.5"
                                        placeholder="Cursor Label"
                                    />
                                </div>
                                <div className="col-span-1">
                                    <label className="text-[9px] text-[#6b7280] uppercase font-semibold block mb-0.5">Day Offset</label>
                                    <div className="relative">
                                        <input
                                            type="number"
                                            value={cursor.dayOffset}
                                            onChange={(e) => handleUpdateCursor(cursor.id, 'dayOffset', parseInt(e.target.value))}
                                            className="w-full text-xs font-mono text-[#d1d5db] bg-[#08090a] border border-white/[0.08] rounded px-2 py-1 focus:border-[#5e6ad2] outline-none"
                                        />
                                    </div>
                                </div>
                                <div className="col-span-1 flex items-center text-[10px] text-[#6b7280] italic">
                                    {cursor.dayOffset > 0 ? `Future (+${cursor.dayOffset}d)` : cursor.dayOffset < 0 ? `Past (${cursor.dayOffset}d)` : 'Current Day'}
                                </div>
                            </div>

                            {/* Actions */}
                            <div className="shrink-0">
                                <button
                                    onClick={() => handleDeleteCursor(cursor.id)}
                                    className="p-1.5 text-[#4b5563] hover:text-[#c4626a] hover:bg-[#c4626a]/10 rounded-md transition-colors"
                                    title="Delete Cursor"
                                >
                                    <Trash2 size={14} />
                                </button>
                            </div>
                        </div>
                        ))}
                    </div>
                </div>
              </div>
          )}

          {/* --- STAGES --- */}
          {activeTab === 'stages' && (
              <div className="flex flex-col h-full">
                {/* Action Header - Condensed */}
                <div className="p-3 border-b border-white/[0.06] bg-[#0d0e10] flex justify-between items-center shrink-0 h-12">
                    <div>
                        <h3 className="text-sm font-semibold text-[#e8e8e8]">Project Stages & Colors</h3>
                        <p className="text-[#6b7280] text-[10px]">Define lifecycle stages. Drag to reorder.</p>
                    </div>
                    <div className="flex gap-2">
                         <button
                            onClick={handleAddStage}
                            className="px-3 py-1 rounded-md font-semibold text-[10px] flex items-center gap-1 bg-[#141517] text-white border border-white/[0.1] hover:bg-[#1a1b1e] transition-colors"
                        >
                            <Plus size={12} /> Add Stage
                        </button>
                        <div className="w-px h-6 bg-white/[0.08] mx-1" />
                        <button
                            onClick={handleResetStages}
                            disabled={!stageUnsaved}
                            className={`px-3 py-1 rounded-md font-semibold text-[10px] flex items-center gap-1 transition-colors
                                ${stageUnsaved ? 'text-[#9ca3af] hover:bg-[#141517]' : 'text-[#4b5563] cursor-not-allowed'}
                            `}
                        >
                            <Wrench size={12} /> Reset
                        </button>
                        <button
                            onClick={handleSaveStages}
                            disabled={!stageUnsaved}
                            className={`px-4 py-1 rounded-md font-semibold text-[10px] flex items-center gap-1 transition-all
                                ${stageUnsaved
                                    ? 'bg-[#5e6ad2] text-white hover:bg-[#7b86e0]'
                                    : 'bg-[#141517] text-[#6b7280] cursor-not-allowed'}
                            `}
                        >
                            <CheckSquare size={12} /> Save Changes
                        </button>
                    </div>
                </div>

                <div className="p-4 space-y-4 overflow-y-auto h-full custom-scrollbar bg-[#08090a]">
                    {/* Preset Loader */}
                    <div className="bg-[#0d0e10] p-4 rounded-lg border border-white/[0.08]">
                        <h4 className="text-xs font-semibold text-[#e8e8e8] mb-3 flex items-center gap-2">
                            <Layers size={14} className="text-[#6e79d6]" /> Load Workflow Preset
                        </h4>
                        <div className="flex gap-3 items-end">
                            <div className="flex-1">
                                <label className="block text-[9px] font-semibold text-[#6b7280] mb-1 uppercase">Select Preset</label>
                                <select
                                    value={selectedStagePresetId}
                                    onChange={(e) => setSelectedStagePresetId(e.target.value)}
                                    className="w-full text-xs bg-[#08090a] border border-white/[0.08] rounded-md px-3 py-2 text-[#e8e8e8] focus:border-[#5e6ad2] outline-none"
                                >
                                    <option value="">Choose a preset...</option>
                                    {STAGE_PRESETS.map(preset => (
                                        <option key={preset.id} value={preset.id}>{preset.name}</option>
                                    ))}
                                </select>
                            </div>
                            <button
                                onClick={handleAddStageFromPreset}
                                disabled={!selectedStagePresetId}
                                className={`px-3 py-2 rounded-md text-[10px] font-semibold flex items-center gap-1 transition-colors whitespace-nowrap
                                    ${selectedStagePresetId ? 'bg-[#141517] text-white border border-white/[0.1] hover:bg-[#1a1b1e]' : 'bg-[#141517] text-[#4b5563] cursor-not-allowed'}`}
                            >
                                <Plus size={12} /> Add to Existing
                            </button>
                            <button
                                onClick={handleLoadStagePreset}
                                disabled={!selectedStagePresetId}
                                className={`px-3 py-2 rounded-md text-[10px] font-semibold flex items-center gap-1 transition-colors whitespace-nowrap
                                    ${selectedStagePresetId ? 'bg-[#5e6ad2] text-white hover:bg-[#7b86e0]' : 'bg-[#141517] text-[#4b5563] cursor-not-allowed'}`}
                            >
                                <Download size={12} /> Replace All
                            </button>
                        </div>
                        {selectedStagePreset && (
                            <div className="mt-3 pt-3 border-t border-white/[0.06]">
                                <p className="text-[10px] text-[#6b7280] mb-2">{selectedStagePreset.description}</p>
                                <div className="flex flex-wrap gap-2">
                                    {selectedStagePreset.stages.map((stage, idx) => (
                                        <div key={idx} className="flex items-center gap-1.5 bg-[#08090a] px-2 py-1 rounded text-[10px]">
                                            <div className={`w-2.5 h-2.5 rounded-full ${stage.color}`} />
                                            <span className="text-[#9ca3af]">{stage.label}</span>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}
                    </div>

                    {/* Stage List */}
                    <div className="space-y-1">
                        {localStages.map((stage, index) => (
                            <div
                                key={stage.id}
                                draggable={true}
                                onDragStart={(e) => onDragStartStage(e, index)}
                                onDragOver={onDragOverStage}
                                onDrop={(e) => onDropStage(e, index)}
                                className={`
                                    bg-[#0d0e10]/80 px-2 py-0.5 rounded-lg border border-white/[0.08] flex items-center gap-2 hover:border-white/[0.15] transition-colors group h-10
                                    ${draggedStageIndex === index ? 'opacity-50 ring-1 ring-[#5e6ad2]' : ''}
                                `}
                            >
                            {/* Drag Handle */}
                            <div className="text-[#4b5563] hover:text-[#d1d5db] cursor-grab active:cursor-grabbing flex-shrink-0 p-1">
                                <GripVertical size={14} />
                            </div>

                            {/* Color Picker - Condensed */}
                            <div className="shrink-0 flex items-center">
                                <div className="group/color relative">
                                    <div className={`w-4 h-4 rounded-full ${stage.color} border border-white/[0.1] cursor-pointer ring-1 ring-white/[0.06] hover:scale-110 transition-transform`} />
                                    {/* Palette Popover */}
                                    <div className="absolute top-full left-0 mt-1 bg-[#141517] border border-white/[0.08] p-2 rounded-lg shadow-xl grid grid-cols-6 gap-1.5 z-50 w-48 opacity-0 invisible group-hover/color:opacity-100 group-hover/color:visible transition-all">
                                        {TAILWIND_COLORS.map(c => (
                                            <button
                                                key={c}
                                                className={`w-5 h-5 rounded-full ${c} hover:scale-125 transition-transform ${stage.color === c ? 'ring-1 ring-white' : ''}`}
                                                onClick={() => handleUpdateStage(stage.id, 'color', c)}
                                            />
                                        ))}
                                    </div>
                                </div>
                            </div>

                            {/* Inputs - Condensed */}
                            <div className="flex-1 grid grid-cols-3 gap-3">
                                <div className="col-span-1">
                                    <input
                                        type="text"
                                        value={stage.label}
                                        onChange={(e) => handleUpdateStage(stage.id, 'label', e.target.value)}
                                        className="w-full text-[10px] font-semibold text-[#e8e8e8] bg-transparent border-b border-transparent hover:border-white/[0.1] focus:border-[#5e6ad2] outline-none pb-0.5"
                                        placeholder="Stage Name"
                                    />
                                </div>
                                <div className="col-span-2">
                                    <input
                                        type="text"
                                        value={stage.description}
                                        onChange={(e) => handleUpdateStage(stage.id, 'description', e.target.value)}
                                        className="w-full text-[10px] text-[#9ca3af] bg-transparent border-b border-transparent hover:border-white/[0.1] focus:border-[#5e6ad2] outline-none pb-0.5"
                                        placeholder="Description"
                                    />
                                </div>
                            </div>

                            {/* Actions */}
                            <div className="shrink-0">
                                <button
                                    onClick={() => handleDeleteStage(stage.id)}
                                    className="p-1 text-[#4b5563] hover:text-[#c4626a] hover:bg-[#c4626a]/10 rounded-md transition-colors opacity-0 group-hover:opacity-100"
                                    title="Delete Stage"
                                >
                                    <Trash2 size={12} />
                                </button>
                            </div>
                            </div>
                        ))}

                        {localStages.length === 0 && (
                            <div className="text-center py-10 text-[#6b7280] italic text-xs">
                                No stages defined. Add a stage to begin, or load a workflow preset above.
                            </div>
                        )}
                    </div>
                </div>
              </div>
          )}

          {/* --- HANGARS --- */}
          {activeTab === 'hangars' && (
             <div className="flex flex-col h-full">
                {/* Action Header */}
                <div className="p-6 border-b border-white/[0.06] bg-[#0d0e10] flex justify-between items-center shrink-0">
                    <div>
                        <h3 className="text-lg font-semibold text-[#e8e8e8]">Facility Management</h3>
                        <p className="text-[#6b7280] text-sm">Manage bases and hangars. Changes reflect on timeline.</p>
                    </div>
                    <div className="flex gap-3">
                        <button
                            onClick={() => { handleResetBases(); handleResetHangars(); }}
                            disabled={!hangarUnsaved && !basesUnsaved}
                            className={`px-4 py-2 rounded-md font-semibold text-sm flex items-center gap-2 transition-colors
                                ${(hangarUnsaved || basesUnsaved) ? 'text-[#9ca3af] hover:bg-[#141517]' : 'text-[#4b5563] cursor-not-allowed'}
                            `}
                        >
                            <Wrench size={16} /> Reset
                        </button>
                        <button
                            onClick={() => { handleSaveBases(); handleSaveHangars(); }}
                            disabled={!hangarUnsaved && !basesUnsaved}
                            className={`px-6 py-2 rounded-md font-semibold text-sm flex items-center gap-2 transition-all
                                ${(hangarUnsaved || basesUnsaved)
                                    ? 'bg-[#5e6ad2] text-white hover:bg-[#7b86e0]'
                                    : 'bg-[#141517] text-[#6b7280] cursor-not-allowed'}
                            `}
                        >
                            <CheckSquare size={16} /> Save Changes
                        </button>
                    </div>
                </div>

                <div className="p-8 h-full overflow-y-auto custom-scrollbar bg-[#08090a] space-y-8">

                   {/* ===== FACILITY PACKAGES SECTION ===== */}
                   <div className="bg-[#0d0e10] p-6 rounded-xl border border-white/[0.08]">
                       <h3 className="text-lg font-semibold text-[#e8e8e8] mb-4 flex items-center gap-2">
                           <Package size={18} className="text-[#6e79d6]"/> Load Facility Package
                       </h3>
                       <p className="text-[#6b7280] text-xs mb-4">Load pre-configured bases and hangars from a template.</p>

                       <div className="flex gap-4 items-end">
                           <div className="flex-1">
                               <label className="block text-xs font-semibold text-[#6b7280] mb-1 uppercase">Select Package</label>
                               <select
                                   value={selectedFacilityPackageId}
                                   onChange={(e) => handleSelectFacilityPackage(e.target.value)}
                                   className="w-full bg-[#141517] border border-white/[0.1] rounded-md p-2 text-[#e8e8e8] focus:border-[#5e6ad2] outline-none"
                               >
                                   <option value="">-- Select a Package --</option>
                                   {FACILITY_PACKAGES.map(pkg => (
                                       <option key={pkg.id} value={pkg.id}>{pkg.name}</option>
                                   ))}
                               </select>
                           </div>
                           <button
                               onClick={handleEditFacilityPackage}
                               disabled={!selectedFacilityPackageId}
                               className="px-4 py-2 bg-[#141517] hover:bg-[#1a1b1e] disabled:opacity-50 disabled:cursor-not-allowed text-[#d1d5db] font-semibold rounded-md text-sm flex items-center gap-2 transition-colors border border-white/[0.1]"
                           >
                               <FolderCog size={16} /> Edit Before Load
                           </button>
                           <button
                               onClick={handleLoadFacilityPackage}
                               disabled={!selectedFacilityPackageId}
                               className="px-4 py-2 bg-[#5e6ad2] hover:bg-[#7b86e0] disabled:opacity-50 disabled:cursor-not-allowed text-white font-semibold rounded-md text-sm flex items-center gap-2 transition-colors"
                           >
                               <Download size={16} /> Load Package
                           </button>
                       </div>

                       {/* Package Preview */}
                       {selectedFacilityPackage && (
                           <div className="mt-4 p-4 bg-[#08090a] rounded-lg border border-white/[0.06]">
                               <p className="text-[#9ca3af] text-xs mb-2">{selectedFacilityPackage.description}</p>
                               <div className="flex gap-6 text-xs">
                                   <span className="text-[#6b7280]">
                                       <span className="text-[#d1d5db] font-semibold">{selectedFacilityPackage.bases.length}</span> Base(s)
                                   </span>
                                   <span className="text-[#6b7280]">
                                       <span className="text-[#d1d5db] font-semibold">{selectedFacilityPackage.hangars.length}</span> Hangar(s)
                                   </span>
                               </div>
                           </div>
                       )}

                       {/* Editable Package Modal */}
                       {showFacilityPackageEdit && editableFacilityPackage && (
                           <div className="mt-4 p-4 bg-[#141517] rounded-lg border border-[#5e6ad2]/30">
                               <div className="flex justify-between items-center mb-4">
                                   <h4 className="text-sm font-semibold text-[#e8e8e8]">Edit Package Before Loading</h4>
                                   <button
                                       onClick={() => setShowFacilityPackageEdit(false)}
                                       className="text-[#6b7280] hover:text-[#d1d5db]"
                                   >
                                       <X size={16} />
                                   </button>
                               </div>

                               {/* Editable Bases */}
                               <div className="mb-4">
                                   <label className="block text-xs font-semibold text-[#6b7280] mb-2 uppercase">Bases</label>
                                   <div className="space-y-2">
                                       {editableFacilityPackage.bases.map((base, index) => (
                                           <div key={index} className="flex gap-2">
                                               <input
                                                   type="text"
                                                   value={base.name}
                                                   onChange={(e) => handleUpdateEditableBase(index, 'name', e.target.value)}
                                                   className="flex-1 bg-[#08090a] border border-white/[0.1] rounded px-2 py-1 text-xs text-[#e8e8e8] focus:border-[#5e6ad2] outline-none"
                                                   placeholder="Base Name"
                                               />
                                               <input
                                                   type="text"
                                                   value={base.location}
                                                   onChange={(e) => handleUpdateEditableBase(index, 'location', e.target.value)}
                                                   className="flex-1 bg-[#08090a] border border-white/[0.1] rounded px-2 py-1 text-xs text-[#e8e8e8] focus:border-[#5e6ad2] outline-none"
                                                   placeholder="Location"
                                               />
                                           </div>
                                       ))}
                                   </div>
                               </div>

                               {/* Editable Hangars */}
                               <div>
                                   <label className="block text-xs font-semibold text-[#6b7280] mb-2 uppercase">Hangars</label>
                                   <div className="space-y-2">
                                       {editableFacilityPackage.hangars.map((hangar, index) => (
                                           <div key={index} className="flex gap-2 items-center">
                                               <input
                                                   type="text"
                                                   value={hangar.name}
                                                   onChange={(e) => handleUpdateEditableHangar(index, 'name', e.target.value)}
                                                   className="flex-1 bg-[#08090a] border border-white/[0.1] rounded px-2 py-1 text-xs text-[#e8e8e8] focus:border-[#5e6ad2] outline-none"
                                                   placeholder="Hangar Name"
                                               />
                                               <select
                                                   value={hangar.size}
                                                   onChange={(e) => handleUpdateEditableHangar(index, 'size', e.target.value)}
                                                   className="bg-[#08090a] border border-white/[0.1] rounded px-2 py-1 text-xs text-[#d1d5db] focus:border-[#5e6ad2] outline-none"
                                               >
                                                   <option value="Small">Small</option>
                                                   <option value="Medium">Medium</option>
                                                   <option value="Large">Large</option>
                                               </select>
                                               <select
                                                   value={hangar.baseIndex}
                                                   onChange={(e) => handleUpdateEditableHangar(index, 'baseIndex', parseInt(e.target.value))}
                                                   className="bg-[#08090a] border border-white/[0.1] rounded px-2 py-1 text-xs text-[#d1d5db] focus:border-[#5e6ad2] outline-none"
                                               >
                                                   {editableFacilityPackage.bases.map((b, i) => (
                                                       <option key={i} value={i}>{b.name || `Base ${i + 1}`}</option>
                                                   ))}
                                               </select>
                                           </div>
                                       ))}
                                   </div>
                               </div>
                           </div>
                       )}
                   </div>

                   {/* ===== BASES OF OPERATION SECTION ===== */}
                   <div className="bg-[#0d0e10] p-6 rounded-xl border border-white/[0.08]">
                       <div className="flex justify-between items-center mb-4">
                           <h3 className="text-lg font-semibold text-[#e8e8e8] flex items-center gap-2">
                               <MapPin size={18} className="text-[#3dae6c]"/> Bases of Operation
                           </h3>
                           {basesUnsaved && (
                               <span className="text-xs text-amber-400 flex items-center gap-1">
                                   <div className="w-2 h-2 bg-amber-500 rounded-full" /> Unsaved changes
                               </span>
                           )}
                       </div>
                       <p className="text-[#6b7280] text-xs mb-4">Define your facility locations. Hangars are assigned to bases.</p>

                       {/* Bases List */}
                       <div className="space-y-2 mb-4">
                           {localBases.map((base) => (
                               <div
                                   key={base.id}
                                   className="flex items-center bg-[#08090a] border border-white/[0.08] p-3 rounded-lg group hover:border-white/[0.15] transition-colors"
                               >
                                   <div className="w-1/3 pr-4">
                                       <label className="block text-[9px] font-semibold text-[#6b7280] uppercase mb-0.5">Base Name</label>
                                       <input
                                           type="text"
                                           value={base.name}
                                           onChange={(e) => handleBaseNameChange(base.id, e.target.value)}
                                           className="w-full bg-transparent text-sm font-semibold text-[#e8e8e8] border-b border-transparent hover:border-white/[0.1] focus:border-[#5e6ad2] focus:outline-none pb-0.5"
                                       />
                                   </div>
                                   <div className="flex-1 pr-4">
                                       <label className="block text-[9px] font-semibold text-[#6b7280] uppercase mb-0.5">Location</label>
                                       <input
                                           type="text"
                                           value={base.location}
                                           onChange={(e) => handleBaseLocationChange(base.id, e.target.value)}
                                           className="w-full bg-transparent text-sm text-[#d1d5db] border-b border-transparent hover:border-white/[0.1] focus:border-[#5e6ad2] focus:outline-none pb-0.5"
                                       />
                                   </div>
                                   <div className="text-xs text-[#6b7280] pr-4">
                                       {localHangars.filter(h => h.baseId === base.id).length} hangar(s)
                                   </div>
                                   <button
                                       onClick={() => handleDeleteBase(base.id)}
                                       className="p-1.5 text-[#4b5563] hover:text-[#c4626a] hover:bg-[#c4626a]/10 rounded-md transition-colors opacity-0 group-hover:opacity-100"
                                       title="Delete Base"
                                   >
                                       <Trash2 size={14} />
                                   </button>
                                   <div className="w-6 flex justify-center">
                                       {JSON.stringify(base) !== JSON.stringify(gameState.bases.find(b => b.id === base.id)) && (
                                           <div className="w-2 h-2 bg-amber-500 rounded-full" title="Unsaved" />
                                       )}
                                   </div>
                               </div>
                           ))}

                           {localBases.length === 0 && (
                               <div className="text-center py-6 text-[#6b7280] italic text-xs">
                                   No bases defined. Add a base below to begin.
                               </div>
                           )}
                       </div>

                       {/* Add New Base Form */}
                       <div className="flex gap-4 items-end pt-4 border-t border-white/[0.06]">
                           <div className="flex-1">
                               <label className="block text-xs font-semibold text-[#6b7280] mb-1 uppercase">Base Name</label>
                               <input
                                   type="text"
                                   value={newBaseName}
                                   onChange={(e) => setNewBaseName(e.target.value)}
                                   className="w-full bg-[#141517] border border-white/[0.1] rounded-md p-2 text-[#e8e8e8] focus:border-[#5e6ad2] outline-none"
                                   placeholder="e.g. APA - Centennial"
                               />
                           </div>
                           <div className="flex-1">
                               <label className="block text-xs font-semibold text-[#6b7280] mb-1 uppercase">Location</label>
                               <input
                                   type="text"
                                   value={newBaseLocation}
                                   onChange={(e) => setNewBaseLocation(e.target.value)}
                                   className="w-full bg-[#141517] border border-white/[0.1] rounded-md p-2 text-[#e8e8e8] focus:border-[#5e6ad2] outline-none"
                                   placeholder="e.g. Centennial Airport, CO (KAPA)"
                               />
                           </div>
                           <button
                               onClick={handleAddBase}
                               disabled={!newBaseName.trim()}
                               className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 disabled:cursor-not-allowed text-white font-semibold rounded-md text-sm flex items-center gap-2 transition-colors"
                           >
                               <Plus size={16} /> Add Base
                           </button>
                       </div>
                   </div>

                   {/* ===== HANGARS SECTION ===== */}
                   <div className="bg-[#0d0e10] p-6 rounded-xl border border-white/[0.08]">
                       <div className="flex justify-between items-center mb-4">
                           <h3 className="text-lg font-semibold text-[#e8e8e8] flex items-center gap-2">
                               <Warehouse size={18} className="text-[#6e79d6]"/> Hangars
                           </h3>
                           {hangarUnsaved && (
                               <span className="text-xs text-amber-400 flex items-center gap-1">
                                   <div className="w-2 h-2 bg-amber-500 rounded-full" /> Unsaved changes
                               </span>
                           )}
                       </div>
                       <p className="text-[#6b7280] text-xs mb-4">Drag to reorder hangars. Assign each hangar to a base.</p>

                       {/* Hangars List */}
                       <div className="space-y-2 mb-4">
                           {localHangars.map((hangar, index) => (
                               <div
                                   key={hangar.id}
                                   draggable={true}
                                   onDragStart={(e) => onDragStartHangar(e, index)}
                                   onDragOver={(e) => onDragOverHangar(e, index)}
                                   onDrop={(e) => onDropHangar(e, index)}
                                   className={`
                                       flex items-center bg-[#08090a] border border-white/[0.08] p-3 rounded-lg group hover:border-white/[0.15] transition-colors
                                       ${draggedHangarIndex === index ? 'opacity-50 ring-1 ring-[#5e6ad2]' : ''}
                                   `}
                               >
                                   <div className="text-[#4b5563] hover:text-[#d1d5db] p-1 cursor-grab active:cursor-grabbing mr-3">
                                       <GripVertical size={16} />
                                   </div>
                                   <div className="w-1/3 pr-4">
                                       <label className="block text-[9px] font-semibold text-[#6b7280] uppercase mb-0.5">Hangar Name</label>
                                       <input
                                           type="text"
                                           value={hangar.name}
                                           onChange={(e) => handleHangarNameChange(hangar.id, e.target.value)}
                                           className="w-full bg-transparent text-sm font-semibold text-[#e8e8e8] border-b border-transparent hover:border-white/[0.1] focus:border-[#5e6ad2] focus:outline-none pb-0.5"
                                       />
                                   </div>
                                   <div className="w-1/3 pr-4">
                                       <label className="block text-[9px] font-semibold text-[#6b7280] uppercase mb-0.5 flex items-center gap-1">
                                           <MapPin size={10} /> Base
                                       </label>
                                       <select
                                           value={hangar.baseId}
                                           onChange={(e) => handleHangarBaseChange(hangar.id, e.target.value)}
                                           className="w-full bg-[#141517] border border-white/[0.08] rounded px-2 py-1 text-xs text-[#d1d5db] focus:border-[#5e6ad2] outline-none"
                                       >
                                           {localBases.map(b => (
                                               <option key={b.id} value={b.id}>{b.name}</option>
                                           ))}
                                       </select>
                                   </div>
                                   <div className="w-1/4">
                                       <label className="block text-[9px] font-semibold text-[#6b7280] uppercase mb-0.5">Size Class</label>
                                       <select
                                           value={hangar.size}
                                           onChange={(e) => handleHangarSizeChange(hangar.id, e.target.value)}
                                           className="w-full bg-[#141517] border border-white/[0.08] rounded px-2 py-1 text-xs text-[#d1d5db] focus:border-[#5e6ad2] outline-none"
                                       >
                                           <option value="Small">Small</option>
                                           <option value="Medium">Medium</option>
                                           <option value="Large">Large</option>
                                       </select>
                                   </div>
                                   <button
                                       onClick={() => handleDeleteHangar(hangar.id)}
                                       className="p-1.5 text-[#4b5563] hover:text-[#c4626a] hover:bg-[#c4626a]/10 rounded-md transition-colors opacity-0 group-hover:opacity-100"
                                       title="Delete Hangar"
                                   >
                                       <Trash2 size={14} />
                                   </button>
                                   <div className="w-6 flex justify-center">
                                       {JSON.stringify(hangar) !== JSON.stringify(gameState.hangars.find(h => h.id === hangar.id)) && (
                                           <div className="w-2 h-2 bg-amber-500 rounded-full" title="Unsaved" />
                                       )}
                                   </div>
                               </div>
                           ))}

                           {localHangars.length === 0 && (
                               <EmptyState
                                   icon={Warehouse}
                                   title="No hangars yet"
                                   description="Add hangars in the Facilities tab to enable scheduling jobs on the timeline."
                                   size="sm"
                               />
                           )}
                       </div>

                       {/* Add New Hangar Form */}
                       <div className="flex gap-4 items-end pt-4 border-t border-white/[0.06]">
                           <div className="flex-1">
                               <label className="block text-xs font-semibold text-[#6b7280] mb-1 uppercase">Hangar Name</label>
                               <input
                                   type="text"
                                   value={newHangarName}
                                   onChange={(e) => setNewHangarName(e.target.value)}
                                   className="w-full bg-[#141517] border border-white/[0.1] rounded-md p-2 text-[#e8e8e8] focus:border-[#5e6ad2] outline-none"
                                   placeholder="e.g. Hangar D"
                               />
                           </div>
                           <div className="flex-1">
                               <label className="block text-xs font-semibold text-[#6b7280] mb-1 uppercase flex items-center gap-1">
                                   <MapPin size={10} /> Base
                               </label>
                               <select
                                   value={newHangarBaseId}
                                   onChange={(e) => setNewHangarBaseId(e.target.value)}
                                   className="w-full bg-[#141517] border border-white/[0.1] rounded-md p-2 text-[#e8e8e8] focus:border-[#5e6ad2] outline-none"
                               >
                                   {localBases.map(b => (
                                       <option key={b.id} value={b.id}>{b.name}</option>
                                   ))}
                               </select>
                           </div>
                           <div>
                               <label className="block text-xs font-semibold text-[#6b7280] mb-1 uppercase">Size</label>
                               <select
                                   value={newHangarSize}
                                   onChange={(e) => setNewHangarSize(e.target.value as 'Small' | 'Medium' | 'Large')}
                                   className="bg-[#141517] border border-white/[0.1] rounded-md p-2 text-[#e8e8e8] focus:border-[#5e6ad2] outline-none"
                               >
                                   <option value="Small">Small</option>
                                   <option value="Medium">Medium</option>
                                   <option value="Large">Large</option>
                               </select>
                           </div>
                           <button
                               onClick={handleAddHangar}
                               disabled={!newHangarName.trim()}
                               className="px-4 py-2 bg-[#5e6ad2] hover:bg-[#7b86e0] disabled:opacity-50 disabled:cursor-not-allowed text-white font-semibold rounded-md text-sm flex items-center gap-2 transition-colors"
                           >
                               <Plus size={16} /> Add Hangar
                           </button>
                       </div>
                   </div>
                </div>
             </div>
          )}

          {/* --- FLEET / AIRCRAFT --- */}
          {activeTab === 'fleet' && (
            <div className="p-8 overflow-y-auto h-full custom-scrollbar bg-[#08090a]">
              <div className="space-y-8">

                 {/* Warning Banner for Import */}
                 {showImportWarning && (
                   <div className="bg-amber-500/10 border border-amber-500/20 rounded-lg p-4 flex items-start gap-3">
                     <AlertTriangle size={20} className="text-amber-400 flex-shrink-0 mt-0.5" />
                     <div className="flex-1">
                       <p className="text-amber-400 font-semibold text-sm">Aircraft Imported Successfully</p>
                       <p className="text-amber-400/80 text-xs mt-1">
                         New aircraft have been assigned to ALL hangars by default. Review the aircraft list below and
                         deselect hangars that cannot accommodate specific aircraft types.
                       </p>
                     </div>
                     <button
                       onClick={() => setShowImportWarning(false)}
                       className="text-amber-400/60 hover:text-amber-400 transition-colors"
                     >
                       <X size={16} />
                     </button>
                   </div>
                 )}

                 {/* Import from Package */}
                 <div className="bg-[#0d0e10] p-6 rounded-xl border border-white/[0.08]">
                    <h3 className="text-lg font-semibold text-[#e8e8e8] mb-4 flex items-center gap-2">
                      <Package size={18} className="text-violet-400"/> Import from Package
                    </h3>
                    <div className="flex flex-col gap-4">
                       <div className="flex gap-4">
                         <div className="flex-1">
                           <label className="block text-xs font-semibold text-[#6b7280] mb-1 uppercase">Select Package</label>
                           <div className="relative">
                             <select
                               value={selectedPackageId}
                               onChange={(e) => setSelectedPackageId(e.target.value)}
                               className="w-full bg-[#141517] border border-white/[0.1] rounded-md p-2.5 pr-10 text-[#e8e8e8] focus:border-[#5e6ad2] outline-none appearance-none cursor-pointer"
                             >
                               <option value="">-- Select a package --</option>
                               <optgroup label="Built-in Packages">
                                 {AIRCRAFT_PACKAGES.map(pkg => (
                                   <option key={pkg.id} value={pkg.id}>{pkg.name} ({pkg.aircraft.length} aircraft)</option>
                                 ))}
                               </optgroup>
                               {(gameState.customAircraftPackages || []).length > 0 && (
                                 <optgroup label="Custom Packages">
                                   {(gameState.customAircraftPackages || []).map(pkg => (
                                     <option key={pkg.id} value={pkg.id}>{pkg.name} ({pkg.aircraft.length} aircraft)</option>
                                   ))}
                                 </optgroup>
                               )}
                             </select>
                             <ChevronDown size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-[#6b7280] pointer-events-none" />
                           </div>
                         </div>
                         <div className="flex items-end gap-2">
                           <button
                             onClick={handleStartPackageImport}
                             disabled={!selectedPackageId}
                             className="bg-violet-500 hover:bg-violet-400 disabled:opacity-50 disabled:cursor-not-allowed text-white font-semibold py-2.5 px-5 rounded-md transition-colors flex items-center gap-2"
                           >
                             <Download size={16} /> Import
                           </button>
                           <button
                             onClick={() => setShowPackageManager(true)}
                             className="bg-[#1a1b1e] hover:bg-[#222326] border border-white/[0.1] text-[#e8e8e8] font-semibold py-2.5 px-4 rounded-md transition-colors flex items-center gap-2"
                           >
                             <FolderCog size={16} /> Manage
                           </button>
                         </div>
                       </div>

                       {/* Package Preview */}
                       {selectedPackage && (
                         <div className="bg-[#141517] rounded-lg p-4 border border-white/[0.06]">
                           <div className="flex items-center justify-between mb-3">
                             <div>
                               <h4 className="text-sm font-semibold text-[#e8e8e8]">{selectedPackage.name}</h4>
                               <p className="text-xs text-[#6b7280] mt-0.5">{selectedPackage.description}</p>
                             </div>
                             <span className="text-xs bg-violet-500/20 text-violet-300 px-2 py-1 rounded-full font-semibold">
                               {selectedPackage.aircraft.length} aircraft
                             </span>
                           </div>
                           <div className="max-h-32 overflow-y-auto custom-scrollbar">
                             <div className="grid grid-cols-3 gap-1.5">
                               {selectedPackage.aircraft.map((a, idx) => (
                                 <div key={idx} className="text-xs text-[#9ca3af] bg-[#0d0e10] px-2 py-1.5 rounded truncate">
                                   {a.name}
                                 </div>
                               ))}
                             </div>
                           </div>
                         </div>
                       )}
                    </div>
                 </div>

                 {/* Add New */}
                 <div className="bg-[#0d0e10] p-6 rounded-xl border border-white/[0.08]">
                    <h3 className="text-lg font-semibold text-[#e8e8e8] mb-4 flex items-center gap-2">
                      <Plus size={18} className="text-[#6e79d6]"/> Add New Aircraft Model
                    </h3>
                    <div className="flex flex-col gap-4">
                       <div>
                         <label className="block text-xs font-semibold text-[#6b7280] mb-1 uppercase">Model Name</label>
                         <input
                           type="text"
                           value={newModelName}
                           onChange={(e) => setNewModelName(e.target.value)}
                           className="w-full bg-[#141517] border border-white/[0.1] rounded-md p-2 text-[#e8e8e8] focus:border-[#5e6ad2] outline-none"
                           placeholder="e.g. Cessna Citation X"
                         />
                       </div>

                       <div>
                          <label className="block text-xs font-semibold text-[#6b7280] mb-2 uppercase flex items-center gap-2">
                              <Warehouse size={12} /> Compatible Facilities (Defaults to All)
                          </label>
                          <div className="grid grid-cols-4 gap-2">
                              {gameState.hangars.map(h => {
                                  const isSelected = newModelHangarIds.includes(h.id);
                                  return (
                                      <button
                                          key={h.id}
                                          onClick={() => {
                                              setNewModelHangarIds(prev =>
                                                  prev.includes(h.id) ? prev.filter(id => id !== h.id) : [...prev, h.id]
                                              )
                                          }}
                                          className={`
                                            flex items-center justify-between p-2 rounded-md border text-xs transition-colors
                                            ${isSelected
                                                ? 'bg-[#1a1b1e] border-white/[0.15] text-white'
                                                : 'bg-[#0d0e10] border-white/[0.08] text-[#6b7280] hover:bg-[#141517]'}
                                          `}
                                      >
                                          <span className="truncate font-semibold">{h.name}</span>
                                          {isSelected ? <CheckSquare size={12} /> : <Square size={12} />}
                                      </button>
                                  )
                              })}
                          </div>
                       </div>

                       <div className="flex justify-end mt-2">
                           <button
                             onClick={handleAddAircraft}
                             disabled={!newModelName}
                             className="bg-[#5e6ad2] hover:bg-[#7b86e0] disabled:opacity-50 disabled:cursor-not-allowed text-white font-semibold py-2 px-6 rounded-md h-10 transition-colors"
                           >
                             Add Model
                           </button>
                       </div>
                    </div>
                 </div>

                 {/* Toolbar */}
                 <div className="bg-[#0d0e10] p-4 rounded-xl border border-white/[0.08]">
                    <div className="flex flex-wrap items-center gap-4">
                       {/* View Mode Toggle */}
                       <div className="flex items-center gap-1 bg-[#141517] rounded-lg p-1">
                         <button
                           onClick={() => setViewMode('list')}
                           className={`p-2 rounded-md transition-colors ${viewMode === 'list' ? 'bg-[#5e6ad2] text-white' : 'text-[#6b7280] hover:text-white'}`}
                           title="List View"
                         >
                           <List size={16} />
                         </button>
                         <button
                           onClick={() => setViewMode('small')}
                           className={`p-2 rounded-md transition-colors ${viewMode === 'small' ? 'bg-[#5e6ad2] text-white' : 'text-[#6b7280] hover:text-white'}`}
                           title="Small Grid"
                         >
                           <LayoutGrid size={16} />
                         </button>
                         <button
                           onClick={() => setViewMode('large')}
                           className={`p-2 rounded-md transition-colors ${viewMode === 'large' ? 'bg-[#5e6ad2] text-white' : 'text-[#6b7280] hover:text-white'}`}
                           title="Large Grid"
                         >
                           <Grid3x3 size={16} />
                         </button>
                       </div>

                       {/* Search */}
                       <div className="relative flex-1 min-w-[200px]">
                         <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#6b7280]" />
                         <input
                           type="text"
                           value={searchTerm}
                           onChange={(e) => setSearchTerm(e.target.value)}
                           placeholder="Search by name or manufacturer..."
                           className="w-full bg-[#141517] border border-white/[0.1] rounded-md pl-9 pr-3 py-2 text-sm text-[#e8e8e8] focus:border-[#5e6ad2] outline-none"
                         />
                       </div>

                       {/* Manufacturer Filter */}
                       <div className="relative">
                         <button
                           onClick={() => { setShowManufacturerDropdown(!showManufacturerDropdown); setShowHangarDropdown(false); setShowSortDropdown(false); }}
                           className={`flex items-center gap-2 px-3 py-2 rounded-md border text-sm transition-colors ${
                             selectedManufacturers.length > 0
                               ? 'bg-[#5e6ad2]/10 border-[#5e6ad2]/30 text-indigo-300'
                               : 'bg-[#141517] border-white/[0.1] text-[#9ca3af] hover:text-white'
                           }`}
                         >
                           <Filter size={14} />
                           <span>Manufacturer{selectedManufacturers.length > 0 && ` (${selectedManufacturers.length})`}</span>
                           <ChevronDown size={14} />
                         </button>
                         {showManufacturerDropdown && (
                           <div className="absolute top-full left-0 mt-1 w-48 bg-[#141517] border border-white/[0.1] rounded-lg shadow-xl z-20 max-h-64 overflow-y-auto custom-scrollbar">
                             <div className="p-2">
                               {selectedManufacturers.length > 0 && (
                                 <button
                                   onClick={() => setSelectedManufacturers([])}
                                   className="w-full text-left text-xs text-[#6e79d6] hover:text-indigo-300 px-2 py-1 mb-1"
                                 >
                                   Clear all
                                 </button>
                               )}
                               {uniqueManufacturers.map(mfr => (
                                 <button
                                   key={mfr}
                                   onClick={() => setSelectedManufacturers(prev =>
                                     prev.includes(mfr) ? prev.filter(m => m !== mfr) : [...prev, mfr]
                                   )}
                                   className="w-full flex items-center gap-2 px-2 py-1.5 text-sm text-left hover:bg-white/[0.05] rounded"
                                 >
                                   <div className={`w-3.5 h-3.5 rounded border flex items-center justify-center ${
                                     selectedManufacturers.includes(mfr) ? 'bg-[#5e6ad2] border-[#5e6ad2]' : 'border-white/[0.2]'
                                   }`}>
                                     {selectedManufacturers.includes(mfr) && <CheckSquare size={10} className="text-white" />}
                                   </div>
                                   <span className={selectedManufacturers.includes(mfr) ? 'text-white' : 'text-[#9ca3af]'}>{mfr}</span>
                                 </button>
                               ))}
                             </div>
                           </div>
                         )}
                       </div>

                       {/* Hangar Filter */}
                       <div className="relative">
                         <button
                           onClick={() => { setShowHangarDropdown(!showHangarDropdown); setShowManufacturerDropdown(false); setShowSortDropdown(false); }}
                           className={`flex items-center gap-2 px-3 py-2 rounded-md border text-sm transition-colors ${
                             selectedHangarIds.length > 0
                               ? 'bg-violet-500/10 border-violet-500/30 text-violet-300'
                               : 'bg-[#141517] border-white/[0.1] text-[#9ca3af] hover:text-white'
                           }`}
                         >
                           <Warehouse size={14} />
                           <span>Hangars{selectedHangarIds.length > 0 && ` (${selectedHangarIds.length})`}</span>
                           <ChevronDown size={14} />
                         </button>
                         {showHangarDropdown && (
                           <div className="absolute top-full left-0 mt-1 w-56 bg-[#141517] border border-white/[0.1] rounded-lg shadow-xl z-20 max-h-64 overflow-y-auto custom-scrollbar">
                             <div className="p-2">
                               {selectedHangarIds.length > 0 && (
                                 <button
                                   onClick={() => setSelectedHangarIds([])}
                                   className="w-full text-left text-xs text-violet-400 hover:text-violet-300 px-2 py-1 mb-1"
                                 >
                                   Clear all
                                 </button>
                               )}
                               {gameState.hangars.map(h => (
                                 <button
                                   key={h.id}
                                   onClick={() => setSelectedHangarIds(prev =>
                                     prev.includes(h.id) ? prev.filter(id => id !== h.id) : [...prev, h.id]
                                   )}
                                   className="w-full flex items-center gap-2 px-2 py-1.5 text-sm text-left hover:bg-white/[0.05] rounded"
                                 >
                                   <div className={`w-3.5 h-3.5 rounded border flex items-center justify-center ${
                                     selectedHangarIds.includes(h.id) ? 'bg-violet-500 border-violet-500' : 'border-white/[0.2]'
                                   }`}>
                                     {selectedHangarIds.includes(h.id) && <CheckSquare size={10} className="text-white" />}
                                   </div>
                                   <span className={selectedHangarIds.includes(h.id) ? 'text-white' : 'text-[#9ca3af]'}>{h.name}</span>
                                 </button>
                               ))}
                             </div>
                           </div>
                         )}
                       </div>

                       {/* Sort */}
                       <div className="relative">
                         <button
                           onClick={() => { setShowSortDropdown(!showSortDropdown); setShowManufacturerDropdown(false); setShowHangarDropdown(false); }}
                           className="flex items-center gap-2 px-3 py-2 rounded-md border bg-[#141517] border-white/[0.1] text-sm text-[#9ca3af] hover:text-white transition-colors"
                         >
                           <ArrowUpDown size={14} />
                           <span>{sortField === 'name' ? 'Name' : sortField === 'manufacturer' ? 'Manufacturer' : 'Hangars'}</span>
                           <span className="text-[10px] text-[#6b7280]">{sortDirection === 'asc' ? 'A-Z' : 'Z-A'}</span>
                         </button>
                         {showSortDropdown && (
                           <div className="absolute top-full right-0 mt-1 w-40 bg-[#141517] border border-white/[0.1] rounded-lg shadow-xl z-20">
                             <div className="p-2">
                               {(['name', 'manufacturer', 'hangarCount'] as SortField[]).map(field => (
                                 <button
                                   key={field}
                                   onClick={() => {
                                     if (sortField === field) {
                                       setSortDirection(prev => prev === 'asc' ? 'desc' : 'asc');
                                     } else {
                                       setSortField(field);
                                       setSortDirection('asc');
                                     }
                                   }}
                                   className={`w-full flex items-center justify-between px-2 py-1.5 text-sm text-left hover:bg-white/[0.05] rounded ${
                                     sortField === field ? 'text-white' : 'text-[#9ca3af]'
                                   }`}
                                 >
                                   <span>{field === 'name' ? 'Name' : field === 'manufacturer' ? 'Manufacturer' : 'Hangar Count'}</span>
                                   {sortField === field && (
                                     <span className="text-[10px] text-[#6e79d6]">{sortDirection === 'asc' ? '↑' : '↓'}</span>
                                   )}
                                 </button>
                               ))}
                             </div>
                           </div>
                         )}
                       </div>

                       {/* Result count */}
                       <div className="text-xs text-[#6b7280] ml-auto">
                         Showing {sortedAircraft.length} of {gameState.aircraftModels.length}
                       </div>
                    </div>
                 </div>

                 {/* Aircraft Display */}
                 {viewMode === 'list' && (
                   <div className="bg-[#0d0e10] rounded-xl border border-white/[0.08] overflow-hidden">
                     <table className="w-full">
                       <thead>
                         <tr className="border-b border-white/[0.08]">
                           <th className="text-left text-[10px] text-[#6b7280] font-semibold uppercase px-4 py-3">Manufacturer</th>
                           <th className="text-left text-[10px] text-[#6b7280] font-semibold uppercase px-4 py-3">Model Name</th>
                           <th className="text-left text-[10px] text-[#6b7280] font-semibold uppercase px-4 py-3">Hangars</th>
                           <th className="text-right text-[10px] text-[#6b7280] font-semibold uppercase px-4 py-3">Actions</th>
                         </tr>
                       </thead>
                       <tbody>
                         {sortedAircraft.map(model => (
                           <tr key={model.id} className="border-b border-white/[0.04] hover:bg-white/[0.02] group">
                             <td className="px-4 py-3">
                               <span className="text-xs text-[#6e79d6] font-semibold">{model.manufacturer || '-'}</span>
                             </td>
                             <td className="px-4 py-3">
                               <input
                                 type="text"
                                 value={model.name}
                                 onChange={(e) => handleUpdateModelName(model.id, e.target.value)}
                                 className="bg-transparent text-[#e8e8e8] font-semibold text-sm border-b border-transparent hover:border-white/[0.1] focus:border-[#5e6ad2] outline-none w-full"
                               />
                             </td>
                             <td className="px-4 py-3">
                               <span className="text-xs text-[#9ca3af]">{getHangarCount(model.id)} hangars</span>
                             </td>
                             <td className="px-4 py-3 text-right">
                               <button
                                 onClick={() => handleDeleteModel(model.id)}
                                 className="text-[#6b7280] hover:text-[#c4626a] transition-colors opacity-0 group-hover:opacity-100"
                                 title="Delete Model"
                               >
                                 <Trash2 size={14} />
                               </button>
                             </td>
                           </tr>
                         ))}
                       </tbody>
                     </table>
                   </div>
                 )}

                 {viewMode === 'small' && (
                   <div className="grid grid-cols-5 gap-2">
                     {sortedAircraft.map(model => (
                       <div key={model.id} className="bg-[#0d0e10] p-3 rounded-lg border border-white/[0.08] hover:border-white/[0.15] transition-all group relative">
                         <button
                           onClick={() => handleDeleteModel(model.id)}
                           className="absolute top-2 right-2 text-[#4b5563] hover:text-[#c4626a] transition-colors opacity-0 group-hover:opacity-100"
                           title="Delete"
                         >
                           <Trash2 size={12} />
                         </button>
                         <div className="text-sm text-[#e8e8e8] font-semibold truncate pr-4">{model.name}</div>
                         <div className="text-[10px] text-[#6e79d6] mt-1">{model.manufacturer || '-'}</div>
                         <div className="text-[10px] text-[#6b7280] mt-1">{getHangarCount(model.id)} hangars</div>
                       </div>
                     ))}
                   </div>
                 )}

                 {viewMode === 'large' && (
                   <div className="grid grid-cols-3 gap-4">
                     {sortedAircraft.map(model => (
                       <div key={model.id} className="bg-[#0d0e10] p-4 rounded-lg border border-white/[0.08] group relative flex flex-col gap-3 hover:border-white/[0.15] transition-all">
                         <div className="flex justify-between items-start">
                           <div className="w-full">
                             <label className="text-[10px] text-[#6b7280] font-semibold uppercase block mb-1">Model Name</label>
                             <input
                               type="text"
                               value={model.name}
                               onChange={(e) => handleUpdateModelName(model.id, e.target.value)}
                               className="w-full bg-transparent text-[#e8e8e8] font-semibold border-b border-transparent hover:border-white/[0.1] focus:border-[#5e6ad2] outline-none transition-colors"
                             />
                             <div className="text-xs text-[#6e79d6] mt-1">{model.manufacturer || '-'}</div>
                           </div>
                           <button
                             onClick={() => handleDeleteModel(model.id)}
                             className="text-[#6b7280] hover:text-[#c4626a] transition-colors ml-2"
                             title="Delete Model"
                           >
                             <Trash2 size={16} />
                           </button>
                         </div>

                         <div className="border-t border-white/[0.06] pt-3">
                           <label className="text-[10px] text-[#6b7280] font-semibold uppercase block mb-2 flex items-center gap-1">
                             <Warehouse size={10} /> Allowed Hangars
                           </label>
                           <div className="flex flex-col gap-1.5 max-h-40 overflow-y-auto custom-scrollbar pr-1">
                             {gameState.hangars.map(h => {
                               const isSupported = h.supportedTypes.includes(model.id);
                               return (
                                 <button
                                   key={h.id}
                                   onClick={() => handleToggleHangarForModel(model.id, h.id)}
                                   className={`
                                     w-full flex items-center gap-2 text-[10px] px-2 py-1 rounded-md border text-left transition-all
                                     ${isSupported
                                       ? 'bg-[#141517] border-white/[0.1] text-white'
                                       : 'bg-[#0d0e10] border-white/[0.08] text-[#6b7280] hover:bg-[#141517]'}
                                   `}
                                 >
                                   <div className={`w-3 h-3 rounded border flex items-center justify-center ${isSupported ? 'bg-[#5e6ad2]/30 border-[#5e6ad2]/50' : 'border-white/[0.1]'}`}>
                                     {isSupported && <CheckSquare size={8} className="text-white" />}
                                   </div>
                                   <span className="truncate">{h.name}</span>
                                 </button>
                               );
                             })}
                           </div>
                         </div>

                         <div className="text-[10px] text-[#4b5563] font-mono mt-auto pt-2">ID: {model.id}</div>
                       </div>
                     ))}
                   </div>
                 )}
              </div>
            </div>
          )}

        </div>
      </div>

      {/* Duplicate Resolution Modal */}
      {showDuplicateModal && pendingImport && (
        <AircraftDuplicateModal
          conflict={pendingImport.conflicts[pendingImport.currentConflictIndex]}
          currentIndex={pendingImport.currentConflictIndex}
          totalConflicts={pendingImport.conflicts.length}
          onResolve={handleResolveConflict}
          onApplyToAll={handleApplyToAllConflicts}
          onCancel={handleCancelImport}
        />
      )}

      {/* Package Manager Modal */}
      {showPackageManager && (
        <AircraftPackageManager
          builtInPackages={AIRCRAFT_PACKAGES}
          customPackages={gameState.customAircraftPackages || []}
          onUpdateCustomPackages={onUpdateCustomPackages}
          onClose={() => setShowPackageManager(false)}
        />
      )}
    </div>
  );
};

export default React.memo(ConfigurationPanel);