import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import {
  Building2,
  Users,
  CreditCard,
  BarChart3,
  Search,
  Settings,
  LogOut,
  Shield,
  UserPlus,
  Activity,
  AlertTriangle,
  Clock
} from 'lucide-react';
import OrganizationList from './OrganizationList';
import UserSearch from './UserSearch';
import PlatformAnalytics from './PlatformAnalytics';
import PlatformAdminManagement from './PlatformAdminManagement';

type PlatformView = 'organizations' | 'users' | 'analytics' | 'admins';

interface PlatformDashboardProps {
  onExitPlatformAdmin: () => void;
}

const PlatformDashboard: React.FC<PlatformDashboardProps> = ({ onExitPlatformAdmin }) => {
  const { user, logout, platformRole } = useAuth();
  const [activeView, setActiveView] = useState<PlatformView>('organizations');

  const navItems = [
    {
      id: 'organizations' as PlatformView,
      label: 'Organizations',
      icon: Building2,
      description: 'Manage customer companies'
    },
    {
      id: 'users' as PlatformView,
      label: 'User Search',
      icon: Search,
      description: 'Find users across organizations'
    },
    {
      id: 'analytics' as PlatformView,
      label: 'Analytics',
      icon: BarChart3,
      description: 'Platform metrics & health'
    },
    ...(platformRole === 'super_admin' ? [{
      id: 'admins' as PlatformView,
      label: 'Platform Admins',
      icon: Shield,
      description: 'Manage admin access'
    }] : []),
  ];

  const renderView = () => {
    switch (activeView) {
      case 'organizations':
        return <OrganizationList />;
      case 'users':
        return <UserSearch />;
      case 'analytics':
        return <PlatformAnalytics />;
      case 'admins':
        return <PlatformAdminManagement />;
      default:
        return <OrganizationList />;
    }
  };

  const getRoleBadgeColor = () => {
    switch (platformRole) {
      case 'super_admin':
        return 'bg-[#c4626a]/20 text-[#c4626a] border-[#c4626a]/30';
      case 'support_admin':
        return 'bg-[#5e6ad2]/20 text-[#6e79d6] border-[#5e6ad2]/30';
      case 'billing_admin':
        return 'bg-[#3dae6c]/20 text-[#3dae6c] border-[#3dae6c]/30';
      default:
        return 'bg-[#141517] text-[#9ca3af] border-white/[0.08]';
    }
  };

  const formatRole = (role: string | null) => {
    if (!role) return 'Admin';
    return role.split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
  };

  return (
    <div className="h-screen bg-[#08090a] flex flex-col">
      {/* Top Header */}
      <header className="bg-[#0d0e10] border-b border-white/[0.06] px-6 py-4 flex justify-between items-center shrink-0">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-3">
            <div className="bg-[#141517] p-2 rounded-lg border border-white/[0.08]">
              <Shield className="text-zinc-300" size={24} />
            </div>
            <div>
              <h1 className="text-xl font-semibold text-white tracking-wide">Platform Admin</h1>
              <p className="text-xs text-[#6b7280]">AeroManager 145 SaaS Management</p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-4">
          {/* User Info */}
          <div className="flex items-center gap-3 px-4 py-2 bg-[#141517]/50 rounded-lg border border-white/[0.08]">
            <div className="text-right">
              <div className="text-sm font-medium text-[#e8e8e8]">{user?.name}</div>
              <div className="text-xs text-[#6b7280]">{user?.email}</div>
            </div>
            <span className={`text-xs font-bold px-2 py-1 rounded border ${getRoleBadgeColor()}`}>
              {formatRole(platformRole)}
            </span>
          </div>

          {/* Exit Platform Admin */}
          <button
            onClick={onExitPlatformAdmin}
            className="flex items-center gap-2 px-4 py-2 bg-[#141517] hover:bg-[#1a1b1e] text-[#d1d5db] rounded-lg text-sm font-medium transition-colors border border-white/[0.08]"
          >
            <Building2 size={16} />
            Exit to App
          </button>

          {/* Logout */}
          <button
            onClick={logout}
            className="p-2 hover:bg-[#141517] rounded-lg text-[#6b7280] hover:text-[#d1d5db] transition-colors"
            title="Logout"
          >
            <LogOut size={20} />
          </button>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar Navigation */}
        <nav className="w-64 bg-[#0d0e10]/50 border-r border-white/[0.06] p-4 shrink-0">
          <div className="space-y-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeView === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveView(item.id)}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-left transition-all ${
                    isActive
                      ? 'bg-white/10 text-white border border-white/20'
                      : 'text-[#9ca3af] hover:bg-[#141517] hover:text-[#e8e8e8] border border-transparent'
                  }`}
                >
                  <Icon size={20} />
                  <div>
                    <div className="text-sm font-medium">{item.label}</div>
                    <div className="text-xs opacity-60">{item.description}</div>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Quick Stats */}
          <div className="mt-8 pt-6 border-t border-white/[0.06]">
            <h3 className="text-xs font-semibold text-[#6b7280] uppercase tracking-wider mb-3 px-2">Quick Stats</h3>
            <div className="space-y-2">
              <div className="flex items-center justify-between px-3 py-2 bg-[#141517]/50 rounded-lg">
                <div className="flex items-center gap-2 text-[#9ca3af]">
                  <Activity size={14} />
                  <span className="text-xs">Active Orgs</span>
                </div>
                <span className="text-sm font-bold text-[#3dae6c]">--</span>
              </div>
              <div className="flex items-center justify-between px-3 py-2 bg-[#141517]/50 rounded-lg">
                <div className="flex items-center gap-2 text-[#9ca3af]">
                  <Clock size={14} />
                  <span className="text-xs">In Trial</span>
                </div>
                <span className="text-sm font-bold text-amber-400">--</span>
              </div>
              <div className="flex items-center justify-between px-3 py-2 bg-[#141517]/50 rounded-lg">
                <div className="flex items-center gap-2 text-[#9ca3af]">
                  <AlertTriangle size={14} />
                  <span className="text-xs">Past Due</span>
                </div>
                <span className="text-sm font-bold text-[#c4626a]">--</span>
              </div>
            </div>
          </div>
        </nav>

        {/* Main Content Area */}
        <main className="flex-1 overflow-hidden">
          {renderView()}
        </main>
      </div>
    </div>
  );
};

export default PlatformDashboard;
