import React, { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import { Organization, SubscriptionStatus, User } from '../../types';
import { useAuth } from '../../contexts/AuthContext';
import {
  ArrowLeft,
  Building2,
  Users,
  Calendar,
  CreditCard,
  AlertCircle,
  Clock,
  CheckCircle,
  XCircle,
  RefreshCw,
  Edit2,
  Save,
  UserCog,
  Mail,
  Shield,
  Play,
  Pause,
  DollarSign,
  CalendarPlus,
  AlertTriangle,
  Plus,
  X,
  Loader2
} from 'lucide-react';

interface OrganizationDetailsProps {
  organization: Organization;
  onBack: () => void;
  onRefresh: () => void;
}

interface OrgUser {
  id: string;
  email: string;
  name: string;
  role: string;
  createdAt: string;
}

const OrganizationDetails: React.FC<OrganizationDetailsProps> = ({
  organization,
  onBack,
  onRefresh
}) => {
  const { startImpersonation, platformRole } = useAuth();
  const [org, setOrg] = useState<Organization>(organization);
  const [users, setUsers] = useState<OrgUser[]>([]);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  // Edit mode state
  const [editMode, setEditMode] = useState(false);
  const [editedName, setEditedName] = useState(org.name);
  const [editedStatus, setEditedStatus] = useState<SubscriptionStatus>(org.subscriptionStatus);
  const [editedTier, setEditedTier] = useState(org.subscriptionTier);

  // Grace period modal
  const [showGraceModal, setShowGraceModal] = useState(false);

  // Add user modal state
  const [showAddUserModal, setShowAddUserModal] = useState(false);
  const [addUserLoading, setAddUserLoading] = useState(false);
  const [addUserError, setAddUserError] = useState<string | null>(null);
  const [newUser, setNewUser] = useState({
    email: '',
    name: '',
    password: '',
    role: 'technician' as 'owner' | 'admin' | 'manager' | 'technician' | 'viewer'
  });

  // Fetch organization users
  const fetchUsers = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('id, email, full_name, role, created_at')
        .eq('organization_id', org.id)
        .order('created_at', { ascending: true });

      if (error) throw error;

      setUsers((data || []).map(u => ({
        id: u.id,
        email: u.email,
        name: u.full_name,
        role: u.role,
        createdAt: u.created_at
      })));
    } catch (err: any) {
      console.error('Error fetching users:', err);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, [org.id]);

  // Save organization changes
  const handleSave = async () => {
    if (platformRole !== 'super_admin' && platformRole !== 'billing_admin') {
      setError('You do not have permission to edit organizations');
      return;
    }

    setSaving(true);
    setError(null);

    try {
      const { error: updateError } = await supabase
        .from('organizations')
        .update({
          name: editedName,
          subscription_status: editedStatus,
          subscription_tier: editedTier,
          updated_at: new Date().toISOString()
        })
        .eq('id', org.id);

      if (updateError) throw updateError;

      // Log the action
      await supabase.from('platform_audit_log').insert({
        action: 'update_organization',
        target_type: 'organization',
        target_id: org.id,
        details: {
          changes: {
            name: editedName !== org.name ? { from: org.name, to: editedName } : undefined,
            status: editedStatus !== org.subscriptionStatus ? { from: org.subscriptionStatus, to: editedStatus } : undefined,
            tier: editedTier !== org.subscriptionTier ? { from: org.subscriptionTier, to: editedTier } : undefined,
          }
        }
      });

      setOrg({
        ...org,
        name: editedName,
        subscriptionStatus: editedStatus,
        subscriptionTier: editedTier
      });

      setEditMode(false);
      setSuccess('Organization updated successfully');
      setTimeout(() => setSuccess(null), 3000);
      onRefresh();
    } catch (err: any) {
      setError(err.message || 'Failed to update organization');
    } finally {
      setSaving(false);
    }
  };

  // Extend trial
  const handleExtendTrial = async (days: number) => {
    if (platformRole !== 'super_admin' && platformRole !== 'billing_admin') {
      setError('You do not have permission to extend trials');
      return;
    }

    setSaving(true);
    setError(null);

    try {
      const currentEnd = org.trialEndsAt ? new Date(org.trialEndsAt) : new Date();
      const newEnd = new Date(currentEnd.getTime() + days * 24 * 60 * 60 * 1000);

      const { error: updateError } = await supabase
        .from('organizations')
        .update({
          trial_ends_at: newEnd.toISOString(),
          subscription_status: 'trial'
        })
        .eq('id', org.id);

      if (updateError) throw updateError;

      await supabase.from('platform_audit_log').insert({
        action: 'extend_trial',
        target_type: 'organization',
        target_id: org.id,
        details: { days_extended: days, new_end_date: newEnd.toISOString() }
      });

      setOrg({
        ...org,
        trialEndsAt: newEnd.toISOString(),
        subscriptionStatus: 'trial'
      });

      setSuccess(`Trial extended by ${days} days`);
      setTimeout(() => setSuccess(null), 3000);
      onRefresh();
    } catch (err: any) {
      setError(err.message || 'Failed to extend trial');
    } finally {
      setSaving(false);
    }
  };

  // Grant grace period
  const handleGrantGracePeriod = async () => {
    if (platformRole !== 'super_admin' && platformRole !== 'billing_admin') {
      setError('You do not have permission to grant grace periods');
      return;
    }

    setSaving(true);
    setError(null);

    try {
      const graceEnd = new Date(Date.now() + 3 * 24 * 60 * 60 * 1000);

      const { error: updateError } = await supabase
        .from('organizations')
        .update({
          grace_period_used: true,
          grace_period_ends_at: graceEnd.toISOString()
        })
        .eq('id', org.id);

      if (updateError) throw updateError;

      await supabase.from('platform_audit_log').insert({
        action: 'grant_grace_period',
        target_type: 'organization',
        target_id: org.id,
        details: { grace_ends_at: graceEnd.toISOString() }
      });

      setOrg({
        ...org,
        gracePeriodUsed: true,
        gracePeriodEndsAt: graceEnd.toISOString()
      });

      setShowGraceModal(false);
      setSuccess('3-day grace period granted');
      setTimeout(() => setSuccess(null), 3000);
      onRefresh();
    } catch (err: any) {
      setError(err.message || 'Failed to grant grace period');
    } finally {
      setSaving(false);
    }
  };

  // Handle impersonation
  const handleImpersonate = async (userId: string) => {
    try {
      await startImpersonation(userId);
      // Redirect or reload
      window.location.reload();
    } catch (err: any) {
      setError(err.message || 'Failed to start impersonation');
    }
  };

  // Add user to organization
  const handleAddUser = async () => {
    if (!newUser.email || !newUser.name || !newUser.password) {
      setAddUserError('All fields are required');
      return;
    }

    if (newUser.password.length < 6) {
      setAddUserError('Password must be at least 6 characters');
      return;
    }

    setAddUserLoading(true);
    setAddUserError(null);

    try {
      // Create the auth user
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: newUser.email,
        password: newUser.password,
        options: {
          data: {
            full_name: newUser.name,
          },
          emailRedirectTo: `${window.location.origin}/auth/callback`,
        },
      });

      if (authError) throw authError;

      if (!authData.user) {
        throw new Error('Failed to create user');
      }

      // Update the profile to link to this organization
      const { error: profileError } = await supabase
        .from('profiles')
        .update({
          organization_id: org.id,
          role: newUser.role,
          full_name: newUser.name,
        })
        .eq('id', authData.user.id);

      if (profileError) {
        console.error('Profile update error:', profileError);
      }

      // Log the action
      await supabase.from('platform_audit_log').insert({
        action: 'add_user_to_org',
        target_type: 'user',
        target_id: authData.user.id,
        details: {
          organization_id: org.id,
          organization_name: org.name,
          user_email: newUser.email,
          user_role: newUser.role
        }
      });

      // Reset form and close modal
      setNewUser({
        email: '',
        name: '',
        password: '',
        role: 'technician'
      });
      setShowAddUserModal(false);

      // Refresh users list
      await fetchUsers();
      setSuccess('User added successfully. They will receive a verification email.');
      setTimeout(() => setSuccess(null), 4000);

    } catch (err: any) {
      console.error('Error adding user:', err);
      setAddUserError(err.message || 'Failed to add user');
    } finally {
      setAddUserLoading(false);
    }
  };

  const formatDate = (dateStr: string | null) => {
    if (!dateStr) return 'N/A';
    return new Date(dateStr).toLocaleDateString('en-US', {
      month: 'long',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getStatusBadge = (status: SubscriptionStatus) => {
    const badges = {
      active: { icon: CheckCircle, class: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30', label: 'Active' },
      trial: { icon: Clock, class: 'bg-amber-500/20 text-amber-400 border-amber-500/30', label: 'Trial' },
      cancelled: { icon: XCircle, class: 'bg-slate-500/20 text-[#9ca3af] border-slate-500/30', label: 'Cancelled' },
      past_due: { icon: AlertCircle, class: 'bg-rose-500/20 text-rose-400 border-rose-500/30', label: 'Past Due' }
    };
    const badge = badges[status];
    const Icon = badge.icon;
    return (
      <span className={`flex items-center gap-1 text-sm font-bold px-3 py-1.5 rounded-lg border ${badge.class}`}>
        <Icon size={14} /> {badge.label}
      </span>
    );
  };

  const canEdit = platformRole === 'super_admin' || platformRole === 'billing_admin';
  const canImpersonate = platformRole === 'super_admin' || platformRole === 'support_admin';

  return (
    <div className="h-full flex flex-col bg-[#08090a] overflow-hidden">
      {/* Header */}
      <div className="p-6 border-b border-white/[0.08] shrink-0">
        <div className="flex items-center gap-4">
          <button
            onClick={onBack}
            className="p-2 hover:bg-[#141517] rounded-lg text-[#9ca3af] hover:text-white transition-colors"
          >
            <ArrowLeft size={20} />
          </button>
          <div className="flex-1">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-[#141517] rounded-lg flex items-center justify-center text-zinc-300 font-bold text-lg">
                {org.name.substring(0, 2).toUpperCase()}
              </div>
              <div>
                {editMode ? (
                  <input
                    type="text"
                    value={editedName}
                    onChange={(e) => setEditedName(e.target.value)}
                    className="text-xl font-bold text-white bg-[#141517] border border-white/[0.08] rounded px-2 py-1 outline-none focus:border-white/40"
                  />
                ) : (
                  <h2 className="text-xl font-bold text-white">{org.name}</h2>
                )}
                <p className="text-sm text-[#6b7280]">{org.slug} &middot; ID: {org.id.substring(0, 8)}...</p>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {editMode ? (
              <>
                <button
                  onClick={() => {
                    setEditMode(false);
                    setEditedName(org.name);
                    setEditedStatus(org.subscriptionStatus);
                    setEditedTier(org.subscriptionTier);
                  }}
                  className="px-4 py-2 text-[#9ca3af] hover:text-white text-sm font-medium"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSave}
                  disabled={saving}
                  className="flex items-center gap-2 px-4 py-2 bg-white hover:bg-zinc-100 text-[#09090b] text-white rounded-lg text-sm font-medium disabled:opacity-50"
                >
                  <Save size={14} />
                  {saving ? 'Saving...' : 'Save Changes'}
                </button>
              </>
            ) : (
              canEdit && (
                <button
                  onClick={() => setEditMode(true)}
                  className="flex items-center gap-2 px-4 py-2 bg-[#141517] hover:bg-[#1a1b1e] text-[#d1d5db] rounded-lg text-sm font-medium"
                >
                  <Edit2 size={14} />
                  Edit
                </button>
              )
            )}
          </div>
        </div>

        {/* Messages */}
        {error && (
          <div className="mt-4 p-3 bg-rose-900/20 border border-rose-500/30 rounded-lg text-rose-400 text-sm">
            {error}
          </div>
        )}
        {success && (
          <div className="mt-4 p-3 bg-emerald-900/20 border border-emerald-500/30 rounded-lg text-emerald-400 text-sm">
            {success}
          </div>
        )}
      </div>

      {/* Content */}
      <div className="flex-1 overflow-auto p-6">
        <div className="grid grid-cols-3 gap-6">
          {/* Subscription Info */}
          <div className="col-span-2 space-y-6">
            {/* Status Card */}
            <div className="bg-[#0d0e10]/50 rounded-lg border border-white/[0.08] p-6">
              <h3 className="text-sm font-bold text-[#9ca3af] uppercase tracking-wider mb-4">Subscription</h3>
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs text-[#6b7280] mb-1">Status</label>
                  {editMode ? (
                    <select
                      value={editedStatus}
                      onChange={(e) => setEditedStatus(e.target.value as SubscriptionStatus)}
                      className="w-full bg-[#141517] border border-white/[0.08] rounded-lg px-3 py-2 text-sm text-white outline-none focus:border-white/40"
                    >
                      <option value="trial">Trial</option>
                      <option value="active">Active</option>
                      <option value="cancelled">Cancelled</option>
                      <option value="past_due">Past Due</option>
                    </select>
                  ) : (
                    getStatusBadge(org.subscriptionStatus)
                  )}
                </div>
                <div>
                  <label className="block text-xs text-[#6b7280] mb-1">Tier</label>
                  {editMode ? (
                    <select
                      value={editedTier}
                      onChange={(e) => setEditedTier(e.target.value)}
                      className="w-full bg-[#141517] border border-white/[0.08] rounded-lg px-3 py-2 text-sm text-white outline-none focus:border-white/40"
                    >
                      <option value="standard">Standard ($200/mo)</option>
                      <option value="annual">Annual ($2,000/yr)</option>
                    </select>
                  ) : (
                    <div className="text-sm text-white font-medium capitalize">{org.subscriptionTier}</div>
                  )}
                </div>
                <div>
                  <label className="block text-xs text-[#6b7280] mb-1">Trial Ends</label>
                  <div className="text-sm text-[#d1d5db]">{formatDate(org.trialEndsAt)}</div>
                </div>
                <div>
                  <label className="block text-xs text-[#6b7280] mb-1">Stripe Customer</label>
                  <div className="text-sm text-[#d1d5db]">{org.stripeCustomerId || 'Not connected'}</div>
                </div>
              </div>

              {/* Quick Actions */}
              {canEdit && !editMode && (
                <div className="mt-6 pt-4 border-t border-white/[0.08] flex gap-3">
                  {org.subscriptionStatus === 'trial' && (
                    <>
                      <button
                        onClick={() => handleExtendTrial(7)}
                        disabled={saving}
                        className="flex items-center gap-2 px-3 py-2 bg-amber-500/20 hover:bg-amber-500/30 text-amber-400 rounded-lg text-xs font-bold"
                      >
                        <CalendarPlus size={14} /> +7 Days
                      </button>
                      <button
                        onClick={() => handleExtendTrial(14)}
                        disabled={saving}
                        className="flex items-center gap-2 px-3 py-2 bg-amber-500/20 hover:bg-amber-500/30 text-amber-400 rounded-lg text-xs font-bold"
                      >
                        <CalendarPlus size={14} /> +14 Days
                      </button>
                    </>
                  )}
                  {!org.gracePeriodUsed && org.subscriptionStatus !== 'active' && (
                    <button
                      onClick={() => setShowGraceModal(true)}
                      disabled={saving}
                      className="flex items-center gap-2 px-3 py-2 bg-[#141517] hover:bg-indigo-500/30 text-zinc-300 rounded-lg text-xs font-bold"
                    >
                      <Clock size={14} /> Grant 3-Day Grace
                    </button>
                  )}
                  {org.subscriptionStatus !== 'active' && (
                    <button
                      onClick={() => {
                        setEditedStatus('active');
                        setEditMode(true);
                      }}
                      className="flex items-center gap-2 px-3 py-2 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-400 rounded-lg text-xs font-bold"
                    >
                      <CheckCircle size={14} /> Activate
                    </button>
                  )}
                </div>
              )}
            </div>

            {/* Grace Period Card */}
            {(org.gracePeriodUsed || org.gracePeriodEndsAt) && (
              <div className="bg-[#0d0e10]/50 rounded-lg border border-white/[0.08] p-6">
                <h3 className="text-sm font-bold text-[#9ca3af] uppercase tracking-wider mb-4">Grace Period</h3>
                <div className="flex items-center gap-4">
                  <div className={`p-3 rounded-lg ${org.gracePeriodUsed ? 'bg-amber-500/10' : 'bg-[#141517]'}`}>
                    <AlertTriangle size={20} className={org.gracePeriodUsed ? 'text-amber-400' : 'text-[#6b7280]'} />
                  </div>
                  <div>
                    <div className="text-sm text-white font-medium">
                      {org.gracePeriodUsed ? 'Grace Period Used' : 'Grace Period Available'}
                    </div>
                    {org.gracePeriodEndsAt && (
                      <div className="text-xs text-[#6b7280]">
                        Ends: {formatDate(org.gracePeriodEndsAt)}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* Users Table */}
            <div className="bg-[#0d0e10]/50 rounded-lg border border-white/[0.08] overflow-hidden">
              <div className="p-4 border-b border-white/[0.08] flex justify-between items-center">
                <h3 className="text-sm font-bold text-[#9ca3af] uppercase tracking-wider">
                  Users ({users.length})
                </h3>
                {canEdit && (
                  <button
                    onClick={() => setShowAddUserModal(true)}
                    className="flex items-center gap-2 px-3 py-1.5 bg-white hover:bg-zinc-100 text-[#09090b] text-white rounded-lg text-xs font-medium"
                  >
                    <Plus size={14} />
                    Add User
                  </button>
                )}
              </div>
              <table className="w-full">
                <thead>
                  <tr className="bg-[#141517]/50">
                    <th className="text-left px-4 py-3 text-xs font-bold text-[#9ca3af] uppercase">User</th>
                    <th className="text-left px-4 py-3 text-xs font-bold text-[#9ca3af] uppercase">Role</th>
                    <th className="text-left px-4 py-3 text-xs font-bold text-[#9ca3af] uppercase">Joined</th>
                    {canImpersonate && (
                      <th className="text-right px-4 py-3 text-xs font-bold text-[#9ca3af] uppercase">Actions</th>
                    )}
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/[0.06]">
                  {users.map((user) => (
                    <tr key={user.id} className="hover:bg-[#141517]/30">
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 bg-[#1a1b1e] rounded-full flex items-center justify-center text-[#d1d5db] font-bold text-xs">
                            {user.name.substring(0, 2).toUpperCase()}
                          </div>
                          <div>
                            <div className="text-sm text-white font-medium">{user.name}</div>
                            <div className="text-xs text-[#6b7280]">{user.email}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <span className={`text-xs font-bold px-2 py-1 rounded ${
                          user.role === 'owner'
                            ? 'bg-rose-500/20 text-rose-400'
                            : user.role === 'admin'
                            ? 'bg-[#141517] text-zinc-300'
                            : 'bg-slate-500/20 text-[#9ca3af]'
                        }`}>
                          {user.role.charAt(0).toUpperCase() + user.role.slice(1)}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-sm text-[#9ca3af]">
                        {new Date(user.createdAt).toLocaleDateString()}
                      </td>
                      {canImpersonate && (
                        <td className="px-4 py-3 text-right">
                          <button
                            onClick={() => handleImpersonate(user.id)}
                            className="flex items-center gap-1 px-2 py-1 text-xs bg-[#1a1b1e] hover:bg-[#1a1b1e] text-[#d1d5db] rounded ml-auto"
                            title="Login as this user"
                          >
                            <UserCog size={12} /> Impersonate
                          </button>
                        </td>
                      )}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Quick Info */}
            <div className="bg-[#0d0e10]/50 rounded-lg border border-white/[0.08] p-6">
              <h3 className="text-sm font-bold text-[#9ca3af] uppercase tracking-wider mb-4">Details</h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-xs text-[#6b7280] mb-1">Created</label>
                  <div className="text-sm text-[#d1d5db]">{formatDate(org.createdAt)}</div>
                </div>
                <div>
                  <label className="block text-xs text-[#6b7280] mb-1">Last Updated</label>
                  <div className="text-sm text-[#d1d5db]">{formatDate(org.updatedAt)}</div>
                </div>
                <div>
                  <label className="block text-xs text-[#6b7280] mb-1">Owner</label>
                  <div className="text-sm text-[#d1d5db]">{org.ownerName}</div>
                  <div className="text-xs text-[#6b7280]">{org.ownerEmail}</div>
                </div>
              </div>
            </div>

            {/* Danger Zone */}
            {platformRole === 'super_admin' && (
              <div className="bg-rose-900/10 rounded-lg border border-rose-500/30 p-6">
                <h3 className="text-sm font-bold text-rose-400 uppercase tracking-wider mb-4">Danger Zone</h3>
                <p className="text-xs text-[#9ca3af] mb-4">
                  These actions are permanent and cannot be undone.
                </p>
                <button
                  disabled
                  className="w-full px-4 py-2 bg-rose-500/20 text-rose-400 rounded-lg text-sm font-medium opacity-50 cursor-not-allowed"
                >
                  Delete Organization
                </button>
                <p className="text-xs text-[#6b7280] mt-2">Contact engineering for deletion requests</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Grace Period Modal */}
      {showGraceModal && (
        <div className="fixed inset-0 bg-[#08090a]/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#0d0e10] border border-white/[0.08] rounded-xl p-6 w-full max-w-md">
            <h3 className="text-lg font-bold text-white mb-2">Grant Grace Period</h3>
            <p className="text-sm text-[#9ca3af] mb-6">
              This will give the organization 3 additional days of full access. This can only be used once per organization.
            </p>
            <div className="bg-amber-900/20 border border-amber-500/30 rounded-lg p-4 mb-6">
              <div className="flex items-start gap-3">
                <AlertTriangle className="text-amber-400 shrink-0 mt-0.5" size={18} />
                <div className="text-sm text-amber-200">
                  <strong>Warning:</strong> This action cannot be undone. The grace period flag will be permanently set.
                </div>
              </div>
            </div>
            <div className="flex gap-3">
              <button
                onClick={() => setShowGraceModal(false)}
                className="flex-1 py-2 text-[#9ca3af] hover:bg-[#141517] rounded-lg font-medium text-sm"
              >
                Cancel
              </button>
              <button
                onClick={handleGrantGracePeriod}
                disabled={saving}
                className="flex-1 py-2 bg-white hover:bg-zinc-100 text-[#09090b] text-white rounded-lg font-medium text-sm disabled:opacity-50"
              >
                {saving ? 'Processing...' : 'Confirm Grant'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add User Modal */}
      {showAddUserModal && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
          <div className="bg-[#0d0e10] rounded-xl border border-white/[0.08] w-full max-w-md shadow-2xl">
            {/* Modal Header */}
            <div className="flex items-center justify-between p-6 border-b border-white/[0.08]">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#141517] rounded-lg">
                  <Users className="text-zinc-300" size={20} />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white">Add User</h3>
                  <p className="text-xs text-[#6b7280]">Add a new user to {org.name}</p>
                </div>
              </div>
              <button
                onClick={() => {
                  setShowAddUserModal(false);
                  setAddUserError(null);
                }}
                className="p-2 hover:bg-[#141517] rounded-lg text-[#9ca3af] hover:text-white transition-colors"
              >
                <X size={20} />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 space-y-4">
              {addUserError && (
                <div className="p-3 bg-rose-900/30 border border-rose-500/30 rounded-lg text-rose-400 text-sm">
                  {addUserError}
                </div>
              )}

              {/* Name */}
              <div>
                <label className="block text-sm font-medium text-[#d1d5db] mb-2">
                  Full Name *
                </label>
                <input
                  type="text"
                  value={newUser.name}
                  onChange={(e) => setNewUser({ ...newUser, name: e.target.value })}
                  placeholder="John Smith"
                  className="w-full bg-[#141517] border border-white/[0.08] rounded-lg px-4 py-2.5 text-sm text-white placeholder-[#6b7280] focus:border-white/40 outline-none"
                />
              </div>

              {/* Email */}
              <div>
                <label className="block text-sm font-medium text-[#d1d5db] mb-2">
                  Email Address *
                </label>
                <input
                  type="email"
                  value={newUser.email}
                  onChange={(e) => setNewUser({ ...newUser, email: e.target.value })}
                  placeholder="john@company.com"
                  className="w-full bg-[#141517] border border-white/[0.08] rounded-lg px-4 py-2.5 text-sm text-white placeholder-[#6b7280] focus:border-white/40 outline-none"
                />
              </div>

              {/* Password */}
              <div>
                <label className="block text-sm font-medium text-[#d1d5db] mb-2">
                  Password *
                </label>
                <input
                  type="password"
                  value={newUser.password}
                  onChange={(e) => setNewUser({ ...newUser, password: e.target.value })}
                  placeholder="Minimum 6 characters"
                  className="w-full bg-[#141517] border border-white/[0.08] rounded-lg px-4 py-2.5 text-sm text-white placeholder-[#6b7280] focus:border-white/40 outline-none"
                />
              </div>

              {/* Role */}
              <div>
                <label className="block text-sm font-medium text-[#d1d5db] mb-2">
                  Role
                </label>
                <select
                  value={newUser.role}
                  onChange={(e) => setNewUser({ ...newUser, role: e.target.value as typeof newUser.role })}
                  className="w-full bg-[#141517] border border-white/[0.08] rounded-lg px-4 py-2.5 text-sm text-white focus:border-white/40 outline-none"
                >
                  <option value="owner">Owner</option>
                  <option value="admin">Admin</option>
                  <option value="manager">Manager</option>
                  <option value="technician">Technician</option>
                  <option value="viewer">Viewer</option>
                </select>
              </div>

              <p className="text-xs text-[#6b7280]">
                The user will receive an email verification link. After verifying, they can log in to this organization.
              </p>
            </div>

            {/* Modal Footer */}
            <div className="flex items-center justify-end gap-3 p-6 border-t border-white/[0.08]">
              <button
                onClick={() => {
                  setShowAddUserModal(false);
                  setAddUserError(null);
                }}
                className="px-4 py-2 text-sm text-[#9ca3af] hover:text-white transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleAddUser}
                disabled={addUserLoading}
                className="flex items-center gap-2 px-4 py-2 bg-white hover:bg-zinc-100 text-[#09090b] text-white rounded-lg text-sm font-medium transition-colors disabled:opacity-50"
              >
                {addUserLoading ? (
                  <>
                    <Loader2 size={16} className="animate-spin" />
                    Adding...
                  </>
                ) : (
                  <>
                    <Plus size={16} />
                    Add User
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default OrganizationDetails;
