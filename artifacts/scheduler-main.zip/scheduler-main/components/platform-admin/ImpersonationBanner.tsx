import React, { useState, useEffect } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { UserCog, X, Clock, AlertTriangle } from 'lucide-react';

const ImpersonationBanner: React.FC = () => {
  const { impersonationSession, endImpersonation } = useAuth();
  const [timeRemaining, setTimeRemaining] = useState<string>('');

  useEffect(() => {
    if (!impersonationSession) return;

    const updateTimer = () => {
      const remaining = impersonationSession.expiresAt - Date.now();
      if (remaining <= 0) {
        endImpersonation();
        return;
      }

      const minutes = Math.floor(remaining / 60000);
      const seconds = Math.floor((remaining % 60000) / 1000);
      setTimeRemaining(`${minutes}:${seconds.toString().padStart(2, '0')}`);
    };

    updateTimer();
    const interval = setInterval(updateTimer, 1000);

    return () => clearInterval(interval);
  }, [impersonationSession, endImpersonation]);

  if (!impersonationSession) return null;

  const isExpiringSoon = impersonationSession.expiresAt - Date.now() < 5 * 60 * 1000; // 5 minutes

  return (
    <div className={`fixed top-0 left-0 right-0 z-[9999] px-4 py-2 flex items-center justify-between ${
      isExpiringSoon ? 'bg-rose-600' : 'bg-amber-600'
    }`}>
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2">
          <UserCog size={18} className="text-white" />
          <span className="text-sm font-bold text-white">IMPERSONATING</span>
        </div>
        <div className="h-4 w-px bg-white/30" />
        <div className="text-sm text-white/90">
          Viewing as <strong>{impersonationSession.targetUserEmail}</strong>
        </div>
        <div className="text-sm text-white/70">
          ({impersonationSession.targetOrgName})
        </div>
      </div>

      <div className="flex items-center gap-4">
        <div className={`flex items-center gap-2 text-sm ${isExpiringSoon ? 'text-white' : 'text-white/80'}`}>
          {isExpiringSoon && <AlertTriangle size={14} />}
          <Clock size={14} />
          <span>{timeRemaining} remaining</span>
        </div>
        <button
          onClick={endImpersonation}
          className="flex items-center gap-2 px-3 py-1.5 bg-white/20 hover:bg-white/30 text-white rounded-lg text-sm font-medium transition-colors"
        >
          <X size={14} />
          Exit Impersonation
        </button>
      </div>
    </div>
  );
};

export default ImpersonationBanner;
