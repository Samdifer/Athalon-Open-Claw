import React, { useState, useEffect, useMemo } from 'react';
import { supabase } from '../../lib/supabase';
import { PlatformMetrics } from '../../types';
import {
  BarChart3,
  Building2,
  Users,
  DollarSign,
  TrendingUp,
  TrendingDown,
  Clock,
  AlertTriangle,
  CheckCircle,
  RefreshCw,
  Calendar
} from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts';

const COLORS = ['#10b981', '#f59e0b', '#6366f1', '#ef4444'];

const PlatformAnalytics: React.FC = () => {
  const [metrics, setMetrics] = useState<PlatformMetrics | null>(null);
  const [loading, setLoading] = useState(true);
  const [signupData, setSignupData] = useState<{ date: string; count: number }[]>([]);
  const [trialsExpiring, setTrialsExpiring] = useState<any[]>([]);

  const fetchMetrics = async () => {
    setLoading(true);

    try {
      // Fetch organizations with status counts
      const { data: orgs, error: orgsError } = await supabase
        .from('organizations')
        .select('id, subscription_status, trial_ends_at, created_at');

      if (orgsError) throw orgsError;

      // Fetch user count
      const { count: userCount, error: usersError } = await supabase
        .from('profiles')
        .select('id', { count: 'exact', head: true });

      if (usersError) throw usersError;

      // Calculate metrics
      const now = new Date();
      const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
      const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
      const sevenDaysFromNow = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);

      const activeOrgs = orgs.filter(o => o.subscription_status === 'active');
      const trialOrgs = orgs.filter(o => o.subscription_status === 'trial');
      const cancelledOrgs = orgs.filter(o => o.subscription_status === 'cancelled');
      const pastDueOrgs = orgs.filter(o => o.subscription_status === 'past_due');

      const signups7Days = orgs.filter(o => new Date(o.created_at) >= sevenDaysAgo).length;
      const signups30Days = orgs.filter(o => new Date(o.created_at) >= thirtyDaysAgo).length;

      const trialsEndingSoon = trialOrgs.filter(o => {
        if (!o.trial_ends_at) return false;
        const trialEnd = new Date(o.trial_ends_at);
        return trialEnd <= sevenDaysFromNow && trialEnd >= now;
      });

      // Calculate MRR (assuming $200/month per active org)
      const monthlyPrice = 200;
      const annualPrice = 2000;
      const mrr = activeOrgs.length * monthlyPrice;
      const arr = mrr * 12;

      setMetrics({
        totalOrganizations: orgs.length,
        activeOrganizations: activeOrgs.length,
        trialOrganizations: trialOrgs.length,
        cancelledOrganizations: cancelledOrgs.length,
        pastDueOrganizations: pastDueOrgs.length,
        totalUsers: userCount || 0,
        signupsLast7Days: signups7Days,
        signupsLast30Days: signups30Days,
        trialsExpiringIn7Days: trialsEndingSoon.length,
        mrr,
        arr
      });

      // Set trials expiring
      setTrialsExpiring(trialsEndingSoon.slice(0, 10));

      // Generate signup trend data (last 14 days)
      const signupTrend: { date: string; count: number }[] = [];
      for (let i = 13; i >= 0; i--) {
        const date = new Date(now.getTime() - i * 24 * 60 * 60 * 1000);
        const dateStr = date.toISOString().split('T')[0];
        const count = orgs.filter(o => o.created_at.startsWith(dateStr)).length;
        signupTrend.push({
          date: date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
          count
        });
      }
      setSignupData(signupTrend);

    } catch (err) {
      console.error('Error fetching metrics:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMetrics();
  }, []);

  const statusDistribution = useMemo(() => {
    if (!metrics) return [];
    return [
      { name: 'Active', value: metrics.activeOrganizations, color: '#10b981' },
      { name: 'Trial', value: metrics.trialOrganizations, color: '#f59e0b' },
      { name: 'Cancelled', value: metrics.cancelledOrganizations, color: '#64748b' },
      { name: 'Past Due', value: metrics.pastDueOrganizations, color: '#ef4444' }
    ].filter(d => d.value > 0);
  }, [metrics]);

  if (loading) {
    return (
      <div className="h-full flex items-center justify-center bg-[#08090a]">
        <div className="flex items-center gap-3 text-[#9ca3af]">
          <RefreshCw size={24} className="animate-spin" />
          Loading analytics...
        </div>
      </div>
    );
  }

  return (
    <div className="h-full overflow-auto bg-[#08090a] p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="bg-[#141517] p-2 rounded-lg border border-white/[0.08]">
            <BarChart3 className="text-zinc-300" size={24} />
          </div>
          <div>
            <h2 className="text-xl font-semibold text-[#e8e8e8]">Platform Analytics</h2>
            <p className="text-xs text-[#6b7280]">Real-time metrics and insights</p>
          </div>
        </div>
        <button
          onClick={fetchMetrics}
          className="flex items-center gap-2 px-3 py-2 bg-[#141517] hover:bg-[#1a1b1e] text-[#d1d5db] rounded-lg text-sm border border-white/[0.08] transition-colors"
        >
          <RefreshCw size={14} />
          Refresh
        </button>
      </div>

      {/* Key Metrics Cards */}
      <div className="grid grid-cols-4 gap-4 mb-6">
        <div className="bg-[#0d0e10]/50 rounded-lg border border-white/[0.08] p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="p-2 bg-[#141517] rounded-lg border border-white/[0.08]">
              <Building2 className="text-zinc-300" size={20} />
            </div>
            <span className="text-xs text-[#6b7280]">Total</span>
          </div>
          <div className="text-3xl font-bold text-white">{metrics?.totalOrganizations || 0}</div>
          <div className="text-xs text-[#6b7280] mt-1">Organizations</div>
        </div>

        <div className="bg-[#0d0e10]/50 rounded-lg border border-white/[0.08] p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="p-2 bg-[#3dae6c]/10 rounded-lg">
              <CheckCircle className="text-[#3dae6c]" size={20} />
            </div>
            <span className="text-xs text-[#3dae6c]">
              {metrics && metrics.totalOrganizations > 0
                ? `${Math.round((metrics.activeOrganizations / metrics.totalOrganizations) * 100)}%`
                : '0%'}
            </span>
          </div>
          <div className="text-3xl font-bold text-[#3dae6c]">{metrics?.activeOrganizations || 0}</div>
          <div className="text-xs text-[#6b7280] mt-1">Active Subscriptions</div>
        </div>

        <div className="bg-[#0d0e10]/50 rounded-lg border border-white/[0.08] p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="p-2 bg-amber-500/10 rounded-lg">
              <Clock className="text-amber-400" size={20} />
            </div>
            <span className="text-xs text-amber-400">
              {metrics?.trialsExpiringIn7Days || 0} expiring
            </span>
          </div>
          <div className="text-3xl font-bold text-amber-400">{metrics?.trialOrganizations || 0}</div>
          <div className="text-xs text-[#6b7280] mt-1">In Trial</div>
        </div>

        <div className="bg-[#0d0e10]/50 rounded-lg border border-white/[0.08] p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="p-2 bg-[#3dae6c]/10 rounded-lg">
              <DollarSign className="text-[#3dae6c]" size={20} />
            </div>
            <span className="text-xs text-[#6b7280]">Revenue</span>
          </div>
          <div className="text-3xl font-bold text-[#3dae6c]">
            ${(metrics?.mrr || 0).toLocaleString()}
          </div>
          <div className="text-xs text-[#6b7280] mt-1">Monthly (MRR)</div>
        </div>
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-3 gap-6 mb-6">
        {/* Signup Trend */}
        <div className="col-span-2 bg-[#0d0e10]/50 rounded-lg border border-white/[0.08] p-6">
          <h3 className="text-sm font-semibold text-[#6b7280] uppercase tracking-wider mb-4">
            Signups (Last 14 Days)
          </h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={signupData}>
                <XAxis dataKey="date" stroke="#6b7280" fontSize={10} />
                <YAxis stroke="#6b7280" fontSize={10} allowDecimals={false} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#141517',
                    border: '1px solid rgba(255,255,255,0.1)',
                    borderRadius: '8px'
                  }}
                />
                <Bar dataKey="count" fill="#5e6ad2" radius={[4, 4, 0, 0]} isAnimationActive={true} animationDuration={200} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Status Distribution */}
        <div className="bg-[#0d0e10]/50 rounded-lg border border-white/[0.08] p-6">
          <h3 className="text-sm font-semibold text-[#6b7280] uppercase tracking-wider mb-4">
            Status Distribution
          </h3>
          <div className="h-64 flex items-center justify-center">
            {statusDistribution.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={statusDistribution}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={80}
                    paddingAngle={2}
                    dataKey="value"
                    isAnimationActive={true}
                    animationDuration={250}
                  >
                    {statusDistribution.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#141517',
                      border: '1px solid rgba(255,255,255,0.1)',
                      borderRadius: '8px'
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <p className="text-[#6b7280] text-sm">No data</p>
            )}
          </div>
          <div className="flex flex-wrap gap-3 justify-center mt-2">
            {statusDistribution.map((item) => (
              <div key={item.name} className="flex items-center gap-2 text-xs text-[#9ca3af]">
                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                {item.name}: {item.value}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Additional Stats */}
      <div className="grid grid-cols-3 gap-6">
        {/* Quick Stats */}
        <div className="bg-[#0d0e10]/50 rounded-lg border border-white/[0.08] p-6">
          <h3 className="text-sm font-semibold text-[#6b7280] uppercase tracking-wider mb-4">
            Quick Stats
          </h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm text-[#9ca3af]">Total Users</span>
              <span className="text-sm font-bold text-white">{metrics?.totalUsers || 0}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-[#9ca3af]">Signups (7 days)</span>
              <span className="text-sm font-bold text-[#3dae6c]">+{metrics?.signupsLast7Days || 0}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-[#9ca3af]">Signups (30 days)</span>
              <span className="text-sm font-bold text-[#3dae6c]">+{metrics?.signupsLast30Days || 0}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-[#9ca3af]">Past Due</span>
              <span className="text-sm font-bold text-[#c4626a]">{metrics?.pastDueOrganizations || 0}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-[#9ca3af]">Cancelled</span>
              <span className="text-sm font-bold text-[#9ca3af]">{metrics?.cancelledOrganizations || 0}</span>
            </div>
          </div>
        </div>

        {/* Revenue Overview */}
        <div className="bg-[#0d0e10]/50 rounded-lg border border-white/[0.08] p-6">
          <h3 className="text-sm font-semibold text-[#6b7280] uppercase tracking-wider mb-4">
            Revenue
          </h3>
          <div className="space-y-4">
            <div>
              <div className="text-xs text-[#6b7280] mb-1">Monthly Recurring (MRR)</div>
              <div className="text-2xl font-bold text-[#3dae6c]">
                ${(metrics?.mrr || 0).toLocaleString()}
              </div>
            </div>
            <div>
              <div className="text-xs text-[#6b7280] mb-1">Annual Run Rate (ARR)</div>
              <div className="text-2xl font-bold text-white">
                ${(metrics?.arr || 0).toLocaleString()}
              </div>
            </div>
            <div className="pt-4 border-t border-white/[0.06]">
              <div className="text-xs text-[#6b7280] mb-1">Avg Revenue Per Org</div>
              <div className="text-lg font-bold text-[#d1d5db]">
                ${metrics && metrics.activeOrganizations > 0
                  ? Math.round(metrics.mrr / metrics.activeOrganizations).toLocaleString()
                  : 0}/mo
              </div>
            </div>
          </div>
        </div>

        {/* Trials Expiring Soon */}
        <div className="bg-[#0d0e10]/50 rounded-lg border border-white/[0.08] p-6">
          <h3 className="text-sm font-semibold text-[#6b7280] uppercase tracking-wider mb-4 flex items-center gap-2">
            <AlertTriangle size={14} className="text-amber-400" />
            Trials Expiring Soon
          </h3>
          {trialsExpiring.length > 0 ? (
            <div className="space-y-3 max-h-48 overflow-auto">
              {trialsExpiring.map((org) => {
                const daysLeft = Math.ceil(
                  (new Date(org.trial_ends_at).getTime() - Date.now()) / (1000 * 60 * 60 * 24)
                );
                return (
                  <div
                    key={org.id}
                    className="flex items-center justify-between p-2 bg-[#141517]/50 rounded-lg"
                  >
                    <span className="text-sm text-[#d1d5db] truncate max-w-[150px]">
                      {org.id.substring(0, 8)}...
                    </span>
                    <span className={`text-xs font-bold px-2 py-1 rounded ${
                      daysLeft <= 3
                        ? 'bg-[#c4626a]/20 text-[#c4626a]'
                        : 'bg-amber-500/20 text-amber-400'
                    }`}>
                      {daysLeft} day{daysLeft !== 1 ? 's' : ''}
                    </span>
                  </div>
                );
              })}
            </div>
          ) : (
            <p className="text-sm text-[#6b7280]">No trials expiring in the next 7 days</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default PlatformAnalytics;
