import React, { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import { Organization, SubscriptionStatus } from '../../types';
import { useAuth } from '../../contexts/AuthContext';
import {
  Building2,
  Search,
  Filter,
  ChevronRight,
  Users,
  Calendar,
  CreditCard,
  AlertCircle,
  Clock,
  CheckCircle,
  XCircle,
  RefreshCw,
  Eye,
  Edit2,
  UserCog,
  Plus,
  X,
  Loader2
} from 'lucide-react';
import OrganizationDetails from './OrganizationDetails';

interface DBOrganization {
  id: string;
  name: string;
  slug: string;
  subscription_status: string;
  subscription_tier: string;
  trial_ends_at: string | null;
  stripe_customer_id: string | null;
  grace_period_used: boolean | null;
  grace_period_ends_at: string | null;
  created_at: string;
  updated_at: string;
}

const OrganizationList: React.FC = () => {
  const { startImpersonation } = useAuth();
  const [organizations, setOrganizations] = useState<Organization[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<SubscriptionStatus | 'all'>('all');
  const [selectedOrg, setSelectedOrg] = useState<Organization | null>(null);

  // Create organization modal state
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [createLoading, setCreateLoading] = useState(false);
  const [createError, setCreateError] = useState<string | null>(null);
  const [newOrg, setNewOrg] = useState({
    name: '',
    ownerEmail: '',
    ownerName: '',
    ownerPassword: '',
    subscriptionStatus: 'trial' as SubscriptionStatus,
    trialDays: 14
  });

  // Fetch organizations
  const fetchOrganizations = async () => {
    setLoading(true);
    setError(null);

    try {
      // Fetch organizations with user count
      const { data: orgs, error: orgsError } = await supabase
        .from('organizations')
        .select(`
          *,
          profiles!profiles_organization_id_fkey(id, email, full_name, role)
        `)
        .order('created_at', { ascending: false });

      if (orgsError) throw orgsError;

      // Transform to frontend format
      const transformed: Organization[] = (orgs || []).map((org: any) => {
        const owner = org.profiles?.find((p: any) => p.role === 'owner');
        return {
          id: org.id,
          name: org.name,
          slug: org.slug,
          subscriptionStatus: org.subscription_status as SubscriptionStatus,
          subscriptionTier: org.subscription_tier || 'standard',
          trialEndsAt: org.trial_ends_at,
          stripeCustomerId: org.stripe_customer_id,
          gracePeriodUsed: org.grace_period_used || false,
          gracePeriodEndsAt: org.grace_period_ends_at,
          createdAt: org.created_at,
          updatedAt: org.updated_at,
          userCount: org.profiles?.length || 0,
          ownerEmail: owner?.email || 'N/A',
          ownerName: owner?.full_name || 'N/A',
        };
      });

      setOrganizations(transformed);
    } catch (err: any) {
      console.error('Error fetching organizations:', err);
      setError(err.message || 'Failed to fetch organizations');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOrganizations();
  }, []);

  // Create organization with owner
  const handleCreateOrganization = async () => {
    if (!newOrg.name || !newOrg.ownerEmail || !newOrg.ownerName || !newOrg.ownerPassword) {
      setCreateError('All fields are required');
      return;
    }

    if (newOrg.ownerPassword.length < 6) {
      setCreateError('Password must be at least 6 characters');
      return;
    }

    setCreateLoading(true);
    setCreateError(null);

    try {
      // Generate slug from name
      const slug = newOrg.name
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/^-|-$/g, '');

      // Calculate trial end date
      const trialEndsAt = new Date();
      trialEndsAt.setDate(trialEndsAt.getDate() + newOrg.trialDays);

      // Step 1: Create the organization
      const { data: orgData, error: orgError } = await supabase
        .from('organizations')
        .insert({
          name: newOrg.name,
          slug: slug,
          subscription_status: newOrg.subscriptionStatus,
          subscription_tier: 'standard',
          trial_ends_at: newOrg.subscriptionStatus === 'trial' ? trialEndsAt.toISOString() : null,
        })
        .select()
        .single();

      if (orgError) throw orgError;

      // Step 2: Create the auth user via Supabase Admin API
      // Note: This requires the service_role key which we don't have in frontend
      // Instead, we'll create the user via signUp and then update their profile
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: newOrg.ownerEmail,
        password: newOrg.ownerPassword,
        options: {
          data: {
            full_name: newOrg.ownerName,
          },
          emailRedirectTo: `${window.location.origin}/auth/callback`,
        },
      });

      if (authError) {
        // Rollback: delete the organization
        await supabase.from('organizations').delete().eq('id', orgData.id);
        throw authError;
      }

      if (!authData.user) {
        await supabase.from('organizations').delete().eq('id', orgData.id);
        throw new Error('Failed to create user');
      }

      // Step 3: Update the profile to link to the organization and set as owner
      const { error: profileError } = await supabase
        .from('profiles')
        .update({
          organization_id: orgData.id,
          role: 'owner',
          full_name: newOrg.ownerName,
        })
        .eq('id', authData.user.id);

      if (profileError) {
        console.error('Profile update error:', profileError);
        // The user and org are created, just log the error
      }

      // Reset form and close modal
      setNewOrg({
        name: '',
        ownerEmail: '',
        ownerName: '',
        ownerPassword: '',
        subscriptionStatus: 'trial',
        trialDays: 14
      });
      setShowCreateModal(false);

      // Refresh the list
      await fetchOrganizations();

    } catch (err: any) {
      console.error('Error creating organization:', err);
      setCreateError(err.message || 'Failed to create organization');
    } finally {
      setCreateLoading(false);
    }
  };

  // Filter organizations
  const filteredOrgs = organizations.filter(org => {
    const matchesSearch =
      org.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      org.ownerEmail?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      org.ownerName?.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus = statusFilter === 'all' || org.subscriptionStatus === statusFilter;

    return matchesSearch && matchesStatus;
  });

  const getStatusBadge = (status: SubscriptionStatus) => {
    switch (status) {
      case 'active':
        return (
          <span className="flex items-center gap-1 text-xs font-bold px-2 py-1 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
            <CheckCircle size={12} /> Active
          </span>
        );
      case 'trial':
        return (
          <span className="flex items-center gap-1 text-xs font-bold px-2 py-1 rounded bg-amber-500/20 text-amber-400 border border-amber-500/30">
            <Clock size={12} /> Trial
          </span>
        );
      case 'cancelled':
        return (
          <span className="flex items-center gap-1 text-xs font-bold px-2 py-1 rounded bg-[#141517] text-[#9ca3af] border border-white/[0.08]">
            <XCircle size={12} /> Cancelled
          </span>
        );
      case 'past_due':
        return (
          <span className="flex items-center gap-1 text-xs font-bold px-2 py-1 rounded bg-rose-500/20 text-rose-400 border border-rose-500/30">
            <AlertCircle size={12} /> Past Due
          </span>
        );
      default:
        return null;
    }
  };

  const formatDate = (dateStr: string | null) => {
    if (!dateStr) return 'N/A';
    return new Date(dateStr).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  const getDaysRemaining = (dateStr: string | null) => {
    if (!dateStr) return null;
    const endDate = new Date(dateStr);
    const now = new Date();
    const diffTime = endDate.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  if (selectedOrg) {
    return (
      <OrganizationDetails
        organization={selectedOrg}
        onBack={() => setSelectedOrg(null)}
        onRefresh={fetchOrganizations}
      />
    );
  }

  return (
    <div className="h-full flex flex-col bg-[#08090a]">
      {/* Header */}
      <div className="p-6 border-b border-white/[0.06]">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="bg-[#141517] p-2 rounded-lg border border-white/[0.08]">
              <Building2 className="text-zinc-300" size={24} />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-[#e8e8e8]">Organizations</h2>
              <p className="text-xs text-[#6b7280]">
                {filteredOrgs.length} of {organizations.length} organizations
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowCreateModal(true)}
              className="flex items-center gap-2 px-4 py-2 bg-white hover:bg-zinc-100 text-[#09090b] rounded-lg text-sm font-semibold transition-colors"
            >
              <Plus size={16} />
              Create Organization
            </button>
            <button
              onClick={fetchOrganizations}
              disabled={loading}
              className="flex items-center gap-2 px-3 py-2 bg-[#141517] hover:bg-[#1a1b1e] text-[#d1d5db] rounded-lg text-sm transition-colors disabled:opacity-50 border border-white/[0.08]"
            >
              <RefreshCw size={14} className={loading ? 'animate-spin' : ''} />
              Refresh
            </button>
          </div>
        </div>

        {/* Search and Filters */}
        <div className="flex gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-[#6b7280]" size={16} />
            <input
              type="text"
              placeholder="Search by name, email, or owner..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-[#08090a] border border-white/[0.08] rounded-lg pl-10 pr-4 py-2 text-sm text-[#e8e8e8] focus:border-white/40 outline-none transition-all"
            />
          </div>
          <div className="flex items-center gap-2">
            <Filter size={14} className="text-[#6b7280]" />
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as SubscriptionStatus | 'all')}
              className="bg-[#08090a] border border-white/[0.08] rounded-lg px-3 py-2 text-sm text-[#e8e8e8] focus:border-white/40 outline-none transition-all"
            >
              <option value="all">All Status</option>
              <option value="active">Active</option>
              <option value="trial">Trial</option>
              <option value="cancelled">Cancelled</option>
              <option value="past_due">Past Due</option>
            </select>
          </div>
        </div>
      </div>

      {/* Error State */}
      {error && (
        <div className="m-6 p-4 bg-rose-900/20 border border-rose-500/30 rounded-lg text-rose-400 text-sm">
          {error}
        </div>
      )}

      {/* Loading State */}
      {loading && (
        <div className="flex-1 flex items-center justify-center">
          <div className="flex items-center gap-3 text-[#9ca3af]">
            <RefreshCw size={20} className="animate-spin" />
            Loading organizations...
          </div>
        </div>
      )}

      {/* Organizations Table */}
      {!loading && (
        <div className="flex-1 overflow-auto p-6">
          <div className="bg-[#0d0e10]/50 rounded-lg border border-white/[0.08] overflow-hidden">
            <table className="w-full">
              <thead>
                <tr className="bg-[#141517]/50">
                  <th className="text-left px-4 py-3 text-xs font-bold text-[#9ca3af] uppercase tracking-wider">
                    Organization
                  </th>
                  <th className="text-left px-4 py-3 text-xs font-bold text-[#9ca3af] uppercase tracking-wider">
                    Owner
                  </th>
                  <th className="text-center px-4 py-3 text-xs font-bold text-[#9ca3af] uppercase tracking-wider">
                    Users
                  </th>
                  <th className="text-left px-4 py-3 text-xs font-bold text-[#9ca3af] uppercase tracking-wider">
                    Status
                  </th>
                  <th className="text-left px-4 py-3 text-xs font-bold text-[#9ca3af] uppercase tracking-wider">
                    Trial/Billing
                  </th>
                  <th className="text-left px-4 py-3 text-xs font-bold text-[#9ca3af] uppercase tracking-wider">
                    Created
                  </th>
                  <th className="text-right px-4 py-3 text-xs font-bold text-[#9ca3af] uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/[0.06]">
                {filteredOrgs.map((org) => {
                  const trialDaysRemaining = org.subscriptionStatus === 'trial' ? getDaysRemaining(org.trialEndsAt) : null;
                  return (
                    <tr
                      key={org.id}
                      className="hover:bg-[#141517]/30 transition-colors cursor-pointer"
                      onClick={() => setSelectedOrg(org)}
                    >
                      <td className="px-4 py-4">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-[#141517] rounded-lg flex items-center justify-center text-zinc-300 font-bold text-sm">
                            {org.name.substring(0, 2).toUpperCase()}
                          </div>
                          <div>
                            <div className="text-sm font-medium text-white">{org.name}</div>
                            <div className="text-xs text-[#6b7280]">{org.slug}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-4">
                        <div className="text-sm text-[#e8e8e8]">{org.ownerName}</div>
                        <div className="text-xs text-[#6b7280]">{org.ownerEmail}</div>
                      </td>
                      <td className="px-4 py-4 text-center">
                        <div className="flex items-center justify-center gap-1 text-[#d1d5db]">
                          <Users size={14} />
                          <span className="text-sm font-medium">{org.userCount}</span>
                        </div>
                      </td>
                      <td className="px-4 py-4">
                        {getStatusBadge(org.subscriptionStatus)}
                      </td>
                      <td className="px-4 py-4">
                        {org.subscriptionStatus === 'trial' && trialDaysRemaining !== null && (
                          <div className={`text-sm ${trialDaysRemaining <= 3 ? 'text-rose-400' : trialDaysRemaining <= 7 ? 'text-amber-400' : 'text-[#d1d5db]'}`}>
                            {trialDaysRemaining > 0 ? `${trialDaysRemaining} days left` : 'Expired'}
                          </div>
                        )}
                        {org.subscriptionStatus === 'active' && (
                          <div className="text-sm text-emerald-400">
                            {org.stripeCustomerId ? 'Stripe Active' : 'Manual'}
                          </div>
                        )}
                        {org.subscriptionStatus === 'cancelled' && (
                          <div className="text-sm text-[#6b7280]">--</div>
                        )}
                        {org.subscriptionStatus === 'past_due' && (
                          <div className="text-sm text-rose-400">Payment Failed</div>
                        )}
                      </td>
                      <td className="px-4 py-4 text-sm text-[#9ca3af]">
                        {formatDate(org.createdAt)}
                      </td>
                      <td className="px-4 py-4">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setSelectedOrg(org);
                            }}
                            className="p-2 hover:bg-[#1a1b1e] rounded-lg text-[#9ca3af] hover:text-white transition-colors"
                            title="View Details"
                          >
                            <Eye size={16} />
                          </button>
                          <ChevronRight size={16} className="text-[#4b5563]" />
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>

            {filteredOrgs.length === 0 && !loading && (
              <div className="p-12 text-center text-[#6b7280]">
                <Building2 size={48} className="mx-auto mb-4 opacity-50" />
                <p>No organizations found</p>
                {searchTerm && (
                  <p className="text-sm mt-2">Try adjusting your search criteria</p>
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Create Organization Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
          <div className="bg-[#0d0e10] rounded-xl border border-white/[0.08] w-full max-w-lg shadow-2xl">
            {/* Modal Header */}
            <div className="flex items-center justify-between p-6 border-b border-white/[0.08]">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#141517] rounded-lg">
                  <Building2 className="text-zinc-300" size={20} />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white">Create Organization</h3>
                  <p className="text-xs text-[#6b7280]">Set up a new organization with an owner</p>
                </div>
              </div>
              <button
                onClick={() => {
                  setShowCreateModal(false);
                  setCreateError(null);
                }}
                className="p-2 hover:bg-[#141517] rounded-lg text-[#9ca3af] hover:text-white transition-colors"
              >
                <X size={20} />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 space-y-4">
              {createError && (
                <div className="p-3 bg-rose-900/30 border border-rose-500/30 rounded-lg text-rose-400 text-sm">
                  {createError}
                </div>
              )}

              {/* Organization Name */}
              <div>
                <label className="block text-sm font-medium text-[#d1d5db] mb-2">
                  Organization Name *
                </label>
                <input
                  type="text"
                  value={newOrg.name}
                  onChange={(e) => setNewOrg({ ...newOrg, name: e.target.value })}
                  placeholder="Acme Aviation Services"
                  className="w-full bg-[#141517] border border-white/[0.08] rounded-lg px-4 py-2.5 text-sm text-white placeholder-[#6b7280] focus:border-white/40 outline-none"
                />
              </div>

              {/* Owner Details */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-[#d1d5db] mb-2">
                    Owner Name *
                  </label>
                  <input
                    type="text"
                    value={newOrg.ownerName}
                    onChange={(e) => setNewOrg({ ...newOrg, ownerName: e.target.value })}
                    placeholder="John Smith"
                    className="w-full bg-[#141517] border border-white/[0.08] rounded-lg px-4 py-2.5 text-sm text-white placeholder-[#6b7280] focus:border-white/40 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-[#d1d5db] mb-2">
                    Owner Email *
                  </label>
                  <input
                    type="email"
                    value={newOrg.ownerEmail}
                    onChange={(e) => setNewOrg({ ...newOrg, ownerEmail: e.target.value })}
                    placeholder="john@acme.com"
                    className="w-full bg-[#141517] border border-white/[0.08] rounded-lg px-4 py-2.5 text-sm text-white placeholder-[#6b7280] focus:border-white/40 outline-none"
                  />
                </div>
              </div>

              {/* Password */}
              <div>
                <label className="block text-sm font-medium text-[#d1d5db] mb-2">
                  Owner Password *
                </label>
                <input
                  type="password"
                  value={newOrg.ownerPassword}
                  onChange={(e) => setNewOrg({ ...newOrg, ownerPassword: e.target.value })}
                  placeholder="Minimum 6 characters"
                  className="w-full bg-[#141517] border border-white/[0.08] rounded-lg px-4 py-2.5 text-sm text-white placeholder-[#6b7280] focus:border-white/40 outline-none"
                />
              </div>

              {/* Subscription Settings */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-[#d1d5db] mb-2">
                    Subscription Status
                  </label>
                  <select
                    value={newOrg.subscriptionStatus}
                    onChange={(e) => setNewOrg({ ...newOrg, subscriptionStatus: e.target.value as SubscriptionStatus })}
                    className="w-full bg-[#141517] border border-white/[0.08] rounded-lg px-4 py-2.5 text-sm text-white focus:border-white/40 outline-none"
                  >
                    <option value="trial">Trial</option>
                    <option value="active">Active</option>
                  </select>
                </div>
                {newOrg.subscriptionStatus === 'trial' && (
                  <div>
                    <label className="block text-sm font-medium text-[#d1d5db] mb-2">
                      Trial Duration
                    </label>
                    <select
                      value={newOrg.trialDays}
                      onChange={(e) => setNewOrg({ ...newOrg, trialDays: parseInt(e.target.value) })}
                      className="w-full bg-[#141517] border border-white/[0.08] rounded-lg px-4 py-2.5 text-sm text-white focus:border-white/40 outline-none"
                    >
                      <option value={7}>7 days</option>
                      <option value={14}>14 days</option>
                      <option value={30}>30 days</option>
                      <option value={60}>60 days</option>
                    </select>
                  </div>
                )}
              </div>

              <p className="text-xs text-[#6b7280]">
                The owner will receive an email verification link. After verifying, they can log in and set up their organization.
              </p>
            </div>

            {/* Modal Footer */}
            <div className="flex items-center justify-end gap-3 p-6 border-t border-white/[0.08]">
              <button
                onClick={() => {
                  setShowCreateModal(false);
                  setCreateError(null);
                }}
                className="px-4 py-2 text-sm text-[#9ca3af] hover:text-white transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleCreateOrganization}
                disabled={createLoading}
                className="flex items-center gap-2 px-4 py-2 bg-white hover:bg-zinc-100 text-[#09090b] text-white rounded-lg text-sm font-medium transition-colors disabled:opacity-50"
              >
                {createLoading ? (
                  <>
                    <Loader2 size={16} className="animate-spin" />
                    Creating...
                  </>
                ) : (
                  <>
                    <Plus size={16} />
                    Create Organization
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default OrganizationList;
