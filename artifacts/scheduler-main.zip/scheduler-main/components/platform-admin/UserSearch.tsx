import React, { useState } from 'react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';
import {
  Search,
  Users,
  Building2,
  Mail,
  UserCog,
  RefreshCw,
  AlertCircle,
  Clock,
  CheckCircle
} from 'lucide-react';

interface SearchResult {
  id: string;
  email: string;
  name: string;
  role: string;
  organizationId: string;
  organizationName: string;
  subscriptionStatus: string;
  createdAt: string;
}

const UserSearch: React.FC = () => {
  const { startImpersonation, platformRole } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [hasSearched, setHasSearched] = useState(false);

  const handleSearch = async () => {
    if (!searchTerm.trim()) return;

    setLoading(true);
    setError(null);
    setHasSearched(true);

    try {
      const { data, error: searchError } = await supabase
        .from('profiles')
        .select(`
          id,
          email,
          full_name,
          role,
          organization_id,
          created_at,
          organizations(id, name, subscription_status)
        `)
        .or(`email.ilike.%${searchTerm}%,full_name.ilike.%${searchTerm}%`)
        .limit(50);

      if (searchError) throw searchError;

      const transformed: SearchResult[] = (data || []).map((u: any) => ({
        id: u.id,
        email: u.email,
        name: u.full_name,
        role: u.role,
        organizationId: u.organization_id,
        organizationName: u.organizations?.name || 'N/A',
        subscriptionStatus: u.organizations?.subscription_status || 'unknown',
        createdAt: u.created_at
      }));

      setResults(transformed);
    } catch (err: any) {
      setError(err.message || 'Search failed');
      setResults([]);
    } finally {
      setLoading(false);
    }
  };

  const handleImpersonate = async (userId: string) => {
    try {
      await startImpersonation(userId);
      window.location.reload();
    } catch (err: any) {
      setError(err.message || 'Failed to start impersonation');
    }
  };

  const canImpersonate = platformRole === 'super_admin' || platformRole === 'support_admin';

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active':
        return <CheckCircle size={14} className="text-emerald-400" />;
      case 'trial':
        return <Clock size={14} className="text-amber-400" />;
      case 'past_due':
        return <AlertCircle size={14} className="text-rose-400" />;
      default:
        return <AlertCircle size={14} className="text-[#9ca3af]" />;
    }
  };

  return (
    <div className="h-full flex flex-col bg-[#08090a]">
      {/* Header */}
      <div className="p-6 border-b border-white/[0.08]">
        <div className="flex items-center gap-3 mb-4">
          <Search className="text-zinc-300" size={24} />
          <div>
            <h2 className="text-xl font-bold text-white">User Search</h2>
            <p className="text-xs text-[#6b7280]">Find users across all organizations</p>
          </div>
        </div>

        {/* Search Bar */}
        <div className="flex gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-[#6b7280]" size={16} />
            <input
              type="text"
              placeholder="Search by email or name..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
              className="w-full bg-[#141517] border border-white/[0.08] rounded-lg pl-10 pr-4 py-3 text-sm text-[#e8e8e8] focus:border-white/40 outline-none"
            />
          </div>
          <button
            onClick={handleSearch}
            disabled={loading || !searchTerm.trim()}
            className="flex items-center gap-2 px-6 py-3 bg-white hover:bg-zinc-100 text-[#09090b] disabled:bg-indigo-600/50 text-white rounded-lg text-sm font-medium transition-colors"
          >
            {loading ? <RefreshCw size={16} className="animate-spin" /> : <Search size={16} />}
            Search
          </button>
        </div>
      </div>

      {/* Error */}
      {error && (
        <div className="m-6 p-4 bg-rose-900/20 border border-rose-500/30 rounded-lg text-rose-400 text-sm">
          {error}
        </div>
      )}

      {/* Results */}
      <div className="flex-1 overflow-auto p-6">
        {loading && (
          <div className="flex items-center justify-center py-12">
            <RefreshCw size={24} className="animate-spin text-[#9ca3af]" />
          </div>
        )}

        {!loading && hasSearched && results.length === 0 && (
          <div className="text-center py-12">
            <Users size={48} className="mx-auto mb-4 text-[#4b5563]" />
            <p className="text-[#9ca3af]">No users found matching "{searchTerm}"</p>
          </div>
        )}

        {!loading && !hasSearched && (
          <div className="text-center py-12">
            <Search size={48} className="mx-auto mb-4 text-[#4b5563]" />
            <p className="text-[#9ca3af]">Enter an email or name to search</p>
          </div>
        )}

        {!loading && results.length > 0 && (
          <div className="bg-[#0d0e10]/50 rounded-lg border border-white/[0.08] overflow-hidden">
            <table className="w-full">
              <thead>
                <tr className="bg-[#141517]/50">
                  <th className="text-left px-4 py-3 text-xs font-bold text-[#9ca3af] uppercase tracking-wider">
                    User
                  </th>
                  <th className="text-left px-4 py-3 text-xs font-bold text-[#9ca3af] uppercase tracking-wider">
                    Organization
                  </th>
                  <th className="text-left px-4 py-3 text-xs font-bold text-[#9ca3af] uppercase tracking-wider">
                    Role
                  </th>
                  <th className="text-left px-4 py-3 text-xs font-bold text-[#9ca3af] uppercase tracking-wider">
                    Joined
                  </th>
                  {canImpersonate && (
                    <th className="text-right px-4 py-3 text-xs font-bold text-[#9ca3af] uppercase tracking-wider">
                      Actions
                    </th>
                  )}
                </tr>
              </thead>
              <tbody className="divide-y divide-white/[0.06]">
                {results.map((user) => (
                  <tr key={user.id} className="hover:bg-[#141517]/30">
                    <td className="px-4 py-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-[#1a1b1e] rounded-full flex items-center justify-center text-[#d1d5db] font-bold text-sm">
                          {user.name.substring(0, 2).toUpperCase()}
                        </div>
                        <div>
                          <div className="text-sm font-medium text-white">{user.name}</div>
                          <div className="text-xs text-[#6b7280] flex items-center gap-1">
                            <Mail size={10} /> {user.email}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-4">
                      <div className="flex items-center gap-2">
                        {getStatusIcon(user.subscriptionStatus)}
                        <div>
                          <div className="text-sm text-[#e8e8e8]">{user.organizationName}</div>
                          <div className="text-xs text-[#6b7280] capitalize">{user.subscriptionStatus}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-4">
                      <span className={`text-xs font-bold px-2 py-1 rounded ${
                        user.role === 'owner'
                          ? 'bg-rose-500/20 text-rose-400'
                          : user.role === 'admin'
                          ? 'bg-[#5e6ad2]/20 text-zinc-300'
                          : 'bg-slate-500/20 text-[#9ca3af]'
                      }`}>
                        {user.role.charAt(0).toUpperCase() + user.role.slice(1)}
                      </span>
                    </td>
                    <td className="px-4 py-4 text-sm text-[#9ca3af]">
                      {new Date(user.createdAt).toLocaleDateString()}
                    </td>
                    {canImpersonate && (
                      <td className="px-4 py-4 text-right">
                        <button
                          onClick={() => handleImpersonate(user.id)}
                          className="flex items-center gap-1 px-3 py-1.5 text-xs bg-[#1a1b1e] hover:bg-[#1a1b1e] text-[#d1d5db] rounded ml-auto"
                        >
                          <UserCog size={12} /> Impersonate
                        </button>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
            <div className="p-4 border-t border-white/[0.08] text-xs text-[#6b7280]">
              Showing {results.length} result{results.length !== 1 ? 's' : ''}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default UserSearch;
