import React, { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import { PlatformRole, PlatformAdminInvite } from '../../types';
import { useAuth } from '../../contexts/AuthContext';
import {
  Shield,
  UserPlus,
  Mail,
  Clock,
  CheckCircle,
  XCircle,
  RefreshCw,
  Trash2,
  Copy,
  AlertTriangle
} from 'lucide-react';

interface PlatformAdmin {
  id: string;
  email: string;
  name: string;
  platformRole: PlatformRole;
  createdAt: string;
}

const PlatformAdminManagement: React.FC = () => {
  const { user, platformRole } = useAuth();
  const [admins, setAdmins] = useState<PlatformAdmin[]>([]);
  const [invites, setInvites] = useState<PlatformAdminInvite[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  // Invite form
  const [showInviteForm, setShowInviteForm] = useState(false);
  const [inviteEmail, setInviteEmail] = useState('');
  const [inviteRole, setInviteRole] = useState<PlatformRole>('support_admin');
  const [sending, setSending] = useState(false);

  const fetchData = async () => {
    setLoading(true);
    setError(null);

    try {
      // Fetch platform admins
      const { data: adminData, error: adminError } = await supabase
        .from('profiles')
        .select('id, email, full_name, platform_role, created_at')
        .eq('is_platform_admin', true);

      if (adminError) throw adminError;

      setAdmins((adminData || []).map(a => ({
        id: a.id,
        email: a.email,
        name: a.full_name,
        platformRole: a.platform_role as PlatformRole,
        createdAt: a.created_at
      })));

      // Fetch pending invites
      const { data: inviteData, error: inviteError } = await supabase
        .from('platform_admin_invites')
        .select('*')
        .is('accepted_at', null)
        .gt('expires_at', new Date().toISOString())
        .order('created_at', { ascending: false });

      if (inviteError) throw inviteError;

      setInvites((inviteData || []).map(i => ({
        id: i.id,
        email: i.email,
        role: i.role as PlatformRole,
        invitedBy: i.invited_by,
        token: i.token,
        expiresAt: i.expires_at,
        acceptedAt: i.accepted_at,
        createdAt: i.created_at
      })));

    } catch (err: any) {
      setError(err.message || 'Failed to fetch data');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleInvite = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || platformRole !== 'super_admin') return;

    setSending(true);
    setError(null);

    try {
      // Check if email already exists
      const existingAdmin = admins.find(a => a.email.toLowerCase() === inviteEmail.toLowerCase());
      if (existingAdmin) {
        throw new Error('This user is already a platform admin');
      }

      const existingInvite = invites.find(i => i.email.toLowerCase() === inviteEmail.toLowerCase());
      if (existingInvite) {
        throw new Error('An invite is already pending for this email');
      }

      // Generate invite token
      const token = crypto.randomUUID();
      const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000); // 7 days

      const { error: insertError } = await supabase
        .from('platform_admin_invites')
        .insert({
          email: inviteEmail.toLowerCase(),
          role: inviteRole,
          invited_by: user.id,
          token,
          expires_at: expiresAt.toISOString()
        });

      if (insertError) throw insertError;

      // Log the action
      await supabase.from('platform_audit_log').insert({
        admin_id: user.id,
        action: 'invite_platform_admin',
        target_type: 'platform_admin',
        details: { email: inviteEmail, role: inviteRole }
      });

      setSuccess(`Invite sent to ${inviteEmail}`);
      setShowInviteForm(false);
      setInviteEmail('');
      setInviteRole('support_admin');
      fetchData();

      setTimeout(() => setSuccess(null), 5000);

    } catch (err: any) {
      setError(err.message || 'Failed to send invite');
    } finally {
      setSending(false);
    }
  };

  const handleDeleteInvite = async (inviteId: string) => {
    if (!confirm('Are you sure you want to revoke this invite?')) return;

    try {
      const { error } = await supabase
        .from('platform_admin_invites')
        .delete()
        .eq('id', inviteId);

      if (error) throw error;

      setSuccess('Invite revoked');
      fetchData();
      setTimeout(() => setSuccess(null), 3000);
    } catch (err: any) {
      setError(err.message || 'Failed to revoke invite');
    }
  };

  const handleRemoveAdmin = async (adminId: string) => {
    if (adminId === user?.id) {
      setError('You cannot remove yourself');
      return;
    }

    if (!confirm('Are you sure you want to remove this platform admin?')) return;

    try {
      const { error } = await supabase
        .from('profiles')
        .update({
          is_platform_admin: false,
          platform_role: null
        })
        .eq('id', adminId);

      if (error) throw error;

      await supabase.from('platform_audit_log').insert({
        admin_id: user?.id,
        action: 'remove_platform_admin',
        target_type: 'platform_admin',
        target_id: adminId
      });

      setSuccess('Admin access revoked');
      fetchData();
      setTimeout(() => setSuccess(null), 3000);
    } catch (err: any) {
      setError(err.message || 'Failed to remove admin');
    }
  };

  const copyInviteLink = (token: string) => {
    const link = `${window.location.origin}/platform-admin/accept-invite?token=${token}`;
    navigator.clipboard.writeText(link);
    setSuccess('Invite link copied to clipboard');
    setTimeout(() => setSuccess(null), 3000);
  };

  const formatRole = (role: PlatformRole) => {
    return role.split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
  };

  const getRoleBadgeColor = (role: PlatformRole) => {
    switch (role) {
      case 'super_admin':
        return 'bg-[#c4626a]/20 text-[#c4626a] border-[#c4626a]/30';
      case 'support_admin':
        return 'bg-[#5e6ad2]/20 text-[#6e79d6] border-[#5e6ad2]/30';
      case 'billing_admin':
        return 'bg-[#3dae6c]/20 text-[#3dae6c] border-[#3dae6c]/30';
      default:
        return 'bg-[#141517] text-[#9ca3af] border-white/[0.08]';
    }
  };

  if (platformRole !== 'super_admin') {
    return (
      <div className="h-full flex items-center justify-center bg-[#08090a]">
        <div className="text-center">
          <Shield size={48} className="mx-auto mb-4 text-[#4b5563]" />
          <h2 className="text-xl font-semibold text-white mb-2">Access Denied</h2>
          <p className="text-[#9ca3af]">Only Super Admins can manage platform administrators</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col bg-[#08090a]">
      {/* Header */}
      <div className="p-6 border-b border-white/[0.06]">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-[#141517] p-2 rounded-lg border border-white/[0.08]">
              <Shield className="text-zinc-300" size={24} />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-[#e8e8e8]">Platform Administrators</h2>
              <p className="text-xs text-[#6b7280]">Manage who can access the platform admin dashboard</p>
            </div>
          </div>
          <button
            onClick={() => setShowInviteForm(true)}
            className="flex items-center gap-2 px-4 py-2 bg-white hover:bg-zinc-100 text-[#09090b] rounded-lg text-sm font-semibold transition-colors"
          >
            <UserPlus size={16} />
            Invite Admin
          </button>
        </div>

        {/* Messages */}
        {error && (
          <div className="mt-4 p-3 bg-[#c4626a]/10 border border-[#c4626a]/20 rounded-lg text-[#c4626a] text-sm flex items-center gap-2">
            <AlertTriangle size={16} />
            {error}
          </div>
        )}
        {success && (
          <div className="mt-4 p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-lg text-emerald-400 text-sm flex items-center gap-2">
            <CheckCircle size={16} />
            {success}
          </div>
        )}
      </div>

      {/* Content */}
      <div className="flex-1 overflow-auto p-6">
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <RefreshCw size={24} className="animate-spin text-[#9ca3af]" />
          </div>
        ) : (
          <div className="space-y-8">
            {/* Current Admins */}
            <div>
              <h3 className="text-sm font-semibold text-[#6b7280] uppercase tracking-wider mb-4">
                Current Admins ({admins.length})
              </h3>
              <div className="bg-[#0d0e10]/50 rounded-lg border border-white/[0.08] overflow-hidden">
                <table className="w-full">
                  <thead>
                    <tr className="bg-[#08090a]">
                      <th className="text-left px-4 py-3 text-xs font-semibold text-[#6b7280] uppercase">Admin</th>
                      <th className="text-left px-4 py-3 text-xs font-semibold text-[#6b7280] uppercase">Role</th>
                      <th className="text-left px-4 py-3 text-xs font-semibold text-[#6b7280] uppercase">Added</th>
                      <th className="text-right px-4 py-3 text-xs font-semibold text-[#6b7280] uppercase">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/[0.06]">
                    {admins.map((admin) => (
                      <tr key={admin.id} className="hover:bg-[#141517]/30 transition-colors">
                        <td className="px-4 py-4">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-[#141517] rounded-full flex items-center justify-center text-[#d1d5db] font-bold text-sm border border-white/[0.08]">
                              {admin.name.substring(0, 2).toUpperCase()}
                            </div>
                            <div>
                              <div className="text-sm font-medium text-white">
                                {admin.name}
                                {admin.id === user?.id && (
                                  <span className="ml-2 text-xs text-[#6b7280]">(You)</span>
                                )}
                              </div>
                              <div className="text-xs text-[#6b7280]">{admin.email}</div>
                            </div>
                          </div>
                        </td>
                        <td className="px-4 py-4">
                          <span className={`text-xs font-bold px-2 py-1 rounded border ${getRoleBadgeColor(admin.platformRole)}`}>
                            {formatRole(admin.platformRole)}
                          </span>
                        </td>
                        <td className="px-4 py-4 text-sm text-[#9ca3af]">
                          {new Date(admin.createdAt).toLocaleDateString()}
                        </td>
                        <td className="px-4 py-4 text-right">
                          {admin.id !== user?.id && (
                            <button
                              onClick={() => handleRemoveAdmin(admin.id)}
                              className="p-2 hover:bg-[#c4626a]/10 rounded text-[#9ca3af] hover:text-[#c4626a] transition-colors"
                              title="Remove admin access"
                            >
                              <Trash2 size={16} />
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Pending Invites */}
            {invites.length > 0 && (
              <div>
                <h3 className="text-sm font-semibold text-[#6b7280] uppercase tracking-wider mb-4">
                  Pending Invites ({invites.length})
                </h3>
                <div className="bg-[#0d0e10]/50 rounded-lg border border-white/[0.08] overflow-hidden">
                  <table className="w-full">
                    <thead>
                      <tr className="bg-[#08090a]">
                        <th className="text-left px-4 py-3 text-xs font-semibold text-[#6b7280] uppercase">Email</th>
                        <th className="text-left px-4 py-3 text-xs font-semibold text-[#6b7280] uppercase">Role</th>
                        <th className="text-left px-4 py-3 text-xs font-semibold text-[#6b7280] uppercase">Expires</th>
                        <th className="text-right px-4 py-3 text-xs font-semibold text-[#6b7280] uppercase">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/[0.06]">
                      {invites.map((invite) => (
                        <tr key={invite.id} className="hover:bg-[#141517]/30 transition-colors">
                          <td className="px-4 py-4">
                            <div className="flex items-center gap-2 text-sm text-[#d1d5db]">
                              <Mail size={14} className="text-[#6b7280]" />
                              {invite.email}
                            </div>
                          </td>
                          <td className="px-4 py-4">
                            <span className={`text-xs font-bold px-2 py-1 rounded border ${getRoleBadgeColor(invite.role)}`}>
                              {formatRole(invite.role)}
                            </span>
                          </td>
                          <td className="px-4 py-4 text-sm text-[#9ca3af]">
                            <div className="flex items-center gap-1">
                              <Clock size={12} />
                              {new Date(invite.expiresAt).toLocaleDateString()}
                            </div>
                          </td>
                          <td className="px-4 py-4">
                            <div className="flex items-center justify-end gap-2">
                              <button
                                onClick={() => copyInviteLink(invite.token)}
                                className="p-2 hover:bg-[#141517] rounded text-[#9ca3af] hover:text-white transition-colors"
                                title="Copy invite link"
                              >
                                <Copy size={16} />
                              </button>
                              <button
                                onClick={() => handleDeleteInvite(invite.id)}
                                className="p-2 hover:bg-[#c4626a]/10 rounded text-[#9ca3af] hover:text-[#c4626a] transition-colors"
                                title="Revoke invite"
                              >
                                <Trash2 size={16} />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Invite Form Modal */}
      {showInviteForm && (
        <div className="fixed inset-0 bg-[#08090a]/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#0d0e10] border border-white/[0.08] rounded-xl p-6 w-full max-w-md">
            <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
              <UserPlus size={20} className="text-zinc-300" />
              Invite Platform Admin
            </h3>
            <form onSubmit={handleInvite} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-[#6b7280] uppercase mb-1">
                  Email Address
                </label>
                <input
                  type="email"
                  required
                  value={inviteEmail}
                  onChange={(e) => setInviteEmail(e.target.value)}
                  className="w-full bg-[#08090a] border border-white/[0.08] rounded-lg py-2.5 px-3 text-sm text-[#e8e8e8] outline-none focus:border-white/40 transition-all"
                  placeholder="admin@company.com"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-[#6b7280] uppercase mb-1">
                  Role
                </label>
                <select
                  value={inviteRole}
                  onChange={(e) => setInviteRole(e.target.value as PlatformRole)}
                  className="w-full bg-[#08090a] border border-white/[0.08] rounded-lg py-2.5 px-3 text-sm text-[#e8e8e8] outline-none focus:border-white/40 transition-all"
                >
                  <option value="super_admin">Super Admin (Full Access)</option>
                  <option value="support_admin">Support Admin (View + Impersonate)</option>
                  <option value="billing_admin">Billing Admin (Subscriptions Only)</option>
                </select>
                <p className="text-xs text-[#6b7280] mt-1">
                  {inviteRole === 'super_admin' && 'Full access to all platform features'}
                  {inviteRole === 'support_admin' && 'Can view orgs, users, and impersonate for support'}
                  {inviteRole === 'billing_admin' && 'Can manage subscriptions and billing only'}
                </p>
              </div>
              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => {
                    setShowInviteForm(false);
                    setInviteEmail('');
                  }}
                  className="flex-1 py-2 text-[#9ca3af] hover:bg-[#141517] rounded-lg font-medium text-sm border border-white/[0.08] transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={sending}
                  className="flex-1 py-2 bg-white hover:bg-zinc-100 text-[#09090b] rounded-lg font-semibold text-sm disabled:opacity-50 transition-colors"
                >
                  {sending ? 'Sending...' : 'Send Invite'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default PlatformAdminManagement;
