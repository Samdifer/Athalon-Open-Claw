import React, { useMemo, RefObject, useState, useEffect, useRef, useCallback } from 'react';
import { useSyncedScroll } from '../contexts/TimelineSyncContext';
import { AreaChart, Area, XAxis, YAxis, Tooltip as RechartsTooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import { GameState, MONTH_NAMES } from '../types';
import { ExternalLink, Users, BatteryCharging, AlertTriangle, TrendingUp, ChevronsUp, ChevronsDown, Briefcase, CheckCircle } from 'lucide-react';
import { STICKY_COL_WIDTH, TOTAL_DAYS, START_YEAR, GLOSSARY } from '../constants';
import { HelpIcon } from './ui/Tooltip';
import { useCapacityData } from '../hooks';

interface CapacityForecasterProps {
  gameState: GameState;
  visibleDayStart: number;
  cellWidth: number;
  isPoppedOut: boolean;
  onPopOut: () => void;
  scrollRef?: RefObject<HTMLDivElement | null>;
  isOpen: boolean;
  onToggle: () => void;
  onScroll?: (e: React.UIEvent<HTMLDivElement>) => void;
  height?: number;
  selectedBaseId?: string;
}

const CapacityForecaster: React.FC<CapacityForecasterProps> = ({ 
  gameState, visibleDayStart, cellWidth, isPoppedOut, onPopOut, scrollRef, isOpen, onToggle, onScroll, height, selectedBaseId
}) => {
  
  const CHART_HEIGHT = 120;
  
  const [hoverInfo, setHoverInfo] = useState<{ day: number, x: number, y: number } | null>(null);
  const [now, setNow] = useState(new Date());

  // PERFORMANCE: Virtualization - only render visible days + buffer
  const [visibleRange, setVisibleRange] = useState({ start: 0, end: 50 });
  const internalScrollRef = useRef<HTMLDivElement>(null);
  const rafUpdateRef = useRef<number | null>(null);

  // Ref to store the update callback - allows passing to context before it's defined
  const updateCallbackRef = useRef<() => void>(() => {});

  // Bi-directional scroll sync for popped-out windows
  // Pass a stable callback that calls the latest updateVisibleRangeRAF
  const { scrollRef: syncedScrollRef, handleScroll: syncedHandleScroll, state: syncState } = useSyncedScroll(
    'capacity',
    useCallback(() => updateCallbackRef.current(), [])
  );

  // Use context ref when popped out, prop ref when docked
  const effectiveScrollRef = isPoppedOut ? syncedScrollRef : (scrollRef || internalScrollRef);
  const effectiveCellWidth = isPoppedOut ? syncState.cellWidth : cellWidth;

  // PERFORMANCE: RAF-debounced visible range update for 60fps
  const updateVisibleRangeRAF = useCallback(() => {
    if (rafUpdateRef.current) return; // Already pending
    rafUpdateRef.current = requestAnimationFrame(() => {
      const ref = effectiveScrollRef;
      if (!ref?.current) {
        rafUpdateRef.current = null;
        return;
      }
      const scrollLeft = ref.current.scrollLeft;
      const clientWidth = ref.current.clientWidth;
      const start = Math.floor(scrollLeft / effectiveCellWidth);
      const visibleCount = Math.ceil(clientWidth / effectiveCellWidth);
      const buffer = 15;
      setVisibleRange({
        start: Math.max(0, start - buffer),
        end: Math.min(TOTAL_DAYS, start + visibleCount + buffer)
      });
      rafUpdateRef.current = null;
    });
  }, [effectiveScrollRef, effectiveCellWidth]);

  // Keep the callback ref updated
  useEffect(() => {
    updateCallbackRef.current = updateVisibleRangeRAF;
  }, [updateVisibleRangeRAF]);

  // Cleanup RAF on unmount
  useEffect(() => {
    return () => {
      if (rafUpdateRef.current) cancelAnimationFrame(rafUpdateRef.current);
    };
  }, []);

  // Update visible range on scroll - uses RAF for 60fps
  const handleInternalScroll = useCallback((e: React.UIEvent<HTMLDivElement>) => {
    updateVisibleRangeRAF();
    if (isPoppedOut) {
      syncedHandleScroll(e);
    } else if (onScroll) {
      onScroll(e);
    }
  }, [updateVisibleRangeRAF, isPoppedOut, syncedHandleScroll, onScroll]);

  // Sync visible range on mount and zoom change
  useEffect(() => {
    updateVisibleRangeRAF();
  }, [effectiveCellWidth, updateVisibleRangeRAF]);

  // PERFORMANCE: Pre-compute holiday set for O(1) lookup in render
  const holidaySet = useMemo(() =>
    new Set(gameState.holidays.filter(h => h.enabled).map(h => h.dayIndex)),
    [gameState.holidays]
  );

  useEffect(() => {
    const interval = setInterval(() => setNow(new Date()), 60000);
    return () => clearInterval(interval);
  }, []);

  const realTimeDayIndex = useMemo(() => {
    const startOfSim = new Date(START_YEAR, 0, 1);
    const diff = now.getTime() - startOfSim.getTime();
    return diff / (1000 * 60 * 60 * 24);
  }, [now]);
  
  // Use centralized capacity data hook
  const { dailyCapacities, dailyLoads } = useCapacityData(gameState, { baseId: selectedBaseId });

  // Transform to chart-friendly format
  const fullYearData = useMemo(() => {
      const data = new Array(TOTAL_DAYS);
      for (let i = 0; i < TOTAL_DAYS; i++) {
          const capacity = dailyCapacities[i];
          const load = dailyLoads[i];
          data[i] = {
              day: i,
              capacity,
              load,
              utilization: capacity > 0 ? (load / capacity) * 100 : 0
          };
      }
      return data;
  }, [dailyCapacities, dailyLoads]); 

  const { capacityBarPath, safeLoadBarPath, overloadBarPath, loadTrendPath, maxVal } = useMemo(() => {
      let max = 100;
      for (let i = 0; i < fullYearData.length; i++) {
          const d = fullYearData[i];
          if (d.capacity > max) max = d.capacity;
          if (d.load > max) max = d.load;
      }
      max = max * 1.2;
      const safeMax = max || 1;
      let capBarPath = "", safeLdBarPath = "", overLdBarPath = "";
      const ldTrendPts: [number, number][] = [];
      const windowSize = 7;
      const ldHist: number[] = [];
      const padding = Math.max(1, effectiveCellWidth * 0.15);
      const barWidth = effectiveCellWidth - (padding * 2);

      for (let i = 0; i < fullYearData.length; i++) {
          const d = fullYearData[i];
          ldHist.push(d.load);
          if(ldHist.length > windowSize) ldHist.shift();
          const avgLd = ldHist.reduce((a,b)=>a+b,0)/ldHist.length;
          const cx = (i * effectiveCellWidth) + (effectiveCellWidth / 2);
          ldTrendPts.push([cx, avgLd]);

          if (effectiveCellWidth > 4) {
              const xStart = i * effectiveCellWidth + padding;
              const capH = (d.capacity / safeMax) * CHART_HEIGHT;
              const capY = CHART_HEIGHT - capH;
              if (capH > 0) capBarPath += `M${xStart},${CHART_HEIGHT} L${xStart},${capY} L${xStart + barWidth},${capY} L${xStart + barWidth},${CHART_HEIGHT} Z `;

              const safeLoad = Math.min(d.load, d.capacity);
              const overload = Math.max(0, d.load - d.capacity);
              const safeH = (safeLoad / safeMax) * CHART_HEIGHT;
              const safeY = CHART_HEIGHT - safeH;
              if (safeH > 0) safeLdBarPath += `M${xStart},${CHART_HEIGHT} L${xStart},${safeY} L${xStart + barWidth},${safeY} L${xStart + barWidth},${CHART_HEIGHT} Z `;
              if (overload > 0) {
                  const totalLoadH = (d.load / safeMax) * CHART_HEIGHT;
                  const totalLoadY = CHART_HEIGHT - totalLoadH;
                  overLdBarPath += `M${xStart},${safeY} L${xStart},${totalLoadY} L${xStart + barWidth},${totalLoadY} L${xStart + barWidth},${safeY} Z `;
              }
          }
      }
      const makeLine = (pts: [number, number][]) => pts.map((p, i) => {
          const y = CHART_HEIGHT - ((p[1] / safeMax) * CHART_HEIGHT);
          return `${i === 0 ? 'M' : 'L'} ${p[0]} ${y}`;
      }).join(' ');
      return { capacityBarPath: capBarPath, safeLoadBarPath: safeLdBarPath, overloadBarPath: overLdBarPath, loadTrendPath: makeLine(ldTrendPts), maxVal: safeMax };
  }, [fullYearData, effectiveCellWidth]); 

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const bounds = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - bounds.left;
    const dayIndex = Math.floor(x / effectiveCellWidth);
    if (dayIndex >= 0 && dayIndex < TOTAL_DAYS) {
        setHoverInfo({ day: dayIndex, x: x, y: e.clientY - bounds.top });
    }
  };

  const currentStats = fullYearData[gameState.day] || { capacity: 0, load: 0, utilization: 0 };
  
  // Allow small tolerance (0.1h / 6mins) for floating point variance when capacity matches load
  const isOverCapacity = currentStats.load > (currentStats.capacity + 0.1);
  const isUnderUtilized = currentStats.utilization < 70 && currentStats.capacity > 0;

  return (
    <div
        className={`bg-[#0d0e10] flex flex-col shrink-0 select-none relative z-20 w-full transition-all duration-300 ease-in-out overflow-hidden
            ${isPoppedOut ? 'h-full flex-1 border-none' : 'border-t border-white/[0.06]'}
        `}
        style={isPoppedOut ? {} : { height: isOpen ? height : 32 }}
    >
        {/* Header */}
        <div
            onClick={!isPoppedOut ? onToggle : undefined}
            className={`px-3 py-2 bg-[#141517] border-b border-white/[0.06] flex justify-between items-center shrink-0 z-30 transition-colors group h-8 ${!isPoppedOut ? 'cursor-pointer hover:bg-[#1a1b1e]' : ''}`}
        >
            <h3 className="text-[10px] font-semibold text-indigo-400 uppercase tracking-wide flex items-center gap-2">
                {isOpen ? <BatteryCharging size={12} /> : null}
                <span>{isOpen ? 'Capacity Forecaster' : 'Capacity & Load'}</span>
                <HelpIcon tooltip={GLOSSARY.capacity.definition} size={11} />
            </h3>
            <div className="flex items-center gap-2">
                {isOpen && <span className="text-[10px] text-[#6b7280] hidden sm:inline mr-2">Timeline Synced</span>}
                {isOpen && !isPoppedOut && <button onClick={(e) => { e.stopPropagation(); onPopOut(); }} className="text-[#6b7280] hover:text-indigo-400"><ExternalLink size={16} /></button>}
                {!isPoppedOut && (
                    <button onClick={(e) => { e.stopPropagation(); onToggle(); }} className="text-[#6b7280] hover:text-indigo-400">
                        {isOpen ? <ChevronsDown size={16} /> : <ChevronsUp size={16} />}
                    </button>
                )}
            </div>
        </div>

        <div className={`flex flex-1 min-h-0 relative transition-opacity duration-300 ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
            {/* KPI Sidebar */}
            <div
                className="bg-[#0d0e10] border-r border-white/[0.08] shrink-0 flex flex-col px-2 py-3 justify-center gap-2 z-20"
                style={{ width: STICKY_COL_WIDTH, minWidth: STICKY_COL_WIDTH }}
            >
                 <div>
                    <div className="flex items-center gap-1 text-[9px] font-medium text-[#6b7280] uppercase mb-0.5"><Users size={10} /> Available Cap.</div>
                    <div className="text-base font-mono font-semibold text-amber-500 leading-none">{Math.round(currentStats.capacity)} <span className="text-[10px] text-[#4b5563]">hrs</span></div>
                 </div>
                 <div>
                    <div className="flex items-center gap-1 text-[9px] font-medium text-[#6b7280] uppercase mb-0.5"><Briefcase size={10} /> Planned Load</div>
                    <div className={`text-base font-mono font-semibold leading-none ${isOverCapacity ? 'text-rose-500' : 'text-emerald-500'}`}>{Math.round(currentStats.load)} <span className="text-[10px] text-[#4b5563]">hrs</span></div>
                 </div>
                 <div className={`mt-1 p-1.5 rounded border text-[9px] font-semibold text-center leading-tight ${
                     isOverCapacity
                        ? 'bg-rose-500/10 border-rose-500/20 text-rose-400'
                        : isUnderUtilized
                            ? 'bg-indigo-500/10 border-indigo-500/20 text-indigo-400'
                            : 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400'
                 }`}>
                    {isOverCapacity ? (
                        <span className="flex items-center justify-center gap-1"><AlertTriangle size={8} /> OVERLOAD</span>
                    ) : isUnderUtilized ? (
                        <span className="flex items-center justify-center gap-1"><TrendingUp size={8} /> SELL MORE</span>
                    ) : (
                        <span className="flex items-center justify-center gap-1"><CheckCircle size={8} /> OPTIMAL</span>
                    )}
                 </div>
            </div>

            {/* Chart */}
            <div className="flex-1 relative min-w-0 bg-[#08090a]">
                <div className="absolute bottom-4 left-0 right-0 z-0 pointer-events-none" style={{ height: CHART_HEIGHT }}>
                    <div className="w-full h-px bg-white/[0.06] absolute top-0" />
                    <div className="w-full h-px bg-white/[0.06] absolute top-1/2" />
                    <div className="w-full h-px bg-white/[0.06] absolute bottom-0" />
                    <span className="absolute top-0 right-1 text-[9px] text-[#4b5563]">{Math.round(maxVal)}h</span>
                </div>

                <div ref={effectiveScrollRef} onScroll={handleInternalScroll} className="absolute inset-0 overflow-x-auto custom-scrollbar z-10 overscroll-x-none" style={{ contain: 'strict' }}>
                    <div className="relative h-full" style={{ width: TOTAL_DAYS * effectiveCellWidth }} onMouseMove={handleMouseMove} onMouseLeave={() => setHoverInfo(null)}>
                        {/* PERFORMANCE: Virtualized grid - only render visible days + buffer */}
                        <div className="absolute inset-0 pointer-events-none">
                            {Array.from({ length: visibleRange.end - visibleRange.start }).map((_, idx) => {
                                const i = visibleRange.start + idx;
                                const isHoliday = holidaySet.has(i);
                                const isWeekend = (i + 1) % 7 === 6 || (i + 1) % 7 === 0;
                                let bgClass = '';
                                if (isHoliday) bgClass = 'bg-rose-500/10';
                                else if (isWeekend) bgClass = 'bg-white/[0.02]';
                                return (
                                    <div
                                        key={i}
                                        style={{ width: effectiveCellWidth, left: i * effectiveCellWidth, position: 'absolute', top: 0, bottom: 0 }}
                                        className={`border-r border-white/[0.04] ${bgClass}`}
                                    />
                                );
                            })}
                        </div>

                        {realTimeDayIndex >= 0 && realTimeDayIndex < TOTAL_DAYS && (
                           <div className="absolute top-0 bottom-0 z-20 pointer-events-none border-l-2 border-rose-500" style={{ left: realTimeDayIndex * effectiveCellWidth }}>
                              <div className="absolute top-0 left-0 -translate-x-1/2 bg-rose-500 text-white text-[8px] font-semibold px-1 py-0.5 rounded-sm whitespace-nowrap z-50">NOW</div>
                           </div>
                        )}

                        <div className="absolute top-0 bottom-0 border-l border-amber-500 z-10 pointer-events-none" style={{ left: (gameState.day * effectiveCellWidth) + (effectiveCellWidth / 2), transitionProperty: 'left', transitionDuration: gameState.paused ? '300ms' : `${gameState.speed}ms`, transitionTimingFunction: gameState.paused ? 'cubic-bezier(0.4, 0, 0.2, 1)' : 'linear' }} />

                        {/* Configurable Progress Cursors */}
                        {gameState.cursors && gameState.cursors.map(cursor => {
                            if (!cursor.enabled) return null;
                            const targetDay = Math.floor(realTimeDayIndex) + cursor.dayOffset;
                            if (targetDay < 0 || targetDay >= TOTAL_DAYS) return null;

                            return (
                                <div
                                    key={cursor.id}
                                    className={`absolute top-0 bottom-0 z-20 pointer-events-none border-l border-dashed opacity-60 ${cursor.color.replace('bg-', 'border-')}`}
                                    style={{
                                        left: (targetDay * effectiveCellWidth) + (effectiveCellWidth / 2)
                                    }}
                                />
                            );
                        })}

                        <svg className="absolute bottom-4 left-0 pointer-events-none" style={{ width: TOTAL_DAYS * effectiveCellWidth, height: CHART_HEIGHT, overflow: 'visible' }}>
                            <path d={capacityBarPath} fill="#f59e0b" opacity={0.2} />
                            <path d={safeLoadBarPath} fill="#22c55e" opacity={0.9} />
                            <path d={overloadBarPath} fill="#dc2626" opacity={1.0} />
                            <path d={loadTrendPath} fill="none" stroke="#10b981" strokeWidth="1" strokeLinecap="round" strokeLinejoin="round" opacity={0.5} />
                        </svg>

                        {hoverInfo && fullYearData[hoverInfo.day] && (
                            <div className="absolute z-50 bg-[#141517]/95 border border-white/[0.1] rounded-lg p-2 text-xs pointer-events-none whitespace-nowrap backdrop-blur-md" style={{ left: hoverInfo.x + 10, top: 10, transform: hoverInfo.x > (TOTAL_DAYS * effectiveCellWidth) - 150 ? 'translateX(-100%)' : 'none' }}>
                                <div className="font-semibold text-[#e8e8e8] mb-1 border-b border-white/[0.06] pb-1">{MONTH_NAMES[new Date(START_YEAR, 0, 1 + hoverInfo.day).getMonth()]} {new Date(START_YEAR, 0, 1 + hoverInfo.day).getDate()}</div>
                                <div className="grid grid-cols-2 gap-x-4 gap-y-1 mt-1">
                                    <span className="text-[#6b7280]">Available:</span><span className="font-mono text-amber-500 font-semibold text-right">{Math.round(fullYearData[hoverInfo.day].capacity)}h</span>
                                    <span className="text-[#6b7280]">Planned:</span><span className={`font-mono font-semibold text-right ${fullYearData[hoverInfo.day].load > fullYearData[hoverInfo.day].capacity ? 'text-rose-500' : 'text-emerald-500'}`}>{Math.round(fullYearData[hoverInfo.day].load)}h</span>
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    </div>
  );
};

// PERFORMANCE: Wrap with React.memo to prevent unnecessary re-renders
export default React.memo(CapacityForecaster);