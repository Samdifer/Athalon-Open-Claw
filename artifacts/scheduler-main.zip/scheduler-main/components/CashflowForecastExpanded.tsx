
import React, { useState, useMemo } from 'react';
import { Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, ReferenceLine, ComposedChart } from 'recharts';
import { GameState, MONTH_NAMES } from '../types';
import { DOLLAR_SIGN } from '../App';
import { TrendingUp, TrendingDown, AlertTriangle, Calendar, Activity, DollarSign } from 'lucide-react';
import { EmptyState } from './ui';
import { HOURLY_COST_AVG, START_YEAR } from '../constants';

interface CashflowForecastExpandedProps {
  gameState: GameState;
}

const CashflowForecastExpanded: React.FC<CashflowForecastExpandedProps> = ({ gameState }) => {
  const [range, setRange] = useState<number>(90); // Default 90 days

  // --- Logic Duplication from FinancialPanel for Consistency ---
  const calculateLaborCostForDay = (dayIndex: number) => {
    const dayOfWeek = (dayIndex + 1) % 7; // Corrected for 2024 (Jan 1 = Mon)
    
    let dailyCost = 0;
    
    gameState.personnel.forEach(p => {
        const team = gameState.teams.find(t => t.id === p.teamId);
        if (!team) return;

        const shift = gameState.shifts.find(s => s.id === team.shiftId);
        const role = gameState.roles.find(r => r.id === p.roleId);
        
        if (shift && shift.days.includes(dayOfWeek)) {
            const rate = role?.hourlyCost || HOURLY_COST_AVG;
            dailyCost += (shift.duration * rate);
        }
    });
    return dailyCost;
  };

  const { projectionData, revenueEvents, lowestPoint } = useMemo(() => {
    const data = [];
    const events = [];
    let projectedCash = gameState.cash;
    let minCash = gameState.cash;
    let maxCash = gameState.cash;
    const dailyOverhead = gameState.overheadDaily;

    // Map jobs to revenue dates
    const jobRevenueMap: Record<number, { revenue: number, jobs: string[] }> = {};
    
    const paymentTerms = gameState.paymentTerms ?? 7;

    gameState.schedule.forEach(job => {
        if (job.status === 'Scheduled' || job.status === 'In Progress') {
            // Estimate completion + payment terms for payment
            const endDay = job.startDate + job.deadlineDays + paymentTerms;
            if (endDay > gameState.day) {
                if (!jobRevenueMap[endDay]) {
                    jobRevenueMap[endDay] = { revenue: 0, jobs: [] };
                }
                jobRevenueMap[endDay].revenue += job.revenue;
                jobRevenueMap[endDay].jobs.push(job.customer);
            }
        }
    });

    for (let i = 1; i <= range; i++) {
        const targetDay = gameState.day + i;
        const laborCost = calculateLaborCostForDay(targetDay);
        const totalBurn = laborCost + dailyOverhead;
        
        projectedCash -= totalBurn;
        
        const incomeEntry = jobRevenueMap[targetDay];
        const dailyIncome = incomeEntry ? incomeEntry.revenue : 0;
        
        if (dailyIncome > 0) {
            projectedCash += dailyIncome;
            events.push({
                day: i,
                date: targetDay,
                amount: dailyIncome,
                jobs: incomeEntry.jobs,
                balanceAfter: projectedCash
            });
        }

        if (projectedCash < minCash) minCash = projectedCash;
        if (projectedCash > maxCash) maxCash = projectedCash;

        const date = new Date(START_YEAR, 0, 1 + targetDay);
        const label = `${MONTH_NAMES[date.getMonth()]} ${date.getDate()}`;

        data.push({
            day: i,
            label,
            balance: Math.round(projectedCash),
            burn: Math.round(totalBurn),
            income: Math.round(dailyIncome)
        });
    }

    return { 
        projectionData: data, 
        revenueEvents: events,
        lowestPoint: minCash,
        highestPoint: maxCash
    };
  }, [
    gameState.day,
    gameState.cash,
    gameState.overheadDaily,
    gameState.paymentTerms,
    gameState.schedule,
    gameState.personnel,
    gameState.teams,
    gameState.shifts,
    gameState.roles,
    range
  ]);

  const netChange = (projectionData[projectionData.length - 1]?.balance || 0) - gameState.cash;
  const isNegativeTrend = netChange < 0;

  return (
    <div className="flex flex-col h-full bg-[#0d0e10] text-[#e8e8e8]">

        {/* Toolbar */}
        <div className="flex justify-between items-center p-4 border-b border-white/[0.06] bg-[#141517]">
            <div className="flex gap-2">
                {[30, 90, 180, 365].map(r => (
                    <button
                        key={r}
                        onClick={() => setRange(r)}
                        className={`px-3 py-1 text-xs font-semibold rounded border transition-all ${
                            range === r
                            ? 'bg-indigo-500 border-indigo-500 text-white'
                            : 'bg-[#1a1b1e] border-white/[0.08] text-[#9ca3af] hover:bg-[#232428]'
                        }`}
                    >
                        {r} Days
                    </button>
                ))}
            </div>
            <div className="flex items-center gap-4 text-xs font-mono">
                <div className="flex items-center gap-2">
                    <span className="text-[#6b7280]">Projected Low:</span>
                    <span className={`font-semibold ${lowestPoint < 0 ? 'text-rose-500' : 'text-[#e8e8e8]'}`}>
                        {DOLLAR_SIGN}{lowestPoint.toLocaleString()}
                    </span>
                </div>
                <div className="flex items-center gap-2">
                    <span className="text-[#6b7280]">Net Change:</span>
                    <span className={`font-semibold flex items-center ${isNegativeTrend ? 'text-rose-400' : 'text-emerald-400'}`}>
                        {isNegativeTrend ? <TrendingDown size={14} className="mr-1"/> : <TrendingUp size={14} className="mr-1"/>}
                        {DOLLAR_SIGN}{Math.abs(netChange).toLocaleString()}
                    </span>
                </div>
            </div>
        </div>

        <div className="flex-1 flex overflow-hidden">
            {/* Main Chart Area */}
            <div className="flex-1 p-4 flex flex-col min-w-0">
                <div className="bg-[#08090a] rounded-lg border border-white/[0.06] p-1 flex-1 relative">
                    <div className="absolute top-4 left-4 z-10 bg-[#141517]/90 p-2 rounded-lg border border-white/[0.08] backdrop-blur-sm">
                        <div className="text-[10px] uppercase font-semibold text-[#6b7280]">Projected Balance</div>
                        <div className={`text-2xl font-mono font-semibold ${projectionData[projectionData.length-1]?.balance < 0 ? 'text-rose-500' : 'text-emerald-400'}`}>
                            {DOLLAR_SIGN}{projectionData[projectionData.length-1]?.balance.toLocaleString()}
                        </div>
                    </div>

                    <ResponsiveContainer width="100%" height="100%" minHeight={200}>
                        <ComposedChart data={projectionData} margin={{ top: 20, right: 30, left: 10, bottom: 0 }}>
                            <defs>
                                <linearGradient id="colorBalance" x1="0" y1="0" x2="0" y2="1">
                                    <stop offset="5%" stopColor="#818cf8" stopOpacity={0.3}/>
                                    <stop offset="95%" stopColor="#818cf8" stopOpacity={0}/>
                                </linearGradient>
                            </defs>
                            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" vertical={false} />
                            <XAxis dataKey="label" stroke="#4b5563" fontSize={10} minTickGap={40} />
                            <YAxis stroke="#4b5563" fontSize={10} tickFormatter={(val) => `${val/1000}k`} />
                            <Tooltip
                                contentStyle={{ backgroundColor: '#141517', borderColor: 'rgba(255,255,255,0.1)', borderRadius: '8px' }}
                                labelStyle={{ color: '#9ca3af', fontSize: '11px', fontWeight: '600' }}
                                formatter={(value: number, name: string) => {
                                    if (name === 'balance') return [`${DOLLAR_SIGN}${value.toLocaleString()}`, 'Balance'];
                                    if (name === 'income') return [`${DOLLAR_SIGN}${value.toLocaleString()}`, 'Revenue Event'];
                                    return [value, name];
                                }}
                            />
                            <ReferenceLine y={0} stroke="#ef4444" strokeDasharray="3 3" />
                            <Area
                              type="monotone"
                              dataKey="balance"
                              stroke="#818cf8"
                              fillOpacity={1}
                              fill="url(#colorBalance)"
                              strokeWidth={2}
                              isAnimationActive={true}
                              animationDuration={250}
                              animationEasing="ease-out"
                            />
                        </ComposedChart>
                    </ResponsiveContainer>
                </div>
            </div>

            {/* Right Panel: Events & Stats */}
            <div className="w-80 bg-[#08090a] border-l border-white/[0.06] flex flex-col overflow-hidden">
                <div className="p-4 border-b border-white/[0.06]">
                    <h3 className="text-xs font-semibold text-[#9ca3af] uppercase tracking-wide flex items-center gap-2">
                        <Activity size={14} className="text-indigo-400" /> Projected Revenue Events
                    </h3>
                </div>

                <div className="flex-1 overflow-y-auto custom-scrollbar p-4 space-y-3">
                    {revenueEvents.length === 0 ? (
                        <EmptyState
                            icon={DollarSign}
                            title="No revenue events"
                            description="Schedule jobs to see projected revenue from completed work and payments."
                            size="sm"
                        />
                    ) : (
                        revenueEvents.map((evt, idx) => (
                            <div key={idx} className="bg-[#0d0e10] border border-white/[0.06] rounded-lg p-3 relative group hover:border-emerald-500/30 transition-colors">
                                <div className="absolute left-0 top-0 bottom-0 w-1 bg-emerald-500 rounded-l-lg" />
                                <div className="flex justify-between items-start mb-2 pl-2">
                                    <div className="text-xs font-semibold text-[#e8e8e8] flex items-center gap-1">
                                        <Calendar size={10} className="text-[#6b7280]" />
                                        {MONTH_NAMES[new Date(START_YEAR, 0, 1 + evt.date).getMonth()]} {new Date(START_YEAR, 0, 1 + evt.date).getDate()}
                                        <span className="text-[9px] text-[#4b5563] ml-1">Day {evt.date}</span>
                                    </div>
                                    <div className="text-emerald-400 font-mono font-semibold text-sm">
                                        +{DOLLAR_SIGN}{evt.amount.toLocaleString()}
                                    </div>
                                </div>
                                <div className="pl-2">
                                    <div className="text-[10px] text-[#6b7280] uppercase font-medium mb-1">Sources</div>
                                    <div className="flex flex-wrap gap-1">
                                        {evt.jobs.map((job, jIdx) => (
                                            <span key={jIdx} className="text-[10px] bg-[#1a1b1e] text-[#9ca3af] px-1.5 py-0.5 rounded border border-white/[0.08]">
                                                {job}
                                            </span>
                                        ))}
                                    </div>
                                </div>
                            </div>
                        ))
                    )}
                </div>

                {/* Bottom Alert Section */}
                {lowestPoint < 0 && (
                    <div className="p-4 bg-rose-500/5 border-t border-rose-500/20">
                        <div className="flex items-start gap-3">
                             <AlertTriangle size={18} className="text-rose-500 shrink-0 mt-0.5" />
                             <div>
                                 <h4 className="text-sm font-semibold text-rose-400">Cashflow Warning</h4>
                                 <p className="text-[10px] text-rose-300/80 mt-1 leading-relaxed">
                                     Projections indicate a negative balance. Consider rescheduling expenses or securing a bridge loan.
                                 </p>
                             </div>
                        </div>
                    </div>
                )}
            </div>
        </div>
    </div>
  );
};

export default React.memo(CashflowForecastExpanded);
