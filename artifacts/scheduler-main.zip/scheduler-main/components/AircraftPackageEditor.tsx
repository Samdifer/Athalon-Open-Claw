import React, { useState } from 'react';
import { X, Package, Plus, Trash2, ArrowLeft } from 'lucide-react';
import { AircraftPackage, AircraftModel } from '../types';

interface AircraftPackageEditorProps {
  package: AircraftPackage | null; // null for creating new
  onSave: (pkg: Omit<AircraftPackage, 'id' | 'isBuiltIn'>) => void;
  onCancel: () => void;
}

const AircraftPackageEditor: React.FC<AircraftPackageEditorProps> = ({
  package: existingPackage,
  onSave,
  onCancel
}) => {
  const [name, setName] = useState(existingPackage?.name || '');
  const [description, setDescription] = useState(existingPackage?.description || '');
  const [aircraft, setAircraft] = useState<Omit<AircraftModel, 'id'>[]>(
    existingPackage?.aircraft || []
  );
  const [newAircraftName, setNewAircraftName] = useState('');
  const [newAircraftManufacturer, setNewAircraftManufacturer] = useState('');

  const isEditing = existingPackage !== null;

  const handleAddAircraft = () => {
    if (!newAircraftName.trim()) return;
    setAircraft([...aircraft, {
      name: newAircraftName.trim(),
      manufacturer: newAircraftManufacturer.trim() || 'Unknown'
    }]);
    setNewAircraftName('');
    setNewAircraftManufacturer('');
  };

  const handleRemoveAircraft = (index: number) => {
    setAircraft(aircraft.filter((_, i) => i !== index));
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleAddAircraft();
    }
  };

  const handleSave = () => {
    if (!name.trim()) return;
    onSave({
      name: name.trim(),
      description: description.trim(),
      aircraft
    });
  };

  const canSave = name.trim() && aircraft.length > 0;

  return (
    <div className="fixed inset-0 bg-[#08090a]/80 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
      <div className="bg-[#0d0e10] border border-white/[0.1] rounded-xl shadow-2xl max-w-2xl w-full max-h-[85vh] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-white/[0.08]">
          <div className="flex items-center gap-3">
            <button
              onClick={onCancel}
              className="p-2 text-[#6b7280] hover:text-white transition-colors hover:bg-white/[0.05] rounded-lg"
            >
              <ArrowLeft size={18} />
            </button>
            <div>
              <h2 className="text-lg font-semibold text-[#e8e8e8]">
                {isEditing ? 'Edit Package' : 'Create New Package'}
              </h2>
              <p className="text-xs text-[#6b7280] mt-0.5">
                {isEditing ? 'Modify your custom aircraft package' : 'Build a new collection of aircraft'}
              </p>
            </div>
          </div>
          <button
            onClick={onCancel}
            className="text-[#6b7280] hover:text-white transition-colors p-1"
          >
            <X size={20} />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 custom-scrollbar">
          {/* Package Info */}
          <div className="space-y-4 mb-6">
            <div>
              <label className="block text-xs font-semibold text-[#6b7280] mb-1.5 uppercase">
                Package Name *
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g., My Regional Jets"
                className="w-full bg-[#141517] border border-white/[0.1] rounded-md p-3 text-[#e8e8e8] focus:border-[#5e6ad2] outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-[#6b7280] mb-1.5 uppercase">
                Description
              </label>
              <input
                type="text"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="e.g., Common regional jet aircraft for our facility"
                className="w-full bg-[#141517] border border-white/[0.1] rounded-md p-3 text-[#e8e8e8] focus:border-[#5e6ad2] outline-none"
              />
            </div>
          </div>

          {/* Aircraft List */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <label className="text-xs font-semibold text-[#6b7280] uppercase">
                Aircraft in Package ({aircraft.length})
              </label>
            </div>

            {/* Add Aircraft Input */}
            <div className="flex gap-2 mb-4">
              <input
                type="text"
                value={newAircraftName}
                onChange={(e) => setNewAircraftName(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Aircraft name"
                className="flex-1 bg-[#141517] border border-white/[0.1] rounded-md p-2.5 text-[#e8e8e8] focus:border-[#5e6ad2] outline-none text-sm"
              />
              <input
                type="text"
                value={newAircraftManufacturer}
                onChange={(e) => setNewAircraftManufacturer(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Manufacturer"
                className="w-40 bg-[#141517] border border-white/[0.1] rounded-md p-2.5 text-[#e8e8e8] focus:border-[#5e6ad2] outline-none text-sm"
              />
              <button
                onClick={handleAddAircraft}
                disabled={!newAircraftName.trim()}
                className="px-4 py-2.5 bg-violet-500 hover:bg-violet-400 disabled:opacity-50 disabled:cursor-not-allowed text-white font-semibold rounded-md transition-colors flex items-center gap-1.5 text-sm"
              >
                <Plus size={16} /> Add
              </button>
            </div>

            {/* Aircraft List */}
            {aircraft.length === 0 ? (
              <div className="bg-[#141517] border border-white/[0.06] border-dashed rounded-lg p-8 text-center">
                <Package size={32} className="text-[#4b5563] mx-auto mb-3" />
                <p className="text-sm text-[#6b7280]">No aircraft added yet</p>
                <p className="text-xs text-[#4b5563] mt-1">
                  Add aircraft to your package using the input above
                </p>
              </div>
            ) : (
              <div className="bg-[#141517] border border-white/[0.06] rounded-lg p-3 max-h-64 overflow-y-auto custom-scrollbar">
                <div className="space-y-1.5">
                  {aircraft.map((a, idx) => (
                    <div
                      key={idx}
                      className="flex items-center justify-between bg-[#0d0e10] px-3 py-2 rounded-md group"
                    >
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-[#e8e8e8]">{a.name}</span>
                        <span className="text-xs text-[#6b7280]">• {a.manufacturer}</span>
                      </div>
                      <button
                        onClick={() => handleRemoveAircraft(idx)}
                        className="text-[#4b5563] hover:text-[#c4626a] transition-colors opacity-0 group-hover:opacity-100"
                        title="Remove aircraft"
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between p-5 border-t border-white/[0.08] bg-[#0a0b0c]">
          <div className="text-xs text-[#6b7280]">
            {aircraft.length === 0 ? (
              <span className="text-amber-400">Add at least one aircraft to save</span>
            ) : (
              <span>{aircraft.length} aircraft in package</span>
            )}
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={onCancel}
              className="px-4 py-2 text-sm font-semibold text-[#9ca3af] hover:text-white transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleSave}
              disabled={!canSave}
              className="px-5 py-2 text-sm font-semibold bg-[#5e6ad2] hover:bg-[#7b86e0] disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-md transition-colors"
            >
              {isEditing ? 'Save Changes' : 'Create Package'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AircraftPackageEditor;
