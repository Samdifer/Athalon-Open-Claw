import React, { useState } from 'react';
import { X, Package, Plus, Trash2, Edit2, Lock, ChevronRight } from 'lucide-react';
import { AircraftPackage, AircraftModel } from '../types';
import { generateUUID } from '../utils';
import AircraftPackageEditor from './AircraftPackageEditor';

interface AircraftPackageManagerProps {
  builtInPackages: AircraftPackage[];
  customPackages: AircraftPackage[];
  onUpdateCustomPackages: (packages: AircraftPackage[]) => void;
  onClose: () => void;
}

const AircraftPackageManager: React.FC<AircraftPackageManagerProps> = ({
  builtInPackages,
  customPackages,
  onUpdateCustomPackages,
  onClose
}) => {
  const [showEditor, setShowEditor] = useState(false);
  const [editingPackage, setEditingPackage] = useState<AircraftPackage | null>(null);
  const [expandedPackageId, setExpandedPackageId] = useState<string | null>(null);

  const handleCreatePackage = () => {
    setEditingPackage(null);
    setShowEditor(true);
  };

  const handleEditPackage = (pkg: AircraftPackage) => {
    setEditingPackage(pkg);
    setShowEditor(true);
  };

  const handleDeletePackage = (id: string) => {
    const updated = customPackages.filter(p => p.id !== id);
    onUpdateCustomPackages(updated);
  };

  const handleSavePackage = (pkg: Omit<AircraftPackage, 'id' | 'isBuiltIn'>) => {
    if (editingPackage) {
      // Update existing
      const updated = customPackages.map(p =>
        p.id === editingPackage.id ? { ...p, ...pkg } : p
      );
      onUpdateCustomPackages(updated);
    } else {
      // Create new
      const newPackage: AircraftPackage = {
        id: generateUUID(),
        isBuiltIn: false,
        ...pkg
      };
      onUpdateCustomPackages([...customPackages, newPackage]);
    }
    setShowEditor(false);
    setEditingPackage(null);
  };

  const handleCancelEditor = () => {
    setShowEditor(false);
    setEditingPackage(null);
  };

  const toggleExpanded = (id: string) => {
    setExpandedPackageId(prev => prev === id ? null : id);
  };

  if (showEditor) {
    return (
      <AircraftPackageEditor
        package={editingPackage}
        onSave={handleSavePackage}
        onCancel={handleCancelEditor}
      />
    );
  }

  return (
    <div className="fixed inset-0 bg-[#08090a]/80 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
      <div className="bg-[#0d0e10] border border-white/[0.1] rounded-xl shadow-2xl max-w-3xl w-full max-h-[85vh] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-white/[0.08]">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-violet-500/10 rounded-lg">
              <Package size={20} className="text-violet-400" />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-[#e8e8e8]">Manage Aircraft Packages</h2>
              <p className="text-xs text-[#6b7280] mt-0.5">
                View built-in packages or create your own custom packages
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-[#6b7280] hover:text-white transition-colors p-1"
          >
            <X size={20} />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 custom-scrollbar">
          {/* Built-in Packages */}
          <div className="mb-8">
            <h3 className="text-sm font-semibold text-[#6b7280] uppercase tracking-wide mb-3 flex items-center gap-2">
              <Lock size={12} /> Built-in Packages
            </h3>
            <div className="space-y-2">
              {builtInPackages.map(pkg => (
                <div key={pkg.id} className="bg-[#141517] border border-white/[0.06] rounded-lg overflow-hidden">
                  <button
                    onClick={() => toggleExpanded(pkg.id)}
                    className="w-full flex items-center justify-between p-4 text-left hover:bg-[#1a1b1e] transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <ChevronRight
                        size={16}
                        className={`text-[#6b7280] transition-transform ${expandedPackageId === pkg.id ? 'rotate-90' : ''}`}
                      />
                      <div>
                        <div className="font-semibold text-[#e8e8e8]">{pkg.name}</div>
                        <div className="text-xs text-[#6b7280] mt-0.5">{pkg.description}</div>
                      </div>
                    </div>
                    <span className="text-xs bg-[#0d0e10] text-[#9ca3af] px-2.5 py-1 rounded-full font-semibold">
                      {pkg.aircraft.length} aircraft
                    </span>
                  </button>
                  {expandedPackageId === pkg.id && (
                    <div className="px-4 pb-4 pt-0">
                      <div className="bg-[#0d0e10] rounded-lg p-3 max-h-48 overflow-y-auto custom-scrollbar">
                        <div className="grid grid-cols-2 gap-1.5">
                          {pkg.aircraft.map((a, idx) => (
                            <div key={idx} className="text-xs text-[#9ca3af] px-2 py-1.5 bg-[#141517] rounded truncate">
                              {a.name}
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Custom Packages */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-semibold text-[#6b7280] uppercase tracking-wide">
                Custom Packages
              </h3>
              <button
                onClick={handleCreatePackage}
                className="text-xs bg-violet-500 hover:bg-violet-400 text-white font-semibold px-3 py-1.5 rounded-md transition-colors flex items-center gap-1.5"
              >
                <Plus size={14} /> New Package
              </button>
            </div>

            {customPackages.length === 0 ? (
              <div className="bg-[#141517] border border-white/[0.06] border-dashed rounded-lg p-8 text-center">
                <Package size={32} className="text-[#4b5563] mx-auto mb-3" />
                <p className="text-sm text-[#6b7280]">No custom packages yet</p>
                <p className="text-xs text-[#4b5563] mt-1">
                  Create a package to save your own aircraft collections
                </p>
              </div>
            ) : (
              <div className="space-y-2">
                {customPackages.map(pkg => (
                  <div key={pkg.id} className="bg-[#141517] border border-white/[0.06] rounded-lg overflow-hidden">
                    <div className="flex items-center justify-between p-4">
                      <button
                        onClick={() => toggleExpanded(pkg.id)}
                        className="flex items-center gap-3 text-left flex-1"
                      >
                        <ChevronRight
                          size={16}
                          className={`text-[#6b7280] transition-transform ${expandedPackageId === pkg.id ? 'rotate-90' : ''}`}
                        />
                        <div>
                          <div className="font-semibold text-[#e8e8e8]">{pkg.name}</div>
                          <div className="text-xs text-[#6b7280] mt-0.5">{pkg.description}</div>
                        </div>
                      </button>
                      <div className="flex items-center gap-2">
                        <span className="text-xs bg-violet-500/20 text-violet-300 px-2.5 py-1 rounded-full font-semibold">
                          {pkg.aircraft.length} aircraft
                        </span>
                        <button
                          onClick={() => handleEditPackage(pkg)}
                          className="p-2 text-[#6b7280] hover:text-[#6e79d6] transition-colors"
                          title="Edit package"
                        >
                          <Edit2 size={14} />
                        </button>
                        <button
                          onClick={() => handleDeletePackage(pkg.id)}
                          className="p-2 text-[#6b7280] hover:text-[#c4626a] transition-colors"
                          title="Delete package"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </div>
                    {expandedPackageId === pkg.id && (
                      <div className="px-4 pb-4 pt-0">
                        <div className="bg-[#0d0e10] rounded-lg p-3 max-h-48 overflow-y-auto custom-scrollbar">
                          <div className="grid grid-cols-2 gap-1.5">
                            {pkg.aircraft.map((a, idx) => (
                              <div key={idx} className="text-xs text-[#9ca3af] px-2 py-1.5 bg-[#141517] rounded truncate">
                                {a.name}
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end p-5 border-t border-white/[0.08] bg-[#0a0b0c]">
          <button
            onClick={onClose}
            className="px-5 py-2 text-sm font-semibold bg-[#1a1b1e] hover:bg-[#222326] border border-white/[0.1] text-[#e8e8e8] rounded-md transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

export default AircraftPackageManager;
