
import React, { useState } from 'react';
import { GameState, ScheduledJob, Job } from '../types';
import { X, Maximize2, ZoomIn, ZoomOut } from 'lucide-react';
import GanttBoard from './GanttBoard';

interface FullScreenDashboardProps {
  gameState: GameState;
  onClose: () => void;
  onJobClick: (job: Job | ScheduledJob) => void;
}

const FullScreenDashboard: React.FC<FullScreenDashboardProps> = ({ gameState, onClose, onJobClick }) => {
  const [cellWidth, setCellWidth] = useState(60); // Wider default for dashboard visibility

  return (
    <div className="fixed inset-0 bg-[#08090a] z-[200] flex flex-col">
      {/* Simple Header */}
      <div className="h-14 bg-[#0d0e10] border-b border-white/[0.06] flex justify-between items-center px-6 shrink-0">
         <div className="flex items-center gap-3">
             <Maximize2 className="text-indigo-400" size={20} />
             <h1 className="text-lg font-semibold text-white">Operations Dashboard</h1>
         </div>

         <div className="flex items-center gap-4">
             <div className="flex bg-[#141517] rounded-lg p-1 border border-white/[0.08]">
                 <button onClick={() => setCellWidth(Math.max(10, cellWidth - 10))} className="p-2 hover:bg-[#1a1b1e] text-[#9ca3af] rounded-md transition-colors"><ZoomOut size={18}/></button>
                 <button onClick={() => setCellWidth(Math.min(200, cellWidth + 10))} className="p-2 hover:bg-[#1a1b1e] text-[#9ca3af] rounded-md transition-colors"><ZoomIn size={18}/></button>
             </div>
             <button
                 onClick={onClose}
                 className="p-2 bg-[#141517] hover:bg-rose-500/10 text-[#9ca3af] hover:text-white border border-white/[0.08] hover:border-rose-500/30 rounded-lg transition-colors"
             >
                 <X size={24} />
             </button>
         </div>
      </div>

      {/* Main Content - Just the Board */}
      <div className="flex-1 overflow-hidden relative bg-[#08090a]">
         <GanttBoard 
             gameState={gameState}
             cellWidth={cellWidth}
             onZoomChange={setCellWidth}
             onJobDrop={() => {}} 
             onJobClick={onJobClick}
             onDayClick={() => {}}
             scheduleEditMode={false}
             onJobDayToggle={() => {}}
             onVisibleDateRangeChange={() => {}}
             scrollToTodayTrigger={Date.now()} 
             onScroll={() => {}}
             onDragStart={() => {}}
             onDragEnd={() => {}}
             // Dashboard typically shows everything
             selectedBaseId="ALL" 
         />
      </div>
    </div>
  );
};

export default React.memo(FullScreenDashboard);
