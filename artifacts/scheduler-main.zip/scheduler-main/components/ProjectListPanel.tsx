import React, { useState, useMemo } from 'react';
import { ChevronUp, ChevronDown, Download, FileText, Filter } from 'lucide-react';
import { GameState, ScheduledJob } from '../types';
import { formatDateShort, HOURLY_COST_AVG } from '../constants';

interface ProjectListPanelProps {
  gameState: GameState;
  selectedBaseId: string | null;
}

type SortColumn = 'startDate' | 'endDate' | 'customer' | 'aircraft' | 'hangar' | 'status' | 'hours' | 'laborRev' | 'partsRev' | 'totalRev' | 'profit' | 'margin';
type SortDirection = 'asc' | 'desc';

const ProjectListPanel: React.FC<ProjectListPanelProps> = ({ gameState, selectedBaseId }) => {
  const [sortColumn, setSortColumn] = useState<SortColumn>('startDate');
  const [sortDirection, setSortDirection] = useState<SortDirection>('asc');
  const [filterHangar, setFilterHangar] = useState<string>('ALL');
  const [filterAircraftType, setFilterAircraftType] = useState<string>('ALL');
  const [filterBase, setFilterBase] = useState<string>(selectedBaseId || 'ALL');

  // Get lookup maps
  const hangarMap = useMemo(() => {
    const map: Record<string, { name: string; baseId: string }> = {};
    gameState.hangars.forEach(h => { map[h.id] = { name: h.name, baseId: h.baseId }; });
    return map;
  }, [gameState.hangars]);

  const aircraftMap = useMemo(() => {
    const map: Record<string, string> = {};
    gameState.aircraftModels.forEach(a => { map[a.id] = a.name; });
    return map;
  }, [gameState.aircraftModels]);

  const baseMap = useMemo(() => {
    const map: Record<string, string> = {};
    gameState.bases.forEach(b => { map[b.id] = b.name; });
    return map;
  }, [gameState.bases]);

  // Calculate derived values for each job
  const jobsWithCalculations = useMemo(() => {
    return gameState.schedule.map(job => {
      const totalRev = job.revenue + (job.partsRevenue || 0);
      const laborCost = job.estimatedHours * HOURLY_COST_AVG;
      const profit = totalRev - laborCost;
      const margin = totalRev > 0 ? (profit / totalRev) * 100 : 0;
      const endDate = job.startDate + job.deadlineDays;
      const hangarInfo = hangarMap[job.hangarId] || { name: 'Unknown', baseId: '' };
      const aircraftName = aircraftMap[job.aircraftType] || job.aircraftType;

      return {
        ...job,
        endDate,
        totalRev,
        laborCost,
        profit,
        margin,
        hangarName: hangarInfo.name,
        hangarBaseId: hangarInfo.baseId,
        aircraftName,
      };
    });
  }, [gameState.schedule, hangarMap, aircraftMap]);

  // Filter jobs
  const filteredJobs = useMemo(() => {
    return jobsWithCalculations.filter(job => {
      if (filterBase !== 'ALL' && job.hangarBaseId !== filterBase) return false;
      if (filterHangar !== 'ALL' && job.hangarId !== filterHangar) return false;
      if (filterAircraftType !== 'ALL' && job.aircraftType !== filterAircraftType) return false;
      return true;
    });
  }, [jobsWithCalculations, filterBase, filterHangar, filterAircraftType]);

  // Sort jobs
  const sortedJobs = useMemo(() => {
    const sorted = [...filteredJobs].sort((a, b) => {
      let aVal: string | number = 0;
      let bVal: string | number = 0;

      switch (sortColumn) {
        case 'startDate': aVal = a.startDate; bVal = b.startDate; break;
        case 'endDate': aVal = a.endDate; bVal = b.endDate; break;
        case 'customer': aVal = a.customer; bVal = b.customer; break;
        case 'aircraft': aVal = a.aircraftName; bVal = b.aircraftName; break;
        case 'hangar': aVal = a.hangarName; bVal = b.hangarName; break;
        case 'status': aVal = a.status; bVal = b.status; break;
        case 'hours': aVal = a.estimatedHours; bVal = b.estimatedHours; break;
        case 'laborRev': aVal = a.revenue; bVal = b.revenue; break;
        case 'partsRev': aVal = a.partsRevenue || 0; bVal = b.partsRevenue || 0; break;
        case 'totalRev': aVal = a.totalRev; bVal = b.totalRev; break;
        case 'profit': aVal = a.profit; bVal = b.profit; break;
        case 'margin': aVal = a.margin; bVal = b.margin; break;
      }

      if (typeof aVal === 'string') {
        return sortDirection === 'asc' ? aVal.localeCompare(bVal as string) : (bVal as string).localeCompare(aVal);
      }
      return sortDirection === 'asc' ? (aVal as number) - (bVal as number) : (bVal as number) - (aVal as number);
    });
    return sorted;
  }, [filteredJobs, sortColumn, sortDirection]);

  // Calculate totals
  const totals = useMemo(() => {
    return sortedJobs.reduce((acc, job) => ({
      hours: acc.hours + job.estimatedHours,
      laborRev: acc.laborRev + job.revenue,
      partsRev: acc.partsRev + (job.partsRevenue || 0),
      totalRev: acc.totalRev + job.totalRev,
      profit: acc.profit + job.profit,
    }), { hours: 0, laborRev: 0, partsRev: 0, totalRev: 0, profit: 0 });
  }, [sortedJobs]);

  const avgMargin = totals.totalRev > 0 ? (totals.profit / totals.totalRev) * 100 : 0;

  // Get unique values for filters
  const availableHangars = useMemo(() => {
    if (filterBase === 'ALL') return gameState.hangars;
    return gameState.hangars.filter(h => h.baseId === filterBase);
  }, [gameState.hangars, filterBase]);

  const availableAircraftTypes = useMemo(() => {
    const types = new Set(gameState.schedule.map(j => j.aircraftType));
    return gameState.aircraftModels.filter(a => types.has(a.id));
  }, [gameState.schedule, gameState.aircraftModels]);

  // Sort handler
  const handleSort = (column: SortColumn) => {
    if (sortColumn === column) {
      setSortDirection(prev => prev === 'asc' ? 'desc' : 'asc');
    } else {
      setSortColumn(column);
      setSortDirection('asc');
    }
  };

  // Export CSV
  const exportCSV = () => {
    const headers = ['Start Date', 'End Date', 'Customer', 'Aircraft', 'Description', 'Hangar', 'Base', 'Status', 'Labor Hrs', 'Labor Rev', 'Parts Rev', 'Total Rev', 'Profit', 'Margin %'];
    const rows = sortedJobs.map(job => [
      formatDateShort(job.startDate),
      formatDateShort(job.endDate),
      job.customer,
      job.aircraftName,
      `"${job.description.replace(/"/g, '""')}"`,
      job.hangarName,
      baseMap[job.hangarBaseId] || '',
      job.status,
      job.estimatedHours.toFixed(1),
      job.revenue.toFixed(2),
      (job.partsRevenue || 0).toFixed(2),
      job.totalRev.toFixed(2),
      job.profit.toFixed(2),
      job.margin.toFixed(1),
    ]);

    // Add totals row
    rows.push([
      'TOTALS', '', '', '', '', '', '', '',
      totals.hours.toFixed(1),
      totals.laborRev.toFixed(2),
      totals.partsRev.toFixed(2),
      totals.totalRev.toFixed(2),
      totals.profit.toFixed(2),
      avgMargin.toFixed(1),
    ]);

    const csv = [headers.join(','), ...rows.map(row => row.join(','))].join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `project-list-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Export PDF (via print)
  const exportPDF = () => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    const tableRows = sortedJobs.map(job => `
      <tr>
        <td>${formatDateShort(job.startDate)}</td>
        <td>${formatDateShort(job.endDate)}</td>
        <td>${job.customer}</td>
        <td>${job.aircraftName}</td>
        <td>${job.description}</td>
        <td>${job.hangarName}</td>
        <td>${job.status}</td>
        <td style="text-align:right">${job.estimatedHours.toFixed(1)}</td>
        <td style="text-align:right">$${job.revenue.toLocaleString()}</td>
        <td style="text-align:right">$${(job.partsRevenue || 0).toLocaleString()}</td>
        <td style="text-align:right">$${job.totalRev.toLocaleString()}</td>
        <td style="text-align:right">$${job.profit.toLocaleString()}</td>
        <td style="text-align:right">${job.margin.toFixed(1)}%</td>
      </tr>
    `).join('');

    printWindow.document.write(`
      <html>
        <head>
          <title>Project List - ${new Date().toLocaleDateString()}</title>
          <style>
            body { font-family: Arial, sans-serif; font-size: 9px; margin: 20px; }
            h1 { font-size: 16px; margin-bottom: 10px; }
            table { border-collapse: collapse; width: 100%; }
            th, td { border: 1px solid #333; padding: 4px 6px; }
            th { background: #1e293b; color: white; text-align: left; }
            tr:nth-child(even) { background: #f8fafc; }
            .totals { font-weight: bold; background: #e2e8f0 !important; }
            @media print { body { margin: 0; } }
          </style>
        </head>
        <body>
          <h1>Project List Report</h1>
          <p>Generated: ${new Date().toLocaleString()} | Projects: ${sortedJobs.length}</p>
          <table>
            <thead>
              <tr>
                <th>Start</th>
                <th>End</th>
                <th>Customer</th>
                <th>Aircraft</th>
                <th>Description</th>
                <th>Hangar</th>
                <th>Status</th>
                <th>Hours</th>
                <th>Labor Rev</th>
                <th>Parts Rev</th>
                <th>Total Rev</th>
                <th>Profit</th>
                <th>Margin</th>
              </tr>
            </thead>
            <tbody>
              ${tableRows}
              <tr class="totals">
                <td colspan="7">TOTALS</td>
                <td style="text-align:right">${totals.hours.toFixed(1)}</td>
                <td style="text-align:right">$${totals.laborRev.toLocaleString()}</td>
                <td style="text-align:right">$${totals.partsRev.toLocaleString()}</td>
                <td style="text-align:right">$${totals.totalRev.toLocaleString()}</td>
                <td style="text-align:right">$${totals.profit.toLocaleString()}</td>
                <td style="text-align:right">${avgMargin.toFixed(1)}%</td>
              </tr>
            </tbody>
          </table>
        </body>
      </html>
    `);
    printWindow.document.close();
    printWindow.print();
  };

  const SortIcon = ({ column }: { column: SortColumn }) => {
    if (sortColumn !== column) return <ChevronUp className="w-3 h-3 opacity-30" />;
    return sortDirection === 'asc'
      ? <ChevronUp className="w-3 h-3 text-indigo-400" />
      : <ChevronDown className="w-3 h-3 text-indigo-400" />;
  };

  const formatCurrency = (val: number) => `$${val.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`;

  return (
    <div className="flex flex-col h-full bg-[#0d0e10] text-[#e8e8e8]">
      {/* Filter Bar */}
      <div className="flex items-center gap-4 p-3 bg-[#141517] border-b border-white/[0.06]">
        <Filter className="w-4 h-4 text-[#6b7280]" />

        <div className="flex items-center gap-2">
          <label className="text-xs text-[#6b7280]">Base:</label>
          <select
            value={filterBase}
            onChange={(e) => { setFilterBase(e.target.value); setFilterHangar('ALL'); }}
            className="bg-[#1a1b1e] text-[#e8e8e8] text-xs px-2 py-1 rounded border border-white/[0.08] focus:border-indigo-500 focus:outline-none"
          >
            <option value="ALL">All Bases</option>
            {gameState.bases.map(b => (
              <option key={b.id} value={b.id}>{b.name}</option>
            ))}
          </select>
        </div>

        <div className="flex items-center gap-2">
          <label className="text-xs text-[#6b7280]">Hangar:</label>
          <select
            value={filterHangar}
            onChange={(e) => setFilterHangar(e.target.value)}
            className="bg-[#1a1b1e] text-[#e8e8e8] text-xs px-2 py-1 rounded border border-white/[0.08] focus:border-indigo-500 focus:outline-none"
          >
            <option value="ALL">All Hangars</option>
            {availableHangars.map(h => (
              <option key={h.id} value={h.id}>{h.name}</option>
            ))}
          </select>
        </div>

        <div className="flex items-center gap-2">
          <label className="text-xs text-[#6b7280]">Aircraft:</label>
          <select
            value={filterAircraftType}
            onChange={(e) => setFilterAircraftType(e.target.value)}
            className="bg-[#1a1b1e] text-[#e8e8e8] text-xs px-2 py-1 rounded border border-white/[0.08] focus:border-indigo-500 focus:outline-none"
          >
            <option value="ALL">All Types</option>
            {availableAircraftTypes.map(a => (
              <option key={a.id} value={a.id}>{a.name}</option>
            ))}
          </select>
        </div>

        <div className="flex-1" />

        <span className="text-xs text-[#6b7280]">{sortedJobs.length} projects</span>

        <button
          onClick={exportCSV}
          className="flex items-center gap-1 px-2 py-1 text-xs bg-[#1a1b1e] hover:bg-white/[0.08] text-[#9ca3af] hover:text-[#e8e8e8] rounded border border-white/[0.08] transition-colors"
        >
          <Download className="w-3 h-3" /> CSV
        </button>

        <button
          onClick={exportPDF}
          className="flex items-center gap-1 px-2 py-1 text-xs bg-[#1a1b1e] hover:bg-white/[0.08] text-[#9ca3af] hover:text-[#e8e8e8] rounded border border-white/[0.08] transition-colors"
        >
          <FileText className="w-3 h-3" /> PDF
        </button>
      </div>

      {/* Table */}
      <div className="flex-1 overflow-auto bg-[#08090a]">
        <table className="w-full text-xs">
          <thead className="sticky top-0 bg-[#141517] z-10">
            <tr>
              <th className="px-2 py-2 text-left cursor-pointer hover:bg-white/[0.04] text-[#9ca3af] font-medium" onClick={() => handleSort('startDate')}>
                <div className="flex items-center gap-1">Start <SortIcon column="startDate" /></div>
              </th>
              <th className="px-2 py-2 text-left cursor-pointer hover:bg-white/[0.04] text-[#9ca3af] font-medium" onClick={() => handleSort('endDate')}>
                <div className="flex items-center gap-1">End <SortIcon column="endDate" /></div>
              </th>
              <th className="px-2 py-2 text-left cursor-pointer hover:bg-white/[0.04] text-[#9ca3af] font-medium" onClick={() => handleSort('customer')}>
                <div className="flex items-center gap-1">Customer <SortIcon column="customer" /></div>
              </th>
              <th className="px-2 py-2 text-left cursor-pointer hover:bg-white/[0.04] text-[#9ca3af] font-medium" onClick={() => handleSort('aircraft')}>
                <div className="flex items-center gap-1">Aircraft <SortIcon column="aircraft" /></div>
              </th>
              <th className="px-2 py-2 text-left text-[#9ca3af] font-medium">Description</th>
              <th className="px-2 py-2 text-left cursor-pointer hover:bg-white/[0.04] text-[#9ca3af] font-medium" onClick={() => handleSort('hangar')}>
                <div className="flex items-center gap-1">Hangar <SortIcon column="hangar" /></div>
              </th>
              <th className="px-2 py-2 text-left cursor-pointer hover:bg-white/[0.04] text-[#9ca3af] font-medium" onClick={() => handleSort('status')}>
                <div className="flex items-center gap-1">Status <SortIcon column="status" /></div>
              </th>
              <th className="px-2 py-2 text-right cursor-pointer hover:bg-white/[0.04] text-[#9ca3af] font-medium" onClick={() => handleSort('hours')}>
                <div className="flex items-center justify-end gap-1">Hours <SortIcon column="hours" /></div>
              </th>
              <th className="px-2 py-2 text-right cursor-pointer hover:bg-white/[0.04] text-[#9ca3af] font-medium" onClick={() => handleSort('laborRev')}>
                <div className="flex items-center justify-end gap-1">Labor Rev <SortIcon column="laborRev" /></div>
              </th>
              <th className="px-2 py-2 text-right cursor-pointer hover:bg-white/[0.04] text-[#9ca3af] font-medium" onClick={() => handleSort('partsRev')}>
                <div className="flex items-center justify-end gap-1">Parts Rev <SortIcon column="partsRev" /></div>
              </th>
              <th className="px-2 py-2 text-right cursor-pointer hover:bg-white/[0.04] text-[#9ca3af] font-medium" onClick={() => handleSort('totalRev')}>
                <div className="flex items-center justify-end gap-1">Total Rev <SortIcon column="totalRev" /></div>
              </th>
              <th className="px-2 py-2 text-right cursor-pointer hover:bg-white/[0.04] text-[#9ca3af] font-medium" onClick={() => handleSort('profit')}>
                <div className="flex items-center justify-end gap-1">Profit <SortIcon column="profit" /></div>
              </th>
              <th className="px-2 py-2 text-right cursor-pointer hover:bg-white/[0.04] text-[#9ca3af] font-medium" onClick={() => handleSort('margin')}>
                <div className="flex items-center justify-end gap-1">Margin <SortIcon column="margin" /></div>
              </th>
            </tr>
          </thead>
          <tbody>
            {sortedJobs.map((job, idx) => (
              <tr key={job.id} className={`border-t border-white/[0.04] hover:bg-white/[0.03] ${idx % 2 === 0 ? 'bg-[#0d0e10]' : 'bg-[#0a0b0c]'}`}>
                <td className="px-2 py-1.5 text-[#9ca3af]">{formatDateShort(job.startDate)}</td>
                <td className="px-2 py-1.5 text-[#9ca3af]">{formatDateShort(job.endDate)}</td>
                <td className="px-2 py-1.5 font-mono text-[#e8e8e8]">{job.customer}</td>
                <td className="px-2 py-1.5 text-[#9ca3af]">{job.aircraftName}</td>
                <td className="px-2 py-1.5 max-w-[200px] truncate text-[#6b7280]" title={job.description}>{job.description}</td>
                <td className="px-2 py-1.5 text-[#9ca3af]">{job.hangarName}</td>
                <td className="px-2 py-1.5">
                  <span className={`px-1.5 py-0.5 rounded text-[10px] font-medium ${
                    job.status === 'Completed' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' :
                    job.status === 'In Progress' ? 'bg-indigo-500/10 text-indigo-400 border border-indigo-500/20' :
                    job.status === 'Late' ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20' :
                    'bg-white/[0.05] text-[#9ca3af] border border-white/[0.08]'
                  }`}>
                    {job.status}
                  </span>
                </td>
                <td className="px-2 py-1.5 text-right font-mono text-[#9ca3af]">{job.estimatedHours.toFixed(1)}</td>
                <td className="px-2 py-1.5 text-right font-mono text-[#9ca3af]">{formatCurrency(job.revenue)}</td>
                <td className="px-2 py-1.5 text-right font-mono text-[#9ca3af]">{formatCurrency(job.partsRevenue || 0)}</td>
                <td className="px-2 py-1.5 text-right font-mono text-[#e8e8e8]">{formatCurrency(job.totalRev)}</td>
                <td className={`px-2 py-1.5 text-right font-mono ${job.profit >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {formatCurrency(job.profit)}
                </td>
                <td className={`px-2 py-1.5 text-right font-mono ${job.margin >= 30 ? 'text-emerald-400' : job.margin >= 15 ? 'text-amber-400' : 'text-rose-400'}`}>
                  {job.margin.toFixed(1)}%
                </td>
              </tr>
            ))}
          </tbody>
          <tfoot className="sticky bottom-0 bg-[#141517] border-t-2 border-indigo-500/50">
            <tr className="font-semibold">
              <td colSpan={7} className="px-2 py-2 text-[#e8e8e8]">TOTALS ({sortedJobs.length} projects)</td>
              <td className="px-2 py-2 text-right font-mono text-[#e8e8e8]">{totals.hours.toFixed(1)}</td>
              <td className="px-2 py-2 text-right font-mono text-[#e8e8e8]">{formatCurrency(totals.laborRev)}</td>
              <td className="px-2 py-2 text-right font-mono text-[#e8e8e8]">{formatCurrency(totals.partsRev)}</td>
              <td className="px-2 py-2 text-right font-mono text-[#e8e8e8]">{formatCurrency(totals.totalRev)}</td>
              <td className={`px-2 py-2 text-right font-mono ${totals.profit >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                {formatCurrency(totals.profit)}
              </td>
              <td className={`px-2 py-2 text-right font-mono ${avgMargin >= 30 ? 'text-emerald-400' : avgMargin >= 15 ? 'text-amber-400' : 'text-rose-400'}`}>
                {avgMargin.toFixed(1)}%
              </td>
            </tr>
          </tfoot>
        </table>
      </div>
    </div>
  );
};

export default ProjectListPanel;
