import React, { useMemo, useState } from 'react';
import { GameState, ScheduledJob } from '../types';
import { TOTAL_DAYS, START_YEAR } from '../constants';
import { X, Users, BatteryCharging, Calendar, AlertTriangle, ChevronLeft, ChevronRight, Lightbulb, ArrowRight } from 'lucide-react';
import { useCapacityData } from '../hooks';

interface UnifiedCapacityDashboardProps {
  gameState: GameState;
  focusedDayIndex: number;
  cellWidth: number;
  selectedBaseId?: string;
  onClose: () => void;
  onJobClick: (job: ScheduledJob) => void;
  onDayChange?: (dayIndex: number) => void;
}

// Date helpers
const getDateForDay = (dayIndex: number) => new Date(START_YEAR, 0, 1 + dayIndex);
const formatDate = (dayIndex: number) => {
  const date = getDateForDay(dayIndex);
  return date.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
};

const UnifiedCapacityDashboard: React.FC<UnifiedCapacityDashboardProps> = ({
  gameState,
  focusedDayIndex,
  selectedBaseId,
  onClose,
  onJobClick,
  onDayChange
}) => {
  const [localFocusedDay, setLocalFocusedDay] = useState(focusedDayIndex);

  const effectiveFocusedDay = onDayChange ? focusedDayIndex : localFocusedDay;
  const setFocusedDay = (day: number) => {
    if (onDayChange) {
      onDayChange(day);
    } else {
      setLocalFocusedDay(day);
    }
  };

  // Use centralized capacity data hook
  const { getRangeData } = useCapacityData(gameState, { baseId: selectedBaseId });

  // Calculate capacity and load for a 7-day window (with date formatting)
  const weekData = useMemo(() => {
    const startDay = effectiveFocusedDay - 3;
    const rangeData = getRangeData(startDay, startDay + 7);

    return rangeData.map(d => {
      const date = getDateForDay(d.dayIndex);
      return {
        ...d,
        date: formatDate(d.dayIndex),
        dayOfWeek: date.toLocaleDateString('en-US', { weekday: 'short' })
      };
    });
  }, [getRangeData, effectiveFocusedDay]);

  // Get today's specific data
  const todayData = weekData.find(d => d.dayIndex === effectiveFocusedDay) || weekData[3];

  // Get active roster for focused day
  const activeRoster = useMemo(() => {
    const dayOfWeek = (effectiveFocusedDay + 1) % 7;
    const isHoliday = gameState.holidays.some(h => h.dayIndex === effectiveFocusedDay && h.enabled);

    if (isHoliday) return [];

    const isGlobal = !selectedBaseId || selectedBaseId === 'ALL';

    return gameState.personnel.filter(p => {
      if (!isGlobal && p.baseId !== selectedBaseId) return false;

      const team = gameState.teams.find(t => t.id === p.teamId);
      if (!team) return false;

      const shift = gameState.shifts.find(s => s.id === team.shiftId);
      if (!shift) return false;

      return shift.days.includes(dayOfWeek);
    }).map(p => {
      const team = gameState.teams.find(t => t.id === p.teamId);
      const role = gameState.roles.find(r => r.id === p.roleId);
      const shift = team ? gameState.shifts.find(s => s.id === team.shiftId) : null;
      return {
        ...p,
        teamName: team?.name || 'Unassigned',
        roleName: role?.name || 'Unknown',
        efficiency: p.efficiencyOverride ?? role?.baseEfficiency ?? 1.0,
        shiftName: shift?.name || 'Unknown'
      };
    });
  }, [gameState, selectedBaseId, effectiveFocusedDay]);

  // Get jobs contributing to focused day's load
  const contributingJobs = useMemo(() => {
    return gameState.schedule
      .filter(job => {
        return effectiveFocusedDay >= job.startDate &&
               effectiveFocusedDay < job.startDate + job.deadlineDays;
      })
      .map(job => {
        const dayOffset = effectiveFocusedDay - job.startDate;
        const isNonWorkDay = job.nonWorkDays?.includes(dayOffset) ?? false;
        const dayEffort = job.dailyEffort?.[dayOffset] ?? 1.0;
        const workingDays = Array.from({ length: job.deadlineDays })
          .filter((_, d) => !(job.nonWorkDays?.includes(d) ?? false))
          .reduce((sum, _, d) => sum + (job.dailyEffort?.[d] ?? 1.0), 0);
        const hoursToday = isNonWorkDay ? 0 : (workingDays > 0 ? (dayEffort / workingDays) * job.estimatedHours : 0);

        return {
          ...job,
          hoursToday,
          isNonWorkDay
        };
      })
      .filter(j => j.hoursToday > 0)
      .sort((a, b) => b.hoursToday - a.hoursToday);
  }, [gameState.schedule, effectiveFocusedDay]);

  // Generate suggestions if overloaded
  const suggestions = useMemo(() => {
    if (!todayData?.isOverloaded) return [];

    const overloadAmount = todayData.load - (todayData.capacity * (1 - (gameState.capacityBufferPercent ?? 15) / 100));
    const results: Array<{ type: string; message: string; impact: string }> = [];

    // Find moveable jobs (not AOG, not started yet from focused day perspective)
    const moveableJobs = contributingJobs
      .filter(j => !j.isAOG && j.startDate >= effectiveFocusedDay)
      .sort((a, b) => a.hoursToday - b.hoursToday);

    if (moveableJobs.length > 0) {
      const job = moveableJobs[0];
      results.push({
        type: 'move',
        message: `Move "${job.customer}" start date by 2+ days`,
        impact: `-${job.hoursToday.toFixed(1)}h from this day`
      });
    }

    // Suggest extending duration for largest job
    const extendableJobs = contributingJobs
      .filter(j => !j.isAOG && j.hoursToday > 4)
      .sort((a, b) => b.hoursToday - a.hoursToday);

    if (extendableJobs.length > 0 && results.length < 2) {
      const job = extendableJobs[0];
      results.push({
        type: 'extend',
        message: `Extend "${job.customer}" duration to spread load`,
        impact: `Reduces daily peak by ~${(job.hoursToday * 0.3).toFixed(1)}h`
      });
    }

    return results;
  }, [todayData, contributingJobs, effectiveFocusedDay, gameState.capacityBufferPercent]);

  // Group roster by team
  const rosterByTeam = useMemo(() => {
    const grouped: Record<string, typeof activeRoster> = {};
    activeRoster.forEach(p => {
      if (!grouped[p.teamName]) grouped[p.teamName] = [];
      grouped[p.teamName].push(p);
    });
    return grouped;
  }, [activeRoster]);

  const isHoliday = gameState.holidays.some(h => h.dayIndex === effectiveFocusedDay && h.enabled);
  const holidayName = gameState.holidays.find(h => h.dayIndex === effectiveFocusedDay && h.enabled)?.name;

  return (
    <div className="h-full flex flex-col bg-[#08090a] text-white overflow-hidden">
      {/* Header */}
      <div className="px-4 py-3 bg-[#141517] border-b border-white/[0.06] flex justify-between items-center shrink-0">
        <div className="flex items-center gap-3">
          <div className="bg-[#0d0e10] p-2 rounded-lg border border-white/[0.08]">
            <BatteryCharging className="text-[#6e79d6]" size={20} />
          </div>
          <div>
            <h2 className="text-sm font-semibold text-white uppercase tracking-wide">Capacity Command Center</h2>
            <p className="text-xs text-[#6b7280]">{formatDate(effectiveFocusedDay)}</p>
          </div>
        </div>
        <button onClick={onClose} className="p-2 hover:bg-[#0d0e10] rounded-lg text-[#6b7280] hover:text-white transition-colors">
          <X size={20} />
        </button>
      </div>

      {/* Day Navigation */}
      <div className="px-4 py-3 bg-[#0d0e10] border-b border-white/[0.06] flex items-center justify-between shrink-0">
        <button
          onClick={() => setFocusedDay(Math.max(0, effectiveFocusedDay - 1))}
          className="p-2 hover:bg-[#141517] rounded-lg text-[#6b7280] hover:text-white transition-colors"
        >
          <ChevronLeft size={20} />
        </button>
        <div className="flex gap-1">
          {weekData.map(day => (
            <button
              key={day.dayIndex}
              onClick={() => setFocusedDay(day.dayIndex)}
              className={`px-3 py-2 rounded-lg text-xs font-medium transition-all ${
                day.dayIndex === effectiveFocusedDay
                  ? 'bg-[#5e6ad2] text-white'
                  : day.isOverloaded
                    ? 'bg-rose-500/10 text-rose-400 hover:bg-rose-500/20'
                    : 'bg-[#141517] text-[#9ca3af] hover:bg-[#1a1b1e] hover:text-white'
              }`}
            >
              <div>{day.dayOfWeek}</div>
              <div className="text-[10px] opacity-70">{day.date.split(',')[0].split(' ')[1]}</div>
            </button>
          ))}
        </div>
        <button
          onClick={() => setFocusedDay(Math.min(TOTAL_DAYS - 1, effectiveFocusedDay + 1))}
          className="p-2 hover:bg-[#141517] rounded-lg text-[#6b7280] hover:text-white transition-colors"
        >
          <ChevronRight size={20} />
        </button>
      </div>

      {/* Holiday Banner */}
      {isHoliday && (
        <div className="px-4 py-2 bg-amber-500/10 border-b border-amber-500/20 text-amber-400 text-sm flex items-center gap-2">
          <Calendar size={16} />
          <span className="font-medium">{holidayName || 'Holiday'}</span>
          <span className="text-amber-400/70">- Shop Closed</span>
        </div>
      )}

      {/* Summary Cards */}
      <div className="flex gap-4 p-4 shrink-0">
        <div className={`flex-1 rounded-lg p-4 border ${
          todayData?.isOverloaded
            ? 'bg-rose-500/10 border-rose-500/20'
            : 'bg-[#141517] border-white/[0.08]'
        }`}>
          <div className="text-[9px] text-[#6b7280] uppercase font-semibold flex items-center gap-1">
            <BatteryCharging size={10} /> Available Capacity
          </div>
          <div className={`text-2xl font-mono font-semibold ${isHoliday ? 'text-[#6b7280]' : 'text-amber-500'}`}>
            {isHoliday ? '0' : Math.round(todayData?.capacity || 0)}h
          </div>
        </div>
        <div className={`flex-1 rounded-lg p-4 border ${
          todayData?.isOverloaded
            ? 'bg-rose-500/10 border-rose-500/20'
            : 'bg-[#141517] border-white/[0.08]'
        }`}>
          <div className="text-[9px] text-[#6b7280] uppercase font-semibold flex items-center gap-1">
            <Calendar size={10} /> Planned Load
          </div>
          <div className={`text-2xl font-mono font-semibold ${
            todayData?.isOverloaded ? 'text-rose-500' : 'text-emerald-500'
          }`}>
            {Math.round(todayData?.load || 0)}h
          </div>
          {todayData?.isOverloaded && (
            <div className="text-xs text-rose-400 mt-1 flex items-center gap-1">
              <AlertTriangle size={10} />
              {Math.round(todayData.utilization)}% utilization
            </div>
          )}
        </div>
        <div className="flex-1 bg-[#141517] rounded-lg p-4 border border-white/[0.08]">
          <div className="text-[9px] text-[#6b7280] uppercase font-semibold flex items-center gap-1">
            <Users size={10} /> Active Staff
          </div>
          <div className="text-2xl font-mono font-semibold text-[#6e79d6]">
            {isHoliday ? '0' : activeRoster.length}
          </div>
        </div>
      </div>

      {/* Main Content Grid */}
      <div className="flex-1 flex min-h-0 gap-4 px-4 pb-4 overflow-hidden">
        {/* Left Column - Capacity Chart & Jobs */}
        <div className="flex-1 flex flex-col gap-4 min-w-0">
          {/* 7-Day Mini Chart */}
          <div className="bg-[#141517] rounded-lg p-4 border border-white/[0.08]">
            <h3 className="text-xs font-semibold text-[#9ca3af] uppercase mb-3">7-Day Capacity Overview</h3>
            <div className="flex gap-2 h-24">
              {weekData.map(day => {
                const maxHeight = Math.max(...weekData.map(d => Math.max(d.capacity, d.load)));
                const capacityHeight = maxHeight > 0 ? (day.capacity / maxHeight) * 100 : 0;
                const loadHeight = maxHeight > 0 ? (day.load / maxHeight) * 100 : 0;
                const bufferLine = capacityHeight * (1 - (gameState.capacityBufferPercent ?? 15) / 100);

                return (
                  <div
                    key={day.dayIndex}
                    className={`flex-1 flex flex-col items-center cursor-pointer hover:bg-white/5 rounded transition-colors ${
                      day.dayIndex === effectiveFocusedDay ? 'bg-white/10' : ''
                    }`}
                    onClick={() => setFocusedDay(day.dayIndex)}
                  >
                    <div className="flex-1 w-full flex items-end gap-0.5 px-1">
                      {/* Capacity bar */}
                      <div
                        className="flex-1 bg-amber-500/30 rounded-t relative"
                        style={{ height: `${capacityHeight}%` }}
                      >
                        {/* Buffer threshold line */}
                        <div
                          className="absolute w-full border-t border-dashed border-amber-500/50"
                          style={{ bottom: `${bufferLine}%` }}
                        />
                      </div>
                      {/* Load bar */}
                      <div
                        className={`flex-1 rounded-t ${
                          day.isOverloaded ? 'bg-rose-500' : 'bg-emerald-500'
                        }`}
                        style={{ height: `${loadHeight}%` }}
                      />
                    </div>
                    <div className={`text-[9px] mt-1 ${
                      day.dayIndex === effectiveFocusedDay ? 'text-white font-semibold' : 'text-[#6b7280]'
                    }`}>
                      {day.dayOfWeek}
                    </div>
                  </div>
                );
              })}
            </div>
            <div className="flex gap-4 mt-3 text-[9px] text-[#6b7280]">
              <div className="flex items-center gap-1">
                <div className="w-3 h-2 bg-amber-500/30 rounded" /> Capacity
              </div>
              <div className="flex items-center gap-1">
                <div className="w-3 h-2 bg-emerald-500 rounded" /> Load (OK)
              </div>
              <div className="flex items-center gap-1">
                <div className="w-3 h-2 bg-rose-500 rounded" /> Load (Over)
              </div>
            </div>
          </div>

          {/* Jobs Contributing */}
          <div className="flex-1 bg-[#141517] rounded-lg p-4 border border-white/[0.08] overflow-hidden flex flex-col">
            <h3 className="text-xs font-semibold text-[#9ca3af] uppercase mb-3">
              Jobs on {formatDate(effectiveFocusedDay)} ({contributingJobs.length})
            </h3>
            <div className="flex-1 overflow-y-auto custom-scrollbar space-y-2">
              {contributingJobs.length === 0 ? (
                <div className="text-sm text-[#6b7280] italic py-4 text-center">
                  {isHoliday ? 'Holiday - No work scheduled' : 'No jobs scheduled for this day'}
                </div>
              ) : (
                contributingJobs.map(job => (
                  <div
                    key={job.id}
                    onClick={() => onJobClick(job)}
                    className={`p-3 rounded-lg border cursor-pointer transition-all hover:border-[#5e6ad2]/50 ${job.color} bg-opacity-20 border-white/10`}
                  >
                    <div className="flex justify-between items-start">
                      <div className="flex-1 min-w-0">
                        <div className="font-semibold text-sm text-white truncate flex items-center gap-1">
                          {job.customer}
                          {job.isAOG && <AlertTriangle size={12} className="text-rose-500" />}
                        </div>
                        <div className="text-xs text-white/70 truncate">{job.description}</div>
                      </div>
                      <div className="text-right shrink-0 ml-2">
                        <div className="text-lg font-mono font-semibold text-white">
                          {job.hoursToday.toFixed(1)}h
                        </div>
                        <div className="text-[9px] text-white/50">
                          of {job.estimatedHours}h total
                        </div>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Suggestions */}
          {suggestions.length > 0 && (
            <div className="bg-amber-500/10 rounded-lg p-4 border border-amber-500/20">
              <h3 className="text-xs font-semibold text-amber-400 uppercase mb-3 flex items-center gap-2">
                <Lightbulb size={14} /> Actionable Insights
              </h3>
              <div className="space-y-2">
                {suggestions.map((suggestion, idx) => (
                  <div key={idx} className="flex items-center gap-3 text-sm">
                    <ArrowRight size={14} className="text-amber-500 shrink-0" />
                    <div className="flex-1">
                      <span className="text-amber-100">{suggestion.message}</span>
                      <span className="text-amber-500/70 ml-2">({suggestion.impact})</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Right Column - Roster */}
        <div className="w-72 bg-[#141517] rounded-lg p-4 border border-white/[0.08] overflow-hidden flex flex-col shrink-0">
          <h3 className="text-xs font-semibold text-[#9ca3af] uppercase mb-3 flex items-center gap-2">
            <Users size={14} /> Active Roster
          </h3>
          {isHoliday ? (
            <div className="text-sm text-[#6b7280] italic py-4 text-center">
              Holiday - No staff scheduled
            </div>
          ) : activeRoster.length === 0 ? (
            <div className="text-sm text-[#6b7280] italic py-4 text-center">
              No staff working this day
            </div>
          ) : (
            <div className="flex-1 overflow-y-auto custom-scrollbar space-y-4">
              {Object.entries(rosterByTeam).map(([teamName, members]) => (
                <div key={teamName}>
                  <div className="text-[10px] text-[#6b7280] uppercase font-semibold mb-2 flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-[#5e6ad2]" />
                    {teamName} ({members.length})
                  </div>
                  <div className="space-y-1">
                    {members.map(person => (
                      <div key={person.id} className="flex items-center justify-between py-1.5 px-2 bg-[#0d0e10] rounded">
                        <div className="min-w-0 flex-1">
                          <div className="text-sm text-white truncate">{person.name}</div>
                          <div className="text-[9px] text-[#6b7280]">{person.roleName}</div>
                        </div>
                        <div className={`text-xs font-mono font-semibold ${
                          person.efficiency >= 1 ? 'text-emerald-500' : 'text-amber-500'
                        }`}>
                          {Math.round(person.efficiency * 100)}%
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default React.memo(UnifiedCapacityDashboard);
