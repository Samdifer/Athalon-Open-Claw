import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import { X, Search, Book, Plane, DollarSign, Users, Calendar, ChevronDown, ChevronRight } from 'lucide-react';
import { GLOSSARY, GlossaryEntry, searchGlossary, getGlossaryByCategory } from '../constants';

export interface GlossaryModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialSearch?: string;
  initialCategory?: GlossaryEntry['category'] | 'all';
}

type CategoryFilter = GlossaryEntry['category'] | 'all';

const categoryConfig: Record<CategoryFilter, { label: string; icon: React.ReactNode; color: string }> = {
  all: { label: 'All Terms', icon: <Book size={14} />, color: 'text-slate-400' },
  aviation: { label: 'Aviation', icon: <Plane size={14} />, color: 'text-cyan-400' },
  financial: { label: 'Financial', icon: <DollarSign size={14} />, color: 'text-emerald-400' },
  personnel: { label: 'Personnel', icon: <Users size={14} />, color: 'text-violet-400' },
  scheduling: { label: 'Scheduling', icon: <Calendar size={14} />, color: 'text-amber-400' },
};

const GlossaryModal: React.FC<GlossaryModalProps> = ({
  isOpen,
  onClose,
  initialSearch = '',
  initialCategory = 'all',
}) => {
  const [searchQuery, setSearchQuery] = useState(initialSearch);
  const [activeCategory, setActiveCategory] = useState<CategoryFilter>(initialCategory);
  const [expandedTerms, setExpandedTerms] = useState<Set<string>>(new Set());
  const searchInputRef = useRef<HTMLInputElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  // Reset state when modal opens
  useEffect(() => {
    if (isOpen) {
      setSearchQuery(initialSearch);
      setActiveCategory(initialCategory);
      setExpandedTerms(new Set());
      // Focus search input after animation
      setTimeout(() => searchInputRef.current?.focus(), 100);
    }
  }, [isOpen, initialSearch, initialCategory]);

  // Handle keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isOpen) return;

      if (e.key === 'Escape') {
        onClose();
      }

      // Cmd/Ctrl + F to focus search
      if ((e.metaKey || e.ctrlKey) && e.key === 'f') {
        e.preventDefault();
        searchInputRef.current?.focus();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  // Filter and group terms
  const filteredTerms = useMemo(() => {
    let terms = Object.values(GLOSSARY);

    // Apply category filter
    if (activeCategory !== 'all') {
      terms = getGlossaryByCategory(activeCategory);
    }

    // Apply search filter
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      terms = terms.filter(
        entry =>
          entry.term.toLowerCase().includes(query) ||
          entry.definition.toLowerCase().includes(query) ||
          (entry.example && entry.example.toLowerCase().includes(query))
      );
    }

    // Sort alphabetically by term
    return terms.sort((a, b) => a.term.localeCompare(b.term));
  }, [activeCategory, searchQuery]);

  // Group terms by first letter for alphabetical index
  const groupedTerms = useMemo(() => {
    const groups: Record<string, GlossaryEntry[]> = {};
    filteredTerms.forEach(term => {
      const firstLetter = term.term.charAt(0).toUpperCase();
      if (!groups[firstLetter]) {
        groups[firstLetter] = [];
      }
      groups[firstLetter].push(term);
    });
    return groups;
  }, [filteredTerms]);

  const availableLetters = useMemo(() => Object.keys(groupedTerms).sort(), [groupedTerms]);

  const toggleTerm = useCallback((termKey: string) => {
    setExpandedTerms(prev => {
      const newSet = new Set(prev);
      if (newSet.has(termKey)) {
        newSet.delete(termKey);
      } else {
        newSet.add(termKey);
      }
      return newSet;
    });
  }, []);

  const scrollToLetter = useCallback((letter: string) => {
    const element = document.getElementById(`glossary-section-${letter}`);
    if (element && contentRef.current) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }, []);

  // Expand all terms when searching
  useEffect(() => {
    if (searchQuery.trim()) {
      const allKeys = filteredTerms.map(t => t.term);
      setExpandedTerms(new Set(allKeys));
    }
  }, [searchQuery, filteredTerms]);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 bg-[#08090a]/80 backdrop-blur-sm z-[100] flex items-center justify-center p-4 animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="bg-[#0d0e10] border border-white/[0.08] rounded-2xl w-full max-w-2xl overflow-hidden flex flex-col max-h-[85vh] relative"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-white/[0.06]">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 bg-[#5e6ad2]/10 rounded-lg flex items-center justify-center">
              <Book size={18} className="text-[#5e6ad2]" />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-[#e8e8e8] tracking-wide">Glossary</h2>
              <p className="text-xs text-slate-500">Aviation & business terms explained</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-500 hover:text-white hover:bg-white/[0.06] rounded-lg transition-colors"
            aria-label="Close glossary"
          >
            <X size={18} />
          </button>
        </div>

        {/* Search Bar */}
        <div className="px-5 py-3 border-b border-white/[0.06]">
          <div className="relative">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
            <input
              ref={searchInputRef}
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search terms..."
              className="w-full bg-[#141517] border border-white/[0.08] rounded-lg pl-10 pr-4 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-[#5e6ad2]/50 focus:ring-1 focus:ring-[#5e6ad2]/30 transition-colors"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white"
              >
                <X size={14} />
              </button>
            )}
          </div>
        </div>

        {/* Category Tabs */}
        <div className="px-5 py-2 border-b border-white/[0.06] flex gap-1 overflow-x-auto scrollbar-hide">
          {(Object.keys(categoryConfig) as CategoryFilter[]).map((cat) => {
            const config = categoryConfig[cat];
            const isActive = activeCategory === cat;
            return (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors ${
                  isActive
                    ? 'bg-[#5e6ad2]/20 text-[#5e6ad2] border border-[#5e6ad2]/30'
                    : 'text-slate-400 hover:text-white hover:bg-white/[0.04]'
                }`}
              >
                <span className={isActive ? 'text-[#5e6ad2]' : config.color}>{config.icon}</span>
                {config.label}
                {cat !== 'all' && (
                  <span className={`ml-1 ${isActive ? 'text-[#5e6ad2]/70' : 'text-slate-600'}`}>
                    {getGlossaryByCategory(cat as GlossaryEntry['category']).length}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Alphabetical Index */}
        {!searchQuery && availableLetters.length > 5 && (
          <div className="px-5 py-2 border-b border-white/[0.06] flex gap-1 flex-wrap">
            {availableLetters.map((letter) => (
              <button
                key={letter}
                onClick={() => scrollToLetter(letter)}
                className="w-6 h-6 rounded text-xs font-medium text-slate-500 hover:text-white hover:bg-white/[0.06] transition-colors"
              >
                {letter}
              </button>
            ))}
          </div>
        )}

        {/* Content */}
        <div ref={contentRef} className="flex-1 overflow-y-auto px-5 py-3">
          {filteredTerms.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <Search size={40} className="text-slate-600 mb-3" />
              <p className="text-slate-400 text-sm">No terms found</p>
              <p className="text-slate-600 text-xs mt-1">Try a different search or category</p>
            </div>
          ) : (
            <>
              {availableLetters.map((letter) => (
                <div key={letter} id={`glossary-section-${letter}`} className="mb-4">
                  {/* Letter Header */}
                  {!searchQuery && (
                    <div className="sticky top-0 bg-[#0d0e10] py-1 z-10">
                      <span className="text-xs font-semibold text-slate-600 uppercase tracking-wider">
                        {letter}
                      </span>
                    </div>
                  )}

                  {/* Terms */}
                  <div className="space-y-1">
                    {groupedTerms[letter].map((entry) => {
                      const isExpanded = expandedTerms.has(entry.term);
                      const config = categoryConfig[entry.category];

                      return (
                        <div
                          key={entry.term}
                          className="rounded-lg border border-transparent hover:border-white/[0.06] transition-colors"
                        >
                          <button
                            onClick={() => toggleTerm(entry.term)}
                            className="w-full flex items-center gap-3 px-3 py-2.5 text-left group"
                          >
                            <span className={`${config.color} transition-colors`}>
                              {isExpanded ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
                            </span>
                            <span className="flex-1 text-sm font-medium text-[#e8e8e8] group-hover:text-white transition-colors">
                              {entry.term}
                            </span>
                            <span className={`text-[10px] uppercase font-medium px-1.5 py-0.5 rounded ${config.color} bg-white/[0.03]`}>
                              {entry.category}
                            </span>
                          </button>

                          {isExpanded && (
                            <div className="px-3 pb-3 pl-9 animate-in slide-in-from-top-1 duration-150">
                              <p className="text-sm text-slate-400 leading-relaxed">
                                {entry.definition}
                              </p>
                              {entry.example && (
                                <div className="mt-2 px-3 py-2 bg-[#141517] rounded-lg border border-white/[0.04]">
                                  <p className="text-xs text-slate-500">
                                    <span className="font-medium text-slate-400">Example:</span>{' '}
                                    {entry.example}
                                  </p>
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              ))}
            </>
          )}
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-white/[0.06] flex items-center justify-between text-xs text-slate-600">
          <span>{filteredTerms.length} term{filteredTerms.length !== 1 ? 's' : ''}</span>
          <div className="flex items-center gap-2">
            <kbd className="px-1.5 py-0.5 bg-[#141517] rounded text-[10px] border border-white/[0.08]">Esc</kbd>
            <span>to close</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default React.memo(GlossaryModal);
