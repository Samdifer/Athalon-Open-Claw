import React from 'react';

export interface BadgeProps {
  variant?: 'default' | 'success' | 'warning' | 'error' | 'info' | 'indigo' | 'violet';
  size?: 'sm' | 'md' | 'lg';
  children: React.ReactNode;
  icon?: React.ReactNode;
  className?: string;
}

const Badge: React.FC<BadgeProps> = ({
  variant = 'default',
  size = 'md',
  children,
  icon,
  className = '',
}) => {
  // Size classes
  const sizeClasses = {
    sm: 'px-2 py-0.5 text-[10px] gap-1',
    md: 'px-2.5 py-1 text-[11px] gap-1.5',
    lg: 'px-3 py-1.5 text-[12px] gap-2',
  };

  // Variant classes (Linear-style muted colors)
  const variantClasses = {
    default: 'bg-white/[0.08] text-[#9ca3af] border-white/[0.08]',
    success: 'bg-emerald-500/8 text-[#3dae6c] border-emerald-500/15',
    warning: 'bg-amber-500/8 text-amber-400 border-amber-500/15',
    error: 'bg-red-500/8 text-[#c4626a] border-red-500/15',
    info: 'bg-zinc-500/8 text-zinc-400 border-zinc-500/15',
    indigo: 'bg-white/[0.06] text-zinc-300 border-white/[0.08]',
    violet: 'bg-[#7c6ebd]/8 text-[#7c6ebd] border-[#7c6ebd]/15',
  };

  const combinedClasses = `
    inline-flex items-center
    font-medium uppercase tracking-wider
    rounded-full border
    ${sizeClasses[size]}
    ${variantClasses[variant]}
    ${className}
  `.replace(/\s+/g, ' ').trim();

  return (
    <span className={combinedClasses}>
      {icon && <span className="flex-shrink-0">{icon}</span>}
      {children}
    </span>
  );
};

// Announcement Badge - special badge with pulsing dot for announcements
export interface AnnouncementBadgeProps {
  children: React.ReactNode;
  icon?: React.ReactNode;
  pulse?: boolean;
  href?: string;
  onClick?: () => void;
  className?: string;
}

export const AnnouncementBadge: React.FC<AnnouncementBadgeProps> = ({
  children,
  icon,
  pulse = true,
  href,
  onClick,
  className = '',
}) => {
  const baseClasses = `
    inline-flex items-center gap-2
    px-3 py-1.5
    rounded-full
    bg-white/[0.04]
    border border-white/[0.08]
    text-zinc-300 text-[11px] font-medium
    transition-colors duration-fast
    hover:bg-white/[0.06] hover:border-white/[0.15]
    cursor-pointer
    group
    ${className}
  `.replace(/\s+/g, ' ').trim();

  const content = (
    <>
      {pulse && (
        <span className="relative flex h-2 w-2">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-500 opacity-50" />
          <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
        </span>
      )}
      {icon && (
        <span className="flex-shrink-0 group-hover:rotate-12 transition-transform duration-moderate">
          {icon}
        </span>
      )}
      <span>{children}</span>
    </>
  );

  if (href) {
    return (
      <a href={href} className={baseClasses} target="_blank" rel="noopener noreferrer">
        {content}
      </a>
    );
  }

  return (
    <button onClick={onClick} className={baseClasses} type="button">
      {content}
    </button>
  );
};

// Status Badge - for job/task status indicators
export interface StatusBadgeProps {
  status: 'wip' | 'authorized' | 'complete' | 'rts' | 'scheduled' | 'pending';
  size?: 'sm' | 'md';
  children?: React.ReactNode;
  className?: string;
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({
  status,
  size = 'md',
  children,
  className = '',
}) => {
  // Muted status colors (Linear-style)
  const statusConfig = {
    wip: {
      bg: 'bg-[#7c6ebd]/8',
      border: 'border-[#7c6ebd]/15',
      text: 'text-[#7c6ebd]',
      dot: 'bg-[#7c6ebd]',
      label: 'WIP',
    },
    authorized: {
      bg: 'bg-[#c4626a]/8',
      border: 'border-[#c4626a]/15',
      text: 'text-[#c4626a]',
      dot: 'bg-[#c4626a]',
      label: 'Authorized',
    },
    complete: {
      bg: 'bg-[#3dae6c]/8',
      border: 'border-[#3dae6c]/15',
      text: 'text-[#3dae6c]',
      dot: 'bg-[#3dae6c]',
      label: 'Complete',
    },
    rts: {
      bg: 'bg-[#4a9da8]/8',
      border: 'border-[#4a9da8]/15',
      text: 'text-[#4a9da8]',
      dot: 'bg-[#4a9da8]',
      label: 'RTS',
    },
    scheduled: {
      bg: 'bg-gray-500/8',
      border: 'border-gray-500/15',
      text: 'text-gray-400',
      dot: 'bg-gray-500',
      label: 'Scheduled',
    },
    pending: {
      bg: 'bg-amber-500/8',
      border: 'border-amber-500/15',
      text: 'text-amber-400',
      dot: 'bg-amber-500',
      label: 'Pending',
    },
  };

  const config = statusConfig[status];
  const sizeClasses = size === 'sm' ? 'px-2 py-0.5 text-[10px]' : 'px-2.5 py-1 text-[11px]';
  const dotSize = size === 'sm' ? 'h-1.5 w-1.5' : 'h-2 w-2';

  return (
    <span
      className={`
        inline-flex items-center gap-1.5
        font-medium uppercase tracking-wider
        rounded-full border
        ${config.bg} ${config.border} ${config.text}
        ${sizeClasses}
        ${className}
      `.replace(/\s+/g, ' ').trim()}
    >
      <span className={`rounded-full ${config.dot} ${dotSize}`} />
      {children || config.label}
    </span>
  );
};

export default Badge;
