import React from 'react';
import { LucideIcon } from 'lucide-react';

export interface EmptyStateProps {
  icon: LucideIcon;
  title: string;
  description: string;
  action?: {
    label: string;
    onClick: () => void;
  };
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

const EmptyState: React.FC<EmptyStateProps> = ({
  icon: Icon,
  title,
  description,
  action,
  size = 'md',
  className = '',
}) => {
  const sizeClasses = {
    sm: {
      container: 'py-6 px-4',
      icon: 16,
      iconWrapper: 'w-8 h-8',
      title: 'text-xs',
      description: 'text-[10px]',
      button: 'text-[10px] px-2 py-1',
    },
    md: {
      container: 'py-10 px-6',
      icon: 24,
      iconWrapper: 'w-12 h-12',
      title: 'text-sm',
      description: 'text-xs',
      button: 'text-xs px-3 py-1.5',
    },
    lg: {
      container: 'py-16 px-8',
      icon: 32,
      iconWrapper: 'w-16 h-16',
      title: 'text-base',
      description: 'text-sm',
      button: 'text-sm px-4 py-2',
    },
  };

  const styles = sizeClasses[size];

  return (
    <div
      className={`flex flex-col items-center justify-center text-center ${styles.container} ${className}`}
      role="status"
      aria-label={`Empty state: ${title}`}
      aria-live="polite"
    >
      <div
        className={`${styles.iconWrapper} rounded-xl bg-[#141517] border border-white/[0.06] flex items-center justify-center mb-3`}
        aria-hidden="true"
      >
        <Icon size={styles.icon} className="text-[#6b7280]" />
      </div>
      <h4 className={`font-medium text-[#e8e8e8] ${styles.title} mb-1`}>
        {title}
      </h4>
      <p className={`text-[#6b7280] ${styles.description} max-w-[240px] leading-relaxed`}>
        {description}
      </p>
      {action && (
        <button
          onClick={action.onClick}
          className={`mt-4 bg-white hover:bg-zinc-100 text-[#09090b] font-medium rounded-lg transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-white/40 focus-visible:ring-offset-2 focus-visible:ring-offset-[#08090a] ${styles.button}`}
        >
          {action.label}
        </button>
      )}
    </div>
  );
};

export default EmptyState;
