import React from 'react';

export interface ContainerProps {
  size?: 'sm' | 'md' | 'lg' | 'xl' | '2xl' | 'full';
  padding?: boolean;
  center?: boolean;
  children: React.ReactNode;
  className?: string;
  as?: keyof JSX.IntrinsicElements;
}

const Container: React.FC<ContainerProps> = ({
  size = 'xl',
  padding = true,
  center = true,
  children,
  className = '',
  as: Component = 'div',
}) => {
  // Max-width based on size
  const sizeClasses = {
    sm: 'max-w-screen-sm',   // 640px
    md: 'max-w-screen-md',   // 768px
    lg: 'max-w-screen-lg',   // 1024px
    xl: 'max-w-screen-xl',   // 1280px
    '2xl': 'max-w-[1400px]', // 1400px (Linear-style wider)
    full: 'max-w-full',
  };

  const combinedClasses = `
    w-full
    ${sizeClasses[size]}
    ${center ? 'mx-auto' : ''}
    ${padding ? 'px-4 sm:px-6 lg:px-8' : ''}
    ${className}
  `.replace(/\s+/g, ' ').trim();

  return <Component className={combinedClasses}>{children}</Component>;
};

export default Container;
