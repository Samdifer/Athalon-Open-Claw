import React, { useState, useRef, useEffect, useCallback } from 'react';
import { HelpCircle } from 'lucide-react';

export interface TooltipProps {
  /** The content to display in the tooltip */
  content: string | React.ReactNode;
  /** The element that triggers the tooltip */
  children: React.ReactNode;
  /** Preferred position (will auto-adjust if near edges) */
  position?: 'top' | 'bottom' | 'left' | 'right';
  /** Delay before showing tooltip (ms) */
  delay?: number;
  /** Max width of tooltip */
  maxWidth?: number;
  /** Show as help icon instead of wrapping children */
  asHelpIcon?: boolean;
  /** Additional class names */
  className?: string;
  /** Disable the tooltip */
  disabled?: boolean;
}

const Tooltip: React.FC<TooltipProps> = ({
  content,
  children,
  position = 'top',
  delay = 300,
  maxWidth = 280,
  asHelpIcon = false,
  className = '',
  disabled = false,
}) => {
  const [isVisible, setIsVisible] = useState(false);
  const [actualPosition, setActualPosition] = useState(position);
  const [coords, setCoords] = useState({ top: 0, left: 0 });
  const triggerRef = useRef<HTMLDivElement>(null);
  const tooltipRef = useRef<HTMLDivElement>(null);
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);

  const calculatePosition = useCallback(() => {
    if (!triggerRef.current || !tooltipRef.current) return;

    const trigger = triggerRef.current.getBoundingClientRect();
    const tooltip = tooltipRef.current.getBoundingClientRect();
    const padding = 8;
    const arrowSize = 6;

    let top = 0;
    let left = 0;
    let finalPosition = position;

    // Calculate initial position
    switch (position) {
      case 'top':
        top = trigger.top - tooltip.height - arrowSize - padding;
        left = trigger.left + (trigger.width - tooltip.width) / 2;
        break;
      case 'bottom':
        top = trigger.bottom + arrowSize + padding;
        left = trigger.left + (trigger.width - tooltip.width) / 2;
        break;
      case 'left':
        top = trigger.top + (trigger.height - tooltip.height) / 2;
        left = trigger.left - tooltip.width - arrowSize - padding;
        break;
      case 'right':
        top = trigger.top + (trigger.height - tooltip.height) / 2;
        left = trigger.right + arrowSize + padding;
        break;
    }

    // Adjust if off-screen
    const viewportWidth = window.innerWidth;
    const viewportHeight = window.innerHeight;

    // Flip vertically if needed
    if (position === 'top' && top < padding) {
      top = trigger.bottom + arrowSize + padding;
      finalPosition = 'bottom';
    } else if (position === 'bottom' && top + tooltip.height > viewportHeight - padding) {
      top = trigger.top - tooltip.height - arrowSize - padding;
      finalPosition = 'top';
    }

    // Flip horizontally if needed
    if (position === 'left' && left < padding) {
      left = trigger.right + arrowSize + padding;
      finalPosition = 'right';
    } else if (position === 'right' && left + tooltip.width > viewportWidth - padding) {
      left = trigger.left - tooltip.width - arrowSize - padding;
      finalPosition = 'left';
    }

    // Constrain horizontal position
    if (left < padding) left = padding;
    if (left + tooltip.width > viewportWidth - padding) {
      left = viewportWidth - tooltip.width - padding;
    }

    // Constrain vertical position
    if (top < padding) top = padding;
    if (top + tooltip.height > viewportHeight - padding) {
      top = viewportHeight - tooltip.height - padding;
    }

    setCoords({ top, left });
    setActualPosition(finalPosition);
  }, [position]);

  useEffect(() => {
    if (isVisible) {
      calculatePosition();
      window.addEventListener('scroll', calculatePosition, true);
      window.addEventListener('resize', calculatePosition);
    }

    return () => {
      window.removeEventListener('scroll', calculatePosition, true);
      window.removeEventListener('resize', calculatePosition);
    };
  }, [isVisible, calculatePosition]);

  const handleMouseEnter = () => {
    if (disabled) return;
    timeoutRef.current = setTimeout(() => {
      setIsVisible(true);
    }, delay);
  };

  const handleMouseLeave = () => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
      timeoutRef.current = null;
    }
    setIsVisible(false);
  };

  const handleFocus = () => {
    if (disabled) return;
    setIsVisible(true);
  };

  const handleBlur = () => {
    setIsVisible(false);
  };

  // Touch support
  const handleTouchStart = () => {
    if (disabled) return;
    setIsVisible(!isVisible);
  };

  // Arrow position classes
  const arrowClasses = {
    top: 'bottom-[-5px] left-1/2 -translate-x-1/2 border-l-transparent border-r-transparent border-b-transparent border-t-[#2a2b2f]',
    bottom: 'top-[-5px] left-1/2 -translate-x-1/2 border-l-transparent border-r-transparent border-t-transparent border-b-[#2a2b2f]',
    left: 'right-[-5px] top-1/2 -translate-y-1/2 border-t-transparent border-b-transparent border-r-transparent border-l-[#2a2b2f]',
    right: 'left-[-5px] top-1/2 -translate-y-1/2 border-t-transparent border-b-transparent border-l-transparent border-r-[#2a2b2f]',
  };

  const trigger = asHelpIcon ? (
    <button
      type="button"
      className="inline-flex items-center justify-center p-0.5 rounded-full text-slate-400 hover:text-slate-300 hover:bg-white/[0.06] transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-white/40 focus-visible:ring-offset-1 focus-visible:ring-offset-[#08090a]"
      aria-label="Help"
    >
      <HelpCircle size={14} />
    </button>
  ) : (
    children
  );

  if (disabled || !content) {
    return <>{asHelpIcon ? null : children}</>;
  }

  return (
    <>
      <div
        ref={triggerRef}
        className={`inline-flex ${className}`}
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
        onFocus={handleFocus}
        onBlur={handleBlur}
        onTouchStart={handleTouchStart}
        role="button"
        tabIndex={0}
        aria-describedby={isVisible ? 'tooltip' : undefined}
      >
        {trigger}
      </div>

      {isVisible && (
        <div
          ref={tooltipRef}
          id="tooltip"
          role="tooltip"
          className="fixed z-[9999] animate-in fade-in-0 zoom-in-95 duration-150"
          style={{
            top: coords.top,
            left: coords.left,
            maxWidth,
          }}
        >
          <div className="relative bg-[#2a2b2f] text-slate-200 text-[13px] leading-relaxed px-3 py-2 rounded-lg shadow-lg border border-white/[0.08]">
            {/* Arrow */}
            <div
              className={`absolute w-0 h-0 border-[5px] ${arrowClasses[actualPosition]}`}
            />
            {content}
          </div>
        </div>
      )}
    </>
  );
};

export default Tooltip;

// HelpIcon component for standalone use
export interface HelpIconProps {
  tooltip: string | React.ReactNode;
  size?: number;
  className?: string;
}

export const HelpIcon: React.FC<HelpIconProps> = ({
  tooltip,
  size = 14,
  className = '',
}) => {
  return (
    <Tooltip content={tooltip} position="top" asHelpIcon>
      <span className={className}>
        <HelpCircle size={size} />
      </span>
    </Tooltip>
  );
};
