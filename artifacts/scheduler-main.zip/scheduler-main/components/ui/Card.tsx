import React from 'react';

export interface CardProps {
  variant?: 'default' | 'elevated' | 'glass' | 'outline' | 'gradient';
  padding?: 'none' | 'sm' | 'md' | 'lg' | 'xl';
  hover?: boolean;
  glow?: boolean;
  children: React.ReactNode;
  className?: string;
  onClick?: () => void;
}

const Card: React.FC<CardProps> = ({
  variant = 'default',
  padding = 'md',
  hover = false,
  glow = false,
  children,
  className = '',
  onClick,
}) => {
  // Padding classes
  const paddingClasses = {
    none: '',
    sm: 'p-3',
    md: 'p-4',
    lg: 'p-6',
    xl: 'p-8',
  };

  // Variant classes
  const variantClasses = {
    default: `
      bg-[#0d0e10]
      border border-white/[0.08]
    `,
    elevated: `
      bg-[#141517]
      border border-white/[0.08]
      shadow-xl shadow-black/30
    `,
    glass: `
      bg-white/[0.04]
      backdrop-blur-xl
      border border-white/[0.08]
    `,
    outline: `
      bg-transparent
      border border-white/[0.12]
    `,
    gradient: `
      bg-gradient-to-br from-[#0d0e10] to-[#08090a]
      border border-white/[0.08]
    `,
  };

  // Hover classes (subtle, no lift)
  const hoverClasses = hover
    ? `
        cursor-pointer
        transition-colors duration-fast ease-linear-smooth
        hover:border-white/[0.15]
        hover:bg-white/[0.02]
      `
    : '';

  // Glow effect removed - keeping prop for backwards compatibility but no visual effect
  const glowClasses = '';

  const combinedClasses = `
    rounded-xl
    ${variantClasses[variant]}
    ${paddingClasses[padding]}
    ${hoverClasses}
    ${glowClasses}
    ${className}
  `.replace(/\s+/g, ' ').trim();

  return (
    <div
      className={combinedClasses}
      onClick={onClick}
      role={onClick ? 'button' : undefined}
      tabIndex={onClick ? 0 : undefined}
    >
      {children}
    </div>
  );
};

// Card Header subcomponent
export interface CardHeaderProps {
  children: React.ReactNode;
  className?: string;
}

export const CardHeader: React.FC<CardHeaderProps> = ({
  children,
  className = '',
}) => (
  <div className={`pb-4 border-b border-white/[0.06] ${className}`}>
    {children}
  </div>
);

// Card Title subcomponent
export interface CardTitleProps {
  children: React.ReactNode;
  className?: string;
}

export const CardTitle: React.FC<CardTitleProps> = ({
  children,
  className = '',
}) => (
  <h3 className={`text-lg font-semibold text-white ${className}`}>
    {children}
  </h3>
);

// Card Description subcomponent
export interface CardDescriptionProps {
  children: React.ReactNode;
  className?: string;
}

export const CardDescription: React.FC<CardDescriptionProps> = ({
  children,
  className = '',
}) => (
  <p className={`text-sm text-[#9ca3af] mt-1 ${className}`}>
    {children}
  </p>
);

// Card Content subcomponent
export interface CardContentProps {
  children: React.ReactNode;
  className?: string;
}

export const CardContent: React.FC<CardContentProps> = ({
  children,
  className = '',
}) => (
  <div className={`pt-4 ${className}`}>
    {children}
  </div>
);

// Card Footer subcomponent
export interface CardFooterProps {
  children: React.ReactNode;
  className?: string;
}

export const CardFooter: React.FC<CardFooterProps> = ({
  children,
  className = '',
}) => (
  <div className={`pt-4 mt-4 border-t border-white/[0.06] ${className}`}>
    {children}
  </div>
);

export default Card;
