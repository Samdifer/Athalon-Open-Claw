import React from 'react';
import { Link } from 'react-router-dom';

export interface ButtonProps {
  variant?: 'primary' | 'secondary' | 'ghost' | 'outline' | 'danger';
  size?: 'sm' | 'md' | 'lg';
  children: React.ReactNode;
  onClick?: () => void;
  href?: string;
  to?: string;
  disabled?: boolean;
  loading?: boolean;
  icon?: React.ReactNode;
  iconPosition?: 'left' | 'right';
  fullWidth?: boolean;
  className?: string;
  type?: 'button' | 'submit' | 'reset';
}

const Button: React.FC<ButtonProps> = ({
  variant = 'primary',
  size = 'md',
  children,
  onClick,
  href,
  to,
  disabled = false,
  loading = false,
  icon,
  iconPosition = 'left',
  fullWidth = false,
  className = '',
  type = 'button',
}) => {
  // Size classes
  const sizeClasses = {
    sm: 'px-3 py-1.5 text-[13px] gap-1.5',
    md: 'px-5 py-2.5 text-[14px] gap-2',
    lg: 'px-8 py-3.5 text-[15px] gap-2.5',
  };

  // Variant classes (Linear-style flat design)
  const variantClasses = {
    primary: `
      bg-white
      text-[#09090b] font-medium
      hover:bg-zinc-100
      active:bg-zinc-200
      disabled:bg-zinc-700 disabled:text-zinc-400 disabled:cursor-not-allowed
    `,
    secondary: `
      bg-white/[0.08]
      text-white font-medium
      border border-white/[0.1]
      hover:bg-white/[0.12] hover:border-white/[0.15]
      active:bg-white/[0.06]
      disabled:bg-white/[0.04] disabled:text-white/40 disabled:cursor-not-allowed
    `,
    ghost: `
      bg-transparent
      text-[#9ca3af] font-medium
      hover:text-white hover:bg-white/[0.06]
      active:bg-white/[0.04]
      disabled:text-white/30 disabled:cursor-not-allowed
    `,
    outline: `
      bg-transparent
      text-white font-medium
      border border-white/[0.2]
      hover:border-white/[0.4] hover:bg-white/[0.04]
      active:bg-white/[0.02]
      disabled:border-white/[0.1] disabled:text-white/30 disabled:cursor-not-allowed
    `,
    danger: `
      bg-red-600
      text-white font-medium
      hover:bg-red-500
      active:bg-red-700
      disabled:bg-slate-700 disabled:text-slate-400 disabled:cursor-not-allowed
    `,
  };

  const baseClasses = `
    inline-flex items-center justify-center
    rounded-lg
    transition-colors duration-fast ease-linear-smooth
    select-none cursor-pointer
    focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/40 focus-visible:ring-offset-2 focus-visible:ring-offset-[#08090a]
  `;

  const combinedClasses = `
    ${baseClasses}
    ${sizeClasses[size]}
    ${variantClasses[variant]}
    ${fullWidth ? 'w-full' : ''}
    ${disabled || loading ? 'pointer-events-none' : ''}
    ${className}
  `.replace(/\s+/g, ' ').trim();

  const content = (
    <>
      {/* Loading spinner */}
      {loading && (
        <svg
          className="animate-spin h-4 w-4 text-current"
          xmlns="http://www.w3.org/2000/svg"
          fill="none"
          viewBox="0 0 24 24"
        >
          <circle
            className="opacity-25"
            cx="12"
            cy="12"
            r="10"
            stroke="currentColor"
            strokeWidth="4"
          />
          <path
            className="opacity-75"
            fill="currentColor"
            d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
          />
        </svg>
      )}

      {/* Icon left */}
      {!loading && icon && iconPosition === 'left' && (
        <span className="flex-shrink-0">{icon}</span>
      )}

      {/* Text content */}
      <span className={loading ? 'opacity-0' : ''}>{children}</span>

      {/* Icon right */}
      {!loading && icon && iconPosition === 'right' && (
        <span className="flex-shrink-0">{icon}</span>
      )}
    </>
  );

  // Render as Link (internal routing)
  if (to && !disabled) {
    return (
      <Link to={to} className={`group ${combinedClasses}`}>
        {content}
      </Link>
    );
  }

  // Render as anchor (external link)
  if (href && !disabled) {
    return (
      <a
        href={href}
        className={`group ${combinedClasses}`}
        target="_blank"
        rel="noopener noreferrer"
      >
        {content}
      </a>
    );
  }

  // Render as button
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled || loading}
      className={`group ${combinedClasses}`}
    >
      {content}
    </button>
  );
};

export default Button;
