import React, { useState } from 'react';
import { X, AlertTriangle, RefreshCw, SkipForward, Copy } from 'lucide-react';
import { AircraftConflict } from '../types';

interface AircraftDuplicateModalProps {
  conflict: AircraftConflict;
  currentIndex: number;
  totalConflicts: number;
  onResolve: (resolution: 'overwrite' | 'skip' | 'keep_both') => void;
  onApplyToAll: (resolution: 'overwrite' | 'skip' | 'keep_both') => void;
  onCancel: () => void;
}

const AircraftDuplicateModal: React.FC<AircraftDuplicateModalProps> = ({
  conflict,
  currentIndex,
  totalConflicts,
  onResolve,
  onApplyToAll,
  onCancel
}) => {
  const [selectedResolution, setSelectedResolution] = useState<'overwrite' | 'skip' | 'keep_both' | null>(null);

  const handleResolve = () => {
    if (selectedResolution) {
      onResolve(selectedResolution);
      setSelectedResolution(null);
    }
  };

  const handleApplyToAll = () => {
    if (selectedResolution) {
      onApplyToAll(selectedResolution);
    }
  };

  return (
    <div className="fixed inset-0 bg-[#08090a]/80 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
      <div className="bg-[#0d0e10] border border-white/[0.1] rounded-xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-white/[0.08]">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-amber-500/10 rounded-lg">
              <AlertTriangle size={20} className="text-amber-400" />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-[#e8e8e8]">Duplicate Aircraft Found</h2>
              <p className="text-xs text-[#6b7280] mt-0.5">
                Conflict {currentIndex + 1} of {totalConflicts}
              </p>
            </div>
          </div>
          <button
            onClick={onCancel}
            className="text-[#6b7280] hover:text-white transition-colors p-1"
          >
            <X size={20} />
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          <p className="text-sm text-[#9ca3af] mb-6">
            This aircraft already exists in your list. Choose how to handle this conflict:
          </p>

          {/* Side-by-side comparison */}
          <div className="grid grid-cols-2 gap-4 mb-6">
            {/* Incoming */}
            <div className="bg-violet-500/10 border border-violet-500/20 rounded-lg p-4">
              <div className="text-xs font-semibold text-violet-400 uppercase mb-2">Incoming (New)</div>
              <div className="text-[#e8e8e8] font-semibold">{conflict.incoming.name}</div>
              <div className="text-xs text-[#6b7280] mt-1">From package import</div>
            </div>

            {/* Existing */}
            <div className="bg-[#141517] border border-white/[0.08] rounded-lg p-4">
              <div className="text-xs font-semibold text-[#6b7280] uppercase mb-2">Existing</div>
              <div className="text-[#e8e8e8] font-semibold">{conflict.existing.name}</div>
              <div className="text-xs text-[#6b7280] mt-1 font-mono">ID: {conflict.existing.id}</div>
            </div>
          </div>

          {/* Resolution options */}
          <div className="space-y-3">
            <button
              onClick={() => setSelectedResolution('overwrite')}
              className={`w-full flex items-center gap-3 p-4 rounded-lg border transition-all text-left ${
                selectedResolution === 'overwrite'
                  ? 'bg-[#5e6ad2]/10 border-[#5e6ad2]/30 text-white'
                  : 'bg-[#141517] border-white/[0.08] text-[#9ca3af] hover:bg-[#1a1b1e] hover:border-white/[0.12]'
              }`}
            >
              <div className={`p-2 rounded-lg ${selectedResolution === 'overwrite' ? 'bg-[#5e6ad2]/20' : 'bg-[#0d0e10]'}`}>
                <RefreshCw size={18} className={selectedResolution === 'overwrite' ? 'text-[#6e79d6]' : 'text-[#6b7280]'} />
              </div>
              <div>
                <div className="font-semibold text-sm">Overwrite Existing</div>
                <div className="text-xs text-[#6b7280] mt-0.5">Replace the existing aircraft with the new one</div>
              </div>
            </button>

            <button
              onClick={() => setSelectedResolution('skip')}
              className={`w-full flex items-center gap-3 p-4 rounded-lg border transition-all text-left ${
                selectedResolution === 'skip'
                  ? 'bg-[#5e6ad2]/10 border-[#5e6ad2]/30 text-white'
                  : 'bg-[#141517] border-white/[0.08] text-[#9ca3af] hover:bg-[#1a1b1e] hover:border-white/[0.12]'
              }`}
            >
              <div className={`p-2 rounded-lg ${selectedResolution === 'skip' ? 'bg-[#5e6ad2]/20' : 'bg-[#0d0e10]'}`}>
                <SkipForward size={18} className={selectedResolution === 'skip' ? 'text-[#6e79d6]' : 'text-[#6b7280]'} />
              </div>
              <div>
                <div className="font-semibold text-sm">Skip (Keep Existing)</div>
                <div className="text-xs text-[#6b7280] mt-0.5">Don't import this aircraft, keep your current entry</div>
              </div>
            </button>

            <button
              onClick={() => setSelectedResolution('keep_both')}
              className={`w-full flex items-center gap-3 p-4 rounded-lg border transition-all text-left ${
                selectedResolution === 'keep_both'
                  ? 'bg-[#5e6ad2]/10 border-[#5e6ad2]/30 text-white'
                  : 'bg-[#141517] border-white/[0.08] text-[#9ca3af] hover:bg-[#1a1b1e] hover:border-white/[0.12]'
              }`}
            >
              <div className={`p-2 rounded-lg ${selectedResolution === 'keep_both' ? 'bg-[#5e6ad2]/20' : 'bg-[#0d0e10]'}`}>
                <Copy size={18} className={selectedResolution === 'keep_both' ? 'text-[#6e79d6]' : 'text-[#6b7280]'} />
              </div>
              <div>
                <div className="font-semibold text-sm">Keep Both</div>
                <div className="text-xs text-[#6b7280] mt-0.5">Add the new aircraft alongside the existing one</div>
              </div>
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between p-5 border-t border-white/[0.08] bg-[#0a0b0c]">
          <div className="text-xs text-[#6b7280]">
            {totalConflicts - currentIndex - 1} remaining conflicts
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={onCancel}
              className="px-4 py-2 text-sm font-semibold text-[#9ca3af] hover:text-white transition-colors"
            >
              Cancel Import
            </button>
            {totalConflicts > 1 && (
              <button
                onClick={handleApplyToAll}
                disabled={!selectedResolution}
                className="px-4 py-2 text-sm font-semibold bg-[#1a1b1e] hover:bg-[#222326] border border-white/[0.1] text-[#e8e8e8] rounded-md transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Apply to All ({totalConflicts - currentIndex})
              </button>
            )}
            <button
              onClick={handleResolve}
              disabled={!selectedResolution}
              className="px-5 py-2 text-sm font-semibold bg-[#5e6ad2] hover:bg-[#7b86e0] text-white rounded-md transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {currentIndex < totalConflicts - 1 ? 'Next' : 'Finish Import'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AircraftDuplicateModal;
