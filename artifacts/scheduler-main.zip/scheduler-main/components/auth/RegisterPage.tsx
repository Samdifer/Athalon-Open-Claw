
import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { Loader2, Mail, Lock, ArrowRight, User, AlertCircle, ChevronLeft, Building, CheckCircle } from 'lucide-react';

interface RegisterPageProps {
  onSwitchToLogin: () => void;
  onSuccess: () => void;
  onBack: () => void;
}

const RegisterPage: React.FC<RegisterPageProps> = ({ onSwitchToLogin, onSuccess, onBack }) => {
  const { register } = useAuth();
  const [name, setName] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [registrationComplete, setRegistrationComplete] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    // Validation
    if (!name || !email || !password) {
      setError('Name, email, and password are required.');
      setLoading(false);
      return;
    }

    if (password.length < 6) {
      setError('Password must be at least 6 characters.');
      setLoading(false);
      return;
    }

    if (password !== confirmPassword) {
      setError('Passwords do not match.');
      setLoading(false);
      return;
    }

    try {
      await register(email, password, name);
      setRegistrationComplete(true);
    } catch (err: any) {
      setError(err.message || 'Failed to create account. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  // Show success screen after registration
  if (registrationComplete) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#08090a] p-4 relative overflow-hidden">
        <div className="absolute top-1/3 left-1/3 w-96 h-96 bg-[#3dae6c]/[0.03] rounded-full blur-[120px] pointer-events-none" />

        <div className="w-full max-w-sm bg-[#0d0e10] border border-white/[0.08] rounded-xl shadow-2xl p-6 relative z-10 text-center">
          <div className="w-14 h-14 bg-emerald-500/10 border border-emerald-500/20 rounded-full flex items-center justify-center mx-auto mb-5">
            <CheckCircle className="text-emerald-400" size={28} />
          </div>

          <h1 className="text-xl font-semibold text-white mb-2">
            Check your email
          </h1>

          <p className="text-[#9ca3af] text-sm mb-5">
            We've sent a verification link to <span className="text-white font-medium">{email}</span>.
            Click the link to activate your account.
          </p>

          <div className="bg-white/[0.03] border border-white/[0.06] rounded-lg p-4 text-left text-xs text-[#9ca3af] mb-5">
            <p className="mb-2 font-medium text-[#e8e8e8]">After verifying your email:</p>
            <ul className="list-disc list-inside space-y-1 text-[#6b7280]">
              <li>Your 14-day free trial will begin</li>
              <li>You'll have access to all features</li>
              <li>Invite unlimited team members</li>
            </ul>
          </div>

          <button
            onClick={onSwitchToLogin}
            className="w-full bg-white hover:bg-zinc-100 text-[#09090b] font-medium py-2.5 rounded-lg transition-colors text-sm"
          >
            Continue to Login
          </button>

          <p className="text-xs text-[#6b7280] mt-4">
            Didn't receive the email? Check your spam folder or{' '}
            <button onClick={onSwitchToLogin} className="text-zinc-300 hover:text-white">
              try again
            </button>
          </p>
        </div>
      </div>
    );
  }

  return (
    <div
      className="min-h-screen flex items-center justify-center bg-[#08090a] p-4 relative overflow-hidden cursor-pointer"
      onClick={onBack}
    >
      {/* Subtle Background Accent */}
      <div className="absolute top-1/3 left-1/3 w-96 h-96 bg-white/[0.02] rounded-full blur-[120px] pointer-events-none" />

      <div
        className="w-full max-w-sm bg-[#0d0e10] border border-white/[0.08] rounded-xl shadow-2xl p-6 relative z-10 cursor-default"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          type="button"
          onClick={onBack}
          className="absolute top-4 left-4 p-1.5 text-[#6b7280] hover:text-white hover:bg-white/[0.06] rounded-lg transition-colors"
          title="Back"
        >
          <ChevronLeft size={18} />
        </button>

        <div className="text-center mb-6 pt-2">
          <h1 className="text-xl font-semibold text-white mb-1">Create account</h1>
          <p className="text-[#6b7280] text-sm">Start your 14-day free trial</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3">
          {error && (
            <div className="bg-red-500/10 border border-red-500/20 text-red-400 p-3 rounded-lg text-xs flex items-start gap-2">
              <AlertCircle size={14} className="mt-0.5 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div className="space-y-1.5">
            <label className="text-xs font-medium text-[#6b7280]">Full name</label>
            <div className="relative">
              <User className="absolute left-3 top-2.5 text-[#4b5563]" size={16} />
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-[#08090a] border border-white/[0.08] rounded-lg py-2.5 pl-10 pr-4 text-[#e8e8e8] focus:border-white/40 focus:ring-1 focus:ring-white/10 outline-none transition-all text-sm"
                placeholder="John Doe"
                autoComplete="name"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-medium text-[#6b7280]">
              Company name <span className="text-[#4b5563]">(optional)</span>
            </label>
            <div className="relative">
              <Building className="absolute left-3 top-2.5 text-[#4b5563]" size={16} />
              <input
                type="text"
                value={companyName}
                onChange={(e) => setCompanyName(e.target.value)}
                className="w-full bg-[#08090a] border border-white/[0.08] rounded-lg py-2.5 pl-10 pr-4 text-[#e8e8e8] focus:border-white/40 focus:ring-1 focus:ring-white/10 outline-none transition-all text-sm"
                placeholder="Acme Aviation Services"
                autoComplete="organization"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-medium text-[#6b7280]">Email</label>
            <div className="relative">
              <Mail className="absolute left-3 top-2.5 text-[#4b5563]" size={16} />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-[#08090a] border border-white/[0.08] rounded-lg py-2.5 pl-10 pr-4 text-[#e8e8e8] focus:border-white/40 focus:ring-1 focus:ring-white/10 outline-none transition-all text-sm"
                placeholder="name@company.com"
                autoComplete="email"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-[#6b7280]">Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-2.5 text-[#4b5563]" size={16} />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-[#08090a] border border-white/[0.08] rounded-lg py-2.5 pl-10 pr-4 text-[#e8e8e8] focus:border-white/40 focus:ring-1 focus:ring-white/10 outline-none transition-all text-sm"
                  placeholder="••••••"
                  autoComplete="new-password"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-medium text-[#6b7280]">Confirm</label>
              <div className="relative">
                <Lock className="absolute left-3 top-2.5 text-[#4b5563]" size={16} />
                <input
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className={`w-full bg-[#08090a] border rounded-lg py-2.5 pl-10 pr-4 text-[#e8e8e8] focus:ring-1 outline-none transition-all text-sm ${
                    confirmPassword && confirmPassword !== password
                      ? 'border-red-500/50 focus:border-red-500 focus:ring-red-500/20'
                      : 'border-white/[0.08] focus:border-white/40 focus:ring-white/10'
                  }`}
                  placeholder="••••••"
                  autoComplete="new-password"
                />
              </div>
            </div>
          </div>

          <p className="text-[11px] text-[#6b7280]">
            Password must be at least 6 characters.
          </p>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-white hover:bg-zinc-100 text-[#09090b] font-medium py-2.5 rounded-lg transition-colors flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed text-sm mt-1"
          >
            {loading ? <Loader2 className="animate-spin" size={18} /> : <>Create account <ArrowRight size={16} /></>}
          </button>

          <p className="text-[11px] text-[#6b7280] text-center">
            By creating an account, you agree to our{' '}
            <a href="#" className="text-zinc-400 hover:text-white">Terms</a>
            {' '}and{' '}
            <a href="#" className="text-zinc-400 hover:text-white">Privacy Policy</a>.
          </p>
        </form>

        <div className="mt-5 pt-4 border-t border-white/[0.06] text-center">
          <p className="text-sm text-[#6b7280]">
            Already have an account?{' '}
            <button onClick={onSwitchToLogin} className="text-zinc-300 hover:text-white font-medium transition-colors">
              Log in
            </button>
          </p>
        </div>
      </div>
    </div>
  );
};

export default RegisterPage;
