
import React, { useState } from 'react';
import { X, Lock, Check, AlertCircle, Loader2, ShieldCheck } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

interface ChangePasswordModalProps {
  onClose: () => void;
}

const ChangePasswordModal: React.FC<ChangePasswordModalProps> = ({ onClose }) => {
  const { changePassword } = useAuth();
  const [currentPass, setCurrentPass] = useState('');
  const [newPass, setNewPass] = useState('');
  const [confirmPass, setConfirmPass] = useState('');
  
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (newPass !== confirmPass) {
        setError("New passwords do not match");
        return;
    }

    if (newPass.length < 6) {
        setError("Password must be at least 6 characters");
        return;
    }

    setIsLoading(true);
    try {
        await changePassword(currentPass, newPass);
        setSuccess(true);
        setTimeout(() => {
            onClose();
        }, 1500);
    } catch (err: any) {
        setError(err.message || "Failed to change password");
        setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-[#08090a]/80 backdrop-blur-sm z-[300] flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="bg-[#0d0e10] w-full max-w-md border border-white/[0.08] rounded-xl overflow-hidden relative">

        <button
            onClick={onClose}
            className="absolute top-3 right-3 text-[#6b7280] hover:text-white hover:bg-[#141517] rounded-full p-1 transition-colors"
        >
            <X size={18} />
        </button>

        {success ? (
            <div className="p-8 flex flex-col items-center text-center animate-in zoom-in duration-300">
                <div className="w-16 h-16 bg-[#3dae6c]/10 rounded-full flex items-center justify-center mb-4 border border-[#3dae6c]/30">
                    <Check size={32} className="text-[#3dae6c]" />
                </div>
                <h3 className="text-xl font-semibold text-white mb-2">Password Updated</h3>
                <p className="text-[#9ca3af] text-sm">Your credentials have been successfully changed.</p>
            </div>
        ) : (
            <form onSubmit={handleSubmit} className="p-6">
                <div className="flex items-center gap-3 mb-6">
                    <div className="p-2 bg-white/[0.06] rounded-lg border border-white/[0.08]">
                        <ShieldCheck className="text-zinc-300" size={24} />
                    </div>
                    <div>
                        <h3 className="text-lg font-semibold text-white tracking-wide">Change Password</h3>
                        <p className="text-xs text-[#6b7280]">Update your account security credentials.</p>
                    </div>
                </div>

                {error && (
                    <div className="mb-4 p-3 bg-[#c4626a]/10 border border-[#c4626a]/20 rounded-lg flex items-center gap-2 text-xs text-[#c4626a]">
                        <AlertCircle size={14} /> {error}
                    </div>
                )}

                <div className="space-y-4">
                    <div className="space-y-1.5">
                        <label className="block text-xs font-semibold text-[#6b7280] uppercase">Current Password</label>
                        <div className="relative">
                            <Lock className="absolute left-3 top-2.5 text-[#4b5563]" size={14} />
                            <input
                                type="password"
                                value={currentPass}
                                onChange={(e) => setCurrentPass(e.target.value)}
                                className="w-full bg-[#141517] border border-white/[0.08] rounded-lg py-2 pl-9 pr-3 text-sm text-white focus:border-white/40 outline-none"
                                placeholder="••••••••"
                                required
                            />
                        </div>
                    </div>

                    <div className="space-y-1.5">
                        <label className="block text-xs font-semibold text-[#6b7280] uppercase">New Password</label>
                        <div className="relative">
                            <Lock className="absolute left-3 top-2.5 text-[#4b5563]" size={14} />
                            <input
                                type="password"
                                value={newPass}
                                onChange={(e) => setNewPass(e.target.value)}
                                className="w-full bg-[#141517] border border-white/[0.08] rounded-lg py-2 pl-9 pr-3 text-sm text-white focus:border-white/40 outline-none"
                                placeholder="••••••••"
                                required
                                minLength={6}
                            />
                        </div>
                        <p className="text-[10px] text-[#6b7280] pl-1">Minimum 6 characters.</p>
                    </div>

                    <div className="space-y-1.5">
                        <label className="block text-xs font-semibold text-[#6b7280] uppercase">Confirm New Password</label>
                        <div className="relative">
                            <Lock className="absolute left-3 top-2.5 text-[#4b5563]" size={14} />
                            <input
                                type="password"
                                value={confirmPass}
                                onChange={(e) => setConfirmPass(e.target.value)}
                                className={`w-full bg-[#141517] border rounded-lg py-2 pl-9 pr-3 text-sm text-white focus:border-white/40 outline-none ${confirmPass && confirmPass !== newPass ? 'border-[#c4626a]' : 'border-white/[0.08]'}`}
                                placeholder="••••••••"
                                required
                            />
                        </div>
                    </div>
                </div>

                <div className="mt-8 flex gap-3">
                    <button
                        type="button"
                        onClick={onClose}
                        className="flex-1 py-2.5 rounded-lg border border-white/[0.08] text-[#e8e8e8] font-semibold text-xs hover:bg-[#141517] transition-colors"
                    >
                        Cancel
                    </button>
                    <button
                        type="submit"
                        disabled={isLoading || !currentPass || !newPass || !confirmPass}
                        className="flex-1 py-2.5 rounded-lg bg-white hover:bg-zinc-100 text-[#09090b] font-semibold text-xs transition-all flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        {isLoading ? <Loader2 className="animate-spin" size={14} /> : 'Update Password'}
                    </button>
                </div>
            </form>
        )}
      </div>
    </div>
  );
};

export default ChangePasswordModal;
