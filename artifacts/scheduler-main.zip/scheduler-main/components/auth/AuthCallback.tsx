
import React, { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import { Loader2, CheckCircle, XCircle } from 'lucide-react';

interface AuthCallbackProps {
  onSuccess: () => void;
  onError: () => void;
}

const AuthCallback: React.FC<AuthCallbackProps> = ({ onSuccess, onError }) => {
  const [status, setStatus] = useState<'loading' | 'success' | 'error'>('loading');
  const [message, setMessage] = useState('Verifying your email...');

  useEffect(() => {
    const handleAuthCallback = async () => {
      try {
        // Get the hash fragment from URL (Supabase puts tokens there)
        const hashParams = new URLSearchParams(window.location.hash.substring(1));
        const accessToken = hashParams.get('access_token');
        const refreshToken = hashParams.get('refresh_token');
        const type = hashParams.get('type');

        if (accessToken && refreshToken) {
          // Set the session with the tokens from the URL
          const { error } = await supabase.auth.setSession({
            access_token: accessToken,
            refresh_token: refreshToken,
          });

          if (error) {
            throw error;
          }

          // Success!
          setStatus('success');
          if (type === 'signup') {
            setMessage('Email verified successfully! Redirecting to dashboard...');
          } else if (type === 'recovery') {
            setMessage('Password reset link verified! Redirecting...');
          } else {
            setMessage('Authentication successful! Redirecting...');
          }

          // Redirect after a brief delay
          setTimeout(() => {
            window.location.href = '/';
          }, 2000);
        } else {
          // Check if we have a code in query params (for PKCE flow)
          const urlParams = new URLSearchParams(window.location.search);
          const code = urlParams.get('code');

          if (code) {
            const { error } = await supabase.auth.exchangeCodeForSession(code);

            if (error) {
              throw error;
            }

            setStatus('success');
            setMessage('Email verified successfully! Redirecting...');

            setTimeout(() => {
              window.location.href = '/';
            }, 2000);
          } else {
            // No tokens or code found
            throw new Error('No authentication tokens found in URL');
          }
        }
      } catch (error: any) {
        console.error('Auth callback error:', error);
        setStatus('error');
        setMessage(error.message || 'Verification failed. Please try again.');

        // Redirect to login after delay
        setTimeout(() => {
          onError();
        }, 3000);
      }
    };

    handleAuthCallback();
  }, [onSuccess, onError]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-950 p-4 relative overflow-hidden">
      {/* Background Accents */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-cyan-900/10 rounded-full blur-[100px]" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-blue-900/10 rounded-full blur-[100px]" />

      <div className="w-full max-w-md bg-slate-900/80 backdrop-blur-xl border border-slate-700/50 rounded-2xl shadow-2xl p-8 relative z-10 text-center">
        {status === 'loading' && (
          <>
            <Loader2 className="animate-spin text-cyan-400 mx-auto mb-4" size={48} />
            <h1 className="text-xl font-bold text-white mb-2">Verifying...</h1>
            <p className="text-slate-400 text-sm">{message}</p>
          </>
        )}

        {status === 'success' && (
          <>
            <div className="w-16 h-16 bg-emerald-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="text-emerald-400" size={32} />
            </div>
            <h1 className="text-xl font-bold text-white mb-2">Verified!</h1>
            <p className="text-slate-400 text-sm">{message}</p>
          </>
        )}

        {status === 'error' && (
          <>
            <div className="w-16 h-16 bg-rose-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <XCircle className="text-rose-400" size={32} />
            </div>
            <h1 className="text-xl font-bold text-white mb-2">Verification Failed</h1>
            <p className="text-slate-400 text-sm mb-4">{message}</p>
            <button
              onClick={onError}
              className="text-cyan-400 hover:text-cyan-300 text-sm"
            >
              Return to Login
            </button>
          </>
        )}
      </div>
    </div>
  );
};

export default AuthCallback;
