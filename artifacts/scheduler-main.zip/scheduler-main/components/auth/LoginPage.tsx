
import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { Loader2, Mail, Lock, ArrowRight, AlertCircle, CheckCircle, RefreshCw } from 'lucide-react';

interface LoginPageProps {
  onSwitchToRegister: () => void;
  onSuccess: () => void;
}

const LoginPage: React.FC<LoginPageProps> = ({ onSwitchToRegister, onSuccess }) => {
  const auth = useAuth();
  const { login } = auth;
  // Access extended properties
  const emailVerificationPending = (auth as any).emailVerificationPending;
  const resendVerificationEmail = (auth as any).resendVerificationEmail;

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [resending, setResending] = useState(false);
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccessMessage('');
    setLoading(true);

    if (!email || !password) {
      setError('Please enter both email and password.');
      setLoading(false);
      return;
    }

    try {
      await login(email, password);
      onSuccess();
    } catch (err: any) {
      setError(err.message || 'Failed to sign in. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleResendVerification = async () => {
    if (!email) {
      setError('Please enter your email address to resend verification.');
      return;
    }

    setResending(true);
    setError('');

    try {
      await resendVerificationEmail(email);
      setSuccessMessage('Verification email sent! Please check your inbox.');
    } catch (err: any) {
      setError(err.message || 'Failed to send verification email.');
    } finally {
      setResending(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#08090a] p-4 relative overflow-hidden">
      {/* Subtle Background Accent */}
      <div className="absolute top-1/3 left-1/3 w-96 h-96 bg-white/[0.02] rounded-full blur-[120px]" />

      <div className="w-full max-w-sm bg-[#0d0e10] border border-white/[0.08] rounded-xl shadow-2xl p-6 relative z-10">
        <div className="text-center mb-6">
          <h1 className="text-xl font-semibold text-white mb-1">Welcome back</h1>
          <p className="text-[#6b7280] text-sm">Sign in to your account</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {error && (
            <div className="bg-red-500/10 border border-red-500/20 text-red-400 p-3 rounded-lg text-xs flex items-start gap-2">
              <AlertCircle size={14} className="mt-0.5 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {successMessage && (
            <div className="bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 p-3 rounded-lg text-xs flex items-start gap-2">
              <CheckCircle size={14} className="mt-0.5 flex-shrink-0" />
              <span>{successMessage}</span>
            </div>
          )}

          {emailVerificationPending && (
            <div className="bg-amber-500/10 border border-amber-500/20 text-amber-400 p-3 rounded-lg text-sm">
              <div className="flex items-start gap-2 mb-2">
                <Mail size={16} className="mt-0.5 flex-shrink-0" />
                <div>
                  <p className="font-medium">Email verification required</p>
                  <p className="text-xs mt-1 text-amber-400/70">
                    Please check your inbox and click the verification link.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={handleResendVerification}
                disabled={resending}
                className="w-full flex items-center justify-center gap-2 text-xs bg-amber-500/20 hover:bg-amber-500/30 py-2 rounded-md transition-colors disabled:opacity-50"
              >
                {resending ? (
                  <Loader2 className="animate-spin" size={14} />
                ) : (
                  <RefreshCw size={14} />
                )}
                Resend Verification Email
              </button>
            </div>
          )}

          <div className="space-y-1.5">
            <label className="text-xs font-medium text-[#6b7280]">Email</label>
            <div className="relative">
              <Mail className="absolute left-3 top-2.5 text-[#4b5563]" size={16} />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-[#08090a] border border-white/[0.08] rounded-lg py-2.5 pl-10 pr-4 text-[#e8e8e8] focus:border-white/40 focus:ring-1 focus:ring-white/10 outline-none transition-all text-sm"
                placeholder="name@company.com"
                autoComplete="email"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-medium text-[#6b7280]">Password</label>
            <div className="relative">
              <Lock className="absolute left-3 top-2.5 text-[#4b5563]" size={16} />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-[#08090a] border border-white/[0.08] rounded-lg py-2.5 pl-10 pr-4 text-[#e8e8e8] focus:border-white/40 focus:ring-1 focus:ring-white/10 outline-none transition-all text-sm"
                placeholder="Enter your password"
                autoComplete="current-password"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-white hover:bg-zinc-100 text-[#09090b] font-medium py-2.5 rounded-lg transition-colors flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed text-sm"
          >
            {loading ? <Loader2 className="animate-spin" size={18} /> : <>Sign in <ArrowRight size={16} /></>}
          </button>
        </form>

        <div className="mt-6 pt-4 border-t border-white/[0.06] text-center">
          <p className="text-sm text-[#6b7280]">
            Don't have an account?{' '}
            <button onClick={onSwitchToRegister} className="text-zinc-300 hover:text-white font-medium transition-colors">
              Start free trial
            </button>
          </p>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
