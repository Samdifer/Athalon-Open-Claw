
import React, { useEffect, useState } from 'react';
import { GameNotification } from '../types';
import { Info, Terminal } from 'lucide-react';

const Toast: React.FC<{ note: GameNotification }> = ({ note }) => {
  const [isFading, setIsFading] = useState(false);
  const [isGone, setIsGone] = useState(false);

  useEffect(() => {
    // Wait 3 seconds (3000ms) then start fading
    const fadeTimer = setTimeout(() => {
      setIsFading(true);
    }, 3000);

    // Wait 3s + 0.5s fade duration then remove from DOM flow
    const removeTimer = setTimeout(() => {
        setIsGone(true);
    }, 3500);

    return () => {
      clearTimeout(fadeTimer);
      clearTimeout(removeTimer);
    };
  }, []);

  if (isGone) return null;

  return (
    <div
        className={`
            flex items-center gap-3 px-4 py-3 rounded-lg
            border-l-2 border-l-indigo-500 border-y border-r border-white/[0.08]
            bg-[#141517]/95 backdrop-blur-md text-[#e8e8e8] text-xs font-medium pointer-events-none
            transition-all duration-500 ease-out transform translate-x-0
            ${isFading ? 'opacity-0 translate-x-8' : 'opacity-100'}
        `}
    >
      <div className="bg-indigo-500/10 p-1.5 rounded-md border border-indigo-500/20 shrink-0">
         <Terminal size={12} className="text-indigo-400" />
      </div>
      <span>{note.message}</span>
    </div>
  );
};

interface NotificationCenterProps {
  notifications: GameNotification[];
}

const NotificationCenter: React.FC<NotificationCenterProps> = ({ notifications }) => {
  // Only render the last 5 notifications to prevent DOM overload
  const recentNotifications = notifications.slice(-5);

  return (
    <div className="absolute bottom-4 right-4 flex flex-col items-end gap-2 z-[100] w-full max-w-md pointer-events-none">
      {recentNotifications.map((note) => (
        <Toast key={note.id} note={note} />
      ))}
    </div>
  );
};

export default NotificationCenter;
