
import React, { useRef, useEffect, useState, useMemo, useCallback } from 'react';
import { ZOOM_LEVELS, STICKY_COL_WIDTH, START_YEAR, TOTAL_DAYS } from '../constants';
import { useSyncedScroll } from '../contexts/TimelineSyncContext';
import { ScheduledJob, GameState, MONTH_NAMES, Job } from '../types';
import { AlertCircle, AlertTriangle, Loader2, GripVertical, CheckCircle2, Ban, X, HelpCircle, SlidersHorizontal, CalendarOff, Warehouse, GripHorizontal } from 'lucide-react';
import { useCapacityData } from '../hooks';
import NotificationCenter from './NotificationCenter';
import { Tooltip, EmptyState } from './ui';

interface GanttBoardProps {
  gameState: GameState;
  cellWidth: number;
  onZoomChange: (width: number) => void;
  onJobDrop: (jobId: string, hangarId: string, dayIndex: number) => void;
  onJobClick: (job: ScheduledJob) => void;
  onDayClick: (dayIndex: number) => void;
  scheduleEditMode: boolean;
  // Add editTool prop
  editTool?: 'distribute' | 'block';
  onJobDayToggle: (jobId: string, dayOffset: number) => void;
  onJobEffortChange?: (jobId: string, dayOffset: number, effort: number) => void;
  onVisibleDateRangeChange: (startDay: number) => void;
  scrollToTodayTrigger?: number;
  onScroll?: (scrollLeft: number) => void;
  draggedJob?: Job | ScheduledJob | null;
  onDragStart: (e: React.DragEvent, job: Job | ScheduledJob) => void;
  onDragEnd: () => void;
  onHangarReorder?: (fromId: string, toId: string) => void;
  onJobResize?: (jobId: string, newStart: number, newDuration: number) => void;
  scrollRef?: React.RefObject<HTMLDivElement | null>;
  scenarioStart?: number;
  scenarioEnd?: number;
  selectedBaseId?: string;
  dayAlignment?: 'center' | 'left';
  readOnly?: boolean;
  focusedDayIndex?: number;
  
  // Magic Scheduler Props
  magicMode?: boolean;
  selectedMagicJobIds?: string[];
  onMagicJobToggle?: (job: ScheduledJob) => void;

  // View Modes
  viewCapacityMode?: boolean;
  simplifiedViewMode?: boolean;

  // Context Menu Actions
  onFindAvailableSlot?: (job: ScheduledJob) => void;
}

// Date helpers
const getDateForDay = (dayIndex: number) => new Date(START_YEAR, 0, 1 + dayIndex);

const GanttBoard: React.FC<GanttBoardProps> = ({
  gameState, cellWidth, onZoomChange, onJobDrop, onJobClick, onDayClick, scheduleEditMode, editTool = 'distribute', onJobDayToggle, onJobEffortChange, onVisibleDateRangeChange, scrollToTodayTrigger, onScroll, draggedJob, onDragStart, onDragEnd, onHangarReorder, onJobResize, scrollRef,
  scenarioStart, scenarioEnd, selectedBaseId, dayAlignment = 'center', readOnly = false, focusedDayIndex,
  magicMode = false, selectedMagicJobIds = [], onMagicJobToggle,
  viewCapacityMode = false, simplifiedViewMode = false,
  onFindAvailableSlot
}) => {
  // Dynamic Dimensions based on View Mode
  const JOB_HEIGHT = simplifiedViewMode ? 24 : 42;
  const JOB_GUTTER = simplifiedViewMode ? 2 : 6;
  const BASE_ROW_HEIGHT = simplifiedViewMode ? 40 : 96;

  const internalScrollRef = useRef<HTMLDivElement>(null);
  const scrollContainerRef = (scrollRef || internalScrollRef) as React.RefObject<HTMLDivElement>;

  // Ref to store the update callback for context sync
  const updateCallbackRef = useRef<() => void>(() => {});

  // Bi-directional scroll sync with popped-out windows
  // Pass a stable callback that calls the latest updateVisibleRange
  const { handleScroll: syncedHandleScroll } = useSyncedScroll(
    'gantt',
    useCallback(() => updateCallbackRef.current(), [])
  );

  const gridRef = useRef<HTMLDivElement>(null);
  const [hoveredCell, setHoveredCell] = useState<{h: string, d: number} | null>(null);
  const [isMounted, setIsMounted] = useState(false);

  // Edit Mode Hover State
  const [hoveredEditDayIndex, setHoveredEditDayIndex] = useState<number | null>(null);

  // Virtualization State
  const [visibleRange, setVisibleRange] = useState({ start: 0, end: 50 });

  // Row DnD State
  const [draggedHangarId, setDraggedHangarId] = useState<string | null>(null);

  // Editing State for Sliders
  const [isDraggingSlider, setIsDraggingSlider] = useState(false);
  const [sliderTarget, setSliderTarget] = useState<{ jobId: string, offset: number } | null>(null);
  const [sliderTooltip, setSliderTooltip] = useState<{ x: number, y: number, hours: number, percent: number, maxAllowed?: number } | null>(null);

  // Resizing State
  const [resizingJob, setResizingJob] = useState<{ 
      jobId: string, 
      mode: 'start' | 'end', 
      startX: number, 
      originalStart: number, 
      originalDuration: number 
  } | null>(null);
  const [resizePreview, setResizePreview] = useState<{ jobId: string, newStart: number, newDuration: number } | null>(null);

  // Panning State
  const [isPanning, setIsPanning] = useState(false);
  const panStartRef = useRef<{ x: number, y: number, scrollLeft: number, scrollTop: number } | null>(null);
  const hasMovedRef = useRef(false);
  
  // Spacebar Panning Mode
  const [isSpaceData, setIsSpaceDown] = useState(false);

  // Capacity Popover State (for day header conflict indicators)
  const [capacityPopoverDay, setCapacityPopoverDay] = useState<number | null>(null);

  // Job Context Menu State
  const [jobContextMenu, setJobContextMenu] = useState<{ job: ScheduledJob; x: number; y: number } | null>(null);

  // === VIRTUALIZATION: Lazy Loading for Hangar Rows ===
  const [visibleHangarRowIds, setVisibleHangarRowIds] = useState<Set<string>>(new Set());
  const hangarRowRefs = useRef<Map<string, HTMLDivElement>>(new Map());

  // --- Real Time Cursor State ---
  const [now, setNow] = useState(new Date());

  useEffect(() => {
    // Update 'now' every minute to track time of day positioning
    const interval = setInterval(() => setNow(new Date()), 60000);
    return () => clearInterval(interval);
  }, []);

  // Spacebar Listener for Hand Tool
  useEffect(() => {
      const handleKeyDown = (e: KeyboardEvent) => {
          if (e.code === 'Space' && !e.repeat && !(e.target instanceof HTMLInputElement)) {
              setIsSpaceDown(true);
          }
      };
      const handleKeyUp = (e: KeyboardEvent) => {
          if (e.code === 'Space') {
              setIsSpaceDown(false);
              setIsPanning(false); // Cancel pan on release
          }
      };
      window.addEventListener('keydown', handleKeyDown);
      window.addEventListener('keyup', handleKeyUp);
      return () => {
          window.removeEventListener('keydown', handleKeyDown);
          window.removeEventListener('keyup', handleKeyUp);
      };
  }, []);

  // Resize Handlers
  useEffect(() => {
      const handleGlobalMouseMove = (e: MouseEvent) => {
          if (resizingJob) {
              e.preventDefault();
              const deltaPixels = e.clientX - resizingJob.startX;
              const deltaDays = Math.round(deltaPixels / cellWidth);
              
              let newStart = resizingJob.originalStart;
              let newDuration = resizingJob.originalDuration;

              if (resizingJob.mode === 'start') {
                  // Dragging left handle
                  newStart = resizingJob.originalStart + deltaDays;
                  newDuration = resizingJob.originalDuration - deltaDays;
              } else {
                  // Dragging right handle
                  newDuration = resizingJob.originalDuration + deltaDays;
              }

              // Constraint Check
              if (newDuration < 1) {
                  if (resizingJob.mode === 'start') {
                      newStart = resizingJob.originalStart + resizingJob.originalDuration - 1;
                  }
                  newDuration = 1;
              }
              
              setResizePreview({ jobId: resizingJob.jobId, newStart, newDuration });
          }
      };

      const handleGlobalMouseUp = () => {
          if (resizingJob) {
              if (resizePreview && onJobResize) {
                  // Commit change
                  if (resizePreview.newStart !== resizingJob.originalStart || resizePreview.newDuration !== resizingJob.originalDuration) {
                      onJobResize(resizePreview.jobId, resizePreview.newStart, resizePreview.newDuration);
                  }
              }
              setResizingJob(null);
              setResizePreview(null);
          }
      };

      if (resizingJob) {
          window.addEventListener('mousemove', handleGlobalMouseMove);
          window.addEventListener('mouseup', handleGlobalMouseUp);
          document.body.style.cursor = 'col-resize';
      } else {
          document.body.style.cursor = '';
      }

      return () => {
          window.removeEventListener('mousemove', handleGlobalMouseMove);
          window.removeEventListener('mouseup', handleGlobalMouseUp);
          document.body.style.cursor = '';
      };
  }, [resizingJob, resizePreview, cellWidth, onJobResize]);

  const handleResizeStart = (e: React.MouseEvent, job: ScheduledJob, mode: 'start' | 'end') => {
      if (readOnly || scheduleEditMode || magicMode) return;
      e.preventDefault();
      e.stopPropagation();
      
      setResizingJob({
          jobId: job.id,
          mode,
          startX: e.clientX,
          originalStart: job.startDate,
          originalDuration: job.deadlineDays
      });
      setResizePreview({ jobId: job.id, newStart: job.startDate, newDuration: job.deadlineDays });
  };

  // Calculate float day index for real time (e.g. 10.5 for Noon on Jan 11th)
  const realTimeDayIndex = useMemo(() => {
    const startOfSim = new Date(START_YEAR, 0, 1);
    const diff = now.getTime() - startOfSim.getTime();
    return diff / (1000 * 60 * 60 * 24);
  }, [now]);

  // --- Initial Load Handling ---
  useEffect(() => {
      // Simulate layout calculation delay to allow spinner to show
      const timer = setTimeout(() => {
          setIsMounted(true);
      }, 300);
      return () => clearTimeout(timer);
  }, []);

  // === VIRTUALIZATION: IntersectionObserver for Lazy Loading Hangar Rows ===
  useEffect(() => {
    if (!scrollContainerRef.current) return;

    const observer = new IntersectionObserver(
      (entries) => {
        setVisibleHangarRowIds(prev => {
          const next = new Set(prev);
          entries.forEach(entry => {
            const hangarId = entry.target.getAttribute('data-hangar-id');
            if (hangarId) {
              if (entry.isIntersecting) {
                next.add(hangarId);
              } else {
                next.delete(hangarId);
              }
            }
          });
          return next;
        });
      },
      {
        root: scrollContainerRef.current,
        rootMargin: '100px 0px', // Pre-load rows 100px before they enter viewport
        threshold: 0
      }
    );

    // Observe all hangar row refs
    hangarRowRefs.current.forEach((element) => {
      observer.observe(element);
    });

    return () => observer.disconnect();
  }, [gameState.hangars, selectedBaseId, isMounted]); // Re-observe when hangars change

  // Perform Initial Scroll once DOM is ready
  useEffect(() => {
      if (isMounted && scrollContainerRef.current) {
           const container = scrollContainerRef.current;
           const viewportWidth = container.clientWidth;
           
           // Default to real-time date for initial view
           const targetDay = Math.floor(realTimeDayIndex) > 0 ? Math.floor(realTimeDayIndex) : gameState.day;
           
           let targetScroll = 0;

           if (dayAlignment === 'left') {
               targetScroll = targetDay * cellWidth;
           } else {
               const dayCenterX = STICKY_COL_WIDTH + (targetDay * cellWidth) + (cellWidth / 2);
               const availableWidth = viewportWidth - STICKY_COL_WIDTH;
               const screenCenterX = STICKY_COL_WIDTH + (availableWidth / 2);
               targetScroll = dayCenterX - screenCenterX;
           }
           
           // Use auto behavior for instant jump on load
           container.scrollTo({ left: Math.max(0, targetScroll), behavior: 'auto' });
      }
  }, [isMounted]); // Depend only on isMounted to run once after render

  // --- Virtualization Logic ---
  const updateVisibleRange = (e?: React.UIEvent<HTMLDivElement>) => {
      if (!scrollContainerRef.current) return;

      const scrollLeft = scrollContainerRef.current.scrollLeft;
      const clientWidth = scrollContainerRef.current.clientWidth;

      // Calculate indices
      const start = Math.floor(scrollLeft / cellWidth);
      const visibleCount = Math.ceil(clientWidth / cellWidth);

      // Add buffer (e.g., 15 days on each side)
      const buffer = 15;
      const newStart = Math.max(0, start - buffer);
      const newEnd = Math.min(TOTAL_DAYS, start + visibleCount + buffer);

      setVisibleRange({ start: newStart, end: newEnd });

      // Broadcast scroll to context for popped-out window sync
      if (e) syncedHandleScroll(e);

      if (onScroll) onScroll(scrollLeft);
      onVisibleDateRangeChange(start);
  };

  // Keep callback ref updated for context sync (allows other panels to trigger updateVisibleRange)
  useEffect(() => {
    updateCallbackRef.current = () => updateVisibleRange();
  });

  // --- Zoom Levels & Visual Thresholds ---
  const isMacroView = cellWidth < 14; // "Year/Quarter View" - No Text
  
  const getZoomLabel = (width: number) => {
      if (width <= 4) return "YEAR";
      if (width <= 14) return "QTR";
      if (width <= 30) return "MONTH";
      if (width <= 60) return "STD";
      if (width <= 100) return "DETAIL";
      return "OPS";
  };
  
  const scrollToDay = (dayIndex: number) => {
    if (scrollContainerRef.current) {
       const container = scrollContainerRef.current;
       const viewportWidth = container.clientWidth;
       
       let targetScroll = 0;
       if (dayAlignment === 'left') {
           targetScroll = dayIndex * cellWidth;
       } else {
           const dayCenterX = STICKY_COL_WIDTH + (dayIndex * cellWidth) + (cellWidth / 2);
           const availableWidth = viewportWidth - STICKY_COL_WIDTH;
           const screenCenterX = STICKY_COL_WIDTH + (availableWidth / 2);
           targetScroll = dayCenterX - screenCenterX;
       }
       
       container.scrollTo({ left: Math.max(0, targetScroll), behavior: 'smooth' });
    }
  };

  // Re-align when trigger updates
  useEffect(() => {
      if (isMounted) {
          scrollToDay(focusedDayIndex ?? gameState.day);
      }
  }, [scrollToTodayTrigger, focusedDayIndex]); 

  useEffect(() => {
    // Only auto-scroll if paused and explicitly following focus logic
    // Removing auto-center on every tick to allow free exploration
    if (isMounted && !gameState.paused && scrollContainerRef.current) {
      const container = scrollContainerRef.current;
      const viewWidth = container.clientWidth;
      const scrollLeft = container.scrollLeft;
      
      const targetDay = focusedDayIndex ?? gameState.day;

      const indicatorPos = STICKY_COL_WIDTH + (targetDay * cellWidth);
      const screenPos = indicatorPos - scrollLeft;
      // Keep it in view if it moves off screen
      if (screenPos > viewWidth * 0.9 || screenPos < STICKY_COL_WIDTH) {
         scrollToDay(targetDay);
      }
    }
  }, [gameState.day, gameState.paused, isMounted]);

  // --- Panning Handlers ---
  const handleMouseDown = (e: React.MouseEvent) => {
      // Allow Middle Click OR Left Click 
      // ENABLED: Canvas style panning on left click
      const isPanClick = e.button === 1 || e.button === 0; 
      
      if (!isPanClick) return;
      
      // If Left Click, ensure we aren't interacting with controls
      if (e.button === 0) {
          const target = e.target as HTMLElement;
          // Allow normal interaction with jobs/inputs/resize handles
          // Also disable pan if edit mode is active (to allow painting cells)
          if (target.closest('[draggable="true"]') || target.closest('button') || target.closest('input') || scheduleEditMode || target.dataset.resizeHandle) {
              hasMovedRef.current = false;  // Reset to ensure click handlers work after panning
              return;
          }
      }

      panStartRef.current = {
          x: e.clientX,
          y: e.clientY,
          scrollLeft: scrollContainerRef.current ? scrollContainerRef.current.scrollLeft : 0,
          scrollTop: scrollContainerRef.current ? scrollContainerRef.current.scrollTop : 0
      };
      hasMovedRef.current = false;
      
      // If panning, we might want to change cursor immediately
      // But we wait for movement threshold
  };

  const handleMouseMove = (e: React.MouseEvent) => {
      if (!panStartRef.current || !scrollContainerRef.current) return;
      
      // Only process if we determined this was a pan action (middle click or space or background)
      const isPanMode = (e.buttons === 4 || e.buttons === 1) && !scheduleEditMode && !draggedJob && !resizingJob;

      if (!isPanMode) return;

      const deltaX = e.clientX - panStartRef.current.x;
      const deltaY = e.clientY - panStartRef.current.y;
      
      // Threshold check to distinguish click from drag
      if (Math.abs(deltaX) > 5 || Math.abs(deltaY) > 5) {
          hasMovedRef.current = true;
          if (!isPanning) setIsPanning(true);
      }

      if (hasMovedRef.current) {
          e.preventDefault();
          scrollContainerRef.current.scrollLeft = panStartRef.current.scrollLeft - deltaX;
          scrollContainerRef.current.scrollTop = panStartRef.current.scrollTop - deltaY;
      }
  };

  const handleMouseUp = () => {
      panStartRef.current = null;
      if (isPanning) {
          // Defer state update to avoid conflict with click handlers running immediately
          setTimeout(() => setIsPanning(false), 0);
      }
  };

  const handleDayCellClick = (dayIndex: number) => {
      // Only trigger if we haven't dragged significantly
      if (!hasMovedRef.current) {
          onDayClick(dayIndex);
      }
  };

  // --- Calculations ---

  // === PERFORMANCE: Pre-computed lookup maps and caches ===

  // Holiday lookup - O(1) instead of O(n) per day
  const holidayLookup = useMemo(() => ({
    enabledSet: new Set(gameState.holidays.filter(h => h.enabled).map(h => h.dayIndex)),
    byDay: new Map(gameState.holidays.filter(h => h.enabled).map(h => [h.dayIndex, h]))
  }), [gameState.holidays]);

  // Filter hangars based on selected base
  const visibleHangars = useMemo(() => {
      if (!selectedBaseId || selectedBaseId === 'ALL') return gameState.hangars;
      return gameState.hangars.filter(h => h.baseId === selectedBaseId);
  }, [gameState.hangars, selectedBaseId]);

  // === PERFORMANCE: Pre-computed job hours cache - O(1) lookup instead of O(days) per call ===
  const jobHoursCache = useMemo(() => {
    const cache = new Map<string, Map<number, number>>();

    gameState.schedule.forEach(job => {
      const dayHoursMap = new Map<number, number>();

      // Pre-calculate total weight once per job
      let totalWeight = 0;
      const weights: number[] = [];

      for (let i = 0; i < job.deadlineDays; i++) {
        let w = 1;
        if (job.dailyEffort && job.dailyEffort[i] !== undefined) {
          w = job.dailyEffort[i];
        } else if (job.nonWorkDays?.includes(i)) {
          w = 0;
        }
        weights[i] = w;
        totalWeight += w;
      }

      if (totalWeight === 0) {
        cache.set(job.id, dayHoursMap);
        return;
      }

      // Pre-calculate hours for each day offset
      for (let dayOffset = 0; dayOffset < job.deadlineDays; dayOffset++) {
        const dayWeight = weights[dayOffset];
        const hours = (dayWeight / totalWeight) * job.estimatedHours;
        dayHoursMap.set(dayOffset, hours);
      }

      cache.set(job.id, dayHoursMap);
    });

    return cache;
  }, [gameState.schedule]);

  // Calculate Load Distribution Helper - now O(1) lookup
  const getJobHoursForDay = (job: ScheduledJob, dayOffset: number) => {
    return jobHoursCache.get(job.id)?.get(dayOffset) ?? 0;
  };

  // Use centralized capacity data hook
  const visibleHangarIds = useMemo(() => visibleHangars.map(h => h.id), [visibleHangars]);
  const { dailyCapacities, dailyLoads, getJobCapacityStatus } = useCapacityData(gameState, {
    baseId: selectedBaseId,
    hangarIds: visibleHangarIds
  });

  // Helper to get jobs contributing to a specific day's load
  const getJobsForDay = (dayIndex: number): { job: ScheduledJob; hoursOnDay: number }[] => {
    const result: { job: ScheduledJob; hoursOnDay: number }[] = [];

    gameState.schedule.forEach(job => {
      const startDay = job.startDate;
      const endDay = job.startDate + job.deadlineDays;

      // Check if this day falls within the job's range
      if (dayIndex >= startDay && dayIndex < endDay) {
        const dayOffset = dayIndex - startDay;

        // Check if this day is a work day (not blocked)
        if (!job.nonWorkDays?.includes(dayOffset)) {
          // Calculate hours for this day
          const effort = job.dailyEffort?.[dayOffset] ?? 1;
          const workDays = job.deadlineDays - (job.nonWorkDays?.length || 0);
          const dailyHours = workDays > 0 ? (job.estimatedHours / workDays) * effort : 0;

          if (dailyHours > 0) {
            result.push({ job, hoursOnDay: dailyHours });
          }
        }
      }
    });

    return result.sort((a, b) => b.hoursOnDay - a.hoursOnDay);
  };

  // === PERFORMANCE: Memoized hangar layout cache - prevents O(N²) recalculation on every render ===
  const hangarLayoutCache = useMemo(() => {
    const cache = new Map<string, { jobs: ScheduledJob[], lanes: ScheduledJob[][], jobLaneMap: Map<string, number> }>();

    visibleHangars.forEach(hangar => {
      const jobs = gameState.schedule
        .filter(j => j.hangarId === hangar.id)
        .sort((a, b) => a.startDate - b.startDate);

      const lanes: ScheduledJob[][] = [];
      const jobLaneMap = new Map<string, number>();

      jobs.forEach(job => {
        let placed = false;
        for (let i = 0; i < lanes.length; i++) {
          const lane = lanes[i];
          const lastJob = lane[lane.length - 1];
          if (job.startDate >= (lastJob.startDate + lastJob.deadlineDays)) {
            lane.push(job);
            jobLaneMap.set(job.id, i);
            placed = true;
            break;
          }
        }
        if (!placed) {
          lanes.push([job]);
          jobLaneMap.set(job.id, lanes.length - 1);
        }
      });

      cache.set(hangar.id, { jobs, lanes, jobLaneMap });
    });

    return cache;
  }, [gameState.schedule, visibleHangars]);

  // Accessor function using cached layout
  const getHangarLayout = (hangarId: string) => {
    return hangarLayoutCache.get(hangarId) || { jobs: [], lanes: [], jobLaneMap: new Map() };
  };

  // === PERFORMANCE: Debounced drag-over using requestAnimationFrame ===
  const pendingHoverRef = useRef<{ h: string, d: number } | null>(null);
  const rafIdRef = useRef<number | null>(null);

  const handleDragOver = (e: React.DragEvent, hangarId: string, dayIndex: number) => {
    if (scheduleEditMode || readOnly || magicMode) return;
    e.preventDefault();
    e.dataTransfer.dropEffect = "move";

    // Store pending update
    pendingHoverRef.current = { h: hangarId, d: dayIndex };

    // Debounce using RAF - limits to 60 updates/sec max
    if (!rafIdRef.current) {
      rafIdRef.current = requestAnimationFrame(() => {
        if (pendingHoverRef.current) {
          const { h, d } = pendingHoverRef.current;
          if (hoveredCell?.h !== h || hoveredCell?.d !== d) {
            setHoveredCell({ h, d });
          }
        }
        rafIdRef.current = null;
      });
    }
  };

  // Cleanup RAF on unmount
  useEffect(() => {
    return () => {
      if (rafIdRef.current) {
        cancelAnimationFrame(rafIdRef.current);
      }
    };
  }, []);

  const handleDragLeave = () => {
      // Removing per-cell clearing to prevent flickering
      // setHoveredCell(null); 
  };

  const handleDrop = (e: React.DragEvent, hangarId: string, dayIndex: number) => {
    if (scheduleEditMode || readOnly || magicMode) return;
    e.preventDefault();
    setHoveredCell(null);
    const jobId = e.dataTransfer.getData('jobId');
    if (jobId) onJobDrop(jobId, hangarId, dayIndex);
  };

  // --- Row Reorder Handlers ---
  const handleRowDragStart = (e: React.DragEvent, hangarId: string) => {
      e.dataTransfer.setData('hangarId', hangarId);
      e.dataTransfer.effectAllowed = 'move';
      setDraggedHangarId(hangarId);
  };

  const handleRowDragOver = (e: React.DragEvent) => {
      e.preventDefault();
  };

  const handleRowDrop = (e: React.DragEvent, targetHangarId: string) => {
      e.preventDefault();
      const sourceHangarId = e.dataTransfer.getData('hangarId');
      if (sourceHangarId && sourceHangarId !== targetHangarId && onHangarReorder) {
          onHangarReorder(sourceHangarId, targetHangarId);
      }
      setDraggedHangarId(null);
  };

  // --- Slider Interaction Handlers ---
  const handleSliderMouseDown = (e: React.MouseEvent, job: ScheduledJob, offset: number) => {
      if (!scheduleEditMode) return;
      
      // BLOCK TOOL: Toggle day directly, no dragging
      if (editTool === 'block') {
          e.preventDefault();
          e.stopPropagation();
          onJobDayToggle(job.id, offset);
          return;
      }

      // DISTRIBUTE TOOL: Handle dragging
      e.preventDefault();
      e.stopPropagation();
      setIsDraggingSlider(true);
      setSliderTarget({ jobId: job.id, offset });
      updateSliderValue(e, job, offset);
  };

  const updateSliderValue = (e: MouseEvent | React.MouseEvent, job: ScheduledJob, offset: number) => {
      const el = document.getElementById(`effort-slider-${job.id}-${offset}`);
      if (!el) return;
      
      // In 'distribute' mode, we are distributing HOURS, not just generic weights.
      // The max range for the slider should allow going up to the total estimated hours (though unrealistic)
      // to allow full flexibility. Let's cap visual at EstimatedHours or a sensible max like 24h.
      
      const maxVisualHours = Math.min(job.estimatedHours, 24); 

      const rect = el.getBoundingClientRect();
      const relativeY = e.clientY - rect.top;
      const height = rect.height;
      
      // Invert because bottom is 0%
      let percent = 1 - (relativeY / height);
      percent = Math.max(0, Math.min(1, percent));
      
      // Calculate new value based on scale
      let newValue = percent * maxVisualHours;
      
      // Rounding for UX
      newValue = Math.round(newValue * 2) / 2; // 0.5h increments

      if (onJobEffortChange) {
          onJobEffortChange(job.id, offset, newValue);
      }

      // Update Tooltip Data - Note: We show what the redistribution WOULD result in
      // But since onJobEffortChange updates state, we can just calculate current value for tooltip
      
      setSliderTooltip({
          x: e.clientX,
          y: e.clientY,
          percent,
          hours: newValue,
          maxAllowed: job.estimatedHours
      });
  };

  useEffect(() => {
      const handleGlobalMouseMove = (e: MouseEvent) => {
          if (isDraggingSlider && sliderTarget) {
              const job = gameState.schedule.find(j => j.id === sliderTarget.jobId);
              if (job) {
                  updateSliderValue(e, job, sliderTarget.offset);
              }
          }
      };

      const handleGlobalMouseUp = () => {
          if (isDraggingSlider) {
              setIsDraggingSlider(false);
              setSliderTarget(null);
              setSliderTooltip(null);
          }
      };

      if (isDraggingSlider) {
          window.addEventListener('mousemove', handleGlobalMouseMove);
          window.addEventListener('mouseup', handleGlobalMouseUp);
      }

      return () => {
          window.removeEventListener('mousemove', handleGlobalMouseMove);
          window.removeEventListener('mouseup', handleGlobalMouseUp);
      };
  }, [isDraggingSlider, sliderTarget, gameState.schedule, dailyCapacities, dailyLoads]); 


  // --- Renderers ---

  // Generates the dynamic quarters for the timeline range (2024-2027)
  const renderQuarters = () => {
    const quarters = [];
    let dayAccumulator = 0;
    
    // Assuming TOTAL_DAYS covers full years 2024, 25, 26, 27
    for (let year = START_YEAR; year < START_YEAR + 4; year++) {
        const isLeap = (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
        
        // Q1: Jan, Feb, Mar
        const q1Days = 31 + (isLeap ? 29 : 28) + 31;
        quarters.push({ label: `Q1 ${year}`, days: q1Days, start: dayAccumulator });
        dayAccumulator += q1Days;

        // Q2: Apr, May, Jun
        const q2Days = 30 + 31 + 30;
        quarters.push({ label: `Q2 ${year}`, days: q2Days, start: dayAccumulator });
        dayAccumulator += q2Days;

        // Q3: Jul, Aug, Sep
        const q3Days = 31 + 31 + 30;
        quarters.push({ label: `Q3 ${year}`, days: q3Days, start: dayAccumulator });
        dayAccumulator += q3Days;

        // Q4: Oct, Nov, Dec
        const q4Days = 31 + 30 + 31;
        quarters.push({ label: `Q4 ${year}`, days: q4Days, start: dayAccumulator });
        dayAccumulator += q4Days;
    }

    return (
        <div className="relative h-6 bg-[#0d0e10] border-b border-white/[0.06]" style={{ width: TOTAL_DAYS * cellWidth }}>
            {quarters.map((q, i) => (
                <div
                    key={i}
                    className="absolute top-0 h-full flex items-center justify-center text-[10px] font-semibold text-[#6b7280] border-r border-white/[0.06] uppercase tracking-wide overflow-hidden px-2 whitespace-nowrap"
                    style={{
                        left: q.start * cellWidth,
                        width: q.days * cellWidth
                    }}
                >
                    {q.label}
                </div>
            ))}
        </div>
    );
  };

  // Dedicated Months Row
  const renderMonthsRow = () => {
    const months = [];
    let dayAccumulator = 0;
    const viewStart = visibleRange.start * cellWidth;
    const viewEnd = visibleRange.end * cellWidth;
    
    for (let year = START_YEAR; year < START_YEAR + 4; year++) {
        for (let month = 0; month < 12; month++) {
            const daysInMonth = new Date(year, month + 1, 0).getDate();
            const monthName = MONTH_NAMES[month];
            
            const startPx = dayAccumulator * cellWidth;
            const widthPx = daysInMonth * cellWidth;
            const endPx = startPx + widthPx;
            
            // Only render if within visible range (plus buffer)
            if (endPx > viewStart && startPx < viewEnd) {
                 months.push(
                    <div
                        key={`${year}-${month}`}
                        className="absolute top-0 h-full border-r border-white/[0.06] flex items-center px-2 overflow-hidden bg-[#0d0e10]/50 whitespace-nowrap"
                        style={{ left: startPx, width: widthPx }}
                    >
                        <span className="text-[10px] font-semibold text-zinc-400/80 uppercase tracking-wide sticky left-2">
                             {cellWidth > 2 ? `${monthName} ${year}` : ''}
                        </span>
                    </div>
                 );
            }
            dayAccumulator += daysInMonth;
        }
    }

    return (
        <div className="relative h-6 bg-[#141517] border-b border-white/[0.06]" style={{ width: TOTAL_DAYS * cellWidth }}>
            {months}

            {/* Report Range Indicator */}
            {scenarioStart !== undefined && scenarioEnd !== undefined && (
               <div
                  className="absolute top-0 h-full bg-white/10 border-t-2 border-white/40 z-10 pointer-events-none"
                  style={{
                      left: scenarioStart * cellWidth,
                      width: ((scenarioEnd - scenarioStart) + 1) * cellWidth
                  }}
               />
            )}
        </div>
    );
  };

  const renderVisibleDays = () => {
    const days = [];
    
    // Zoom dependent thresholds
    const showDayNumber = cellWidth >= 14;
    const showCapacity = cellWidth >= 32;
    const showFullDayName = cellWidth >= 80;

    for (let i = visibleRange.start; i < visibleRange.end; i++) {
      const date = getDateForDay(i);
      const isWeekend = date.getDay() === 0 || date.getDay() === 6;
      
      // PERFORMANCE: Use pre-computed lookup instead of .find()
      const holiday = holidayLookup.byDay.get(i);
      const isHoliday = !!holiday;

      const isToday = i === gameState.day;
      const isMonthStart = date.getDate() === 1;
      const dayOfWeek = date.getDay(); // 0=Sun
      
      const dayNameShort = ['S','M','T','W','T','F','S'][dayOfWeek];
      const dayNameFull = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'][dayOfWeek];

      // Calculate Capacity using memoized array for consistency
      const dailyCapacity = dailyCapacities[i] || 0;
      
      const load = dailyLoads[i] || 0;
      let utilization = 0;
      if (dailyCapacity > 0) {
          utilization = (load / dailyCapacity) * 100;
      } else if (load > 0) {
          // No capacity but load exists = Overload
          utilization = 110; 
      }
      
      let borderClass = 'border-r border-white/[0.06]';
      if (isMacroView) {
          borderClass = isMonthStart ? 'border-r border-white/[0.1]' : '';
      }

      let bgClass = '';
      if (isMacroView) {
           bgClass = isMonthStart ? 'bg-[#141517]' : i % 2 === 0 ? 'bg-[#0d0e10]' : 'bg-[#0d0e10]';
      } else {
           // Enhanced Contrast for Holidays and Weekends
           if (isHoliday) bgClass = 'bg-[#c4626a]/10 text-[#c4626a]';
           else if (isWeekend) bgClass = 'bg-white/[0.02] text-[#6b7280]';
           else bgClass = 'bg-[#08090a] text-[#6b7280]';
      }

      days.push(
        <div
          key={i}
          onClick={() => handleDayCellClick(i)}
          className={`
            absolute top-0 bottom-0 flex flex-col items-center justify-center text-xs select-none group cursor-pointer hover:bg-[#1a1b1e]
            ${bgClass} ${borderClass}
            ${isToday ? 'bg-white/10 border-t-2 border-t-amber-500' : ''}
          `}
          style={{
              left: i * cellWidth,
              width: cellWidth
          }}
          title={holiday ? holiday.name : undefined}
        >
          {cellWidth >= 32 ? (
              // Standard View
              <div className="flex flex-col items-center justify-center h-full w-full py-0.5">
                   <span className="text-[9px] uppercase font-semibold leading-none mb-0.5 opacity-80">
                      {showFullDayName ? dayNameFull : dayNameShort}
                   </span>

                   <span className={`text-sm ${isToday ? 'font-semibold text-zinc-400' : 'font-medium opacity-80'} leading-none`}>
                      {date.getDate()}
                   </span>

                   {/* Capacity Bar with Warning Indicator */}
                   {showCapacity && (
                       <div className="w-full px-1.5 mt-1 relative">
                            {(() => {
                                // Check explicit equality with tolerance for floats
                                const isFull = Math.abs(load - dailyCapacity) < 0.1 && dailyCapacity > 0;
                                const bufferThreshold = 100 - (gameState.capacityBufferPercent || 15);
                                const hasConflict = utilization > bufferThreshold && dailyCapacity > 0;
                                const isCritical = utilization > 100;

                                let barColor = 'bg-amber-500';
                                if (isFull) barColor = 'bg-[#3dae6c]';
                                else if (isCritical) barColor = 'bg-[#c4626a]';
                                else if (utilization < bufferThreshold) barColor = 'bg-[#3dae6c]';

                                return (
                                    <>
                                        <div
                                            className={`w-full h-0.5 bg-white/[0.06] overflow-hidden rounded-full ${hasConflict ? 'cursor-pointer' : ''}`}
                                            onClick={hasConflict ? (e) => {
                                                e.stopPropagation();
                                                setCapacityPopoverDay(capacityPopoverDay === i ? null : i);
                                            } : undefined}
                                        >
                                            <div
                                                className={`h-full ${barColor}`}
                                                style={{ width: `${Math.min(utilization, 100)}%` }}
                                            />
                                        </div>
                                        {/* Warning Icon */}
                                        {hasConflict && (
                                            <div
                                                className={`absolute -top-1.5 -right-1 cursor-pointer ${isCritical ? 'text-[#c4626a]' : 'text-amber-500'}`}
                                                onClick={(e) => {
                                                    e.stopPropagation();
                                                    setCapacityPopoverDay(capacityPopoverDay === i ? null : i);
                                                }}
                                            >
                                                <AlertTriangle size={10} />
                                            </div>
                                        )}
                                        {/* Capacity Popover */}
                                        {capacityPopoverDay === i && (
                                            <div
                                                className="absolute z-50 top-full left-1/2 -translate-x-1/2 mt-1 min-w-[200px] bg-[#1a1b1e] border border-[#2a2b2e] rounded-lg shadow-xl p-3"
                                                onClick={(e) => e.stopPropagation()}
                                            >
                                                <div className="flex items-center justify-between mb-2">
                                                    <span className={`text-xs font-semibold ${isCritical ? 'text-[#c4626a]' : 'text-amber-500'}`}>
                                                        {isCritical ? 'Over Capacity' : 'Capacity Warning'}
                                                    </span>
                                                    <button
                                                        className="text-[#6b7280] hover:text-white"
                                                        onClick={() => setCapacityPopoverDay(null)}
                                                    >
                                                        <X size={12} />
                                                    </button>
                                                </div>
                                                <div className="text-[10px] text-[#6b7280] mb-2">
                                                    {load.toFixed(1)}h / {dailyCapacity.toFixed(1)}h ({utilization.toFixed(0)}%)
                                                </div>
                                                <div className="space-y-1 max-h-[120px] overflow-y-auto">
                                                    {getJobsForDay(i).map(({ job, hoursOnDay }) => (
                                                        <div
                                                            key={job.id}
                                                            className="flex items-center justify-between text-[10px] py-0.5 px-1 rounded bg-white/[0.03] hover:bg-white/[0.06] cursor-pointer"
                                                            onClick={() => onJobClick(job)}
                                                        >
                                                            <span className="text-white truncate max-w-[120px]">{job.customer}</span>
                                                            <span className="text-[#6b7280] ml-2">{hoursOnDay.toFixed(1)}h</span>
                                                        </div>
                                                    ))}
                                                </div>
                                            </div>
                                        )}
                                    </>
                                );
                            })()}
                       </div>
                   )}
              </div>
          ) : cellWidth >= 14 ? (
              // Compact View (Number only)
              <div className="flex flex-col items-center justify-center h-full w-full">
                  <span className={`text-[10px] font-semibold ${isToday ? 'text-zinc-400' : ''}`}>{date.getDate()}</span>
              </div>
          ) : (
              // Macro View (Just visual blocks)
              null
          )}
        </div>
      );
    }
    return days;
  };

  if (!isMounted) {
      return (
          <div className="flex-1 flex flex-col items-center justify-center bg-[#08090a] relative h-full">
              <Loader2 size={48} className="text-zinc-400 animate-spin mb-4" />
              <h3 className="text-lg font-semibold text-zinc-400 tracking-wide">Loading Timeline...</h3>
          </div>
      );
  }

  return (
    <div className="flex-1 flex flex-col relative overflow-hidden bg-[#08090a] select-none h-full w-full">

      <div className="absolute bottom-4 right-4 z-50">
          <NotificationCenter notifications={gameState.notifications} />
      </div>

      {/* Floating Tooltip for Slider */}
      {isDraggingSlider && sliderTooltip && (
          <div
              className="fixed z-[9999] bg-[#141517] text-white text-xs p-2 rounded-lg border border-white/40/50 shadow-xl pointer-events-none flex flex-col items-center"
              style={{
                  left: sliderTooltip.x + 15,
                  top: sliderTooltip.y - 15
              }}
          >
              <span className="font-semibold text-zinc-400">
                  {editTool === 'distribute' ? 'Redistributing:' : ''} {sliderTooltip.hours.toFixed(1)} hrs
              </span>
              {sliderTooltip.maxAllowed !== undefined && (
                  <span className="text-[9px] text-[#6b7280]">Total Job: {sliderTooltip.maxAllowed.toFixed(1)}h</span>
              )}
          </div>
      )}

      <div 
        ref={scrollContainerRef}
        onScroll={updateVisibleRange}
        // Explicit vertical scrollbar enabled
        className={`flex-1 overflow-scroll relative custom-scrollbar overscroll-x-none ${isPanning ? 'cursor-grabbing' : 'cursor-default'}`}
        onMouseDown={handleMouseDown}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        onMouseMove={handleMouseMove}
        style={{ height: '100%', width: '100%' }}
      >
        {/* Sticky Header Group */}
        <div className="sticky top-0 z-50 min-w-max shadow-lg bg-[#0d0e10] border-b border-white/[0.06] flex flex-col">

           {/* Edit Mode Indicator Banner */}
           {scheduleEditMode && (
               <div className={`flex items-center justify-center gap-4 py-1.5 px-4 text-xs font-medium ${
                   editTool === 'distribute'
                     ? 'bg-amber-500/20 text-amber-300 border-b border-amber-500/30'
                     : 'bg-rose-500/20 text-rose-300 border-b border-rose-500/30'
               }`}>
                   <div className="flex items-center gap-2">
                       {editTool === 'distribute' ? (
                           <>
                               <SlidersHorizontal size={14} className="text-amber-400" />
                               <span>Edit Mode: <strong>Distribute Hours</strong> - Click days on a job to adjust effort allocation</span>
                           </>
                       ) : (
                           <>
                               <CalendarOff size={14} className="text-rose-400" />
                               <span>Edit Mode: <strong>Block Days</strong> - Click days on a job to mark as non-work days</span>
                           </>
                       )}
                   </div>
                   <span className="text-[10px] opacity-70 flex items-center gap-1">
                       <kbd className="px-1.5 py-0.5 bg-white/10 rounded text-[10px] border border-white/10">Esc</kbd>
                       <span>to exit</span>
                   </span>
               </div>
           )}

           {/* Row 1: Quarters & Zoom Indicator */}
           <div className="flex border-b border-white/[0.06]">
               <div
                  className="sticky left-0 z-50 bg-[#0d0e10] border-r border-white/[0.08] h-6 shrink-0 flex items-center justify-between px-2 text-[9px] font-semibold text-[#9ca3af]"
                  style={{ width: STICKY_COL_WIDTH, minWidth: STICKY_COL_WIDTH }}
               >
                   <span className="uppercase tracking-wide text-zinc-400 flex items-center gap-1">
                       TIMELINE
                       <Tooltip content="Job Colors: Violet = In Progress, Rose = AOG/Authorized, Emerald = Completed, Cyan = Ready to Ship. Red line = Now." position="bottom">
                           <HelpCircle size={10} className="text-[#4b5563] hover:text-zinc-400 cursor-help transition-colors" />
                       </Tooltip>
                   </span>
                   <span className="text-zinc-400 bg-white/10 px-1 rounded border border-white/40/20 flex items-center gap-1">
                      {getZoomLabel(cellWidth)}
                   </span>
               </div>
               {renderQuarters()}
           </div>

           {/* Row 2: Months (Dedicated) */}
           <div className="flex border-b border-white/[0.06]">
               <div
                  className="sticky left-0 z-40 bg-[#141517] border-r border-white/[0.08] h-6 shrink-0 flex items-center justify-center text-[9px] text-[#6b7280] font-semibold uppercase tracking-wide"
                  style={{ width: STICKY_COL_WIDTH, minWidth: STICKY_COL_WIDTH }}
               >
                  Month
               </div>
               {renderMonthsRow()}
           </div>

           {/* Row 3: Days */}
           <div className="flex border-b border-white/[0.06] bg-[#0d0e10]">
               {/* Days Label */}
               <div
                  className="sticky left-0 z-40 bg-[#0d0e10] border-r border-white/[0.08] h-10 flex flex-col justify-center items-center text-[#6b7280] font-semibold text-xs shadow-[4px_0_10px_-3px_rgba(0,0,0,0.3)] gap-1 overflow-hidden px-2"
                  style={{ width: STICKY_COL_WIDTH, minWidth: STICKY_COL_WIDTH }}
               >
                  <span className="text-[9px] text-[#4b5563] font-mono uppercase flex items-center gap-1">
                      Days
                      <Tooltip content="Capacity bar: Green = under 80% utilized, Amber = 80-100%, Red = overbooked. Bars show daily labor utilization." position="right">
                          <HelpCircle size={10} className="text-[#4b5563] hover:text-zinc-400 cursor-help transition-colors" />
                      </Tooltip>
                  </span>
               </div>

               {/* The Virtualized Days Track */}
               <div className="relative h-10" style={{ width: TOTAL_DAYS * cellWidth }}>
                 {renderVisibleDays()}
               </div>
           </div>
        </div>

        {/* Grid Body */}
        <div className="min-w-max relative bg-[#08090a]" ref={gridRef}>

           {/* Edit Mode Column Highlighter */}
           {scheduleEditMode && hoveredEditDayIndex !== null && (
               <div
                 className="absolute top-0 bottom-0 z-[40] pointer-events-none bg-white/10 border-x border-white/40/30"
                 style={{
                    left: STICKY_COL_WIDTH + (hoveredEditDayIndex * cellWidth),
                    width: cellWidth
                 }}
               >
                  {/* Index Label */}
                  <div className="sticky top-0 w-full flex justify-center pt-1">
                      <div className="bg-[#141517]/90 border border-white/40/50 text-zinc-400 text-[9px] font-semibold px-1.5 py-0.5 rounded shadow-sm backdrop-blur-sm">
                          D{hoveredEditDayIndex + 1}
                      </div>
                  </div>
               </div>
           )}

           {/* Real-time "Now" Line */}
           {realTimeDayIndex >= 0 && realTimeDayIndex < TOTAL_DAYS && (
               <div
                 className="absolute top-0 bottom-0 z-20 pointer-events-none border-l-2 border-[#c4626a]"
                 style={{
                    left: STICKY_COL_WIDTH + (realTimeDayIndex * cellWidth),
                 }}
               >
                  <div className="absolute -top-12 left-0 -translate-x-1/2 bg-[#c4626a] text-white text-[9px] font-semibold px-1.5 py-0.5 rounded-sm whitespace-nowrap z-50 flex flex-col items-center leading-none gap-0.5">
                    <span>NOW</span>
                    <span className="font-mono text-[8px] opacity-90">{now.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit', hour12: false})}</span>
                  </div>
               </div>
           )}

           {/* Configurable Progress Cursors */}
           {gameState.cursors.map(cursor => {
               if (!cursor.enabled) return null;
               // Sync with Real-Time Today (Math.floor to align with grid day)
               const baseDay = Math.floor(realTimeDayIndex);
               const targetDay = baseDay + cursor.dayOffset;
               
               // Only render if roughly within bounds
               if (targetDay < visibleRange.start || targetDay > visibleRange.end) return null;

               return (
                   <div
                       key={cursor.id}
                       className={`absolute top-0 bottom-0 z-30 pointer-events-none border-l border-dashed opacity-70 ${cursor.color.replace('bg-', 'border-')}`}
                       style={{
                           left: STICKY_COL_WIDTH + (targetDay * cellWidth) + (cellWidth / 2)
                       }}
                   >
                       {/* Label positioned inside the grid (top-2) instead of above (-top-3) */}
                       <div className={`absolute top-2 left-0 -translate-x-1/2 ${cursor.color} text-white text-[9px] font-bold px-1.5 py-0.5 rounded-sm shadow-sm whitespace-nowrap z-50 uppercase tracking-wider flex items-center gap-1`}>
                           {cursor.label}
                           <span className="opacity-75 text-[8px]">({getDateForDay(targetDay).getDate()})</span>
                       </div>
                   </div>
               );
           })}

           {/* Selected Day Line (Game Time) */}
           <div
             className="absolute top-0 bottom-0 z-20 pointer-events-none border-l border-amber-500"
             style={{
                left: STICKY_COL_WIDTH + (gameState.day * cellWidth) + (cellWidth / 2),
                transitionProperty: 'left',
                transitionDuration: gameState.paused ? '300ms' : `${gameState.speed}ms`,
                transitionTimingFunction: gameState.paused ? 'cubic-bezier(0.4, 0, 0.2, 1)' : 'linear'
             }}
           >
              <div className="absolute -top-3 left-0 -translate-x-1/2 bg-amber-500 text-[#08090a] text-[9px] font-semibold px-1.5 rounded-sm whitespace-nowrap z-50">
                ACTUAL
              </div>
           </div>

           {visibleHangars.length === 0 && (
               <EmptyState
                   icon={Warehouse}
                   title="No hangars configured"
                   description="Add hangars in the Configuration panel to start scheduling jobs on the timeline."
                   size="lg"
               />
           )}

           {visibleHangars.map((hangar) => {
             const { jobs, lanes, jobLaneMap } = getHangarLayout(hangar.id);
             const laneCount = Math.max(1, lanes.length);
             // Adjusted height calculation for simplified view
             const rowHeight = Math.max(BASE_ROW_HEIGHT, (laneCount * (JOB_HEIGHT + JOB_GUTTER)) + (simplifiedViewMode ? 10 : 24));

             // === VIRTUALIZATION: Check if row is visible ===
             const isRowVisible = visibleHangarRowIds.has(hangar.id) || visibleHangarRowIds.size === 0;

             return (
             <div
               key={hangar.id}
               ref={(el) => {
                 if (el) {
                   hangarRowRefs.current.set(hangar.id, el);
                 } else {
                   hangarRowRefs.current.delete(hangar.id);
                 }
               }}
               data-hangar-id={hangar.id}
               className="flex relative transition-colors group/row border-b border-white/[0.06]"
               style={{ height: rowHeight }}
             >
               {/* === VIRTUALIZATION: Render placeholder for off-screen rows === */}
               {!isRowVisible ? (
                 <div className="w-full bg-[#0d0e10]" style={{ height: rowHeight }} />
               ) : (
               <>
               {/* Sticky Hangar Name (Draggable Handle) */}
               <div
                  draggable={!readOnly}
                  onDragStart={(e) => !readOnly && handleRowDragStart(e, hangar.id)}
                  onDragOver={handleRowDragOver}
                  onDrop={(e) => handleRowDrop(e, hangar.id)}
                  className={`
                    sticky left-0 z-40 bg-[#0d0e10] border-r border-white/[0.08] flex flex-col justify-center p-2 shadow-[4px_0_10px_-3px_rgba(0,0,0,0.3)]
                    ${!readOnly ? 'cursor-grab active:cursor-grabbing hover:bg-[#141517]' : 'cursor-default'} transition-colors
                    ${draggedHangarId === hangar.id ? 'opacity-50' : ''}
                  `}
                  style={{ width: STICKY_COL_WIDTH, minWidth: STICKY_COL_WIDTH }}
               >
                 {!readOnly && (
                     <div className="absolute left-1 top-1/2 -translate-y-1/2 text-[#4b5563] opacity-0 group-hover/row:opacity-100 transition-opacity">
                        <GripVertical size={14} />
                     </div>
                 )}
                 <div className="pl-3">
                    <div className="font-semibold text-sm text-[#e8e8e8] tracking-wide truncate" title={hangar.name}>{hangar.name}</div>
                    <div className="text-[10px] text-[#6b7280] uppercase">{hangar.size}</div>
                    <div className="text-[9px] text-[#4b5563] mt-1 truncate" title="Base Location">
                        {gameState.bases.find(b => b.id === hangar.baseId)?.name || 'Unassigned'}
                    </div>
                 </div>
               </div>

               {/* Virtualized Grid Cells */}
               <div className="relative z-0" style={{ width: TOTAL_DAYS * cellWidth }}>
                 {(() => {
                    const cells = [];
                    for(let i = visibleRange.start; i < visibleRange.end; i++) {
                        const date = getDateForDay(i);
                        const isWeekend = date.getDay() === 0 || date.getDay() === 6;
                        
                        // PERFORMANCE: Use pre-computed Set instead of .some()
                        const isHoliday = holidayLookup.enabledSet.has(i);

                        const isMonthStart = date.getDate() === 1;
                        const isPast = i < gameState.day;
                        const isHovered = hoveredCell?.h === hangar.id && hoveredCell?.d === i;

                        let borderClass = 'border-r border-white/[0.04]';
                        if (isMacroView) {
                            borderClass = isMonthStart ? 'border-r border-white/[0.08]' : '';
                        }

                        let bgClass = '';
                        if (!isMacroView) {
                            if (isHoliday) bgClass = 'bg-[#c4626a]/10';
                            else if (isWeekend) bgClass = 'bg-white/[0.02]';
                        } else {
                            bgClass = i % 2 === 0 ? 'bg-[#08090a]' : 'bg-white/[0.01]';
                        }

                        let hoverStyle = '';
                        if (isHovered) {
                            let borderColor = 'border-white/40';
                            let bgColor = 'bg-white/20';
                            if (draggedJob && !hangar.supportedTypes.includes(draggedJob.aircraftType)) {
                                borderColor = 'border-red-500';
                                bgColor = 'bg-red-500/20';
                            }
                            hoverStyle = `${bgColor} box-border border-2 ${borderColor} z-20`;
                        }

                        cells.push(
                            <div
                                key={i}
                                onClick={() => handleDayCellClick(i)}
                                onDragOver={(e) => handleDragOver(e, hangar.id, i)}
                                // onDragLeave removed to fix flickering
                                onDrop={(e) => handleDrop(e, hangar.id, i)}
                                style={{ 
                                    width: cellWidth,
                                    left: i * cellWidth
                                }}
                                className={`
                                    absolute top-0 bottom-0
                                    ${bgClass}
                                    ${isPast ? (bgClass ? 'opacity-50' : 'opacity-40 bg-black/20') : ''}
                                    ${borderClass}
                                    ${hoverStyle}
                                `}
                            />
                        );
                    }
                    return cells;
                 })()}
               </div>

               {/* Jobs Overlay */}
               <div 
                  className="absolute top-0 bottom-0 pointer-events-none z-10"
                  style={{ left: STICKY_COL_WIDTH, width: TOTAL_DAYS * cellWidth }}
               >
                  {jobs.map((job) => {
                      // Check for local resize override
                      let start = job.startDate;
                      let duration = job.deadlineDays;
                      if (resizePreview?.jobId === job.id) {
                          start = resizePreview.newStart;
                          duration = resizePreview.newDuration;
                      }

                      const left = start * cellWidth;
                      const width = duration * cellWidth;
                      const right = left + width;
                      
                      const viewStart = visibleRange.start * cellWidth;
                      const viewEnd = visibleRange.end * cellWidth;
                      
                      if (right < viewStart || left > viewEnd) return null;

                      const laneIndex = jobLaneMap.get(job.id) || 0;
                      // Adjusted top calculation for simplified view
                      const top = (simplifiedViewMode ? 4 : 12) + (laneIndex * (JOB_HEIGHT + JOB_GUTTER));

                      const showDetails = width > 30;
                      const showTitle = width > 10;
                      const isMicroJob = width < 6;

                      // Magic Mode State
                      const isMagicSelected = selectedMagicJobIds.includes(job.id);
                      const magicPriorityIndex = selectedMagicJobIds.indexOf(job.id);
                      const isDimmed = magicMode && !isMagicSelected;

                      // Max visual weight for slider is now arbitrary but should relate to hours roughly.
                      // We set max visual to 24h or total estimated hours to prevent layout breaks
                      const maxVisualHours = Math.min(job.estimatedHours, 24);

                      // Determine if we show daily capacity breakdown
                      // This happens in Edit Mode OR in 'Show Capacity' View Mode
                      const showCapacityDetails = scheduleEditMode || viewCapacityMode;

                      // === VIRTUALIZATION: Calculate visible day cell range ===
                      // Only render day cells that are within the visible viewport + buffer
                      const CELL_BUFFER = 5; // Render 5 extra cells on each side
                      const jobVisibleStart = Math.max(0, visibleRange.start - start - CELL_BUFFER);
                      const jobVisibleEnd = Math.min(duration, visibleRange.end - start + CELL_BUFFER);

                      return (
                        <div
                          key={job.id}
                          draggable={!readOnly && job.status !== 'Completed' && !scheduleEditMode && !isSpaceData && !magicMode && !resizingJob && !viewCapacityMode}
                          onDragStart={(e) => {
                              if (!readOnly && !isSpaceData && !magicMode && !viewCapacityMode) onDragStart(e, job);
                          }}
                          onDragEnd={onDragEnd}
                          onClick={(e) => {
                            if (!readOnly && !hasMovedRef.current) {
                                e.stopPropagation();
                                if (magicMode && onMagicJobToggle) {
                                    onMagicJobToggle(job);
                                } else if (!scheduleEditMode) {
                                    onJobClick(job);
                                }
                            }
                          }}
                          onContextMenu={(e) => {
                            if (!readOnly && !magicMode && !scheduleEditMode) {
                                e.preventDefault();
                                e.stopPropagation();
                                setJobContextMenu({ job, x: e.clientX, y: e.clientY });
                            }
                          }}
                          className={`
                            absolute select-none group z-10
                            ${scheduleEditMode ? 'cursor-default pointer-events-auto' : (readOnly || isSpaceData || magicMode || viewCapacityMode ? 'cursor-pointer pointer-events-auto' : 'cursor-grab active:cursor-grabbing pointer-events-auto')}
                            ${isDimmed ? 'opacity-30 grayscale' : ''}
                            ${isMagicSelected ? 'z-30' : ''}
                          `}
                          style={{ 
                              left, 
                              width, 
                              top: `${top}px`,
                              height: `${JOB_HEIGHT}px`
                          }}
                        >
                          {/* Inner Visual Container (Clipped) */}
                          <div className={`
                              absolute inset-0 rounded shadow-[0_2px_4px_rgba(0,0,0,0.3)] overflow-hidden border border-white/10
                              ${job.color}
                              ${!magicMode && 'hover:brightness-110 transition-all'}
                              ${job.status === 'Completed' ? 'opacity-50 grayscale' : ''}
                              ${isMagicSelected ? 'ring-2 ring-[#7c6ebd] scale-[1.02]' : ''}
                              ${scheduleEditMode ? 'ring-1 ring-white/40' : ''}
                          `}>
                              {!isMicroJob && (
                                  <div className="absolute inset-0 flex flex-col justify-center px-1">
                                      {/* Magic Selection Indicator Overlay (Inside clipped area) */}
                                      {isMagicSelected && (
                                          <div className="absolute top-1 right-1 z-30 bg-[#7c6ebd] text-white rounded-full p-0.5 shadow-sm">
                                              <CheckCircle2 size={12} />
                                          </div>
                                      )}

                                      {cellWidth > 15 && (
                                          <div className={`absolute inset-0 z-0 ${showCapacityDetails ? 'pointer-events-auto z-20 opacity-100' : 'pointer-events-none opacity-30'}`}>
                                            {/* VIRTUALIZATION: Only render visible day cells + buffer */}
                                            {Array.from({ length: Math.max(0, jobVisibleEnd - jobVisibleStart) }).map((_, i) => {
                                                const idx = jobVisibleStart + i;
                                                const cellLeft = idx * cellWidth; // Position relative to job container
                                                const dayAbsIndex = start + idx;
                                                // PERFORMANCE: Use pre-computed Set instead of .some()
                                                const isHoliday = holidayLookup.enabledSet.has(dayAbsIndex);
                                                // Use original job data for non-work checks to avoid complexities during resize preview
                                                const isNonWork = job.nonWorkDays?.includes(idx); 
                                                
                                                // Determine specific daily effort
                                                const dayHours = getJobHoursForDay(job, idx);
                                                const isZeroEffort = dayHours === 0;

                                                // Visual styling for edit/capacity mode
                                                if (showCapacityDetails) {
                                                    // In viewCapacityMode, disable interactions but show visuals
                                                    const interactive = scheduleEditMode;

                                                    // Edit Tool: BLOCK DAYS
                                                    if (editTool === 'block' && interactive) {
                                                        return (
                                                            <div
                                                                key={idx}
                                                                className={`absolute top-0 bottom-0 border-r border-white/10 group/cell cursor-pointer flex items-center justify-center hover:bg-white/10 transition-colors ${isNonWork ? 'bg-black/50' : ''}`}
                                                                style={{ left: cellLeft, width: cellWidth }}
                                                                onMouseDown={(e) => handleSliderMouseDown(e, job, idx)}
                                                                onMouseEnter={() => setHoveredEditDayIndex(dayAbsIndex)}
                                                                onMouseLeave={() => setHoveredEditDayIndex(null)}
                                                                title="Click to toggle work day"
                                                            >
                                                                {isNonWork && <Ban size={12} className="text-[#c4626a]" />}
                                                            </div>
                                                        );
                                                    }

                                                    // Edit Tool: DISTRIBUTE (Slider) OR View Capacity Mode
                                                    // Normalize height relative to visual max
                                                    const visualPercent = Math.min(dayHours / maxVisualHours, 1.0);

                                                    return (
                                                        <div
                                                            key={idx}
                                                            id={`effort-slider-${job.id}-${idx}`}
                                                            className={`absolute top-0 bottom-0 border-r border-white/10 group/cell ${interactive ? 'cursor-ns-resize' : 'cursor-default'}`}
                                                            style={{ left: cellLeft, width: cellWidth }}
                                                            onMouseDown={(e) => interactive && handleSliderMouseDown(e, job, idx)}
                                                            onMouseEnter={() => setHoveredEditDayIndex(dayAbsIndex)}
                                                            onMouseLeave={() => setHoveredEditDayIndex(null)}
                                                        >
                                                            {/* Curtain Mask (Top) - Handles the empty space */}
                                                            <div
                                                                className={`absolute top-0 left-0 right-0 transition-all pointer-events-none ${isZeroEffort ? 'bg-[#1a1b1e]' : 'bg-[#0d0e10]/90'}`}
                                                                style={{ height: `${(1 - visualPercent) * 100}%` }}
                                                            />

                                                            {/* Hours Label (Always visible in edit/capacity mode) */}
                                                            <div className="absolute bottom-0.5 left-0 right-0 flex justify-center pointer-events-none">
                                                                <span className="text-[9px] font-mono font-semibold text-white drop-shadow-[0_1px_1px_rgba(0,0,0,0.8)]">
                                                                    {dayHours.toFixed(1)}
                                                                </span>
                                                            </div>

                                                            {/* Hover hint only if interactive */}
                                                            {interactive && <div className="absolute top-0 inset-x-0 h-1 bg-white opacity-0 group-hover/cell:opacity-50"></div>}
                                                        </div>
                                                    );
                                                }

                                                // Normal View
                                                let cellClass = '';
                                                let content = null;

                                                if (isHoliday) {
                                                    cellClass = 'bg-[#c4626a]/20 border-[#c4626a]/30';
                                                } else if (isZeroEffort) {
                                                    // Darker grey square with white X for zero work days
                                                    cellClass = 'flex items-center justify-center';
                                                    content = (
                                                        <div className="w-[70%] h-[60%] bg-[#1a1b1e] border border-white/30 flex items-center justify-center rounded-[1px]">
                                                             <X size={cellWidth < 20 ? 8 : 10} className="text-white/90" strokeWidth={2.5} />
                                                        </div>
                                                    );
                                                } else {
                                                    // Active Work Day
                                                    cellClass = 'border-black/20';
                                                }
                                                
                                                // If we have zoomed in enough, show the hours number even in read-only mode if it varies
                                                if (cellWidth > 35 && dayHours > 0) {
                                                    content = (
                                                        <div className="absolute bottom-0.5 left-0 right-0 flex justify-center pointer-events-none opacity-50 group-hover:opacity-100 transition-opacity duration-200">
                                                            <span className="text-[8px] font-mono text-white group-hover:font-bold group-hover:text-white group-hover:drop-shadow-[0_1px_2px_rgba(0,0,0,0.8)]">
                                                                {dayHours.toFixed(1)}
                                                            </span>
                                                        </div>
                                                    );
                                                }

                                                return (
                                                    <div
                                                        key={idx}
                                                        className={`absolute top-0 bottom-0 border-r ${cellClass}`}
                                                        style={{ left: cellLeft, width: cellWidth }}
                                                        title={isHoliday ? "Holiday" : isNonWork ? "Non-Work" : `Work Day (${dayHours.toFixed(1)}h)`}
                                                    >
                                                        {content}
                                                    </div>
                                                );
                                            })}
                                          </div>
                                      )}

                                      {/* Normal Title (Hidden in Simplified Mode inside bar) */}
                                      {showTitle && !showCapacityDetails && !simplifiedViewMode && (
                                        <div className="relative z-10 flex items-center justify-between text-white drop-shadow-md pointer-events-none">
                                            <span className="font-semibold text-[11px] truncate tracking-wide">{job.customer}</span>
                                            <div className="flex items-center">
                                              {job.isAOG && (
                                                <Tooltip content="AOG: Aircraft On Ground - Urgent priority" position="top">
                                                    <AlertCircle size={8} className="text-[#c4626a] animate-pulse ml-1 shrink-0 pointer-events-auto cursor-help" />
                                                </Tooltip>
                                              )}
                                              {(() => {
                                                const status = getJobCapacityStatus(job);
                                                if (!status.hasWarning || job.isAOG) return null;
                                                return (
                                                  <AlertTriangle
                                                    size={8}
                                                    className={`ml-1 shrink-0 ${
                                                      status.severity === 'critical'
                                                        ? 'text-rose-500 animate-pulse'
                                                        : 'text-amber-500'
                                                    }`}
                                                    title={`${status.overloadedDays} day${status.overloadedDays > 1 ? 's' : ''} exceed capacity threshold (max: ${Math.round(status.maxUtilization)}%)`}
                                                  />
                                                );
                                              })()}
                                            </div>
                                        </div>
                                      )}

                                      {/* Normal Details (Hidden in Simplified Mode inside bar) */}
                                      {showDetails && !showCapacityDetails && !simplifiedViewMode && (
                                        <div className="relative z-10 text-[9px] text-white/80 truncate font-mono pointer-events-none">
                                            {job.description}
                                        </div>
                                      )}
                                  </div>
                              )}
                          </div>

                          {/* Simplified View External Label */}
                          {simplifiedViewMode && (
                              <div className="absolute -top-4 left-0 text-[10px] font-bold text-white/90 drop-shadow-md whitespace-nowrap pointer-events-none z-20 flex items-center gap-1">
                                  {job.customer}
                                  {job.isAOG && (
                                      <Tooltip content="AOG: Aircraft On Ground - Urgent priority" position="top">
                                          <AlertCircle size={8} className="text-[#c4626a] animate-pulse pointer-events-auto cursor-help" />
                                      </Tooltip>
                                  )}
                              </div>
                          )}

                          {/* Resize Handles (Outside of clipped area) */}
                          {!readOnly && !scheduleEditMode && !magicMode && !isSpaceData && !viewCapacityMode && (
                              <>
                                <div 
                                    className="absolute -left-4 top-0 bottom-0 w-4 cursor-w-resize z-50 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-auto flex items-center justify-center" 
                                    onMouseDown={(e) => handleResizeStart(e, job, 'start')}
                                    onClick={(e) => e.stopPropagation()} // Stop click bubbling to card
                                >
                                    <div className="w-1.5 h-6 bg-white border border-slate-500 rounded-full shadow-sm hover:scale-110 transition-transform" />
                                </div>
                                <div 
                                    className="absolute -right-4 top-0 bottom-0 w-4 cursor-e-resize z-50 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-auto flex items-center justify-center" 
                                    onMouseDown={(e) => handleResizeStart(e, job, 'end')}
                                    onClick={(e) => e.stopPropagation()} // Stop click bubbling to card
                                >
                                    <div className="w-1.5 h-6 bg-white border border-slate-500 rounded-full shadow-sm hover:scale-110 transition-transform" />
                                </div>
                              </>
                          )}

                          {/* Magic Selection Priority Badge (Outside) */}
                          {isMagicSelected && magicMode && (
                              <div className="absolute -left-6 top-1/2 -translate-y-1/2 w-5 h-5 bg-[#7c6ebd] text-white rounded-full flex items-center justify-center text-[10px] font-bold shadow-md z-[60] animate-in zoom-in duration-200 pointer-events-none">
                                  {magicPriorityIndex + 1}
                              </div>
                          )}
                          
                          {/* Hover Tooltip (Outside) - Only in standard mode */}
                          {!scheduleEditMode && !readOnly && !magicMode && !resizingJob && !viewCapacityMode && !simplifiedViewMode && (
                              <div className="hidden group-hover:block absolute -top-8 left-1/2 -translate-x-1/2 bg-[#141517] border border-white/[0.1] text-[#e8e8e8] text-xs p-1.5 rounded-lg shadow-xl z-[60] whitespace-nowrap pointer-events-none font-mono">
                                {job.customer}
                              </div>
                          )}
                        </div>
                      );
                    })}
               </div>
               </>
               )}
             </div>
           )})}
           
           {/* Bottom Spacer for Vertical Scrolling Comfort */}
           <div
              className="pointer-events-none border-t border-white/[0.04] opacity-10"
              style={{
                  height: '75vh', // Allow scrolling well past the last item
                  width: STICKY_COL_WIDTH + (TOTAL_DAYS * cellWidth)
              }}
           />
        </div>
      </div>

      {/* Job Context Menu */}
      {jobContextMenu && (
        <>
          {/* Backdrop to close menu */}
          <div
            className="fixed inset-0 z-[100]"
            onClick={() => setJobContextMenu(null)}
            onContextMenu={(e) => {
              e.preventDefault();
              setJobContextMenu(null);
            }}
          />
          {/* Menu */}
          <div
            className="fixed z-[101] bg-[#1a1b1e] border border-[#2a2b2e] rounded-lg shadow-xl py-1 min-w-[180px]"
            style={{ left: jobContextMenu.x, top: jobContextMenu.y }}
          >
            <button
              className="w-full px-3 py-2 text-left text-sm text-white hover:bg-white/20 flex items-center gap-2"
              onClick={() => {
                onJobClick(jobContextMenu.job);
                setJobContextMenu(null);
              }}
            >
              <HelpCircle size={14} className="text-[#6b7280]" />
              View Details
            </button>
            {onFindAvailableSlot && (
              <button
                className="w-full px-3 py-2 text-left text-sm text-white hover:bg-white/20 flex items-center gap-2"
                onClick={() => {
                  onFindAvailableSlot(jobContextMenu.job);
                  setJobContextMenu(null);
                }}
              >
                <CalendarOff size={14} className="text-[#6b7280]" />
                Find Available Slot
              </button>
            )}
          </div>
        </>
      )}
    </div>
  );
};

// PERFORMANCE: Wrap with React.memo to prevent unnecessary re-renders
export default React.memo(GanttBoard);
