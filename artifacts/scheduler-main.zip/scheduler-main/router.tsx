import React from 'react';
import { createBrowserRouter, Outlet, Navigate, useNavigate } from 'react-router-dom';
import { Header, Footer } from './components/layout';
import { useAuth } from './contexts/AuthContext';

// Lazy load pages for better performance
const Landing = React.lazy(() => import('./pages/Landing'));
const Features = React.lazy(() => import('./pages/Features'));
const Pricing = React.lazy(() => import('./pages/Pricing'));
const Customers = React.lazy(() => import('./pages/Customers'));
const About = React.lazy(() => import('./pages/About'));
const Contact = React.lazy(() => import('./pages/Contact'));
const NotFound = React.lazy(() => import('./pages/NotFound'));

// Auth pages - import directly since they're small
import LoginPage from './components/auth/LoginPage';
import RegisterPage from './components/auth/RegisterPage';
import AuthCallback from './components/auth/AuthCallback';

// Loading fallback
export const PageLoader: React.FC = () => (
  <div className="min-h-screen bg-[#08090a] flex items-center justify-center">
    <div className="flex flex-col items-center gap-4">
      <div className="w-8 h-8 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin" />
      <span className="text-[#6b7280] text-sm">Loading...</span>
    </div>
  </div>
);

// Marketing Layout - wraps all public marketing pages
const MarketingLayout: React.FC = () => {
  const { isAuthenticated } = useAuth();

  // If authenticated, redirect to dashboard
  if (isAuthenticated) {
    return <Navigate to="/dashboard" replace />;
  }

  return (
    <div className="min-h-screen bg-[#08090a]">
      <Header transparent />
      <main>
        <React.Suspense fallback={<PageLoader />}>
          <Outlet />
        </React.Suspense>
      </main>
      <Footer />
    </div>
  );
};

// Auth Layout wrapper for login/register with navigation
const LoginPageWrapper: React.FC = () => {
  const navigate = useNavigate();
  return (
    <LoginPage
      onSwitchToRegister={() => navigate('/register')}
      onSuccess={() => navigate('/dashboard')}
    />
  );
};

const RegisterPageWrapper: React.FC = () => {
  const navigate = useNavigate();
  return (
    <RegisterPage
      onSwitchToLogin={() => navigate('/login')}
      onSuccess={() => navigate('/dashboard')}
      onBack={() => navigate('/')}
    />
  );
};

const AuthCallbackWrapper: React.FC = () => {
  const navigate = useNavigate();
  return (
    <AuthCallback
      onSuccess={() => navigate('/dashboard')}
      onError={() => navigate('/login')}
    />
  );
};

// Protected Route - redirects to login if not authenticated
interface ProtectedRouteProps {
  children: React.ReactNode;
}

export const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ children }) => {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return <PageLoader />;
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  return <>{children}</>;
};

// Public Only Route - redirects to dashboard if already authenticated
interface PublicOnlyRouteProps {
  children: React.ReactNode;
}

const PublicOnlyRoute: React.FC<PublicOnlyRouteProps> = ({ children }) => {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return <PageLoader />;
  }

  if (isAuthenticated) {
    return <Navigate to="/dashboard" replace />;
  }

  return <>{children}</>;
};

// Route configuration
export const router = createBrowserRouter([
  // Marketing routes (public - redirects to dashboard if authenticated)
  {
    path: '/',
    element: <MarketingLayout />,
    children: [
      { index: true, element: <Landing /> },
      { path: 'features', element: <Features /> },
      { path: 'pricing', element: <Pricing /> },
      { path: 'customers', element: <Customers /> },
      { path: 'about', element: <About /> },
      { path: 'contact', element: <Contact /> },
    ],
  },

  // Auth routes
  {
    path: '/login',
    element: (
      <PublicOnlyRoute>
        <LoginPageWrapper />
      </PublicOnlyRoute>
    ),
  },
  {
    path: '/register',
    element: (
      <PublicOnlyRoute>
        <RegisterPageWrapper />
      </PublicOnlyRoute>
    ),
  },
  {
    path: '/auth/callback',
    element: <AuthCallbackWrapper />,
  },

  // Dashboard route - protected, redirects to login when not authenticated
  // When authenticated, App.tsx's RouterRoot renders Dashboard directly (not via router)
  // This route handles the case when user logs out while on /dashboard
  {
    path: '/dashboard',
    element: (
      <ProtectedRoute>
        <PageLoader />
      </ProtectedRoute>
    ),
  },
  {
    path: '/dashboard/*',
    element: (
      <ProtectedRoute>
        <PageLoader />
      </ProtectedRoute>
    ),
  },

  // Catch-all 404
  {
    path: '*',
    element: (
      <div className="min-h-screen bg-[#08090a]">
        <Header />
        <main>
          <React.Suspense fallback={<PageLoader />}>
            <NotFound />
          </React.Suspense>
        </main>
        <Footer />
      </div>
    ),
  },
]);

export default router;
