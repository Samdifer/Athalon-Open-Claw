# AeroManager 145 - Troubleshooting Data Loading

## Quick Diagnostic (Run in Browser Console)

While your app is running on `http://localhost:3001`, open the browser console (F12 → Console) and paste this code:

```javascript
// Diagnostic Script for AeroManager 145
(async function diagnose() {
    console.log('=== AEROMANAGER 145 DIAGNOSTIC ===\n');

    // Import Supabase client from global (if available)
    const checkSupabase = async () => {
        try {
            // Try to get current user from Supabase
            const { createClient } = window.supabase || {};
            if (!createClient) {
                console.error('❌ Supabase client not loaded globally');
                console.log('\n📋 Manual check:');
                console.log('1. Open Network tab');
                console.log('2. Look for requests to supabase.co');
                console.log('3. Check if any return 400 errors');
                return;
            }
        } catch (e) {
            console.warn('⚠️ Could not access Supabase globally');
        }
    };

    // Check localStorage
    console.log('1️⃣ CHECKING LOCAL STORAGE');
    console.log('-'.repeat(50));
    const sbAuth = localStorage.getItem('sb-kmjjymsbwjfkwhcgrdfr-auth-token');
    if (sbAuth) {
        console.log('✅ Supabase auth token found');
        try {
            const parsed = JSON.parse(sbAuth);
            console.log('   User:', parsed.user?.email || 'Unknown');
            console.log('   Expires:', new Date(parsed.expires_at * 1000).toLocaleString());
        } catch (e) {
            console.log('   (Could not parse token)');
        }
    } else {
        console.log('❌ No Supabase auth token found');
        console.log('   → You need to log in!');
    }
    console.log('');

    // Check sessionStorage
    console.log('2️⃣ CHECKING SESSION STORAGE');
    console.log('-'.repeat(50));
    console.log('Session keys:', Object.keys(sessionStorage));
    console.log('');

    // Check IndexedDB
    console.log('3️⃣ CHECKING INDEXEDDB');
    console.log('-'.repeat(50));
    const dbs = await indexedDB.databases();
    if (dbs.length > 0) {
        console.log('✅ IndexedDB databases found:');
        dbs.forEach(db => console.log('   -', db.name));
    } else {
        console.log('⚠️ No IndexedDB databases (this is OK - app uses Supabase now)');
    }
    console.log('');

    // Check Network for errors
    console.log('4️⃣ NETWORK CHECK');
    console.log('-'.repeat(50));
    console.log('Open the Network tab and look for:');
    console.log('   • Requests to: kmjjymsbwjfkwhcgrdfr.supabase.co');
    console.log('   • Status codes: 400, 401, 403 (these are errors)');
    console.log('   • Status code: 200 (this is good)');
    console.log('');

    // Final recommendations
    console.log('5️⃣ RECOMMENDATIONS');
    console.log('-'.repeat(50));
    if (!sbAuth) {
        console.log('🔴 YOU ARE NOT LOGGED IN');
        console.log('   Solution: Click "Login" in the app');
    } else {
        console.log('🟢 You appear to be logged in');
        console.log('   If you still see no data:');
        console.log('   1. Check Network tab for 400 errors');
        console.log('   2. Try logging out and back in');
        console.log('   3. Check browser console for error messages');
    }
    console.log('\n=== END DIAGNOSTIC ===\n');
})();
```

## Common Issues & Solutions

### Issue 1: "No data showing but I'm logged in"

**Symptoms:**
- You can log in successfully
- App shows empty hangars, no jobs, no personnel
- No errors in console

**Solution:**
```javascript
// Paste in console to check if org data exists
(async function checkOrgData() {
    const token = localStorage.getItem('sb-kmjjymsbwjfkwhcgrdfr-auth-token');
    if (!token) {
        console.log('Not logged in!');
        return;
    }

    console.log('Checking organization data...');
    // You'll need to check the Network tab to see if Supabase requests are succeeding
    console.log('→ Open Network tab');
    console.log('→ Filter by "supabase"');
    console.log('→ Look for requests to /rest/v1/personnel, /rest/v1/hangars, etc.');
    console.log('→ If they return empty arrays [], your org has no data');
    console.log('→ If they return 400/401, there\'s an auth issue');
})();
```

**Fix:** Log out, clear storage, log back in:
```javascript
// Clear everything and start fresh
localStorage.clear();
sessionStorage.clear();
indexedDB.deleteDatabase('AeroManagerDB');
// Then reload the page and log in again
location.reload();
```

### Issue 2: "400 Bad Request errors in Network tab"

**Symptoms:**
- Network tab shows red 400 errors
- Error message mentions UUID formatting
- Requests to Supabase fail

**Solution:**
This is likely an authentication issue. The user's organization_id isn't being passed correctly.

**Fix:**
1. Log out
2. Clear browser storage (see code above)
3. Re-register with a new account
4. The registration process should properly initialize your organization

### Issue 3: "Data was working before, now it's gone"

**Symptoms:**
- You had data before
- After refresh, everything is empty
- You're still logged in

**Solution:**
Check if session expired:
```javascript
// Check session expiration
const token = localStorage.getItem('sb-kmjjymsbwjfkwhcgrdfr-auth-token');
if (token) {
    const parsed = JSON.parse(token);
    const expiresAt = new Date(parsed.expires_at * 1000);
    const now = new Date();

    if (expiresAt < now) {
        console.log('❌ Session expired!');
        console.log('   → Log out and log back in');
    } else {
        console.log('✅ Session valid until:', expiresAt.toLocaleString());
    }
}
```

## Manual Database Check (Advanced)

If you have access to Supabase dashboard:

1. Go to https://supabase.com/dashboard
2. Select your project (kmjjymsbwjfkwhcgrdfr)
3. Go to Table Editor
4. Check these tables:
   - `profiles` → Should have your user with an organization_id
   - `personnel` → Should have 10 rows with your organization_id
   - `hangars` → Should have 4 rows with your organization_id
   - `jobs` → Should have 10 rows with your organization_id

If tables are empty → Your organization wasn't initialized
If organization_id is NULL in profiles → Registration didn't complete properly

## Nuclear Option (Complete Reset)

If nothing else works:

```javascript
// COMPLETE RESET - Only use if everything else fails
(async function nuclearReset() {
    if (!confirm('⚠️ This will delete ALL local data. Continue?')) return;

    // Clear all storage
    localStorage.clear();
    sessionStorage.clear();

    // Clear all IndexedDB
    const dbs = await indexedDB.databases();
    for (const db of dbs) {
        indexedDB.deleteDatabase(db.name);
    }

    console.log('✅ All local data cleared');
    console.log('→ Reload the page');
    console.log('→ Register a NEW account');
    console.log('→ Fresh seed data will be loaded');

    setTimeout(() => location.reload(), 2000);
})();
```

## What Should Happen on First Login

When you log in (or register) for the first time:

1. **App.tsx line 288-327** runs the initialization
2. It calls `loadGameState()` from Supabase
3. If no data exists, it calls `initializeOrganizationData()`
4. This should upload all INITIAL_* data from constants.ts to Supabase
5. You should see console logs like:
   - "No cloud data found, checking local storage..."
   - "No existing data found, initializing with defaults..."

If you don't see these logs, the initialization isn't running.

## Still Stuck?

Run this final diagnostic and share the output:

```javascript
// Complete diagnostic dump
console.log('=== COMPLETE DIAGNOSTIC DUMP ===');
console.log('LocalStorage keys:', Object.keys(localStorage));
console.log('SessionStorage keys:', Object.keys(sessionStorage));
console.log('Cookies:', document.cookie);
console.log('Current URL:', window.location.href);
console.log('User Agent:', navigator.userAgent);

// Check React app state
console.log('\n=== REACT APP STATE ===');
console.log('Look for gameState in React DevTools:');
console.log('1. Install React DevTools extension');
console.log('2. Open React DevTools');
console.log('3. Find <App> component');
console.log('4. Check gameState in props/state');
console.log('5. Look for: personnel, hangars, backlog arrays');
```
