# AeroManager 145 - Complete UI Reference

This document provides a comprehensive description of every page, panel, and popup in the AeroManager 145 application.

---

## Table of Contents

1. [Public Pages (Pre-Authentication)](#1-public-pages-pre-authentication)
2. [Main Dashboard](#2-main-dashboard)
3. [Core Operational Panels](#3-core-operational-panels)
4. [Configuration Modals](#4-configuration-modals)
5. [Job Management Modals](#5-job-management-modals)
6. [Utility Modals & Overlays](#6-utility-modals--overlays)
7. [Administration Panels](#7-administration-panels)
8. [Platform Admin Dashboard](#8-platform-admin-dashboard)
9. [Draggable Window System](#9-draggable-window-system)
10. [Summary Statistics](#10-summary-statistics)

---

## 1. Public Pages (Pre-Authentication)

### Landing Page
**File**: `components/LandingPage.tsx`
**Purpose**: Marketing homepage for unauthenticated visitors

**Features**:
- Hero section with animated taglines and CTAs ("Run Your Hangar Like a Machine")
- Three feature showcase sections with interactive mockups:
  - **Gantt Board mockup** - Shows drag-drop scheduling visualization
  - **Financial Dashboard mockup** - Displays cashflow and profit forecasting
  - **Capacity Monitor mockup** - Shows workforce utilization metrics
- Social proof section with brand logos
- "Founder's Offer" pricing lock promotional block
- Final CTA section with trial signup button
- Sticky navigation with login/signup buttons

### Login Page
**File**: `components/auth/LoginPage.tsx`
**Purpose**: User authentication

**Features**:
- Email and password input fields
- Email verification pending banner (if unverified)
- Resend verification email functionality
- Error/success message displays
- Link to registration page
- Glassmorphism dark theme styling

### Register Page
**File**: `components/auth/RegisterPage.tsx`
**Purpose**: New user account creation

**Features**:
- Full name, company name (optional), email, password, confirm password fields
- Form validation with error feedback
- 14-day free trial messaging
- Terms of Service/Privacy Policy links
- Post-registration: Email verification confirmation screen with instructions
- Back button to return to landing page

---

## 2. Main Dashboard

**File**: `App.tsx`

### Primary Layout Structure
The main dashboard is divided into several resizable regions:
- **Left sidebar**: Quotes/Backlog panel (collapsible)
- **Center**: Gantt Board timeline
- **Right sidebar**: Roster panel (collapsible)
- **Bottom dock**: Capacity, P&L Tracker, and Analytics panels (expandable/collapsible)
- **Top toolbar**: Navigation, zoom controls, view options, user menu

### Header Toolbar Elements
- Logo and brand name
- Main navigation tabs: Board, Personnel, Config, Financials, Quote Builder
- Base selector dropdown (filters by location)
- Zoom controls (+/-)
- View mode dropdown (Simplified View, Capacity View)
- Schedule Edit toggle
- Edit tool selector (Distribute/Block)
- Magic Scheduler button
- Undo/Redo buttons
- Fullscreen dashboard button
- User dropdown (profile, password change, admin, logout)
- Platform Admin button (if super admin)
- Saving indicator

### View States
The dashboard supports multiple view states controlled by the `view` state variable:
- `board` - Main Gantt scheduling view
- `personnel` - Personnel Manager
- `config` - Configuration Panel
- `financials` - Financial Panel
- `quote` - Quote Builder
- `fullscreen` - Fullscreen Dashboard
- `setup` - Setup Defaults Panel
- `admin` - User Management

---

## 3. Core Operational Panels

### Gantt Board
**File**: `components/GanttBoard.tsx`
**Purpose**: Visual timeline for scheduling aircraft maintenance projects

**Features**:
- Multi-row hangar lanes (grouped by base)
- Horizontal timeline with day columns
- Zoom levels from 2px to 240px per day
- Real-time "Today" cursor with time-of-day indicator
- Custom progress cursors (configurable)
- Month/week header separators
- Weekend/holiday shading
- Drag-and-drop job scheduling from backlog
- Job bar visualization with:
  - Color-coded status (violet=WIP, emerald=complete, rose=AOG)
  - Progress percentage
  - Customer/aircraft labels
  - Resize handles for duration adjustment
- Edit mode features:
  - Day blocking (mark non-work days)
  - Effort distribution sliders (allocate hours per day)
- Magic mode: Multi-select jobs for batch optimization
- Spacebar + drag for pan navigation
- Compatibility indicators when dragging jobs to hangars
- View modes: Standard, Capacity, Simplified

### Backlog Panel
**File**: `components/BacklogPanel.tsx`
**Purpose**: Queue of unscheduled jobs/quotes awaiting scheduling

**Features**:
- Collapsible sidebar (expands to ~288px)
- View modes: List, Small Cards, Large Cards (in popout)
- Job cards displaying: customer, aircraft type, hours, revenue, deadline, AOG status
- Drag-to-schedule functionality
- "New Quote" button
- Pop-out to floating window option
- Graveyard link (for archived jobs)
- Highlighted job scrolling (when linked from elsewhere)

### Roster Panel
**File**: `components/RosterPanel.tsx`
**Purpose**: Display today's active workforce by team

**Features**:
- Current date and day-of-week display
- Holiday indicator
- Teams grouped by shift
- Active/inactive status per team (based on shift schedule)
- Personnel list per team showing:
  - Name
  - Role badge
  - Efficiency rating
- Pop-out capability
- Base filtering

### Daily Financial Tracker
**File**: `components/DailyFinancialTracker.tsx`
**Purpose**: Day-by-day P&L aligned with the Gantt timeline

**Features**:
- Synchronized horizontal scroll with Gantt board
- Daily columns showing:
  - Revenue recognition
  - Labor costs
  - Overhead
  - Net profit/loss
- Color-coded profit (green) vs loss (red)
- Hover tooltips with detailed breakdown
- Cumulative totals
- Chart visualization mode
- Pop-out capability

### Capacity Forecaster
**File**: `components/CapacityForecaster.tsx`
**Purpose**: Visual comparison of labor capacity vs workload

**Features**:
- Area chart showing:
  - Available capacity (green area)
  - Scheduled load (blue area)
  - Overlap/overload zones
- Synchronized with Gantt timeline
- Real-time day indicator
- Hover tooltips with daily statistics
- Pop-out capability
- Base-filtered capacity

### Analytics Panel
**File**: `components/AnalyticsPanel.tsx`
**Purpose**: KPI dashboard for reporting period

**Features**:
- Configurable date range (start/end pickers)
- Key metrics:
  - Total capacity hours
  - Sold hours
  - Utilization percentage
  - Planned revenue
  - Labor cost
  - Overhead
  - Gross profit
  - Overtime hours/cost
- Bar chart visualization
- Cash position display (clickable to edit)
- Pop-out capability

---

## 4. Configuration Modals

### Configuration Panel
**File**: `components/ConfigurationPanel.tsx`
**Purpose**: Global settings for fleet, facilities, and workflow

#### Fleet Tab
- List of aircraft models (e.g., "Gulfstream G550")
- Add new aircraft model form
- Hangar compatibility checkboxes per model
- Delete aircraft model

#### Hangars Tab
- List of hangars with drag-to-reorder
- Per-hangar settings: name, base assignment, size
- Add new hangar form
- Bulk save/reset buttons

#### Project Stages Tab
- Configurable workflow stages (e.g., "Authorized", "WIP", "RTS")
- Color picker for each stage
- Description field
- Drag-to-reorder

#### Cursors Tab
- Custom timeline markers
- Day offset from today
- Color and label configuration
- Enable/disable toggle

### Personnel Manager
**File**: `components/PersonnelManager.tsx`
**Purpose**: Workforce and schedule configuration

#### Roster Tab
- Personnel list grouped by base
- Add/edit/delete personnel
- Assign role and team
- Efficiency override setting
- Search/filter functionality

#### Assignments Tab
- Team management
- Shift assignment per team
- Base assignment per team
- Team color picker
- Drag personnel between teams

#### Roles Tab
- Role definitions (e.g., "A&P Technician")
- Base efficiency multiplier
- Hourly cost rate
- Drag-to-reorder for seniority

#### Holidays Tab
- Holiday calendar management
- Add/edit/delete holidays
- Enable/disable toggle per holiday
- Day index and date display

#### Analysis Tab
- Personnel cost breakdown charts
- Team utilization metrics
- Headcount by role

### Financial Panel
**File**: `components/FinancialPanel.tsx`
**Purpose**: Financial configuration and projections

#### General Tab (Edit Mode)
- Starting cash position
- Shop rate (hourly billing rate)
- Parts markup tiers editor
- Service markup tiers editor

#### Projections Tab
- Cashflow projection chart (30/90/365 day views)
- Revenue recognition timeline
- Burn rate analysis
- Runway indicator

#### FP&A Tab
- Expense item management (Facility, Admin, IT, etc.)
- Monthly overrides per expense
- CapEx planning with amortization
- Year-by-year budget view

### Quote Builder
**File**: `components/QuoteBuilder.tsx`
**Purpose**: Create and edit job quotes with line items

**Features**:
- Customer/aircraft selection
- Arrival date picker
- AOG priority toggle
- Line items table:
  - Description
  - Category (Labor/Part/Service)
  - Labor hours and rate
  - Parts cost and markup
  - Fixed price override option
- Standard services library (quick-add)
- Real-time total calculations
- Save as draft to backlog
- Settings sub-modal for service templates

#### Quote Settings Modal (nested)
- Standard service template management
- Category filter (Common vs aircraft-specific)
- Add/edit/delete service templates

---

## 5. Job Management Modals

### Job Details Modal
**File**: `components/JobDetailsModal.tsx`
**Purpose**: View and edit scheduled or backlog job details

**Features**:
- Banner header with project color and aircraft info
- Customer/tail number editor
- Description editor
- AOG status badge
- Project stage color selector
- Statistics cards:
  - Estimated workload (hours)
  - Revenue
  - Schedule dates (start/end with duration calculation)
- "Auto-Fit Capacity" button (magic scheduling)
- Notes section
- Link to Quote Builder for detailed line items
- Delete options:
  - Archive to Graveyard
  - Permanent delete (with double confirmation)

### Graveyard Panel
**File**: `components/GraveyardPanel.tsx`
**Purpose**: Manage deleted/archived jobs

**Features**:
- List of archived jobs (grayed out styling)
- Job info: customer, aircraft, hours, revenue
- "Restore" button (returns to backlog)
- "Delete Forever" button (permanent removal with confirmation)

---

## 6. Utility Modals & Overlays

### Welcome Splash
**File**: `components/WelcomeSplash.tsx`
**Purpose**: First-login welcome screen

**Features**:
- Personalized greeting ("Captain [NAME] on Deck")
- Aviation-themed messaging
- Two CTAs:
  - "Pre-Flight Briefing" (starts tutorial)
  - "Immediate Takeoff" (skip to dashboard)

### Onboarding Tour
**File**: `components/OnboardingTour.tsx`
**Purpose**: Step-by-step interactive tutorial

**Features**:
- 35+ guided steps
- Highlight boxes around target UI elements
- Step navigation (next/prev/close)
- Automatic UI manipulation (opens panels, switches views)
- Covers: Gantt, Roster, Capacity, P&L, Analytics, Config, Personnel, Financials, Quote Builder

### Setup Defaults Panel
**File**: `components/SetupDefaultsPanel.tsx`
**Purpose**: Quick initial configuration

**Features**:
- Cash position setting
- Shop rate setting
- Base management (add/edit/delete)
- Hangar quick setup
- Personnel quick-add

### Magic Scheduler Wizard
**File**: `components/MagicSchedulerWizard.tsx`
**Purpose**: AI-assisted batch scheduling optimization

**Steps**:
1. **Intro**: Explanation of batch optimization process
2. **Selecting**: Click projects on board to include
3. **Prioritizing**: Drag-to-reorder priority list
4. **Results**: Shows optimization results (old vs new end dates, days added)

**Features**:
- Floating selection bar during "selecting" mode
- Reorder controls (up/down arrows)
- Run optimization button
- Results summary with before/after comparison

### Fullscreen Dashboard
**File**: `components/FullScreenDashboard.tsx`
**Purpose**: Distraction-free board view for presentations

**Features**:
- Full-screen takeover
- Simplified header with zoom controls only
- Gantt board only (no sidebars)
- Close button to return

### Cashflow Forecast Expanded
**File**: `components/CashflowForecastExpanded.tsx`
**Purpose**: Detailed cashflow projection view (pop-out)

**Features**:
- Large area chart
- Range selector (30/90 days)
- Revenue event markers
- Lowest cash point indicator
- Trend analysis

### Project List Panel
**File**: `components/ProjectListPanel.tsx`
**Purpose**: Tabular view of all scheduled projects

**Features**:
- Sortable columns: Start, End, Customer, Aircraft, Hangar, Status, Hours, Revenue, Profit, Margin
- Filter by base, hangar, aircraft type
- CSV export functionality
- Color-coded profit margins

### Change Password Modal
**File**: `components/auth/ChangePasswordModal.tsx`
**Purpose**: Update user password

**Features**:
- Current password verification
- New password + confirmation
- Minimum length validation
- Success/error feedback
- Auto-close on success

---

## 7. Administration Panels

### User Management
**File**: `components/admin/UserManagement.tsx`
**Purpose**: Manage organization users

**Features**:
- User list with search/filter
- User cards showing: name, email, role, status, last login
- Invite new user modal (with construction banner - feature incomplete)
- Edit user (name, role, status)
- Delete user with confirmation
- Role selector (Admin, Manager, Technician)
- Status toggle (Active/Inactive)

---

## 8. Platform Admin Dashboard

### Platform Dashboard
**File**: `components/platform-admin/PlatformDashboard.tsx`
**Purpose**: Super-admin platform management (for AeroManager staff)

**Navigation Views**:
- Organizations
- User Search
- Analytics
- Platform Admins (super_admin only)

#### Organization List
**File**: `components/platform-admin/OrganizationList.tsx`
- Browse/search all customer organizations
- Subscription status badges
- User counts
- Impersonation capability

#### Organization Details
**File**: `components/platform-admin/OrganizationDetails.tsx`
- Detailed organization view
- Subscription management
- User list for organization

#### User Search
**File**: `components/platform-admin/UserSearch.tsx`
- Find users across all organizations
- Global search
- Quick actions (impersonate, edit)

#### Platform Analytics
**File**: `components/platform-admin/PlatformAnalytics.tsx`
- System-wide metrics
- Total organizations
- Active/trial/cancelled counts
- MRR/ARR calculations
- Signup trends

#### Platform Admin Management
**File**: `components/platform-admin/PlatformAdminManagement.tsx`
- Manage admin team
- Invite new platform admins
- Role assignment (super_admin, support_admin, billing_admin)
- Remove admin access

### Impersonation Banner
**File**: `components/platform-admin/ImpersonationBanner.tsx`
**Purpose**: Warning banner during user impersonation sessions

**Features**:
- Prominent red warning bar
- Target user info display
- Session timer
- "End Impersonation" button

---

## 9. Draggable Window System

### DraggableWindow
**File**: `components/DraggableWindow.tsx`
**Purpose**: Wrapper for pop-out panels

**Features**:
- Draggable header
- Resizable (via drag handles)
- Minimize/close buttons
- Z-index management
- Remembers position

**Used by**: Analytics, Backlog, P&L, Capacity, Roster, Graveyard, Cashflow, Project List when popped out

---

## 10. Summary Statistics

| Category | Count |
|----------|-------|
| Public pages | 3 |
| Main dashboard views | 5 |
| Collapsible panels | 5 |
| Full-screen modals | 9 |
| Configuration tabs | 12 |
| Pop-out windows | 7 |
| Platform admin views | 4 |
| **Total distinct UI components** | **~45** |

---

## Component File Index

```
components/
├── AnalyticsPanel.tsx          # KPI metrics dashboard
├── BacklogPanel.tsx            # Unscheduled job queue
├── CapacityForecaster.tsx      # Labor capacity visualization
├── CashflowForecastExpanded.tsx # Detailed cashflow view
├── ConfigurationPanel.tsx      # Fleet, hangars, stages config
├── DailyFinancialTracker.tsx   # Day-by-day P&L tracker
├── DraggableWindow.tsx         # Pop-out window wrapper
├── FullScreenDashboard.tsx     # Presentation mode
├── GanttBoard.tsx              # Main scheduling timeline
├── GraveyardPanel.tsx          # Archived jobs management
├── JobDetailsModal.tsx         # Job view/edit modal
├── LandingPage.tsx             # Marketing homepage
├── MagicSchedulerWizard.tsx    # Batch optimization wizard
├── MechanicsManager.tsx        # (Legacy/unused)
├── NotificationCenter.tsx      # Toast notifications
├── OnboardingTour.tsx          # Interactive tutorial
├── PersonnelManager.tsx        # Workforce management
├── ProjectListPanel.tsx        # Tabular project view
├── QuoteBuilder.tsx            # Quote creation/editing
├── RosterPanel.tsx             # Active workforce display
├── SetupDefaultsPanel.tsx      # Initial configuration
├── WelcomeSplash.tsx           # First-login welcome
├── admin/
│   └── UserManagement.tsx      # Organization user admin
├── auth/
│   ├── AuthCallback.tsx        # OAuth callback handler
│   ├── ChangePasswordModal.tsx # Password update
│   ├── LoginPage.tsx           # User login
│   └── RegisterPage.tsx        # User registration
└── platform-admin/
    ├── ImpersonationBanner.tsx # Impersonation warning
    ├── OrganizationDetails.tsx # Org detail view
    ├── OrganizationList.tsx    # Org list/search
    ├── PlatformAdminManagement.tsx # Admin team management
    ├── PlatformAnalytics.tsx   # Platform metrics
    ├── PlatformDashboard.tsx   # Main platform admin UI
    └── UserSearch.tsx          # Global user search
```

---

## UI State Management

The application uses a centralized `UIState` object within `GameState` to track:

```typescript
interface UIState {
  backlogOpen: boolean;      // Left sidebar visibility
  analyticsOpen: boolean;    // Bottom analytics panel
  pnlOpen: boolean;          // Bottom P&L panel
  capacityOpen: boolean;     // Bottom capacity panel
  rosterOpen: boolean;       // Right roster sidebar
  cellWidth: number;         // Gantt zoom level (px per day)
  layoutDims: {              // Resizable panel dimensions
    backlogWidth: number;
    rosterWidth: number;
    capacityHeight: number;
    pnlHeight: number;
    analyticsHeight: number;
  };
  popouts: {                 // Floating window states
    analytics: boolean;
    backlog: boolean;
    pnl: boolean;
    cashflow: boolean;
    capacity: boolean;
    roster: boolean;
    graveyard: boolean;
    projectList: boolean;
  };
  scenarioStart?: number;    # Analytics date range start
  scenarioEnd?: number;      # Analytics date range end
  selectedBaseId: string;    # Current base filter
  tutorialActive: boolean;   # Onboarding tour state
  tutorialStep: number;      # Current tutorial step
}
```

---

## 11. UI Rebrand Progress (Linear.app Aesthetic)

This section documents the ongoing UI rebrand to match Linear.app's ultra-polished aesthetic.

### Rebrand Overview

**Target Aesthetic**: Linear.app's minimalist, professional dark theme
- Clean typography (Inter font throughout)
- Subtle borders (`rgba(255,255,255,0.08)`)
- Indigo/violet accent colors instead of cyan
- Reduced visual noise (no scanlines, less glow effects)
- Purposeful micro-animations

### Completed Phases

#### Phase 1: Design System Foundation ✅

**New Files Created:**
- `styles/design-tokens.css` - CSS custom properties for colors, typography, spacing, shadows, animations
- `styles/utilities.css` - Reusable utility classes built on tokens

**Updated Files:**
- `index.html` - Imports design system, extends Tailwind config, removed scanlines

**Key Design Tokens:**
```css
/* Backgrounds */
--color-bg-app: #08090a;
--color-bg-panel: #0d0e10;
--color-bg-elevated: #141517;
--color-bg-surface: #1a1b1e;

/* Text */
--color-text-primary: #e8e8e8;
--color-text-secondary: #9ca3af;
--color-text-tertiary: #6b7280;

/* Borders */
--color-border-default: rgba(255,255,255,0.08);
--color-border-subtle: rgba(255,255,255,0.04);

/* Accent */
--color-accent-primary: #6366f1;  /* Indigo */
--color-accent-hover: #818cf8;

/* Job Status (preserved) */
--color-job-wip: #8b5cf6;         /* Violet */
--color-job-authorized: #f43f5e;  /* Rose */
--color-job-complete: #22c55e;    /* Emerald */
--color-job-rts: #06b6d4;         /* Cyan */
```

#### Phase 2: Shared Components & Auth Pages ✅

**Updated Files:**
- `components/DraggableWindow.tsx` - Pop-out window wrapper (affects 7+ panels)
- `components/LandingPage.tsx` - Complete marketing page redesign
- `components/auth/LoginPage.tsx` - Clean auth form
- `components/auth/RegisterPage.tsx` - Matching registration flow

#### Phase 3: Sidebar Panels ✅

**Updated Files:**
- `components/BacklogPanel.tsx` - Job cards, quote cards, drag-drop styling
- `components/RosterPanel.tsx` - Team roster, shift displays, personnel cards
- `components/GraveyardPanel.tsx` - Archived jobs display
- `components/ProjectListPanel.tsx` - Data table with filters and exports

#### Phase 4: Analytics Panels ✅

**Updated Files:**
- `components/AnalyticsPanel.tsx` - Docked view updated with indigo accents
- `components/DailyFinancialTracker.tsx` - Updated with Linear styling
- `components/CapacityForecaster.tsx` - Updated with new design tokens
- `components/CashflowForecastExpanded.tsx` - Updated with new color scheme

#### Phase 5: Core Dashboard ✅

**Updated Files:**
- `components/GanttBoard.tsx` ✅ - Complete rebrand (~1,417 LOC)
  - Header/quarters/months row styling
  - Day cells with new hover states
  - Hangar row styling
  - Job bar styling (preserved status colors)
  - Edit mode interactions (indigo highlights)
  - Tooltips and cursors
- `App.tsx` ✅ - Main application chrome (~2,113 LOC)
  - Header toolbar with all navigation buttons
  - User dropdown menu
  - View mode dropdowns
  - Edit tools popup
  - Loading screens
  - Quote success popup
  - Save indicator
  - Bottom dock container

**Remaining in Phase 5:**
- `components/FullScreenDashboard.tsx` (~63 LOC)
- `components/NotificationCenter.tsx` (~64 LOC)

### Remaining Phases

#### Phase 6: Configuration Panels (Pending)
- `components/PersonnelManager.tsx` (~987 LOC)
- `components/ConfigurationPanel.tsx` (~899 LOC)
- `components/FinancialPanel.tsx` (~704 LOC)
- `components/QuoteBuilder.tsx` (~1,198 LOC)

#### Phase 7: Modals & Admin (Pending)
- `components/JobDetailsModal.tsx` (~410 LOC)
- `components/MagicSchedulerWizard.tsx` (~231 LOC)
- `components/WelcomeSplash.tsx` (~66 LOC)
- `components/OnboardingTour.tsx` (~632 LOC)
- `components/SetupDefaultsPanel.tsx` (~328 LOC)
- `components/auth/ChangePasswordModal.tsx` (~156 LOC)
- `components/admin/UserManagement.tsx` (~285 LOC)
- `components/platform-admin/*.tsx` (6 files, ~2,900 LOC total)

### Global Search-Replace Patterns

When continuing the rebrand, apply these replacements:

| Old Pattern | New Pattern |
|-------------|-------------|
| `bg-slate-950` | `bg-[#08090a]` |
| `bg-slate-900` | `bg-[#0d0e10]` |
| `bg-slate-800` | `bg-[#141517]` |
| `bg-slate-700` | `bg-[#1a1b1e]` |
| `border-slate-700` | `border-white/[0.08]` |
| `border-slate-800` | `border-white/[0.06]` |
| `text-slate-300` | `text-[#e8e8e8]` |
| `text-slate-400` | `text-[#9ca3af]` |
| `text-slate-500` | `text-[#6b7280]` |
| `text-cyan-400` | `text-indigo-400` |
| `text-cyan-500` | `text-indigo-500` |
| `bg-cyan-600` | `bg-indigo-500` |
| `hover:bg-cyan-500` | `hover:bg-indigo-400` |
| `border-cyan-500/30` | `border-indigo-500/30` or `border-white/[0.08]` |
| `font-tactical` | Remove (use `font-semibold` or `font-medium`) |
| `uppercase tracking-widest` | Remove or use `tracking-wide` |
| `shadow-[0_0_*px_rgba(6,182,212,*)]` | Remove glow shadows |
| `backdrop-blur-xl` | `backdrop-blur-sm` |
| `animate-pulse` | Remove (except for AOG alerts) |
| `animate-ping` | Remove (except for critical indicators) |

### Typography Changes

1. Remove `font-tactical` class usage (Rajdhani font removed)
2. Use Inter font throughout
3. Replace `uppercase` labels with sentence case
4. Replace `tracking-widest` with `tracking-wide` or remove
5. Reduce font weights (600 → 500 for most headings)

### Color Preservation

Keep these semantic status colors unchanged:
- **Rose/Red**: AOG status, errors, authorized jobs
- **Emerald/Green**: Completed status, success states
- **Amber/Yellow**: Warnings
- **Violet**: Work-in-progress jobs (but remove glow effects)

### Animation Guidelines

**Remove:**
- `animate-pulse` (except critical alerts)
- `animate-ping` (except status indicators)
- `animate-bounce`
- Heavy glow transitions

**Keep/Add:**
- `transition-colors duration-150`
- `transition-all duration-150`
- Subtle hover states (`hover:bg-white/[0.05]`)

---

*Last updated: November 2024*
