-- ============================================================================
-- MRO-AI Database Schema
-- AeroManager 145 - Multi-tenant SaaS for Aviation Maintenance
-- ============================================================================
-- Run this in Supabase SQL Editor: https://supabase.com/dashboard/project/_/sql
-- ============================================================================

-- ============================================================================
-- PART 1: CORE TABLES
-- ============================================================================

-- 1. Organizations (tenant root - every customer company)
CREATE TABLE organizations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    slug TEXT UNIQUE NOT NULL,
    subscription_status TEXT DEFAULT 'trial' CHECK (subscription_status IN ('trial', 'active', 'cancelled', 'past_due')),
    subscription_tier TEXT DEFAULT 'standard',
    trial_ends_at TIMESTAMPTZ DEFAULT (NOW() + INTERVAL '14 days'),
    stripe_customer_id TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Profiles (extends Supabase auth.users)
CREATE TABLE profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
    email TEXT NOT NULL,
    full_name TEXT,
    role TEXT DEFAULT 'member' CHECK (role IN ('owner', 'admin', 'manager', 'technician', 'viewer')),
    avatar_url TEXT,
    auth_provider TEXT CHECK (auth_provider IN ('email', 'google')),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================================
-- PART 2: FACILITY TABLES
-- ============================================================================

-- 3. Bases (physical locations)
CREATE TABLE bases (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
    name TEXT NOT NULL,
    location TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. Hangars
CREATE TABLE hangars (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
    base_id UUID REFERENCES bases(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    size TEXT CHECK (size IN ('Small', 'Medium', 'Large')),
    supported_types TEXT[],
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. Aircraft Models
CREATE TABLE aircraft_models (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
    code TEXT NOT NULL,
    name TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(organization_id, code)
);

-- ============================================================================
-- PART 3: PERSONNEL TABLES
-- ============================================================================

-- 6. Roles (job titles with rates)
CREATE TABLE roles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
    name TEXT NOT NULL,
    base_efficiency DECIMAL(3,2) DEFAULT 1.0,
    hourly_cost DECIMAL(10,2) NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 7. Shifts (work schedules)
CREATE TABLE shifts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
    name TEXT NOT NULL,
    days INTEGER[] NOT NULL,
    start_hour INTEGER NOT NULL,
    duration DECIMAL(4,2) NOT NULL,
    break_count INTEGER DEFAULT 0,
    break_duration INTEGER DEFAULT 0,
    meeting_duration INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 8. Teams
CREATE TABLE teams (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
    name TEXT NOT NULL,
    color TEXT,
    shift_id UUID REFERENCES shifts(id) ON DELETE SET NULL,
    base_id UUID REFERENCES bases(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 9. Personnel (mechanics/staff)
CREATE TABLE personnel (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
    name TEXT NOT NULL,
    role_id UUID REFERENCES roles(id) ON DELETE SET NULL,
    team_id UUID REFERENCES teams(id) ON DELETE SET NULL,
    base_id UUID REFERENCES bases(id) ON DELETE SET NULL,
    efficiency_override DECIMAL(3,2),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================================
-- PART 4: JOB TABLES
-- ============================================================================

-- 10. Jobs (backlog - unscheduled work)
CREATE TABLE jobs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
    customer TEXT NOT NULL,
    aircraft_type TEXT NOT NULL,
    description TEXT NOT NULL,
    estimated_hours DECIMAL(10,2) NOT NULL,
    revenue DECIMAL(12,2) NOT NULL,
    parts_revenue DECIMAL(12,2) DEFAULT 0,
    color TEXT DEFAULT 'bg-slate-500',
    deadline_days INTEGER NOT NULL,
    required_hangar_size TEXT CHECK (required_hangar_size IN ('Small', 'Medium', 'Large')),
    is_aog BOOLEAN DEFAULT FALSE,
    arrival_day INTEGER,
    notes TEXT,
    is_deleted BOOLEAN DEFAULT FALSE,
    deleted_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 11. Quote Line Items
CREATE TABLE quote_line_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    job_id UUID REFERENCES jobs(id) ON DELETE CASCADE NOT NULL,
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
    description TEXT NOT NULL,
    category TEXT CHECK (category IN ('Labor', 'Part', 'Service')),
    labor_hours DECIMAL(10,2) DEFAULT 0,
    labor_rate DECIMAL(10,2) DEFAULT 0,
    parts_cost DECIMAL(12,2) DEFAULT 0,
    parts_markup DECIMAL(4,2) DEFAULT 1.0,
    fixed_price DECIMAL(12,2),
    sort_order INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 12. Scheduled Jobs
CREATE TABLE scheduled_jobs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
    job_id UUID REFERENCES jobs(id) ON DELETE CASCADE NOT NULL,
    hangar_id UUID REFERENCES hangars(id) ON DELETE SET NULL,
    start_date INTEGER NOT NULL,
    end_date INTEGER,
    progress DECIMAL(10,2) DEFAULT 0,
    status TEXT DEFAULT 'Scheduled' CHECK (status IN ('Scheduled', 'In Progress', 'Completed', 'Late')),
    payment_received BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 13. Scheduled Job Non-Work Days
CREATE TABLE scheduled_job_non_work_days (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    scheduled_job_id UUID REFERENCES scheduled_jobs(id) ON DELETE CASCADE NOT NULL,
    day_offset INTEGER NOT NULL,
    UNIQUE(scheduled_job_id, day_offset)
);

-- 14. Scheduled Job Daily Efforts
CREATE TABLE scheduled_job_daily_efforts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    scheduled_job_id UUID REFERENCES scheduled_jobs(id) ON DELETE CASCADE NOT NULL,
    day_offset INTEGER NOT NULL,
    effort DECIMAL(4,2) NOT NULL,
    UNIQUE(scheduled_job_id, day_offset)
);

-- ============================================================================
-- PART 5: SERVICE & CONFIG TABLES
-- ============================================================================

-- 15. Standard Services (templates)
CREATE TABLE standard_services (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
    description TEXT NOT NULL,
    category TEXT CHECK (category IN ('Labor', 'Part', 'Service')),
    labor_hours DECIMAL(10,2) DEFAULT 0,
    labor_rate DECIMAL(10,2) DEFAULT 0,
    parts_cost DECIMAL(12,2) DEFAULT 0,
    parts_markup DECIMAL(4,2) DEFAULT 1.0,
    applicable_model_id UUID REFERENCES aircraft_models(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 16. Project Stages (workflow)
CREATE TABLE project_stages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
    label TEXT NOT NULL,
    color TEXT NOT NULL,
    description TEXT,
    sort_order INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 17. Holidays
CREATE TABLE holidays (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
    name TEXT NOT NULL,
    date DATE NOT NULL,
    day_index INTEGER NOT NULL,
    enabled BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 18. Progress Cursors (timeline markers)
CREATE TABLE progress_cursors (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
    label TEXT NOT NULL,
    day_offset INTEGER NOT NULL,
    color TEXT NOT NULL,
    enabled BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================================
-- PART 6: FINANCIAL TABLES
-- ============================================================================

-- 19. Expense Items
CREATE TABLE expense_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
    category TEXT CHECK (category IN ('Facility', 'Admin', 'IT', 'Marketing', 'Personnel', 'Other')),
    name TEXT NOT NULL,
    monthly_cost DECIMAL(12,2) NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 20. Expense Overrides (monthly variations)
CREATE TABLE expense_overrides (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    expense_item_id UUID REFERENCES expense_items(id) ON DELETE CASCADE NOT NULL,
    year_month TEXT NOT NULL,
    override_amount DECIMAL(12,2) NOT NULL,
    UNIQUE(expense_item_id, year_month)
);

-- 21. Capex Items (capital expenditures)
CREATE TABLE capex_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
    name TEXT NOT NULL,
    cost DECIMAL(12,2) NOT NULL,
    planned_day INTEGER NOT NULL,
    amortize BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 22. Markup Tiers (pricing tiers)
CREATE TABLE markup_tiers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
    tier_type TEXT CHECK (tier_type IN ('parts', 'services')) NOT NULL,
    max_limit DECIMAL(12,2) NOT NULL,
    markup DECIMAL(4,2) NOT NULL,
    sort_order INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 23. Financial Log Entries (daily P&L)
CREATE TABLE financial_log_entries (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
    day INTEGER NOT NULL,
    income DECIMAL(12,2) DEFAULT 0,
    spend DECIMAL(12,2) DEFAULT 0,
    profit DECIMAL(12,2) DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(organization_id, day)
);

-- 24. Organization Settings (simulation state)
CREATE TABLE organization_settings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL UNIQUE,
    current_day INTEGER DEFAULT 0,
    cash DECIMAL(14,2) DEFAULT 500000,
    efficiency DECIMAL(4,2) DEFAULT 1.0,
    paused BOOLEAN DEFAULT TRUE,
    speed INTEGER DEFAULT 1,
    shop_rate DECIMAL(10,2) DEFAULT 125,
    overhead_daily DECIMAL(12,2) DEFAULT 4500,
    ui_state JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================================
-- PART 7: INDEXES FOR PERFORMANCE
-- ============================================================================

-- Organization lookups (used in every RLS policy)
CREATE INDEX idx_profiles_org ON profiles(organization_id);
CREATE INDEX idx_profiles_user ON profiles(id);

-- Job lookups
CREATE INDEX idx_jobs_org ON jobs(organization_id);
CREATE INDEX idx_jobs_deleted ON jobs(organization_id, is_deleted);
CREATE INDEX idx_scheduled_jobs_org ON scheduled_jobs(organization_id);
CREATE INDEX idx_scheduled_jobs_status ON scheduled_jobs(organization_id, status);

-- Personnel lookups
CREATE INDEX idx_personnel_org ON personnel(organization_id);
CREATE INDEX idx_personnel_team ON personnel(team_id);
CREATE INDEX idx_teams_org ON teams(organization_id);

-- Financial lookups
CREATE INDEX idx_financial_log_org_day ON financial_log_entries(organization_id, day);
CREATE INDEX idx_expense_items_org ON expense_items(organization_id);

-- Quote line items
CREATE INDEX idx_quote_lines_job ON quote_line_items(job_id);

-- ============================================================================
-- PART 8: ROW LEVEL SECURITY (RLS)
-- ============================================================================

-- Enable RLS on all tables
ALTER TABLE organizations ENABLE ROW LEVEL SECURITY;
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE bases ENABLE ROW LEVEL SECURITY;
ALTER TABLE hangars ENABLE ROW LEVEL SECURITY;
ALTER TABLE aircraft_models ENABLE ROW LEVEL SECURITY;
ALTER TABLE roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE shifts ENABLE ROW LEVEL SECURITY;
ALTER TABLE teams ENABLE ROW LEVEL SECURITY;
ALTER TABLE personnel ENABLE ROW LEVEL SECURITY;
ALTER TABLE jobs ENABLE ROW LEVEL SECURITY;
ALTER TABLE quote_line_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE scheduled_jobs ENABLE ROW LEVEL SECURITY;
ALTER TABLE scheduled_job_non_work_days ENABLE ROW LEVEL SECURITY;
ALTER TABLE scheduled_job_daily_efforts ENABLE ROW LEVEL SECURITY;
ALTER TABLE standard_services ENABLE ROW LEVEL SECURITY;
ALTER TABLE project_stages ENABLE ROW LEVEL SECURITY;
ALTER TABLE holidays ENABLE ROW LEVEL SECURITY;
ALTER TABLE progress_cursors ENABLE ROW LEVEL SECURITY;
ALTER TABLE expense_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE expense_overrides ENABLE ROW LEVEL SECURITY;
ALTER TABLE capex_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE markup_tiers ENABLE ROW LEVEL SECURITY;
ALTER TABLE financial_log_entries ENABLE ROW LEVEL SECURITY;
ALTER TABLE organization_settings ENABLE ROW LEVEL SECURITY;

-- ============================================================================
-- PART 9: RLS POLICIES
-- ============================================================================

-- Helper function to get user's organization
-- NOTE: Created in public schema (auth schema is protected in Supabase)
CREATE OR REPLACE FUNCTION public.get_user_organization_id()
RETURNS UUID AS $$
  SELECT organization_id FROM public.profiles WHERE id = auth.uid()
$$ LANGUAGE SQL SECURITY DEFINER STABLE;

-- Grant execute to authenticated users
GRANT EXECUTE ON FUNCTION public.get_user_organization_id() TO authenticated;

-- ----------------------------------------------------------------------------
-- Organizations policies
-- ----------------------------------------------------------------------------
CREATE POLICY "Users can view own organization"
    ON organizations FOR SELECT
    USING (id = public.get_user_organization_id());

CREATE POLICY "Owners can update organization"
    ON organizations FOR UPDATE
    USING (id = public.get_user_organization_id()
           AND EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'owner'));

-- Allow creating organizations during signup (before profile exists)
CREATE POLICY "Anyone can create organization during signup"
    ON organizations FOR INSERT
    WITH CHECK (true);

-- ----------------------------------------------------------------------------
-- Profiles policies
-- ----------------------------------------------------------------------------
CREATE POLICY "Users can view profiles in their organization"
    ON profiles FOR SELECT
    USING (organization_id = public.get_user_organization_id() OR id = auth.uid());

CREATE POLICY "Users can update own profile"
    ON profiles FOR UPDATE
    USING (id = auth.uid());

CREATE POLICY "Users can insert own profile"
    ON profiles FOR INSERT
    WITH CHECK (id = auth.uid());

-- ----------------------------------------------------------------------------
-- Standard org-based policies for all other tables
-- ----------------------------------------------------------------------------

-- Bases
CREATE POLICY "org_isolation" ON bases FOR ALL
    USING (organization_id = public.get_user_organization_id())
    WITH CHECK (organization_id = public.get_user_organization_id());

-- Hangars
CREATE POLICY "org_isolation" ON hangars FOR ALL
    USING (organization_id = public.get_user_organization_id())
    WITH CHECK (organization_id = public.get_user_organization_id());

-- Aircraft Models
CREATE POLICY "org_isolation" ON aircraft_models FOR ALL
    USING (organization_id = public.get_user_organization_id())
    WITH CHECK (organization_id = public.get_user_organization_id());

-- Roles
CREATE POLICY "org_isolation" ON roles FOR ALL
    USING (organization_id = public.get_user_organization_id())
    WITH CHECK (organization_id = public.get_user_organization_id());

-- Shifts
CREATE POLICY "org_isolation" ON shifts FOR ALL
    USING (organization_id = public.get_user_organization_id())
    WITH CHECK (organization_id = public.get_user_organization_id());

-- Teams
CREATE POLICY "org_isolation" ON teams FOR ALL
    USING (organization_id = public.get_user_organization_id())
    WITH CHECK (organization_id = public.get_user_organization_id());

-- Personnel
CREATE POLICY "org_isolation" ON personnel FOR ALL
    USING (organization_id = public.get_user_organization_id())
    WITH CHECK (organization_id = public.get_user_organization_id());

-- Jobs
CREATE POLICY "org_isolation" ON jobs FOR ALL
    USING (organization_id = public.get_user_organization_id())
    WITH CHECK (organization_id = public.get_user_organization_id());

-- Quote Line Items
CREATE POLICY "org_isolation" ON quote_line_items FOR ALL
    USING (organization_id = public.get_user_organization_id())
    WITH CHECK (organization_id = public.get_user_organization_id());

-- Scheduled Jobs
CREATE POLICY "org_isolation" ON scheduled_jobs FOR ALL
    USING (organization_id = public.get_user_organization_id())
    WITH CHECK (organization_id = public.get_user_organization_id());

-- Scheduled Job Non-Work Days (via scheduled_jobs)
CREATE POLICY "org_isolation" ON scheduled_job_non_work_days FOR ALL
    USING (scheduled_job_id IN (
        SELECT id FROM scheduled_jobs WHERE organization_id = public.get_user_organization_id()
    ))
    WITH CHECK (scheduled_job_id IN (
        SELECT id FROM scheduled_jobs WHERE organization_id = public.get_user_organization_id()
    ));

-- Scheduled Job Daily Efforts (via scheduled_jobs)
CREATE POLICY "org_isolation" ON scheduled_job_daily_efforts FOR ALL
    USING (scheduled_job_id IN (
        SELECT id FROM scheduled_jobs WHERE organization_id = public.get_user_organization_id()
    ))
    WITH CHECK (scheduled_job_id IN (
        SELECT id FROM scheduled_jobs WHERE organization_id = public.get_user_organization_id()
    ));

-- Standard Services
CREATE POLICY "org_isolation" ON standard_services FOR ALL
    USING (organization_id = public.get_user_organization_id())
    WITH CHECK (organization_id = public.get_user_organization_id());

-- Project Stages
CREATE POLICY "org_isolation" ON project_stages FOR ALL
    USING (organization_id = public.get_user_organization_id())
    WITH CHECK (organization_id = public.get_user_organization_id());

-- Holidays
CREATE POLICY "org_isolation" ON holidays FOR ALL
    USING (organization_id = public.get_user_organization_id())
    WITH CHECK (organization_id = public.get_user_organization_id());

-- Progress Cursors
CREATE POLICY "org_isolation" ON progress_cursors FOR ALL
    USING (organization_id = public.get_user_organization_id())
    WITH CHECK (organization_id = public.get_user_organization_id());

-- Expense Items
CREATE POLICY "org_isolation" ON expense_items FOR ALL
    USING (organization_id = public.get_user_organization_id())
    WITH CHECK (organization_id = public.get_user_organization_id());

-- Expense Overrides (via expense_items)
CREATE POLICY "org_isolation" ON expense_overrides FOR ALL
    USING (expense_item_id IN (
        SELECT id FROM expense_items WHERE organization_id = public.get_user_organization_id()
    ))
    WITH CHECK (expense_item_id IN (
        SELECT id FROM expense_items WHERE organization_id = public.get_user_organization_id()
    ));

-- Capex Items
CREATE POLICY "org_isolation" ON capex_items FOR ALL
    USING (organization_id = public.get_user_organization_id())
    WITH CHECK (organization_id = public.get_user_organization_id());

-- Markup Tiers
CREATE POLICY "org_isolation" ON markup_tiers FOR ALL
    USING (organization_id = public.get_user_organization_id())
    WITH CHECK (organization_id = public.get_user_organization_id());

-- Financial Log Entries
CREATE POLICY "org_isolation" ON financial_log_entries FOR ALL
    USING (organization_id = public.get_user_organization_id())
    WITH CHECK (organization_id = public.get_user_organization_id());

-- Organization Settings
CREATE POLICY "org_isolation" ON organization_settings FOR ALL
    USING (organization_id = public.get_user_organization_id())
    WITH CHECK (organization_id = public.get_user_organization_id());

-- ============================================================================
-- PART 10: TRIGGERS FOR TIMESTAMPS
-- ============================================================================

-- Function to auto-update updated_at
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply to tables with updated_at
CREATE TRIGGER update_organizations_timestamp
    BEFORE UPDATE ON organizations
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER update_profiles_timestamp
    BEFORE UPDATE ON profiles
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER update_jobs_timestamp
    BEFORE UPDATE ON jobs
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER update_scheduled_jobs_timestamp
    BEFORE UPDATE ON scheduled_jobs
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER update_organization_settings_timestamp
    BEFORE UPDATE ON organization_settings
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- ============================================================================
-- SCHEMA COMPLETE!
-- ============================================================================
-- Tables created: 24
-- Indexes created: 11
-- RLS enabled on all tables
-- Policies created for multi-tenant isolation
-- ============================================================================
