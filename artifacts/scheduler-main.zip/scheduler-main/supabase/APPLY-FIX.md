# How to Fix Registration Issues

## Problem
Users cannot register new accounts due to RLS (Row-Level Security) policy violations on the `organizations` and `profiles` tables.

**Error messages you were seeing:**
```
Error: new row violates row-level security policy for table "organizations"
Error: new row violates row-level security policy for table "profiles"
401 Unauthorized on POST requests
```

## Root Cause
The registration flow was trying to manually create organizations and profiles using client-side INSERT operations, which were being blocked by RLS policies because the user wasn't fully authenticated yet (email not verified).

## Solution
Use a **database trigger** that automatically creates the organization and profile when a user signs up. The trigger runs with `SECURITY DEFINER` privileges, bypassing RLS.

## Steps to Apply Fix

### 1. Apply the Database Trigger

Go to your Supabase dashboard:
1. Navigate to https://supabase.com/dashboard
2. Select your project (kmjjymsbwjfkwhcgrdfr)
3. Go to **SQL Editor**
4. Click **New Query**
5. Copy and paste the contents of `supabase/schema-fixed.sql`
6. Click **Run** (or press Cmd/Ctrl + Enter)

**What this does:**
- Updates the RLS policy to allow profile creation
- Creates a `handle_new_user()` function that runs on signup
- Creates a trigger on `auth.users` that auto-creates org + profile

### 2. Code Changes (Already Done)

The `AuthContext.tsx` file has been updated to remove manual organization/profile creation. The database trigger now handles this automatically.

### 3. Test Registration

After applying the SQL fix:

1. Open http://localhost:3001
2. Click **Register** or **Create Account**
3. Fill in the form:
   - Name: Test User
   - Email: test@example.com
   - Password: testpass123
4. Submit the form
5. **You should see:** "Check Your Email" success screen
6. Check the browser console - **no more 401 errors!**

### 4. Verify Data Initialization

After you verify your email and log in:

1. The app should automatically call `initializeOrganizationData()`
2. You should see:
   - ✅ 10 technicians in the roster
   - ✅ 4 hangars (Hangar 1 - Heavy Jets, etc.)
   - ✅ 10 jobs in the backlog

**If you don't see data:**
1. Open browser DevTools (F12)
2. Go to Console tab
3. Look for logs like: "No cloud data found, initializing with defaults..."
4. If you see those logs, data should load within a few seconds

## Alternative: Disable Email Verification (Development Only)

If you want to skip email verification during development:

1. Go to Supabase Dashboard
2. Navigate to **Authentication** → **Settings**
3. Scroll to **Email Auth**
4. **Disable** "Enable email confirmations"
5. Save changes

Now users can register and log in immediately without email verification.

⚠️ **IMPORTANT:** Re-enable this before going to production!

## Troubleshooting

### Still getting 401 errors after applying fix?
- Make sure you ran the SQL in `schema-fixed.sql`
- Check the Supabase SQL Editor for any error messages
- Verify the trigger was created: Run `SELECT * FROM information_schema.triggers WHERE trigger_name = 'on_auth_user_created';`

### Profile not being created?
- Check Supabase logs: Dashboard → Logs → select "Database"
- Look for errors in the `handle_new_user()` function

### Data not loading after login?
- Check browser console for errors
- Verify RLS policies allow data queries: `SELECT * FROM personnel;` in SQL Editor
- Try the force-reinit tool at http://localhost:3000/force-reinit.html

## What Changed

**Before:**
```typescript
// Client-side code tried to INSERT organizations and profiles
// ❌ Blocked by RLS because user not fully authenticated
await supabase.from('organizations').insert({ ... });
await supabase.from('profiles').insert({ ... });
```

**After:**
```typescript
// Just create the auth user
// ✅ Database trigger auto-creates org + profile with elevated privileges
await supabase.auth.signUp({ email, password });
```

## Next Steps

Once registration works:
1. Create a test account
2. Verify email (or disable confirmation)
3. Log in
4. Verify all 10 technicians, 4 hangars, and 10 jobs are visible
5. Test scheduling jobs, managing personnel, etc.
