-- ============================================================================
-- 🚀 AEROMANAGER ONE-SHOT DATABASE MIGRATION
-- ============================================================================
-- This script is IDEMPOTENT - safe to run multiple times
-- Combines: COMPLETE-SETUP.sql + platform-admin.sql
--
-- HOW TO RUN:
-- 1. Go to https://supabase.com/dashboard
-- 2. Select your project
-- 3. Click "SQL Editor" in the left sidebar
-- 4. Click "New Query"
-- 5. Paste this ENTIRE file
-- 6. Click "Run" (or Cmd/Ctrl + Enter)
-- ============================================================================

-- ============================================================================
-- PART 1: CORE TABLES
-- ============================================================================

-- 1. Organizations (tenant root)
CREATE TABLE IF NOT EXISTS organizations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    slug TEXT UNIQUE NOT NULL,
    subscription_status TEXT DEFAULT 'trial' CHECK (subscription_status IN ('trial', 'active', 'cancelled', 'past_due')),
    subscription_tier TEXT DEFAULT 'standard',
    trial_ends_at TIMESTAMPTZ DEFAULT (NOW() + INTERVAL '14 days'),
    stripe_customer_id TEXT,
    -- Platform admin columns (added by platform-admin migration)
    grace_period_used BOOLEAN DEFAULT FALSE,
    grace_period_ends_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Add grace period columns if they don't exist (for existing databases)
DO $$ BEGIN
    ALTER TABLE organizations ADD COLUMN IF NOT EXISTS grace_period_used BOOLEAN DEFAULT FALSE;
    ALTER TABLE organizations ADD COLUMN IF NOT EXISTS grace_period_ends_at TIMESTAMPTZ;
EXCEPTION WHEN OTHERS THEN NULL;
END $$;

-- 2. Profiles (extends Supabase auth.users)
CREATE TABLE IF NOT EXISTS profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
    email TEXT NOT NULL,
    full_name TEXT,
    role TEXT DEFAULT 'member' CHECK (role IN ('owner', 'admin', 'manager', 'technician', 'viewer')),
    avatar_url TEXT,
    auth_provider TEXT CHECK (auth_provider IN ('email', 'google')),
    -- Platform admin columns
    is_platform_admin BOOLEAN DEFAULT FALSE,
    platform_role TEXT CHECK (platform_role IS NULL OR platform_role IN ('super_admin', 'support_admin', 'billing_admin')),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Add platform admin columns if they don't exist (for existing databases)
DO $$ BEGIN
    ALTER TABLE profiles ADD COLUMN IF NOT EXISTS is_platform_admin BOOLEAN DEFAULT FALSE;
    ALTER TABLE profiles ADD COLUMN IF NOT EXISTS platform_role TEXT CHECK (
        platform_role IS NULL OR platform_role IN ('super_admin', 'support_admin', 'billing_admin')
    );
EXCEPTION WHEN OTHERS THEN NULL;
END $$;

-- ============================================================================
-- PART 2: FACILITY TABLES
-- ============================================================================

-- 3. Bases (physical locations)
CREATE TABLE IF NOT EXISTS bases (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
    name TEXT NOT NULL,
    location TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. Hangars
CREATE TABLE IF NOT EXISTS hangars (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
    base_id UUID REFERENCES bases(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    size TEXT CHECK (size IN ('Small', 'Medium', 'Large')),
    supported_types TEXT[],
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. Aircraft Models
CREATE TABLE IF NOT EXISTS aircraft_models (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
    code TEXT NOT NULL,
    name TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(organization_id, code)
);

-- ============================================================================
-- PART 3: PERSONNEL TABLES
-- ============================================================================

-- 6. Roles (job titles with rates)
CREATE TABLE IF NOT EXISTS roles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
    name TEXT NOT NULL,
    base_efficiency DECIMAL(3,2) DEFAULT 1.0,
    hourly_cost DECIMAL(10,2) NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 7. Shifts (work schedules)
CREATE TABLE IF NOT EXISTS shifts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
    name TEXT NOT NULL,
    days INTEGER[] NOT NULL,
    start_hour INTEGER NOT NULL,
    duration DECIMAL(4,2) NOT NULL,
    break_count INTEGER DEFAULT 0,
    break_duration INTEGER DEFAULT 0,
    meeting_duration INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 8. Teams
CREATE TABLE IF NOT EXISTS teams (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
    name TEXT NOT NULL,
    color TEXT,
    shift_id UUID REFERENCES shifts(id) ON DELETE SET NULL,
    base_id UUID REFERENCES bases(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 9. Personnel (mechanics/staff)
CREATE TABLE IF NOT EXISTS personnel (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
    name TEXT NOT NULL,
    role_id UUID REFERENCES roles(id) ON DELETE SET NULL,
    team_id UUID REFERENCES teams(id) ON DELETE SET NULL,
    base_id UUID REFERENCES bases(id) ON DELETE SET NULL,
    efficiency_override DECIMAL(3,2),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================================
-- PART 4: JOB TABLES
-- ============================================================================

-- 10. Jobs (backlog - unscheduled work)
CREATE TABLE IF NOT EXISTS jobs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
    customer TEXT NOT NULL,
    aircraft_type TEXT NOT NULL,
    description TEXT NOT NULL,
    estimated_hours DECIMAL(10,2) NOT NULL,
    revenue DECIMAL(12,2) NOT NULL,
    parts_revenue DECIMAL(12,2) DEFAULT 0,
    color TEXT DEFAULT 'bg-slate-500',
    deadline_days INTEGER NOT NULL,
    required_hangar_size TEXT CHECK (required_hangar_size IN ('Small', 'Medium', 'Large')),
    is_aog BOOLEAN DEFAULT FALSE,
    arrival_day INTEGER,
    notes TEXT,
    is_deleted BOOLEAN DEFAULT FALSE,
    deleted_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 11. Quote Line Items
CREATE TABLE IF NOT EXISTS quote_line_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    job_id UUID REFERENCES jobs(id) ON DELETE CASCADE NOT NULL,
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
    description TEXT NOT NULL,
    category TEXT CHECK (category IN ('Labor', 'Part', 'Service')),
    labor_hours DECIMAL(10,2) DEFAULT 0,
    labor_rate DECIMAL(10,2) DEFAULT 0,
    parts_cost DECIMAL(12,2) DEFAULT 0,
    parts_markup DECIMAL(4,2) DEFAULT 1.0,
    fixed_price DECIMAL(12,2),
    sort_order INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 12. Scheduled Jobs
CREATE TABLE IF NOT EXISTS scheduled_jobs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
    job_id UUID REFERENCES jobs(id) ON DELETE CASCADE NOT NULL,
    hangar_id UUID REFERENCES hangars(id) ON DELETE SET NULL,
    start_date INTEGER NOT NULL,
    end_date INTEGER,
    progress DECIMAL(10,2) DEFAULT 0,
    status TEXT DEFAULT 'Scheduled' CHECK (status IN ('Scheduled', 'In Progress', 'Completed', 'Late')),
    payment_received BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 13. Scheduled Job Non-Work Days
CREATE TABLE IF NOT EXISTS scheduled_job_non_work_days (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    scheduled_job_id UUID REFERENCES scheduled_jobs(id) ON DELETE CASCADE NOT NULL,
    day_offset INTEGER NOT NULL,
    UNIQUE(scheduled_job_id, day_offset)
);

-- 14. Scheduled Job Daily Efforts
CREATE TABLE IF NOT EXISTS scheduled_job_daily_efforts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    scheduled_job_id UUID REFERENCES scheduled_jobs(id) ON DELETE CASCADE NOT NULL,
    day_offset INTEGER NOT NULL,
    effort DECIMAL(4,2) NOT NULL,
    UNIQUE(scheduled_job_id, day_offset)
);

-- ============================================================================
-- PART 5: SERVICE & CONFIG TABLES
-- ============================================================================

-- 15. Standard Services (templates)
CREATE TABLE IF NOT EXISTS standard_services (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
    description TEXT NOT NULL,
    category TEXT CHECK (category IN ('Labor', 'Part', 'Service')),
    labor_hours DECIMAL(10,2) DEFAULT 0,
    labor_rate DECIMAL(10,2) DEFAULT 0,
    parts_cost DECIMAL(12,2) DEFAULT 0,
    parts_markup DECIMAL(4,2) DEFAULT 1.0,
    applicable_model_id UUID REFERENCES aircraft_models(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 16. Project Stages (workflow)
CREATE TABLE IF NOT EXISTS project_stages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
    label TEXT NOT NULL,
    color TEXT NOT NULL,
    description TEXT,
    sort_order INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 17. Holidays
CREATE TABLE IF NOT EXISTS holidays (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
    name TEXT NOT NULL,
    date DATE NOT NULL,
    day_index INTEGER NOT NULL,
    enabled BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 18. Progress Cursors (timeline markers)
CREATE TABLE IF NOT EXISTS progress_cursors (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
    label TEXT NOT NULL,
    day_offset INTEGER NOT NULL,
    color TEXT NOT NULL,
    enabled BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================================
-- PART 6: FINANCIAL TABLES
-- ============================================================================

-- 19. Expense Items
CREATE TABLE IF NOT EXISTS expense_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
    category TEXT CHECK (category IN ('Facility', 'Admin', 'IT', 'Marketing', 'Personnel', 'Other')),
    name TEXT NOT NULL,
    monthly_cost DECIMAL(12,2) NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 20. Expense Overrides (monthly variations)
CREATE TABLE IF NOT EXISTS expense_overrides (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    expense_item_id UUID REFERENCES expense_items(id) ON DELETE CASCADE NOT NULL,
    year_month TEXT NOT NULL,
    override_amount DECIMAL(12,2) NOT NULL,
    UNIQUE(expense_item_id, year_month)
);

-- 21. Capex Items (capital expenditures)
CREATE TABLE IF NOT EXISTS capex_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
    name TEXT NOT NULL,
    cost DECIMAL(12,2) NOT NULL,
    planned_day INTEGER NOT NULL,
    amortize BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 22. Markup Tiers (pricing tiers)
CREATE TABLE IF NOT EXISTS markup_tiers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
    tier_type TEXT CHECK (tier_type IN ('parts', 'services')) NOT NULL,
    max_limit DECIMAL(12,2) NOT NULL,
    markup DECIMAL(4,2) NOT NULL,
    sort_order INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 23. Financial Log Entries (daily P&L)
CREATE TABLE IF NOT EXISTS financial_log_entries (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
    day INTEGER NOT NULL,
    income DECIMAL(12,2) DEFAULT 0,
    spend DECIMAL(12,2) DEFAULT 0,
    profit DECIMAL(12,2) DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(organization_id, day)
);

-- 24. Organization Settings (simulation state)
CREATE TABLE IF NOT EXISTS organization_settings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL UNIQUE,
    current_day INTEGER DEFAULT 0,
    cash DECIMAL(14,2) DEFAULT 500000,
    efficiency DECIMAL(4,2) DEFAULT 1.0,
    paused BOOLEAN DEFAULT TRUE,
    speed INTEGER DEFAULT 1,
    shop_rate DECIMAL(10,2) DEFAULT 125,
    overhead_daily DECIMAL(12,2) DEFAULT 4500,
    ui_state JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================================
-- PART 7: PLATFORM ADMIN TABLES
-- ============================================================================

-- 25. Platform Admin Invites
CREATE TABLE IF NOT EXISTS platform_admin_invites (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('super_admin', 'support_admin', 'billing_admin')),
    invited_by UUID REFERENCES profiles(id) ON DELETE SET NULL,
    token TEXT NOT NULL UNIQUE,
    expires_at TIMESTAMPTZ NOT NULL,
    accepted_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    CONSTRAINT unique_pending_invite UNIQUE (email)
);

-- 26. Platform Audit Log
CREATE TABLE IF NOT EXISTS platform_audit_log (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    admin_id UUID REFERENCES profiles(id) ON DELETE SET NULL,
    action TEXT NOT NULL,
    target_type TEXT,
    target_id UUID,
    details JSONB DEFAULT '{}',
    ip_address TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================================
-- PART 8: INDEXES FOR PERFORMANCE
-- ============================================================================

CREATE INDEX IF NOT EXISTS idx_profiles_org ON profiles(organization_id);
CREATE INDEX IF NOT EXISTS idx_profiles_user ON profiles(id);
CREATE INDEX IF NOT EXISTS idx_profiles_platform_admin ON profiles(is_platform_admin) WHERE is_platform_admin = TRUE;
CREATE INDEX IF NOT EXISTS idx_jobs_org ON jobs(organization_id);
CREATE INDEX IF NOT EXISTS idx_jobs_deleted ON jobs(organization_id, is_deleted);
CREATE INDEX IF NOT EXISTS idx_scheduled_jobs_org ON scheduled_jobs(organization_id);
CREATE INDEX IF NOT EXISTS idx_scheduled_jobs_status ON scheduled_jobs(organization_id, status);
CREATE INDEX IF NOT EXISTS idx_personnel_org ON personnel(organization_id);
CREATE INDEX IF NOT EXISTS idx_personnel_team ON personnel(team_id);
CREATE INDEX IF NOT EXISTS idx_teams_org ON teams(organization_id);
CREATE INDEX IF NOT EXISTS idx_financial_log_org_day ON financial_log_entries(organization_id, day);
CREATE INDEX IF NOT EXISTS idx_expense_items_org ON expense_items(organization_id);
CREATE INDEX IF NOT EXISTS idx_quote_lines_job ON quote_line_items(job_id);
CREATE INDEX IF NOT EXISTS idx_audit_log_admin ON platform_audit_log(admin_id);
CREATE INDEX IF NOT EXISTS idx_audit_log_created ON platform_audit_log(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_log_target ON platform_audit_log(target_type, target_id);

-- ============================================================================
-- PART 9: ENABLE ROW LEVEL SECURITY
-- ============================================================================

ALTER TABLE organizations ENABLE ROW LEVEL SECURITY;
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE bases ENABLE ROW LEVEL SECURITY;
ALTER TABLE hangars ENABLE ROW LEVEL SECURITY;
ALTER TABLE aircraft_models ENABLE ROW LEVEL SECURITY;
ALTER TABLE roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE shifts ENABLE ROW LEVEL SECURITY;
ALTER TABLE teams ENABLE ROW LEVEL SECURITY;
ALTER TABLE personnel ENABLE ROW LEVEL SECURITY;
ALTER TABLE jobs ENABLE ROW LEVEL SECURITY;
ALTER TABLE quote_line_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE scheduled_jobs ENABLE ROW LEVEL SECURITY;
ALTER TABLE scheduled_job_non_work_days ENABLE ROW LEVEL SECURITY;
ALTER TABLE scheduled_job_daily_efforts ENABLE ROW LEVEL SECURITY;
ALTER TABLE standard_services ENABLE ROW LEVEL SECURITY;
ALTER TABLE project_stages ENABLE ROW LEVEL SECURITY;
ALTER TABLE holidays ENABLE ROW LEVEL SECURITY;
ALTER TABLE progress_cursors ENABLE ROW LEVEL SECURITY;
ALTER TABLE expense_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE expense_overrides ENABLE ROW LEVEL SECURITY;
ALTER TABLE capex_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE markup_tiers ENABLE ROW LEVEL SECURITY;
ALTER TABLE financial_log_entries ENABLE ROW LEVEL SECURITY;
ALTER TABLE organization_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE platform_admin_invites ENABLE ROW LEVEL SECURITY;
ALTER TABLE platform_audit_log ENABLE ROW LEVEL SECURITY;

-- ============================================================================
-- PART 10: HELPER FUNCTIONS
-- ============================================================================

-- Get user's organization ID
CREATE OR REPLACE FUNCTION public.get_user_organization_id()
RETURNS UUID AS $$
  SELECT organization_id FROM public.profiles WHERE id = auth.uid()
$$ LANGUAGE SQL SECURITY DEFINER STABLE;

-- Check if user is platform admin
CREATE OR REPLACE FUNCTION public.is_platform_admin()
RETURNS BOOLEAN AS $$
  SELECT COALESCE(
    (SELECT is_platform_admin FROM public.profiles WHERE id = auth.uid()),
    FALSE
  )
$$ LANGUAGE SQL SECURITY DEFINER STABLE;

-- Get platform admin role
CREATE OR REPLACE FUNCTION public.get_platform_admin_role()
RETURNS TEXT AS $$
  SELECT platform_role FROM public.profiles WHERE id = auth.uid() AND is_platform_admin = TRUE
$$ LANGUAGE SQL SECURITY DEFINER STABLE;

-- Grant execute permissions
GRANT EXECUTE ON FUNCTION public.get_user_organization_id() TO authenticated;
GRANT EXECUTE ON FUNCTION public.is_platform_admin() TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_platform_admin_role() TO authenticated;

-- ============================================================================
-- PART 11: RLS POLICIES
-- ============================================================================

-- Organizations policies (with platform admin support)
DROP POLICY IF EXISTS "Users can view own organization" ON organizations;
DROP POLICY IF EXISTS "Users can view own organization or platform admins view all" ON organizations;
CREATE POLICY "Users can view own organization or platform admins view all"
    ON organizations FOR SELECT
    USING (
      id = public.get_user_organization_id()
      OR public.is_platform_admin() = TRUE
    );

DROP POLICY IF EXISTS "Owners can update organization" ON organizations;
DROP POLICY IF EXISTS "Owners or platform admins can update organization" ON organizations;
CREATE POLICY "Owners or platform admins can update organization"
    ON organizations FOR UPDATE
    USING (
      (id = public.get_user_organization_id()
       AND EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'owner'))
      OR (public.is_platform_admin() = TRUE
          AND public.get_platform_admin_role() IN ('super_admin', 'billing_admin'))
    );

DROP POLICY IF EXISTS "Anyone can create organization during signup" ON organizations;
CREATE POLICY "Anyone can create organization during signup"
    ON organizations FOR INSERT
    WITH CHECK (true);

-- Profiles policies (with platform admin support)
DROP POLICY IF EXISTS "Users can view profiles in their organization" ON profiles;
DROP POLICY IF EXISTS "Users can view org profiles or platform admins view all" ON profiles;
CREATE POLICY "Users can view org profiles or platform admins view all"
    ON profiles FOR SELECT
    USING (
      organization_id = public.get_user_organization_id()
      OR id = auth.uid()
      OR public.is_platform_admin() = TRUE
    );

DROP POLICY IF EXISTS "Users can update own profile" ON profiles;
CREATE POLICY "Users can update own profile"
    ON profiles FOR UPDATE
    USING (id = auth.uid());

DROP POLICY IF EXISTS "Users can insert own profile" ON profiles;
DROP POLICY IF EXISTS "Allow profile creation during signup" ON profiles;
CREATE POLICY "Allow profile creation during signup"
    ON profiles FOR INSERT
    WITH CHECK (true);

-- Standard org-based policies for all other tables
DO $$
DECLARE
    tbl_name text;
BEGIN
    FOR tbl_name IN
        SELECT unnest(ARRAY[
            'bases', 'hangars', 'aircraft_models', 'roles', 'shifts', 'teams',
            'personnel', 'jobs', 'quote_line_items', 'scheduled_jobs',
            'standard_services', 'project_stages', 'holidays', 'progress_cursors',
            'expense_items', 'capex_items', 'markup_tiers', 'financial_log_entries',
            'organization_settings'
        ])
    LOOP
        EXECUTE format('DROP POLICY IF EXISTS "org_isolation" ON %I', tbl_name);
        EXECUTE format('CREATE POLICY "org_isolation" ON %I FOR ALL
            USING (organization_id = public.get_user_organization_id())
            WITH CHECK (organization_id = public.get_user_organization_id())',
            tbl_name);
    END LOOP;
END $$;

-- Special policies for junction tables
DROP POLICY IF EXISTS "org_isolation" ON scheduled_job_non_work_days;
CREATE POLICY "org_isolation" ON scheduled_job_non_work_days FOR ALL
    USING (scheduled_job_id IN (
        SELECT id FROM scheduled_jobs WHERE organization_id = public.get_user_organization_id()
    ))
    WITH CHECK (scheduled_job_id IN (
        SELECT id FROM scheduled_jobs WHERE organization_id = public.get_user_organization_id()
    ));

DROP POLICY IF EXISTS "org_isolation" ON scheduled_job_daily_efforts;
CREATE POLICY "org_isolation" ON scheduled_job_daily_efforts FOR ALL
    USING (scheduled_job_id IN (
        SELECT id FROM scheduled_jobs WHERE organization_id = public.get_user_organization_id()
    ))
    WITH CHECK (scheduled_job_id IN (
        SELECT id FROM scheduled_jobs WHERE organization_id = public.get_user_organization_id()
    ));

DROP POLICY IF EXISTS "org_isolation" ON expense_overrides;
CREATE POLICY "org_isolation" ON expense_overrides FOR ALL
    USING (expense_item_id IN (
        SELECT id FROM expense_items WHERE organization_id = public.get_user_organization_id()
    ))
    WITH CHECK (expense_item_id IN (
        SELECT id FROM expense_items WHERE organization_id = public.get_user_organization_id()
    ));

-- Platform admin invites policies
DROP POLICY IF EXISTS "platform_admins_manage_invites" ON platform_admin_invites;
CREATE POLICY "platform_admins_manage_invites" ON platform_admin_invites FOR ALL
    USING (
      EXISTS (
        SELECT 1 FROM profiles
        WHERE id = auth.uid()
        AND is_platform_admin = TRUE
        AND platform_role = 'super_admin'
      )
    )
    WITH CHECK (
      EXISTS (
        SELECT 1 FROM profiles
        WHERE id = auth.uid()
        AND is_platform_admin = TRUE
        AND platform_role = 'super_admin'
      )
    );

-- Platform audit log policies
DROP POLICY IF EXISTS "platform_admins_view_audit" ON platform_audit_log;
CREATE POLICY "platform_admins_view_audit" ON platform_audit_log FOR SELECT
    USING (
      EXISTS (
        SELECT 1 FROM profiles
        WHERE id = auth.uid()
        AND is_platform_admin = TRUE
      )
    );

DROP POLICY IF EXISTS "platform_admins_insert_audit" ON platform_audit_log;
CREATE POLICY "platform_admins_insert_audit" ON platform_audit_log FOR INSERT
    WITH CHECK (
      EXISTS (
        SELECT 1 FROM profiles
        WHERE id = auth.uid()
        AND is_platform_admin = TRUE
      )
    );

-- ============================================================================
-- PART 12: AUTO-UPDATE TRIGGERS
-- ============================================================================

CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS update_organizations_timestamp ON organizations;
CREATE TRIGGER update_organizations_timestamp
    BEFORE UPDATE ON organizations
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

DROP TRIGGER IF EXISTS update_profiles_timestamp ON profiles;
CREATE TRIGGER update_profiles_timestamp
    BEFORE UPDATE ON profiles
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

DROP TRIGGER IF EXISTS update_jobs_timestamp ON jobs;
CREATE TRIGGER update_jobs_timestamp
    BEFORE UPDATE ON jobs
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

DROP TRIGGER IF EXISTS update_scheduled_jobs_timestamp ON scheduled_jobs;
CREATE TRIGGER update_scheduled_jobs_timestamp
    BEFORE UPDATE ON scheduled_jobs
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

DROP TRIGGER IF EXISTS update_organization_settings_timestamp ON organization_settings;
CREATE TRIGGER update_organization_settings_timestamp
    BEFORE UPDATE ON organization_settings
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- ============================================================================
-- PART 13: AUTO-CREATE PROFILE ON SIGNUP (THE MAGIC!)
-- ============================================================================

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    new_org_id UUID;
    user_email TEXT;
    user_name TEXT;
BEGIN
    -- Get user email from auth.users
    SELECT email INTO user_email FROM auth.users WHERE id = NEW.id;

    -- Get user name from metadata or derive from email
    user_name := COALESCE(NEW.raw_user_meta_data->>'full_name', split_part(user_email, '@', 1));

    -- Create organization for new user
    INSERT INTO public.organizations (name, slug, subscription_status, trial_ends_at)
    VALUES (
        user_name || '''s Organization',
        'org-' || substring(NEW.id::text, 1, 8),
        'trial',
        NOW() + INTERVAL '14 days'
    )
    RETURNING id INTO new_org_id;

    -- Create profile for new user
    INSERT INTO public.profiles (id, organization_id, email, full_name, role, auth_provider)
    VALUES (
        NEW.id,
        new_org_id,
        user_email,
        user_name,
        'owner',
        COALESCE(NEW.raw_app_meta_data->>'provider', 'email')
    );

    RETURN NEW;
EXCEPTION
    WHEN OTHERS THEN
        -- Log error but don't block user creation
        RAISE WARNING 'Error in handle_new_user trigger: %', SQLERRM;
        RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger on auth.users
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW
    EXECUTE FUNCTION public.handle_new_user();

-- ============================================================================
-- ✅ MIGRATION COMPLETE!
-- ============================================================================
--
-- Tables created/updated: 26 total
--   - Core: organizations, profiles
--   - Facility: bases, hangars, aircraft_models
--   - Personnel: roles, shifts, teams, personnel
--   - Jobs: jobs, quote_line_items, scheduled_jobs, scheduled_job_non_work_days,
--           scheduled_job_daily_efforts
--   - Config: standard_services, project_stages, holidays, progress_cursors
--   - Financial: expense_items, expense_overrides, capex_items, markup_tiers,
--                financial_log_entries, organization_settings
--   - Platform: platform_admin_invites, platform_audit_log
--
-- Features enabled:
--   ✅ Row Level Security on all tables
--   ✅ Multi-tenant isolation by organization
--   ✅ Platform admin access for super users
--   ✅ Auto-create organization & profile on signup
--   ✅ Auto-update timestamps
--
-- Next steps:
--   1. Register your first user at aeromanager.io
--   2. To make a user a platform admin, run:
--      UPDATE profiles SET is_platform_admin = TRUE, platform_role = 'super_admin'
--      WHERE email = 'your-email@example.com';
--
-- ============================================================================
