-- ============================================
-- AEROMANAGER 145 - BUG FIX MIGRATION
-- Run this script in Supabase SQL Editor
-- ============================================

-- PART 1: Add missing columns to existing tables
-- ----------------------------------------------

-- Add manufacturer to aircraft_models
ALTER TABLE aircraft_models ADD COLUMN IF NOT EXISTS manufacturer TEXT;

-- Add hourly_rate and burden_multiplier to roles
ALTER TABLE roles ADD COLUMN IF NOT EXISTS hourly_rate DECIMAL(10,2);
ALTER TABLE roles ADD COLUMN IF NOT EXISTS burden_multiplier DECIMAL(4,2) DEFAULT 1.35;

-- Backfill hourly_rate from existing hourly_cost (assuming 1.35 burden)
UPDATE roles
SET hourly_rate = ROUND(hourly_cost / COALESCE(burden_multiplier, 1.35), 2),
    burden_multiplier = COALESCE(burden_multiplier, 1.35)
WHERE hourly_rate IS NULL;

-- Make hourly_rate NOT NULL after backfill
ALTER TABLE roles ALTER COLUMN hourly_rate SET NOT NULL;

-- PART 2: Atomic upsert functions for scheduled job data
-- ------------------------------------------------------

CREATE OR REPLACE FUNCTION upsert_scheduled_job_non_work_days(
  p_scheduled_job_id UUID,
  p_day_offsets INTEGER[]
) RETURNS VOID AS $$
BEGIN
  DELETE FROM scheduled_job_non_work_days WHERE scheduled_job_id = p_scheduled_job_id;
  IF array_length(p_day_offsets, 1) > 0 THEN
    INSERT INTO scheduled_job_non_work_days (scheduled_job_id, day_offset)
    SELECT p_scheduled_job_id, unnest(p_day_offsets);
  END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION upsert_scheduled_job_daily_efforts(
  p_scheduled_job_id UUID,
  p_efforts JSONB
) RETURNS VOID AS $$
BEGIN
  DELETE FROM scheduled_job_daily_efforts WHERE scheduled_job_id = p_scheduled_job_id;
  IF jsonb_array_length(p_efforts) > 0 THEN
    INSERT INTO scheduled_job_daily_efforts (scheduled_job_id, day_offset, effort)
    SELECT p_scheduled_job_id, (item->>'day_offset')::INT, (item->>'effort')::DECIMAL
    FROM jsonb_array_elements(p_efforts) AS item;
  END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- PART 3: Create invitations table for proper invite flow
-- -------------------------------------------------------

CREATE TABLE IF NOT EXISTS invitations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
    email TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('admin', 'manager', 'technician', 'viewer')),
    invited_by UUID REFERENCES profiles(id) ON DELETE SET NULL,
    token TEXT NOT NULL UNIQUE DEFAULT encode(gen_random_bytes(32), 'hex'),
    expires_at TIMESTAMPTZ NOT NULL DEFAULT (NOW() + INTERVAL '7 days'),
    accepted_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    CONSTRAINT unique_pending_org_invite UNIQUE (organization_id, email)
);

-- Enable RLS on invitations
ALTER TABLE invitations ENABLE ROW LEVEL SECURITY;

-- Policy: Org members can view their org's invitations
CREATE POLICY "org_members_view_invitations" ON invitations FOR SELECT
    USING (organization_id IN (
        SELECT organization_id FROM profiles WHERE id = auth.uid()
    ));

-- Policy: Admins/owners can manage invitations
CREATE POLICY "org_admins_manage_invitations" ON invitations FOR ALL
    USING (organization_id IN (
        SELECT organization_id FROM profiles
        WHERE id = auth.uid() AND role IN ('owner', 'admin')
    ));

-- Index for faster lookups
CREATE INDEX IF NOT EXISTS idx_invitations_email ON invitations(email);
CREATE INDEX IF NOT EXISTS idx_invitations_org ON invitations(organization_id);

-- PART 4: Update handle_new_user() trigger to check invitations
-- -------------------------------------------------------------

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    new_org_id UUID;
    user_email TEXT;
    user_name TEXT;
    invite_record RECORD;
BEGIN
    -- Get user email from auth.users
    SELECT email INTO user_email FROM auth.users WHERE id = NEW.id;

    -- Get name from metadata or derive from email
    user_name := COALESCE(
        NEW.raw_user_meta_data->>'full_name',
        split_part(user_email, '@', 1)
    );

    -- Check for pending invitation
    SELECT * INTO invite_record
    FROM invitations
    WHERE email = LOWER(user_email)
      AND accepted_at IS NULL
      AND expires_at > NOW()
    ORDER BY created_at DESC
    LIMIT 1;

    IF invite_record IS NOT NULL THEN
        -- User was invited - join existing organization
        INSERT INTO public.profiles (id, organization_id, email, full_name, role, auth_provider)
        VALUES (
            NEW.id,
            invite_record.organization_id,
            user_email,
            user_name,
            invite_record.role,
            COALESCE(NEW.raw_app_meta_data->>'provider', 'email')
        );

        -- Mark invitation as accepted
        UPDATE invitations
        SET accepted_at = NOW()
        WHERE id = invite_record.id;
    ELSE
        -- New user - create their own organization
        INSERT INTO public.organizations (name, slug, subscription_status, trial_ends_at)
        VALUES (
            user_name || '''s Organization',
            'org-' || substring(NEW.id::text, 1, 8),
            'trial',
            NOW() + INTERVAL '14 days'
        )
        RETURNING id INTO new_org_id;

        INSERT INTO public.profiles (id, organization_id, email, full_name, role, auth_provider)
        VALUES (
            NEW.id,
            new_org_id,
            user_email,
            user_name,
            'owner',
            COALESCE(NEW.raw_app_meta_data->>'provider', 'email')
        );
    END IF;

    RETURN NEW;
EXCEPTION WHEN OTHERS THEN
    -- Log error but don't block user creation
    RAISE WARNING 'handle_new_user error: %', SQLERRM;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- PART 5: Cleanup orphaned placeholder profiles (optional)
-- --------------------------------------------------------
-- Uncomment to remove orphaned invite profiles created by old system
-- DELETE FROM profiles
-- WHERE id NOT IN (SELECT id FROM auth.users)
--   AND created_at < NOW() - INTERVAL '1 day';

-- ============================================
-- END OF MIGRATION
-- ============================================
