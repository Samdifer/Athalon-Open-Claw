-- ============================================================================
-- PLATFORM ADMIN MIGRATION
-- AeroManager 145 - SaaS Owner Dashboard
-- ============================================================================
-- Run this in Supabase SQL Editor after the main schema
-- ============================================================================

-- ============================================================================
-- PART 1: ADD PLATFORM ADMIN FIELDS TO PROFILES
-- ============================================================================

-- Add platform admin columns to profiles
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS is_platform_admin BOOLEAN DEFAULT FALSE;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS platform_role TEXT CHECK (
  platform_role IS NULL OR platform_role IN ('super_admin', 'support_admin', 'billing_admin')
);

-- Add grace period columns to organizations
ALTER TABLE organizations ADD COLUMN IF NOT EXISTS grace_period_used BOOLEAN DEFAULT FALSE;
ALTER TABLE organizations ADD COLUMN IF NOT EXISTS grace_period_ends_at TIMESTAMPTZ;

-- Create index for platform admin lookups
CREATE INDEX IF NOT EXISTS idx_profiles_platform_admin ON profiles(is_platform_admin) WHERE is_platform_admin = TRUE;

-- ============================================================================
-- PART 2: PLATFORM ADMIN INVITES TABLE
-- ============================================================================

CREATE TABLE IF NOT EXISTS platform_admin_invites (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('super_admin', 'support_admin', 'billing_admin')),
  invited_by UUID REFERENCES profiles(id) ON DELETE SET NULL,
  token TEXT NOT NULL UNIQUE,
  expires_at TIMESTAMPTZ NOT NULL,
  accepted_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  CONSTRAINT unique_pending_invite UNIQUE (email) -- Only one pending invite per email
);

-- Enable RLS
ALTER TABLE platform_admin_invites ENABLE ROW LEVEL SECURITY;

-- Only platform admins can view/manage invites
CREATE POLICY "platform_admins_manage_invites" ON platform_admin_invites FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid()
      AND is_platform_admin = TRUE
      AND platform_role = 'super_admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid()
      AND is_platform_admin = TRUE
      AND platform_role = 'super_admin'
    )
  );

-- ============================================================================
-- PART 3: PLATFORM AUDIT LOG TABLE
-- ============================================================================

CREATE TABLE IF NOT EXISTS platform_audit_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  admin_id UUID REFERENCES profiles(id) ON DELETE SET NULL,
  action TEXT NOT NULL,
  target_type TEXT, -- 'organization', 'user', 'subscription', 'platform_admin'
  target_id UUID,
  details JSONB DEFAULT '{}',
  ip_address TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create indexes for audit log queries
CREATE INDEX IF NOT EXISTS idx_audit_log_admin ON platform_audit_log(admin_id);
CREATE INDEX IF NOT EXISTS idx_audit_log_created ON platform_audit_log(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_log_target ON platform_audit_log(target_type, target_id);

-- Enable RLS
ALTER TABLE platform_audit_log ENABLE ROW LEVEL SECURITY;

-- Only platform admins can view audit logs
CREATE POLICY "platform_admins_view_audit" ON platform_audit_log FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid()
      AND is_platform_admin = TRUE
    )
  );

-- Platform admins can insert audit logs
CREATE POLICY "platform_admins_insert_audit" ON platform_audit_log FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid()
      AND is_platform_admin = TRUE
    )
  );

-- ============================================================================
-- PART 4: HELPER FUNCTION FOR PLATFORM ADMIN CHECK
-- ============================================================================

-- Function to check if current user is a platform admin
CREATE OR REPLACE FUNCTION public.is_platform_admin()
RETURNS BOOLEAN AS $$
  SELECT COALESCE(
    (SELECT is_platform_admin FROM public.profiles WHERE id = auth.uid()),
    FALSE
  )
$$ LANGUAGE SQL SECURITY DEFINER STABLE;

-- Function to get platform admin role
CREATE OR REPLACE FUNCTION public.get_platform_admin_role()
RETURNS TEXT AS $$
  SELECT platform_role FROM public.profiles WHERE id = auth.uid() AND is_platform_admin = TRUE
$$ LANGUAGE SQL SECURITY DEFINER STABLE;

-- Grant execute to authenticated users
GRANT EXECUTE ON FUNCTION public.is_platform_admin() TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_platform_admin_role() TO authenticated;

-- ============================================================================
-- PART 5: UPDATE RLS POLICIES FOR PLATFORM ADMIN ACCESS
-- ============================================================================

-- Organizations: Platform admins can view ALL organizations
DROP POLICY IF EXISTS "Users can view own organization" ON organizations;
CREATE POLICY "Users can view own organization or platform admins view all"
    ON organizations FOR SELECT
    USING (
      id = public.get_user_organization_id()
      OR public.is_platform_admin() = TRUE
    );

-- Platform admins can update any organization
DROP POLICY IF EXISTS "Owners can update organization" ON organizations;
CREATE POLICY "Owners or platform admins can update organization"
    ON organizations FOR UPDATE
    USING (
      (id = public.get_user_organization_id()
       AND EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'owner'))
      OR (public.is_platform_admin() = TRUE
          AND public.get_platform_admin_role() IN ('super_admin', 'billing_admin'))
    );

-- Profiles: Platform admins can view ALL profiles
DROP POLICY IF EXISTS "Users can view profiles in their organization" ON profiles;
CREATE POLICY "Users can view org profiles or platform admins view all"
    ON profiles FOR SELECT
    USING (
      organization_id = public.get_user_organization_id()
      OR id = auth.uid()
      OR public.is_platform_admin() = TRUE
    );

-- ============================================================================
-- PART 6: SEED FIRST PLATFORM ADMIN
-- ============================================================================
-- NOTE: Run this AFTER registering admin@avly.io through the normal signup flow
-- Password should be: fiveteenmilliontechbro

-- This will be run manually after admin@avly.io signs up:
-- UPDATE profiles
-- SET is_platform_admin = TRUE, platform_role = 'super_admin'
-- WHERE email = 'admin@avly.io';

-- ============================================================================
-- MIGRATION COMPLETE!
-- ============================================================================
-- New tables: platform_admin_invites, platform_audit_log
-- Modified tables: profiles (added is_platform_admin, platform_role)
-- Modified tables: organizations (added grace_period_used, grace_period_ends_at)
-- New functions: is_platform_admin(), get_platform_admin_role()
-- Updated RLS policies for platform admin access
-- ============================================================================
