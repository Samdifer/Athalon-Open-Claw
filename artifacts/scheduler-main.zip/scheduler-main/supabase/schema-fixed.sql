-- ============================================================================
-- FIXED SCHEMA: Auto-create profiles and allow org creation
-- ============================================================================
-- This adds a trigger to auto-create profiles when users sign up
-- Apply this AFTER running the main schema.sql
-- ============================================================================

-- Drop existing profile insert policy
DROP POLICY IF EXISTS "Users can insert own profile" ON profiles;

-- Create a more permissive policy for profile creation
-- This allows the trigger to create profiles with elevated privileges
CREATE POLICY "Allow profile creation during signup"
    ON profiles FOR INSERT
    WITH CHECK (true);

-- ============================================================================
-- AUTO-CREATE PROFILE TRIGGER
-- ============================================================================

-- Function to auto-create profile when user signs up
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    new_org_id UUID;
    user_email TEXT;
    user_name TEXT;
BEGIN
    -- Get user email and name from auth.users metadata
    SELECT email INTO user_email FROM auth.users WHERE id = NEW.id;
    user_name := COALESCE(NEW.raw_user_meta_data->>'full_name', split_part(user_email, '@', 1));

    -- Create organization for new user
    INSERT INTO public.organizations (name, slug, subscription_status, trial_ends_at)
    VALUES (
        user_name || '''s Organization',
        'org-' || substring(NEW.id::text, 1, 8),
        'trial',
        NOW() + INTERVAL '14 days'
    )
    RETURNING id INTO new_org_id;

    -- Create profile for new user
    INSERT INTO public.profiles (id, organization_id, email, full_name, role, auth_provider)
    VALUES (
        NEW.id,
        new_org_id,
        user_email,
        user_name,
        'owner',
        COALESCE(NEW.raw_app_meta_data->>'provider', 'email')
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger on auth.users
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW
    EXECUTE FUNCTION public.handle_new_user();

-- ============================================================================
-- DONE!
-- ============================================================================
-- This trigger will automatically:
-- 1. Create an organization when a user signs up
-- 2. Create a profile linked to that organization
-- 3. Bypass RLS because it runs with SECURITY DEFINER
-- ============================================================================
