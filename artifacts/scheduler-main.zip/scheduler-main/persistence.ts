import type { GameState } from './types';

const DB_NAME = 'AeroManagerDB';
const DB_VERSION = 1;
const STORE_NAME = 'saves';

interface SaveData {
    id: string;
    data: GameState;
    timestamp: number;
}

export const initDB = (): Promise<void> => {
    return new Promise((resolve, reject) => {
        const request = indexedDB.open(DB_NAME, DB_VERSION);
        request.onupgradeneeded = (event) => {
            const db = (event.target as IDBOpenDBRequest).result;
            if (!db.objectStoreNames.contains(STORE_NAME)) {
                db.createObjectStore(STORE_NAME, { keyPath: 'id' });
            }
        };
        request.onsuccess = () => resolve();
        request.onerror = (event) => reject((event.target as IDBOpenDBRequest).error);
    });
};

export const saveGame = (id: string, data: GameState): Promise<void> => {
    return new Promise((resolve, reject) => {
        const request = indexedDB.open(DB_NAME, DB_VERSION);
        request.onsuccess = (event) => {
            const db = (event.target as IDBOpenDBRequest).result;
            const tx = db.transaction(STORE_NAME, 'readwrite');
            const store = tx.objectStore(STORE_NAME);
            const putRequest = store.put({ id, data, timestamp: Date.now() });
            putRequest.onsuccess = () => resolve();
            putRequest.onerror = () => reject(putRequest.error);
        };
        request.onerror = (event) => reject((event.target as IDBOpenDBRequest).error);
    });
};

export const loadGame = (id: string): Promise<GameState | null> => {
    return new Promise((resolve, reject) => {
        const request = indexedDB.open(DB_NAME, DB_VERSION);
        request.onsuccess = (event) => {
            const db = (event.target as IDBOpenDBRequest).result;
            const tx = db.transaction(STORE_NAME, 'readonly');
            const store = tx.objectStore(STORE_NAME);
            const getRequest = store.get(id);
            getRequest.onsuccess = () => {
                if (getRequest.result) {
                    resolve(getRequest.result.data);
                } else {
                    resolve(null);
                }
            };
            getRequest.onerror = () => reject(getRequest.error);
        };
        request.onerror = (event) => reject((event.target as IDBOpenDBRequest).error);
    });
};
