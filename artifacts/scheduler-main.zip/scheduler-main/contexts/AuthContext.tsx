
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User, AuthContextType, SystemRole, PlatformRole, ImpersonationSession } from '../types';
import { supabase } from '../lib/supabase';
import type { Session, AuthError } from '@supabase/supabase-js';
import { generateUUID } from '../utils';

// Storage key for impersonation session
const IMPERSONATION_KEY = 'AM_IMPERSONATION_SESSION';

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Actual database profile type (matching your schema)
interface DBProfile {
  id: string;
  organization_id: string | null;
  email: string;
  full_name: string;
  role: string;
  avatar_url: string | null;
  auth_provider: string | null;
  created_at: string;
  updated_at: string;
  // Platform admin fields
  is_platform_admin: boolean | null;
  platform_role: string | null;
}

// Map database roles to frontend SystemRole
const mapDatabaseRole = (dbRole: string): SystemRole => {
  switch (dbRole) {
    case 'owner':
    case 'admin':
      return 'Admin';
    case 'manager':
      return 'Manager';
    case 'technician':
    case 'viewer':
      return 'Technician';
    default:
      return 'Technician';
  }
};

// Convert database profile to frontend User
const profileToUser = (profile: DBProfile): User => ({
  id: profile.id,
  email: profile.email,
  name: profile.full_name,
  role: mapDatabaseRole(profile.role),
  status: 'Active', // All profiles are active (no status column in DB)
  lastLogin: Date.now(), // No last_sign_in_at column, use current time
  avatar: profile.avatar_url || profile.full_name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase(),
  // Platform admin fields
  isPlatformAdmin: profile.is_platform_admin || false,
  platformRole: profile.platform_role as PlatformRole | undefined,
  organizationId: profile.organization_id || undefined,
});

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [allUsers, setAllUsers] = useState<User[]>([]);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [emailVerificationPending, setEmailVerificationPending] = useState(false);
  const [impersonationSession, setImpersonationSession] = useState<ImpersonationSession | null>(null);

  // Load impersonation session from localStorage on mount
  useEffect(() => {
    const storedSession = localStorage.getItem(IMPERSONATION_KEY);
    if (storedSession) {
      try {
        const session: ImpersonationSession = JSON.parse(storedSession);
        // Check if session is expired
        if (session.expiresAt > Date.now()) {
          setImpersonationSession(session);
        } else {
          localStorage.removeItem(IMPERSONATION_KEY);
        }
      } catch {
        localStorage.removeItem(IMPERSONATION_KEY);
      }
    }
  }, []);

  // Fetch user profile from database
  const fetchUserProfile = async (userId: string): Promise<DBProfile | null> => {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .single();

    if (error) {
      console.error('Error fetching profile:', error);
      return null;
    }

    return data;
  };

  // Fetch all users in the organization (for admin panel)
  const fetchOrganizationUsers = async (organizationId: string) => {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('organization_id', organizationId);

    if (error) {
      console.error('Error fetching organization users:', error);
      return;
    }

    setAllUsers(data.map(profileToUser));
  };

  // Handle auth state changes
  useEffect(() => {
    // Get initial session
    supabase.auth.getSession().then(({ data: { session } }) => {
      handleSession(session);
    });

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (_event, session) => {
        handleSession(session);
      }
    );

    return () => subscription.unsubscribe();
  }, []);

  const handleSession = async (session: Session | null) => {
    if (session?.user) {
      // Check if email is verified
      if (!session.user.email_confirmed_at) {
        setEmailVerificationPending(true);
        setIsAuthenticated(false);
        setUser(null);
        setIsLoading(false);
        return;
      }

      setEmailVerificationPending(false);

      // Fetch profile from database
      const profile = await fetchUserProfile(session.user.id);

      if (profile) {
        setUser(profileToUser(profile));
        setIsAuthenticated(true);

        // Fetch org users for admin functionality
        if (profile.organization_id) {
          await fetchOrganizationUsers(profile.organization_id);
        }
      } else {
        // Profile doesn't exist yet - might be new registration
        setUser(null);
        setIsAuthenticated(false);
      }
    } else {
      setUser(null);
      setIsAuthenticated(false);
      setAllUsers([]);
    }
    setIsLoading(false);
  };

  const login = async (email: string, password: string): Promise<void> => {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) {
      throw new Error(getAuthErrorMessage(error));
    }

    // Check if email is verified
    if (data.user && !data.user.email_confirmed_at) {
      setEmailVerificationPending(true);
      throw new Error('Please verify your email address before signing in. Check your inbox for a verification link.');
    }
  };

  const register = async (email: string, password: string, name: string): Promise<void> => {
    // Create auth user with Supabase
    // Organization and profile will be created automatically by database trigger
    const { data: authData, error: authError } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          full_name: name,
        },
        emailRedirectTo: `${window.location.origin}/auth/callback`,
      },
    });

    if (authError) {
      throw new Error(getAuthErrorMessage(authError));
    }

    if (!authData.user) {
      throw new Error('Registration failed. Please try again.');
    }

    // Note: Organization and profile are created by the handle_new_user() trigger
    // See supabase/schema-fixed.sql

    // Set pending verification state
    setEmailVerificationPending(true);
  };

  const logout = async () => {
    await supabase.auth.signOut();
    setUser(null);
    setIsAuthenticated(false);
    setAllUsers([]);
    setEmailVerificationPending(false);
  };

  const updateUser = async (id: string, updates: Partial<User>): Promise<void> => {
    // Map frontend User updates to database profile fields
    const dbUpdates: Record<string, any> = {};

    if (updates.name) dbUpdates.full_name = updates.name;
    if (updates.role) {
      // Map SystemRole back to database role
      switch (updates.role) {
        case 'Admin':
          dbUpdates.role = 'admin';
          break;
        case 'Manager':
          dbUpdates.role = 'manager';
          break;
        case 'Technician':
          dbUpdates.role = 'technician';
          break;
      }
    }
    if (updates.avatar) dbUpdates.avatar_url = updates.avatar;

    const { error } = await supabase
      .from('profiles')
      .update(dbUpdates)
      .eq('id', id);

    if (error) {
      throw new Error('Failed to update user');
    }

    // Update local state
    setAllUsers(prev =>
      prev.map(u => u.id === id ? { ...u, ...updates } : u)
    );

    // If updating self, update user state
    if (user && user.id === id) {
      setUser(prev => prev ? { ...prev, ...updates } : null);
    }
  };

  const deleteUser = async (id: string): Promise<void> => {
    // Actually delete the profile (no status column for soft delete)
    const { error } = await supabase
      .from('profiles')
      .delete()
      .eq('id', id);

    if (error) {
      throw new Error('Failed to delete user');
    }

    // Update local state
    setAllUsers(prev => prev.filter(u => u.id !== id));

    // If deleting self, logout
    if (user && user.id === id) {
      await logout();
    }
  };

  const inviteUser = async (email: string, name: string, role: SystemRole): Promise<void> => {
    // Check if user already exists in org
    const existingUser = allUsers.find(u => u.email.toLowerCase() === email.toLowerCase());
    if (existingUser) {
      throw new Error('User already exists in this organization');
    }

    if (!user) {
      throw new Error('Not authenticated');
    }

    const { data: currentProfile } = await supabase
      .from('profiles')
      .select('organization_id')
      .eq('id', user.id)
      .single();

    if (!currentProfile?.organization_id) {
      throw new Error('Organization not found');
    }

    // Map SystemRole to database role
    let dbRole: 'admin' | 'manager' | 'technician' | 'viewer' = 'technician';
    switch (role) {
      case 'Admin':
        dbRole = 'admin';
        break;
      case 'Manager':
        dbRole = 'manager';
        break;
      case 'Technician':
        dbRole = 'technician';
        break;
    }

    // Create invitation record (NOT a placeholder profile)
    // The handle_new_user() trigger will link the user when they sign up
    const { data: invitation, error: inviteError } = await supabase
      .from('invitations')
      .insert({
        organization_id: currentProfile.organization_id,
        email: email.toLowerCase(),
        role: dbRole,
        invited_by: user.id,
      })
      .select()
      .single();

    if (inviteError) {
      if (inviteError.code === '23505') { // Unique constraint violation
        throw new Error('An invitation has already been sent to this email');
      }
      throw new Error('Failed to create invitation: ' + inviteError.message);
    }

    // Update local state to show pending invitation
    const newUser: User = {
      id: invitation.id,
      email,
      name,
      role,
      status: 'Invited',
      avatar: name.substring(0, 2).toUpperCase(),
    };

    setAllUsers(prev => [...prev, newUser]);
  };

  const changePassword = async (currentPassword: string, newPassword: string): Promise<void> => {
    if (!user) {
      throw new Error('Not authenticated');
    }

    // Verify current password by attempting to sign in
    const { error: verifyError } = await supabase.auth.signInWithPassword({
      email: user.email,
      password: currentPassword,
    });

    if (verifyError) {
      throw new Error('Incorrect current password');
    }

    // Update password
    const { error: updateError } = await supabase.auth.updateUser({
      password: newPassword,
    });

    if (updateError) {
      throw new Error(getAuthErrorMessage(updateError));
    }
  };

  // Helper to resend verification email
  const resendVerificationEmail = async (email: string): Promise<void> => {
    const { error } = await supabase.auth.resend({
      type: 'signup',
      email,
    });

    if (error) {
      throw new Error(getAuthErrorMessage(error));
    }
  };

  // Start impersonation session (platform admin only)
  const startImpersonation = async (targetUserId: string): Promise<void> => {
    if (!user || !user.isPlatformAdmin) {
      throw new Error('Not authorized to impersonate');
    }

    // Only super_admin and support_admin can impersonate
    if (user.platformRole !== 'super_admin' && user.platformRole !== 'support_admin') {
      throw new Error('Your role does not have impersonation permissions');
    }

    // Fetch target user's profile
    const { data: targetProfile, error: profileError } = await supabase
      .from('profiles')
      .select('*, organizations(id, name)')
      .eq('id', targetUserId)
      .single();

    if (profileError || !targetProfile) {
      throw new Error('User not found');
    }

    // Cannot impersonate other platform admins
    if (targetProfile.is_platform_admin) {
      throw new Error('Cannot impersonate other platform admins');
    }

    // Create impersonation session
    const session: ImpersonationSession = {
      adminId: user.id,
      adminEmail: user.email,
      targetUserId: targetProfile.id,
      targetUserEmail: targetProfile.email,
      targetOrgId: targetProfile.organization_id,
      targetOrgName: targetProfile.organizations?.name || 'Unknown Organization',
      startedAt: Date.now(),
      expiresAt: Date.now() + 60 * 60 * 1000, // 1 hour
    };

    // Save to localStorage
    localStorage.setItem(IMPERSONATION_KEY, JSON.stringify(session));
    setImpersonationSession(session);

    // Log the impersonation action
    await supabase.from('platform_audit_log').insert({
      admin_id: user.id,
      action: 'start_impersonation',
      target_type: 'user',
      target_id: targetUserId,
      details: {
        target_email: targetProfile.email,
        target_org_id: targetProfile.organization_id,
      },
    });
  };

  // End impersonation session
  const endImpersonation = async (): Promise<void> => {
    if (impersonationSession && user) {
      // Log the end of impersonation - await to ensure audit log is written
      try {
        await supabase.from('platform_audit_log').insert({
          admin_id: user.id,
          action: 'end_impersonation',
          target_type: 'user',
          target_id: impersonationSession.targetUserId,
          details: {
            duration_minutes: Math.round((Date.now() - impersonationSession.startedAt) / 60000),
          },
        });
      } catch (err) {
        console.error('Failed to log impersonation end:', err);
      }
    }

    localStorage.removeItem(IMPERSONATION_KEY);
    setImpersonationSession(null);
  };

  // Computed values for platform admin
  const isPlatformAdmin = user?.isPlatformAdmin || false;
  const platformRole = user?.platformRole || null;

  return (
    <AuthContext.Provider value={{
      user,
      isAuthenticated,
      login,
      register,
      logout,
      isLoading,
      allUsers,
      updateUser,
      deleteUser,
      inviteUser,
      changePassword,
      // Platform Admin
      isPlatformAdmin,
      platformRole,
      // Impersonation
      impersonationSession,
      startImpersonation,
      endImpersonation,
      // Email Verification
      emailVerificationPending,
      resendVerificationEmail,
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

// Helper to convert Supabase errors to user-friendly messages
function getAuthErrorMessage(error: AuthError): string {
  switch (error.message) {
    case 'Invalid login credentials':
      return 'Invalid email or password.';
    case 'Email not confirmed':
      return 'Please verify your email address before signing in.';
    case 'User already registered':
      return 'An account with this email already exists.';
    case 'Password should be at least 6 characters':
      return 'Password must be at least 6 characters.';
    case 'Signup requires a valid password':
      return 'Please enter a valid password.';
    default:
      return error.message || 'An error occurred. Please try again.';
  }
}
