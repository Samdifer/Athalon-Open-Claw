import React, { createContext, useContext, useRef, useCallback, useState, useEffect } from 'react';

interface TimelineSyncState {
  cellWidth: number;
}

interface TimelineSyncContextValue {
  state: TimelineSyncState;
  registerScrollRef: (id: string, ref: React.RefObject<HTMLDivElement>, onScroll?: () => void) => void;
  unregisterScrollRef: (id: string) => void;
  syncScroll: (scrollLeft: number, sourceId: string) => void;
  syncZoom: (cellWidth: number) => void;
  getScrollLeft: () => number;
}

const TimelineSyncContext = createContext<TimelineSyncContextValue | null>(null);

export const TimelineSyncProvider: React.FC<{ children: React.ReactNode; initialCellWidth: number }> = ({
  children,
  initialCellWidth
}) => {
  // Use refs for scroll position - NO React state to avoid re-renders during scroll
  const scrollRefsMap = useRef<Map<string, { ref: React.RefObject<HTMLDivElement>, onScroll?: () => void }>>(new Map());
  const scrollLeftRef = useRef(0);
  const rafIdRef = useRef<number | null>(null);

  // Re-entry guard to prevent feedback loops from programmatic scroll updates
  const isSyncingRef = useRef(false);

  // Only cellWidth needs state (for zoom sync which is less frequent)
  const [state, setState] = useState<TimelineSyncState>({ cellWidth: initialCellWidth });

  const registerScrollRef = useCallback((id: string, ref: React.RefObject<HTMLDivElement>, onScroll?: () => void) => {
    scrollRefsMap.current.set(id, { ref, onScroll });
    // Sync to current position when registering
    if (ref.current && scrollLeftRef.current > 0) {
      ref.current.scrollLeft = scrollLeftRef.current;
    }
  }, []);

  const unregisterScrollRef = useCallback((id: string) => {
    scrollRefsMap.current.delete(id);
  }, []);

  // PERFORMANCE FIX: Synchronous scroll sync for true 60fps across all panels
  // Previously used RAF which caused 1-frame delay on slave components
  const syncScroll = useCallback((scrollLeft: number, sourceId: string) => {
    // Prevent re-entry from programmatically triggered scroll events
    if (isSyncingRef.current) return;

    // Skip if scroll position hasn't meaningfully changed
    if (Math.abs(scrollLeftRef.current - scrollLeft) < 1) return;

    scrollLeftRef.current = scrollLeft;
    isSyncingRef.current = true;

    // SYNCHRONOUS: Update all scroll positions in the SAME frame
    // This is the key fix - no RAF delay for scroll position sync
    scrollRefsMap.current.forEach((entry, id) => {
      if (id !== sourceId && entry.ref.current) {
        const currentScroll = entry.ref.current.scrollLeft;
        if (Math.abs(currentScroll - scrollLeft) > 1) {
          entry.ref.current.scrollLeft = scrollLeft;
        }
      }
    });

    // Reset sync flag after microtask to catch any echo scroll events
    queueMicrotask(() => {
      isSyncingRef.current = false;
    });

    // DEBOUNCED: Virtualization updates via RAF (less critical, can be 1 frame behind)
    // This prevents excessive re-renders while maintaining visual scroll sync
    if (rafIdRef.current) {
      cancelAnimationFrame(rafIdRef.current);
    }
    rafIdRef.current = requestAnimationFrame(() => {
      scrollRefsMap.current.forEach((entry) => {
        if (entry.onScroll) {
          entry.onScroll();
        }
      });
      rafIdRef.current = null;
    });
  }, []);

  const syncZoom = useCallback((cellWidth: number) => {
    setState({ cellWidth });
  }, []);

  const getScrollLeft = useCallback(() => scrollLeftRef.current, []);

  // Cleanup RAF on unmount
  useEffect(() => {
    return () => {
      if (rafIdRef.current) {
        cancelAnimationFrame(rafIdRef.current);
      }
    };
  }, []);

  return (
    <TimelineSyncContext.Provider value={{ state, registerScrollRef, unregisterScrollRef, syncScroll, syncZoom, getScrollLeft }}>
      {children}
    </TimelineSyncContext.Provider>
  );
};

export const useTimelineSync = () => {
  const context = useContext(TimelineSyncContext);
  if (!context) throw new Error('useTimelineSync must be used within TimelineSyncProvider');
  return context;
};

// Custom hook for timeline-synchronized components - optimized for 60fps
export const useSyncedScroll = (id: string, onVisibleRangeUpdate?: () => void) => {
  const { state, registerScrollRef, unregisterScrollRef, syncScroll, getScrollLeft } = useTimelineSync();
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    registerScrollRef(id, scrollRef, onVisibleRangeUpdate);
    return () => unregisterScrollRef(id);
  }, [id, registerScrollRef, unregisterScrollRef, onVisibleRangeUpdate]);

  // Handler that broadcasts scroll to other components
  const handleScroll = useCallback((e: React.UIEvent<HTMLDivElement>) => {
    const scrollLeft = (e.target as HTMLDivElement).scrollLeft;
    syncScroll(scrollLeft, id);
  }, [syncScroll, id]);

  return { scrollRef, handleScroll, state, getScrollLeft };
};
