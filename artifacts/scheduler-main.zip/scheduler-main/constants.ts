
import { Hangar, Job, AircraftModel, Role, RolePackage, AircraftPackage, FacilityPackage, Team, Personnel, QuoteLineItem, ProjectStage, Shift, ExpenseItem, Holiday, Base, MarkupTier, ProgressCursor, StandardService, ScheduledJob } from './types';

export const MECHANIC_HOURS_PER_MONTH = 160;
export const HOURLY_COST_AVG = 52;
export const SHOP_RATE = 175; // Part 145 jet/turboprop MRO rate
export const MONTHLY_OVERHEAD = 130000; // $45K hangar + $85K shared services
export const DAILY_OVERHEAD = MONTHLY_OVERHEAD / 30; // $6,000/day

export const HIRING_COST = 2500;
export const FIRING_COST = 1000;

export const DEFAULT_CELL_WIDTH = 40;
export const STICKY_COL_WIDTH = 120;

// Timeline Configuration
export const START_YEAR = 2024;
export const TIMELINE_YEARS = 4;
export const TOTAL_DAYS = 366 + 365 + 365 + 365; // 1461 days (2024 is leap)

export const ZOOM_LEVELS = [2, 4, 8, 14, 24, 40, 60, 90, 130, 180, 240];

// Capacity Planning
export const DEFAULT_CAPACITY_BUFFER_PERCENT = 15; // Warn at 85% capacity

// Payment Terms
export const DEFAULT_PAYMENT_TERMS = 7; // Net 7 days
export const PAYMENT_TERMS_OPTIONS = [7, 15, 30, 45, 60] as const;

// Undo/Redo Configuration
export const MAX_HISTORY_SIZE = 50; // Maximum undo steps to retain

// ============================================================================
// GLOSSARY - Aviation & Financial Terms for Help System
// ============================================================================
export interface GlossaryEntry {
  term: string;
  definition: string;
  category: 'aviation' | 'personnel' | 'financial' | 'scheduling';
  example?: string;
}

export const GLOSSARY: Record<string, GlossaryEntry> = {
  // Aviation Terms
  aog: {
    term: 'AOG (Aircraft On Ground)',
    definition: 'An urgent situation where an aircraft cannot fly due to a maintenance issue or missing part. AOG jobs are highest priority and often require expedited parts and overtime labor.',
    category: 'aviation',
    example: 'A plane with a failed hydraulic pump that cannot take off is AOG.',
  },
  mro: {
    term: 'MRO (Maintenance, Repair & Overhaul)',
    definition: 'The industry term for aircraft maintenance facilities and services. MRO encompasses all activities to keep aircraft in airworthy condition.',
    category: 'aviation',
  },
  part145: {
    term: 'Part 145',
    definition: 'FAA certification that authorizes a repair station to perform maintenance, preventive maintenance, and alterations on aircraft, engines, propellers, and appliances.',
    category: 'aviation',
  },
  tailNumber: {
    term: 'Tail Number (N-Number)',
    definition: 'The unique registration identifier for an aircraft, displayed on the tail or fuselage. In the US, registration numbers begin with "N" followed by letters and numbers.',
    category: 'aviation',
    example: 'N77NZ, N123AB',
  },
  squawk: {
    term: 'Squawk',
    definition: 'An aviation term for a maintenance discrepancy or defect reported by the flight crew. Squawks must be addressed before the next flight.',
    category: 'aviation',
    example: '"Pilot reported a squawk: intermittent autopilot disconnect."',
  },
  airframe: {
    term: 'Airframe',
    definition: 'The mechanical structure of an aircraft, excluding the engine(s) and avionics. Includes the fuselage, wings, and empennage.',
    category: 'aviation',
  },
  powerplant: {
    term: 'Powerplant',
    definition: 'The engine and related components that provide thrust or power to an aircraft. Includes turbines, pistons, and propellers.',
    category: 'aviation',
  },
  avionics: {
    term: 'Avionics',
    definition: 'Electronic systems used in aircraft, including navigation, communications, flight control, and weather systems.',
    category: 'aviation',
  },
  fbo: {
    term: 'FBO (Fixed Base Operator)',
    definition: 'A commercial business at an airport that provides aeronautical services such as fueling, hangaring, tie-down, parking, aircraft rental, and maintenance.',
    category: 'aviation',
  },
  rts: {
    term: 'RTS (Return to Service)',
    definition: 'The status indicating an aircraft has been repaired, inspected, and approved to fly again. Also called "released to service."',
    category: 'aviation',
  },
  hangar: {
    term: 'Hangar',
    definition: 'A large building used to store and work on aircraft. Hangars vary in size to accommodate different aircraft types.',
    category: 'aviation',
  },

  // Personnel Terms
  apTech: {
    term: 'A&P Technician',
    definition: 'Airframe & Powerplant certified mechanic holding an FAA certificate. Authorized to perform maintenance on aircraft structures and engines.',
    category: 'personnel',
  },
  iaInspector: {
    term: 'IA Inspector',
    definition: 'Inspection Authorization holder. A certified mechanic with additional authority to perform annual inspections and approve aircraft for return to service.',
    category: 'personnel',
  },
  leadTech: {
    term: 'Lead Technician',
    definition: 'Senior mechanic who oversees work quality, coordinates team activities, and serves as the primary technical authority on projects.',
    category: 'personnel',
  },
  efficiency: {
    term: 'Efficiency Rating',
    definition: 'A multiplier indicating how productive a worker is compared to standard. 1.0 = standard, 1.2 = 20% faster, 0.8 = 20% slower.',
    category: 'personnel',
    example: 'An efficiency of 1.15 means the technician completes work 15% faster than average.',
  },
  efficiencyOverride: {
    term: 'Efficiency Override',
    definition: 'A per-person adjustment that overrides their role\'s default efficiency. Used when an individual performs above or below their role\'s baseline.',
    category: 'personnel',
  },
  shift: {
    term: 'Shift',
    definition: 'A defined work schedule including start/end times, days of week, and break periods. Shifts determine when staff are available for work.',
    category: 'personnel',
  },
  team: {
    term: 'Team',
    definition: 'A group of personnel assigned to work together on the same shift and at the same base/location.',
    category: 'personnel',
  },
  base: {
    term: 'Base',
    definition: 'A physical location where maintenance work is performed. Companies may have multiple bases at different airports.',
    category: 'personnel',
  },

  // Financial Terms
  shopRate: {
    term: 'Shop Rate',
    definition: 'The hourly rate charged to customers for labor. This is your billing rate, not your cost. Industry average for Part 145 MRO is $125-150/hour.',
    category: 'financial',
    example: 'At a $135 shop rate, a 40-hour job generates $5,400 in labor revenue.',
  },
  burdenMultiplier: {
    term: 'Burden Multiplier',
    definition: 'A factor applied to base wages to account for employer costs like payroll taxes, health insurance, retirement contributions, and other benefits. Typically 1.30-1.40.',
    category: 'financial',
    example: 'A $40/hr wage with a 1.35 burden multiplier costs $54/hr fully loaded.',
  },
  hourlyCost: {
    term: 'Hourly Cost (Fully Burdened)',
    definition: 'The true cost per hour for an employee, including wages plus all employer costs (taxes, benefits, insurance). Used to calculate labor profitability.',
    category: 'financial',
  },
  grossMargin: {
    term: 'Gross Margin',
    definition: 'The percentage of revenue remaining after subtracting direct costs (labor and parts). Calculated as (Revenue - Direct Costs) / Revenue × 100%.',
    category: 'financial',
    example: 'Revenue of $10,000 with $4,000 in costs = 60% gross margin.',
  },
  overhead: {
    term: 'Overhead',
    definition: 'Fixed costs that occur regardless of work volume: rent, utilities, insurance, administrative salaries, equipment leases. Expressed as daily or monthly amounts.',
    category: 'financial',
  },
  markup: {
    term: 'Markup',
    definition: 'The multiplier applied to parts or service costs to determine the customer price. A 1.30 markup means a 30% increase over your cost.',
    category: 'financial',
    example: 'A part costing $100 with a 1.25 markup sells for $125.',
  },
  markupTier: {
    term: 'Markup Tier',
    definition: 'A pricing strategy where different markup percentages apply based on cost ranges. Higher markups for low-cost items, lower markups for expensive items.',
    category: 'financial',
    example: '30% markup on parts under $500, 15% on parts $500-$2500, 5% on parts over $2500.',
  },
  capex: {
    term: 'CapEx (Capital Expenditure)',
    definition: 'Large one-time purchases of equipment, tools, or facilities that provide long-term value. Can be amortized over time or recorded on a specific date.',
    category: 'financial',
  },
  amortization: {
    term: 'Amortization',
    definition: 'Spreading a large expense over a period of time (typically 12 months). Smooths cash flow impact of major purchases.',
    category: 'financial',
    example: 'A $120,000 tool purchase amortized over 12 months adds $10,000/month to overhead.',
  },
  paymentTerms: {
    term: 'Payment Terms (Net 7/15/30)',
    definition: 'The number of days after job completion when payment is expected. "Net 7" means payment due within 7 days.',
    category: 'financial',
  },
  receivables: {
    term: 'Receivables',
    definition: 'Money owed to you by customers for completed work. Also called Accounts Receivable (AR). Important for cash flow planning.',
    category: 'financial',
  },
  burnRate: {
    term: 'Burn Rate',
    definition: 'The daily rate at which cash is consumed by operating expenses (labor + overhead). Used to project how long cash reserves will last.',
    category: 'financial',
  },
  breakEven: {
    term: 'Break-Even',
    definition: 'The point where revenue exactly covers all costs (profit = 0). Useful for determining minimum required sales volume.',
    category: 'financial',
  },
  otPremium: {
    term: 'Overtime Premium',
    definition: 'The additional cost for hours worked beyond regular capacity. Typically 1.5× (time and a half) the standard labor rate.',
    category: 'financial',
  },

  // Scheduling Terms
  capacity: {
    term: 'Capacity',
    definition: 'The total available labor hours based on your staff, shifts, and efficiency ratings. Represents how much work your shop can handle.',
    category: 'scheduling',
  },
  utilization: {
    term: 'Utilization',
    definition: 'The percentage of available capacity that is sold/scheduled. Calculated as (Sold Hours / Capacity Hours) × 100%.',
    category: 'scheduling',
    example: '80 sold hours out of 100 capacity hours = 80% utilization.',
  },
  deadline: {
    term: 'Deadline',
    definition: 'The target completion date for a job. Jobs past their deadline show as "Late" status on the timeline.',
    category: 'scheduling',
  },
  dailyEffort: {
    term: 'Daily Effort',
    definition: 'The distribution of work across days within a job. Allows scheduling variable workloads (heavy start, light finish, or vice versa).',
    category: 'scheduling',
  },
  nonWorkDays: {
    term: 'Non-Work Days',
    definition: 'Days within a job schedule where no work is planned (weekends, waiting for parts, etc.). Labor is not allocated on these days.',
    category: 'scheduling',
  },
  projectStage: {
    term: 'Project Stage',
    definition: 'A workflow phase that jobs progress through, such as Inspection, Repair, Testing, and Documentation.',
    category: 'scheduling',
  },
};

// Helper function to get glossary entries by category
export const getGlossaryByCategory = (category: GlossaryEntry['category']): GlossaryEntry[] => {
  return Object.values(GLOSSARY).filter(entry => entry.category === category);
};

// Helper function to search glossary
export const searchGlossary = (query: string): GlossaryEntry[] => {
  const lowerQuery = query.toLowerCase();
  return Object.values(GLOSSARY).filter(entry =>
    entry.term.toLowerCase().includes(lowerQuery) ||
    entry.definition.toLowerCase().includes(lowerQuery)
  );
};

// ============================================================================
// DATE FORMATTING UTILITIES
// ============================================================================
export const dayIndexToDate = (dayIndex: number): Date => {
  const startDate = new Date(START_YEAR, 0, 1);
  return new Date(startDate.getTime() + dayIndex * 24 * 60 * 60 * 1000);
};

export const formatDateShort = (dayIndex: number): string => {
  const date = dayIndexToDate(dayIndex);
  return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
};

// ============================================================================
// FEDERAL HOLIDAYS (Observed by private businesses)
// ============================================================================
const FEDERAL_HOLIDAYS_2024 = [
  { date: '2024-01-01', name: "New Year's Day" },
  { date: '2024-01-15', name: "Martin Luther King Jr. Day" },
  { date: '2024-02-19', name: "Presidents' Day" },
  { date: '2024-05-27', name: "Memorial Day" },
  { date: '2024-06-19', name: "Juneteenth" },
  { date: '2024-07-04', name: "Independence Day" },
  { date: '2024-09-02', name: "Labor Day" },
  { date: '2024-10-14', name: "Columbus Day" },
  { date: '2024-11-11', name: "Veterans Day" },
  { date: '2024-11-28', name: "Thanksgiving Day" },
  { date: '2024-11-29', name: "Day After Thanksgiving" },
  { date: '2024-12-25', name: "Christmas Day" },
];

const FEDERAL_HOLIDAYS_2025 = [
  { date: '2025-01-01', name: "New Year's Day" },
  { date: '2025-01-20', name: "Martin Luther King Jr. Day" },
  { date: '2025-02-17', name: "Presidents' Day" },
  { date: '2025-05-26', name: "Memorial Day" },
  { date: '2025-06-19', name: "Juneteenth" },
  { date: '2025-07-04', name: "Independence Day" },
  { date: '2025-09-01', name: "Labor Day" },
  { date: '2025-10-13', name: "Columbus Day" },
  { date: '2025-11-11', name: "Veterans Day" },
  { date: '2025-11-27', name: "Thanksgiving Day" },
  { date: '2025-11-28', name: "Day After Thanksgiving" },
  { date: '2025-12-25', name: "Christmas Day" },
];

const FEDERAL_HOLIDAYS_2026 = [
  { date: '2026-01-01', name: "New Year's Day" },
  { date: '2026-01-19', name: "Martin Luther King Jr. Day" },
  { date: '2026-02-16', name: "Presidents' Day" },
  { date: '2026-05-25', name: "Memorial Day" },
  { date: '2026-06-19', name: "Juneteenth" },
  { date: '2026-07-03', name: "Independence Day (Observed)" },
  { date: '2026-09-07', name: "Labor Day" },
  { date: '2026-10-12', name: "Columbus Day" },
  { date: '2026-11-11', name: "Veterans Day" },
  { date: '2026-11-26', name: "Thanksgiving Day" },
  { date: '2026-11-27', name: "Day After Thanksgiving" },
  { date: '2026-12-25', name: "Christmas Day" },
];

const FEDERAL_HOLIDAYS_2027 = [
  { date: '2027-01-01', name: "New Year's Day" },
  { date: '2027-01-18', name: "Martin Luther King Jr. Day" },
  { date: '2027-02-15', name: "Presidents' Day" },
  { date: '2027-05-31', name: "Memorial Day" },
  { date: '2027-06-18', name: "Juneteenth (Observed)" },
  { date: '2027-07-05', name: "Independence Day (Observed)" },
  { date: '2027-09-06', name: "Labor Day" },
  { date: '2027-10-11', name: "Columbus Day" },
  { date: '2027-11-11', name: "Veterans Day" },
  { date: '2027-11-25', name: "Thanksgiving Day" },
  { date: '2027-11-26', name: "Day After Thanksgiving" },
  { date: '2027-12-24', name: "Christmas Day (Observed)" },
];

function dateToDayIndex(dateStr: string): number {
  const date = new Date(dateStr + 'T00:00:00');
  const startDate = new Date('2024-01-01T00:00:00');
  return Math.floor((date.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
}

export const INITIAL_HOLIDAYS: Holiday[] = [
  ...FEDERAL_HOLIDAYS_2024,
  ...FEDERAL_HOLIDAYS_2025,
  ...FEDERAL_HOLIDAYS_2026,
  ...FEDERAL_HOLIDAYS_2027,
].map((h, idx) => ({
  id: `holiday-${idx.toString().padStart(3, '0')}`,
  name: h.name,
  date: h.date,
  dayIndex: dateToDayIndex(h.date),
  enabled: true,
}));

// ============================================================================
// PART 145 MRO ROLES (Billable Positions)
// ============================================================================
export const DEFAULT_BURDEN_MULTIPLIER = 1.35;

export const INITIAL_ROLES: Role[] = [
  { id: 'role-lead', name: 'Lead Technician', baseEfficiency: 0.5, hourlyRate: 55, burdenMultiplier: 1.35, hourlyCost: 74 },
  { id: 'role-amp', name: 'A&P Mechanic', baseEfficiency: 0.8, hourlyRate: 42, burdenMultiplier: 1.35, hourlyCost: 57 },
  { id: 'role-inspector', name: 'IA Inspector', baseEfficiency: 0.4, hourlyRate: 60, burdenMultiplier: 1.35, hourlyCost: 81 },
  { id: 'role-junior', name: 'Junior Mechanic', baseEfficiency: 0.4, hourlyRate: 28, burdenMultiplier: 1.35, hourlyCost: 38 },
];

// ============================================================================
// ROLE PACKAGES - Predefined role sets for quick setup
// ============================================================================
export const ROLE_PACKAGES: RolePackage[] = [
  {
    id: 'pkg-aviation-mro',
    name: 'Aviation MRO Standard',
    description: 'Standard Part 145 MRO facility with A&P technicians, inspectors, and avionics specialists',
    roles: [
      { name: 'Lead Technician', baseEfficiency: 1.15, hourlyRate: 63, burdenMultiplier: 1.35, hourlyCost: 85 },
      { name: 'Senior A&P Technician', baseEfficiency: 1.0, hourlyRate: 48, burdenMultiplier: 1.35, hourlyCost: 65 },
      { name: 'A&P Technician', baseEfficiency: 0.9, hourlyRate: 41, burdenMultiplier: 1.35, hourlyCost: 55 },
      { name: 'Junior A&P Technician', baseEfficiency: 0.8, hourlyRate: 33, burdenMultiplier: 1.35, hourlyCost: 45 },
      { name: 'Apprentice', baseEfficiency: 0.5, hourlyRate: 21, burdenMultiplier: 1.35, hourlyCost: 28 },
      { name: 'IA Inspector', baseEfficiency: 0.0, hourlyRate: 70, burdenMultiplier: 1.35, hourlyCost: 95 },
      { name: 'Avionics Technician', baseEfficiency: 1.0, hourlyRate: 52, burdenMultiplier: 1.35, hourlyCost: 70 },
    ]
  },
  {
    id: 'pkg-small-shop',
    name: 'Small GA Shop',
    description: 'Lean team for general aviation piston and light turboprop maintenance',
    roles: [
      { name: 'Shop Foreman', baseEfficiency: 1.1, hourlyRate: 45, burdenMultiplier: 1.35, hourlyCost: 61 },
      { name: 'A&P Mechanic', baseEfficiency: 1.0, hourlyRate: 35, burdenMultiplier: 1.35, hourlyCost: 47 },
      { name: 'IA Inspector', baseEfficiency: 0.0, hourlyRate: 50, burdenMultiplier: 1.35, hourlyCost: 68 },
      { name: 'Helper', baseEfficiency: 0.6, hourlyRate: 18, burdenMultiplier: 1.35, hourlyCost: 24 },
    ]
  },
  {
    id: 'pkg-jet-center',
    name: 'Turbine Service Center',
    description: 'Full-service jet maintenance with specialized turbine and avionics teams',
    roles: [
      { name: 'Director of Maintenance', baseEfficiency: 0.5, hourlyRate: 85, burdenMultiplier: 1.35, hourlyCost: 115 },
      { name: 'Lead Turbine Tech', baseEfficiency: 1.2, hourlyRate: 70, burdenMultiplier: 1.35, hourlyCost: 95 },
      { name: 'Senior Turbine Tech', baseEfficiency: 1.0, hourlyRate: 55, burdenMultiplier: 1.35, hourlyCost: 74 },
      { name: 'Turbine Technician', baseEfficiency: 0.9, hourlyRate: 45, burdenMultiplier: 1.35, hourlyCost: 61 },
      { name: 'Lead Avionics Tech', baseEfficiency: 1.1, hourlyRate: 60, burdenMultiplier: 1.35, hourlyCost: 81 },
      { name: 'Avionics Technician', baseEfficiency: 1.0, hourlyRate: 50, burdenMultiplier: 1.35, hourlyCost: 68 },
      { name: 'IA Inspector', baseEfficiency: 0.0, hourlyRate: 75, burdenMultiplier: 1.35, hourlyCost: 101 },
      { name: 'Sheet Metal Tech', baseEfficiency: 0.9, hourlyRate: 42, burdenMultiplier: 1.35, hourlyCost: 57 },
      { name: 'Apprentice', baseEfficiency: 0.5, hourlyRate: 22, burdenMultiplier: 1.35, hourlyCost: 30 },
    ]
  },
  {
    id: 'pkg-line-service',
    name: 'Line Service / FBO',
    description: 'FBO line service operations with fuel, ground handling, and light maintenance',
    roles: [
      { name: 'Line Service Manager', baseEfficiency: 0.8, hourlyRate: 40, burdenMultiplier: 1.35, hourlyCost: 54 },
      { name: 'Senior Line Tech', baseEfficiency: 1.0, hourlyRate: 28, burdenMultiplier: 1.35, hourlyCost: 38 },
      { name: 'Line Service Tech', baseEfficiency: 0.9, hourlyRate: 22, burdenMultiplier: 1.35, hourlyCost: 30 },
      { name: 'Fuel Attendant', baseEfficiency: 0.8, hourlyRate: 18, burdenMultiplier: 1.35, hourlyCost: 24 },
      { name: 'CSR / Dispatcher', baseEfficiency: 0.0, hourlyRate: 25, burdenMultiplier: 1.35, hourlyCost: 34 },
    ]
  },
  {
    id: 'pkg-helicopter',
    name: 'Helicopter MRO',
    description: 'Rotorcraft maintenance facility with specialized rotor and dynamic component techs',
    roles: [
      { name: 'Chief Inspector', baseEfficiency: 0.0, hourlyRate: 72, burdenMultiplier: 1.35, hourlyCost: 97 },
      { name: 'Lead Rotor Tech', baseEfficiency: 1.15, hourlyRate: 58, burdenMultiplier: 1.35, hourlyCost: 78 },
      { name: 'Dynamic Component Tech', baseEfficiency: 1.0, hourlyRate: 52, burdenMultiplier: 1.35, hourlyCost: 70 },
      { name: 'Airframe Tech', baseEfficiency: 0.95, hourlyRate: 45, burdenMultiplier: 1.35, hourlyCost: 61 },
      { name: 'Avionics Tech', baseEfficiency: 1.0, hourlyRate: 48, burdenMultiplier: 1.35, hourlyCost: 65 },
      { name: 'Junior Tech', baseEfficiency: 0.7, hourlyRate: 32, burdenMultiplier: 1.35, hourlyCost: 43 },
    ]
  },
];

// ============================================================================
// AIRCRAFT PACKAGES - Predefined aircraft sets for quick setup
// ============================================================================
export const AIRCRAFT_PACKAGES: AircraftPackage[] = [
  {
    id: 'pkg-private-jets',
    name: 'Private Jets',
    description: 'Common private jet aircraft including Citations, Gulfstreams, Phenoms, and more',
    isBuiltIn: true,
    aircraft: [
      // Cessna Citation Family
      { name: 'Citation CJ1/CJ1+ (525)', manufacturer: 'Cessna' },
      { name: 'Citation CJ2/CJ2+ (525A)', manufacturer: 'Cessna' },
      { name: 'Citation CJ3/CJ3+ (525B)', manufacturer: 'Cessna' },
      { name: 'Citation CJ4 (525C)', manufacturer: 'Cessna' },
      { name: 'Citation M2 (525)', manufacturer: 'Cessna' },
      { name: 'Citation Excel (560XL)', manufacturer: 'Cessna' },
      { name: 'Citation XLS/XLS+ (560XLS)', manufacturer: 'Cessna' },
      { name: 'Citation Sovereign (680)', manufacturer: 'Cessna' },
      { name: 'Citation X/X+ (750)', manufacturer: 'Cessna' },
      { name: 'Citation Latitude (680A)', manufacturer: 'Cessna' },
      { name: 'Citation Longitude (700)', manufacturer: 'Cessna' },
      // Gulfstream Family
      { name: 'G280', manufacturer: 'Gulfstream' },
      { name: 'G450', manufacturer: 'Gulfstream' },
      { name: 'G500', manufacturer: 'Gulfstream' },
      { name: 'G550', manufacturer: 'Gulfstream' },
      { name: 'G600', manufacturer: 'Gulfstream' },
      { name: 'G650/G650ER', manufacturer: 'Gulfstream' },
      { name: 'G700', manufacturer: 'Gulfstream' },
      // Embraer Family
      { name: 'Phenom 100/100EV', manufacturer: 'Embraer' },
      { name: 'Phenom 300/300E', manufacturer: 'Embraer' },
      { name: 'Legacy 450', manufacturer: 'Embraer' },
      { name: 'Legacy 500', manufacturer: 'Embraer' },
      { name: 'Legacy 600/650', manufacturer: 'Embraer' },
      { name: 'Praetor 500', manufacturer: 'Embraer' },
      { name: 'Praetor 600', manufacturer: 'Embraer' },
      // Bombardier Family
      { name: 'Learjet 40/45', manufacturer: 'Bombardier' },
      { name: 'Learjet 70/75', manufacturer: 'Bombardier' },
      { name: 'Challenger 300', manufacturer: 'Bombardier' },
      { name: 'Challenger 350', manufacturer: 'Bombardier' },
      { name: 'Challenger 604/605', manufacturer: 'Bombardier' },
      { name: 'Challenger 650', manufacturer: 'Bombardier' },
      { name: 'Global 5000/5500', manufacturer: 'Bombardier' },
      { name: 'Global 6000/6500', manufacturer: 'Bombardier' },
      { name: 'Global 7500', manufacturer: 'Bombardier' },
      // Dassault Falcon Family
      { name: 'Falcon 900/900LX', manufacturer: 'Dassault' },
      { name: 'Falcon 2000/2000LXS', manufacturer: 'Dassault' },
      { name: 'Falcon 7X', manufacturer: 'Dassault' },
      { name: 'Falcon 8X', manufacturer: 'Dassault' },
      { name: 'Falcon 6X', manufacturer: 'Dassault' },
      // Pilatus
      { name: 'PC-24', manufacturer: 'Pilatus' },
      // HondaJet
      { name: 'HA-420', manufacturer: 'HondaJet' },
      { name: 'Elite/Elite II', manufacturer: 'HondaJet' },
      // Cirrus
      { name: 'Vision Jet SF50', manufacturer: 'Cirrus' },
    ]
  },
  {
    id: 'pkg-general-aviation',
    name: 'General Aviation',
    description: 'Single and multi-engine piston aircraft, turboprops, and light aircraft',
    isBuiltIn: true,
    aircraft: [
      // Cessna Single-Engine Piston
      { name: '150/152', manufacturer: 'Cessna' },
      { name: '172 Skyhawk', manufacturer: 'Cessna' },
      { name: '177 Cardinal', manufacturer: 'Cessna' },
      { name: '182 Skylane', manufacturer: 'Cessna' },
      { name: '206 Stationair', manufacturer: 'Cessna' },
      { name: '210 Centurion', manufacturer: 'Cessna' },
      // Cessna Multi-Engine
      { name: '310', manufacturer: 'Cessna' },
      { name: '340', manufacturer: 'Cessna' },
      { name: '402/414', manufacturer: 'Cessna' },
      { name: '421 Golden Eagle', manufacturer: 'Cessna' },
      // Cessna Turboprops
      { name: '208 Caravan', manufacturer: 'Cessna' },
      { name: '208B Grand Caravan', manufacturer: 'Cessna' },
      // Piper Single-Engine
      { name: 'PA-28 Cherokee/Archer/Warrior', manufacturer: 'Piper' },
      { name: 'PA-32 Cherokee Six/Saratoga', manufacturer: 'Piper' },
      { name: 'PA-24 Comanche', manufacturer: 'Piper' },
      { name: 'PA-46 Malibu/Matrix/M-Class', manufacturer: 'Piper' },
      // Piper Multi-Engine
      { name: 'PA-23 Apache/Aztec', manufacturer: 'Piper' },
      { name: 'PA-34 Seneca', manufacturer: 'Piper' },
      { name: 'PA-44 Seminole', manufacturer: 'Piper' },
      { name: 'PA-31 Navajo/Chieftain', manufacturer: 'Piper' },
      // Piper Turboprops
      { name: 'PA-42 Cheyenne', manufacturer: 'Piper' },
      { name: 'M500/M600', manufacturer: 'Piper' },
      // Beechcraft Single-Engine
      { name: 'Bonanza A36/G36', manufacturer: 'Beechcraft' },
      { name: 'Bonanza V35', manufacturer: 'Beechcraft' },
      // Beechcraft Multi-Engine
      { name: 'Baron 55/58', manufacturer: 'Beechcraft' },
      { name: 'Duke B60', manufacturer: 'Beechcraft' },
      // Beechcraft Turboprops
      { name: 'King Air 90', manufacturer: 'Beechcraft' },
      { name: 'King Air 200', manufacturer: 'Beechcraft' },
      { name: 'King Air 250', manufacturer: 'Beechcraft' },
      { name: 'King Air 350', manufacturer: 'Beechcraft' },
      { name: '1900', manufacturer: 'Beechcraft' },
      // Pilatus
      { name: 'PC-12/PC-12 NGX', manufacturer: 'Pilatus' },
      // Cirrus
      { name: 'SR20', manufacturer: 'Cirrus' },
      { name: 'SR22/SR22T', manufacturer: 'Cirrus' },
      // Mooney
      { name: 'M20 Series', manufacturer: 'Mooney' },
      // Diamond
      { name: 'DA40', manufacturer: 'Diamond' },
      { name: 'DA42', manufacturer: 'Diamond' },
      { name: 'DA62', manufacturer: 'Diamond' },
      // TBM/Daher
      { name: '700/850', manufacturer: 'TBM' },
      { name: '900/910/930', manufacturer: 'TBM' },
      { name: '940/960', manufacturer: 'TBM' },
      // Quest/Daher
      { name: 'Kodiak 100', manufacturer: 'Quest' },
      // Epic
      { name: 'E1000', manufacturer: 'Epic' },
    ]
  }
];

// ============================================================================
// BASES - Single base operation
// ============================================================================
export const INITIAL_BASES: Base[] = [
  { id: 'base-main', name: 'Main Facility', location: 'Primary Airport' },
];

// ============================================================================
// SHIFTS - Day and Swing shifts
// ============================================================================
export const INITIAL_SHIFTS: Shift[] = [
  { id: 'shift-day', name: 'Day Shift', days: [1,2,3,4,5], startHour: 6, duration: 8.5, breakCount: 2, breakDuration: 30, meetingDuration: 15 },
  { id: 'shift-swing', name: 'Swing Shift', days: [1,2,3,4,5], startHour: 14, duration: 8.5, breakCount: 2, breakDuration: 30, meetingDuration: 15 },
];

// ============================================================================
// TEAMS - Day Crew and Swing Crew
// ============================================================================
export const INITIAL_TEAMS: Team[] = [
  { id: 'team-day', name: 'Day Crew', color: 'bg-blue-600', shiftId: 'shift-day', baseId: 'base-main' },
  { id: 'team-swing', name: 'Swing Crew', color: 'bg-indigo-600', shiftId: 'shift-swing', baseId: 'base-main' },
];

// ============================================================================
// PERSONNEL - 16 technicians across 2 shifts
// Day Shift: 1 Lead, 1 Inspector, 4 A&P, 2 Junior
// Swing Shift: 1 Lead, 1 Inspector, 4 A&P, 2 Junior
// ============================================================================
export const INITIAL_PERSONNEL: Personnel[] = [
  // === DAY SHIFT (8 people) ===
  { id: 'pers-day-001', name: 'Marcus Thompson', roleId: 'role-lead', teamId: 'team-day', baseId: 'base-main', efficiencyOverride: null },
  { id: 'pers-day-002', name: 'Richard Stevens', roleId: 'role-inspector', teamId: 'team-day', baseId: 'base-main', efficiencyOverride: null },
  { id: 'pers-day-003', name: 'David Chen', roleId: 'role-amp', teamId: 'team-day', baseId: 'base-main', efficiencyOverride: null },
  { id: 'pers-day-004', name: 'Robert Garcia', roleId: 'role-amp', teamId: 'team-day', baseId: 'base-main', efficiencyOverride: null },
  { id: 'pers-day-005', name: 'Michael Brown', roleId: 'role-amp', teamId: 'team-day', baseId: 'base-main', efficiencyOverride: null },
  { id: 'pers-day-006', name: 'James Wilson', roleId: 'role-amp', teamId: 'team-day', baseId: 'base-main', efficiencyOverride: null },
  { id: 'pers-day-007', name: 'Tyler Martinez', roleId: 'role-junior', teamId: 'team-day', baseId: 'base-main', efficiencyOverride: null },
  { id: 'pers-day-008', name: 'Christopher Lee', roleId: 'role-junior', teamId: 'team-day', baseId: 'base-main', efficiencyOverride: null },

  // === SWING SHIFT (8 people) ===
  { id: 'pers-swing-001', name: 'William Rodriguez', roleId: 'role-lead', teamId: 'team-swing', baseId: 'base-main', efficiencyOverride: null },
  { id: 'pers-swing-002', name: 'Gregory Campbell', roleId: 'role-inspector', teamId: 'team-swing', baseId: 'base-main', efficiencyOverride: null },
  { id: 'pers-swing-003', name: 'Kevin Johnson', roleId: 'role-amp', teamId: 'team-swing', baseId: 'base-main', efficiencyOverride: null },
  { id: 'pers-swing-004', name: 'Brian Williams', roleId: 'role-amp', teamId: 'team-swing', baseId: 'base-main', efficiencyOverride: null },
  { id: 'pers-swing-005', name: 'Steven Jones', roleId: 'role-amp', teamId: 'team-swing', baseId: 'base-main', efficiencyOverride: null },
  { id: 'pers-swing-006', name: 'Edward Davis', roleId: 'role-amp', teamId: 'team-swing', baseId: 'base-main', efficiencyOverride: null },
  { id: 'pers-swing-007', name: 'Jason Miller', roleId: 'role-junior', teamId: 'team-swing', baseId: 'base-main', efficiencyOverride: null },
  { id: 'pers-swing-008', name: 'Ryan Clark', roleId: 'role-junior', teamId: 'team-swing', baseId: 'base-main', efficiencyOverride: null },
];

// ============================================================================
// AIRCRAFT MODELS - Jets and Turboprops
// ============================================================================
export const INITIAL_AIRCRAFT_MODELS: AircraftModel[] = [
  // === LIGHT JETS ===
  { id: 'ac-cj1', name: 'Citation CJ1+', manufacturer: 'Cessna' },
  { id: 'ac-cj2', name: 'Citation CJ2+', manufacturer: 'Cessna' },
  { id: 'ac-cj3', name: 'Citation CJ3+', manufacturer: 'Cessna' },
  { id: 'ac-cj4', name: 'Citation CJ4', manufacturer: 'Cessna' },
  { id: 'ac-m2', name: 'Citation Mustang', manufacturer: 'Cessna' },
  { id: 'ac-phenom100', name: 'Phenom 100EV', manufacturer: 'Embraer' },
  { id: 'ac-phenom300', name: 'Phenom 300E', manufacturer: 'Embraer' },
  { id: 'ac-premier', name: 'Premier IA', manufacturer: 'Beechcraft' },
  { id: 'ac-hondajet', name: 'HondaJet Elite', manufacturer: 'Honda' },
  { id: 'ac-pc24', name: 'PC-24', manufacturer: 'Pilatus' },
  // === TURBOPROPS ===
  { id: 'ac-pc12', name: 'PC-12 NGX', manufacturer: 'Pilatus' },
  { id: 'ac-tbm900', name: 'TBM 900', manufacturer: 'Daher' },
  { id: 'ac-tbm960', name: 'TBM 960', manufacturer: 'Daher' },
  { id: 'ac-kingair350', name: 'King Air 350i', manufacturer: 'Beechcraft' },
  { id: 'ac-kingair250', name: 'King Air 250', manufacturer: 'Beechcraft' },
  { id: 'ac-kingair90', name: 'King Air C90GTx', manufacturer: 'Beechcraft' },
  { id: 'ac-caravan', name: 'Grand Caravan EX', manufacturer: 'Cessna' },
  { id: 'ac-conquest', name: 'Conquest II', manufacturer: 'Cessna' },
];

// ============================================================================
// HANGARS - 1 Small (light jets/turboprops) + 1 Large (all aircraft)
// ============================================================================
export const INITIAL_HANGARS: Hangar[] = [
  {
    id: 'hangar-small',
    name: 'Hangar A - Light',
    size: 'Small',
    supportedTypes: ['ac-cj1', 'ac-cj2', 'ac-m2', 'ac-phenom100', 'ac-premier', 'ac-hondajet', 'ac-pc12', 'ac-tbm900', 'ac-tbm960', 'ac-kingair90', 'ac-caravan'],
    baseId: 'base-main'
  },
  {
    id: 'hangar-large',
    name: 'Hangar B - Main',
    size: 'Large',
    supportedTypes: [], // Empty = supports all aircraft
    baseId: 'base-main'
  },
];

// ============================================================================
// FACILITY PACKAGES - Loadable preset configurations for bases and hangars
// ============================================================================
export const FACILITY_PACKAGES: FacilityPackage[] = [
  {
    id: 'pkg-multi-base-mro',
    name: 'Multi-Base MRO (APA + PDX)',
    description: 'Two-base operation: Centennial Airport (APA) and Portland (PDX) with 3 hangars',
    bases: [
      { name: 'APA - Centennial', location: 'Centennial Airport, Englewood, CO (KAPA)' },
      { name: 'PDX - Portland', location: 'Portland International Airport, OR (KPDX)' },
    ],
    hangars: [
      { name: 'APA Hangar 1', size: 'Medium', supportedTypes: ['ac-c525a', 'ac-c525b', 'ac-c525c', 'ac-c560xl', 'ac-c560xls', 'ac-e100', 'ac-e300', 'ac-pc24', 'ac-pc12ngx'], baseIndex: 0 },
      { name: 'PDX Hangar 1 - Heavy', size: 'Large', supportedTypes: ['ac-g450', 'ac-g550', 'ac-g650', 'ac-c750', 'ac-c560xl', 'ac-c560xls'], baseIndex: 1 },
      { name: 'PDX Hangar 2 - Light/Mid', size: 'Medium', supportedTypes: ['ac-c525a', 'ac-c525b', 'ac-c525c', 'ac-c560xl', 'ac-c560xls', 'ac-e100', 'ac-e300', 'ac-pc24', 'ac-pc12ngx'], baseIndex: 1 },
    ]
  },
  {
    id: 'pkg-single-fbo',
    name: 'Single Location FBO',
    description: 'Single base with two hangars for light maintenance',
    bases: [
      { name: 'Main Base', location: 'Airport Code' },
    ],
    hangars: [
      { name: 'Hangar A - Primary', size: 'Large', supportedTypes: [], baseIndex: 0 },
      { name: 'Hangar B - Overflow', size: 'Medium', supportedTypes: [], baseIndex: 0 },
    ]
  },
  {
    id: 'pkg-large-mro',
    name: 'Large Single-Site MRO',
    description: 'Single base with multiple specialized hangars',
    bases: [
      { name: 'Main Facility', location: 'Airport Location' },
    ],
    hangars: [
      { name: 'Hangar 1 - Heavy Jets', size: 'Large', supportedTypes: [], baseIndex: 0 },
      { name: 'Hangar 2 - Mid Jets', size: 'Large', supportedTypes: [], baseIndex: 0 },
      { name: 'Hangar 3 - Light Jets', size: 'Medium', supportedTypes: [], baseIndex: 0 },
      { name: 'Hangar 4 - Paint/Interior', size: 'Medium', supportedTypes: [], baseIndex: 0 },
    ]
  },
];

// ============================================================================
// STANDARD SERVICES - Common to all aircraft
// ============================================================================
export const STANDARD_SERVICES: StandardService[] = [
  // === CONSUMABLES & FEES ===
  { id: 'svc-consumable-fee', description: 'Consumable Materials Fee', category: 'Service', laborHours: 0, laborRate: 0, partsCost: 0, partsMarkup: 1.0, applicableModelId: undefined },
  { id: 'svc-env-fee', description: 'Environmental Disposal Fee', category: 'Service', laborHours: 0, laborRate: 0, partsCost: 85, partsMarkup: 1.0, applicableModelId: undefined },
  { id: 'svc-doc-fee', description: 'Documentation & Records Fee', category: 'Service', laborHours: 2, laborRate: 0, partsCost: 0, partsMarkup: 1.0, applicableModelId: undefined },
  { id: 'svc-aog-premium', description: 'AOG Premium (After Hours)', category: 'Service', laborHours: 0, laborRate: 0, partsCost: 500, partsMarkup: 1.0, applicableModelId: undefined },

  // === SERVICE CHECKS ===
  { id: 'svc-preflight', description: 'Pre-Flight Inspection', category: 'Labor', laborHours: 1.5, laborRate: 0, partsCost: 0, partsMarkup: 1.0, applicableModelId: undefined },
  { id: 'svc-postflight', description: 'Post-Flight Inspection', category: 'Labor', laborHours: 1.0, laborRate: 0, partsCost: 0, partsMarkup: 1.0, applicableModelId: undefined },
  { id: 'svc-ramp-check', description: 'Ramp Check / Quick Turn', category: 'Labor', laborHours: 2.0, laborRate: 0, partsCost: 50, partsMarkup: 1.2, applicableModelId: undefined },
  { id: 'svc-overnight', description: 'Overnight Service Check', category: 'Labor', laborHours: 4.0, laborRate: 0, partsCost: 150, partsMarkup: 1.2, applicableModelId: undefined },

  // === DETAILING PACKAGES ===
  { id: 'svc-detail-quick', description: 'Quick Detail (Exterior Wipe)', category: 'Service', laborHours: 2.0, laborRate: 0, partsCost: 75, partsMarkup: 1.3, applicableModelId: undefined },
  { id: 'svc-detail-standard', description: 'Standard Detail (Ext + Int)', category: 'Service', laborHours: 6.0, laborRate: 0, partsCost: 250, partsMarkup: 1.3, applicableModelId: undefined },
  { id: 'svc-detail-full', description: 'Full Detail (Complete Interior/Exterior)', category: 'Service', laborHours: 12.0, laborRate: 0, partsCost: 500, partsMarkup: 1.3, applicableModelId: undefined },
  { id: 'svc-detail-leather', description: 'Leather Treatment Package', category: 'Service', laborHours: 4.0, laborRate: 0, partsCost: 350, partsMarkup: 1.25, applicableModelId: undefined },
  { id: 'svc-detail-carpet', description: 'Carpet Shampoo & Protection', category: 'Service', laborHours: 3.0, laborRate: 0, partsCost: 200, partsMarkup: 1.25, applicableModelId: undefined },
  { id: 'svc-detail-brightwork', description: 'Brightwork Polish', category: 'Service', laborHours: 4.0, laborRate: 0, partsCost: 150, partsMarkup: 1.25, applicableModelId: undefined },

  // === COMMON MAINTENANCE ===
  { id: 'svc-oil-change', description: 'Engine Oil Change (per engine)', category: 'Labor', laborHours: 2.5, laborRate: 0, partsCost: 180, partsMarkup: 1.2, applicableModelId: undefined },
  { id: 'svc-tire-change', description: 'Tire Change (per tire)', category: 'Part', laborHours: 1.5, laborRate: 0, partsCost: 850, partsMarkup: 1.15, applicableModelId: undefined },
  { id: 'svc-brake-change', description: 'Brake Assembly Change (per wheel)', category: 'Part', laborHours: 3.0, laborRate: 0, partsCost: 2800, partsMarkup: 1.12, applicableModelId: undefined },
  { id: 'svc-battery-service', description: 'Main Battery Service/Replace', category: 'Part', laborHours: 2.0, laborRate: 0, partsCost: 1800, partsMarkup: 1.15, applicableModelId: undefined },
  { id: 'svc-pitot-static', description: 'Pitot-Static System Test', category: 'Labor', laborHours: 4.0, laborRate: 0, partsCost: 0, partsMarkup: 1.0, applicableModelId: undefined },
  { id: 'svc-transponder-test', description: 'Transponder/ADS-B Test (91.413)', category: 'Labor', laborHours: 2.0, laborRate: 0, partsCost: 0, partsMarkup: 1.0, applicableModelId: undefined },
  { id: 'svc-elt-test', description: 'ELT Inspection (91.207)', category: 'Labor', laborHours: 1.0, laborRate: 0, partsCost: 0, partsMarkup: 1.0, applicableModelId: undefined },
  { id: 'svc-compass-swing', description: 'Compass Swing', category: 'Labor', laborHours: 3.0, laborRate: 0, partsCost: 0, partsMarkup: 1.0, applicableModelId: undefined },

  // ============================================================================
  // CITATION CJ2 (525A) SPECIFIC - Phase Inspections per CESCOM
  // ============================================================================
  { id: 'svc-cj2-phase1', description: 'CJ2 Phase 1 Inspection (200 hrs)', category: 'Labor', laborHours: 24, laborRate: 0, partsCost: 1200, partsMarkup: 1.2, applicableModelId: 'ac-cj2' },
  { id: 'svc-cj2-phase2', description: 'CJ2 Phase 2 Inspection (400 hrs)', category: 'Labor', laborHours: 28, laborRate: 0, partsCost: 1500, partsMarkup: 1.2, applicableModelId: 'ac-cj2' },
  { id: 'svc-cj2-phase3', description: 'CJ2 Phase 3 Inspection (600 hrs)', category: 'Labor', laborHours: 26, laborRate: 0, partsCost: 1400, partsMarkup: 1.2, applicableModelId: 'ac-cj2' },
  { id: 'svc-cj2-phase4', description: 'CJ2 Phase 4 Inspection (800 hrs)', category: 'Labor', laborHours: 32, laborRate: 0, partsCost: 1800, partsMarkup: 1.2, applicableModelId: 'ac-cj2' },
  { id: 'svc-cj2-12mo', description: 'CJ2 12-Month Inspection', category: 'Labor', laborHours: 18, laborRate: 0, partsCost: 800, partsMarkup: 1.2, applicableModelId: 'ac-cj2' },
  { id: 'svc-cj2-24mo', description: 'CJ2 24-Month Inspection', category: 'Labor', laborHours: 45, laborRate: 0, partsCost: 2500, partsMarkup: 1.2, applicableModelId: 'ac-cj2' },
  { id: 'svc-cj2-landing-gear', description: 'CJ2 Landing Gear Overhaul (10yr/12000 cycles)', category: 'Service', laborHours: 120, laborRate: 0, partsCost: 45000, partsMarkup: 1.08, applicableModelId: 'ac-cj2' },
  { id: 'svc-cj2-hsi', description: 'CJ2 FJ44-2C HSI (3500 hrs)', category: 'Service', laborHours: 40, laborRate: 0, partsCost: 125000, partsMarkup: 1.05, applicableModelId: 'ac-cj2' },

  // ============================================================================
  // CITATION CJ3 (525B) SPECIFIC
  // ============================================================================
  { id: 'svc-cj3-phase1', description: 'CJ3 Phase 1 Inspection (200 hrs)', category: 'Labor', laborHours: 26, laborRate: 0, partsCost: 1400, partsMarkup: 1.2, applicableModelId: 'ac-cj3' },
  { id: 'svc-cj3-phase2', description: 'CJ3 Phase 2 Inspection (400 hrs)', category: 'Labor', laborHours: 30, laborRate: 0, partsCost: 1700, partsMarkup: 1.2, applicableModelId: 'ac-cj3' },
  { id: 'svc-cj3-phase3', description: 'CJ3 Phase 3 Inspection (600 hrs)', category: 'Labor', laborHours: 28, laborRate: 0, partsCost: 1600, partsMarkup: 1.2, applicableModelId: 'ac-cj3' },
  { id: 'svc-cj3-phase4', description: 'CJ3 Phase 4 Inspection (800 hrs)', category: 'Labor', laborHours: 35, laborRate: 0, partsCost: 2000, partsMarkup: 1.2, applicableModelId: 'ac-cj3' },
  { id: 'svc-cj3-12mo', description: 'CJ3 12-Month Inspection', category: 'Labor', laborHours: 20, laborRate: 0, partsCost: 900, partsMarkup: 1.2, applicableModelId: 'ac-cj3' },
  { id: 'svc-cj3-24mo', description: 'CJ3 24-Month Inspection', category: 'Labor', laborHours: 50, laborRate: 0, partsCost: 2800, partsMarkup: 1.2, applicableModelId: 'ac-cj3' },
  { id: 'svc-cj3-landing-gear', description: 'CJ3 Landing Gear Overhaul (10yr/12000 cycles)', category: 'Service', laborHours: 130, laborRate: 0, partsCost: 52000, partsMarkup: 1.08, applicableModelId: 'ac-cj3' },
  { id: 'svc-cj3-hsi', description: 'CJ3 FJ44-3A HSI (3500 hrs)', category: 'Service', laborHours: 45, laborRate: 0, partsCost: 145000, partsMarkup: 1.05, applicableModelId: 'ac-cj3' },

  // ============================================================================
  // CITATION CJ4 (525C) SPECIFIC
  // ============================================================================
  { id: 'svc-cj4-phase1', description: 'CJ4 Phase 1 Inspection (200 hrs)', category: 'Labor', laborHours: 28, laborRate: 0, partsCost: 1600, partsMarkup: 1.2, applicableModelId: 'ac-cj4' },
  { id: 'svc-cj4-phase2', description: 'CJ4 Phase 2 Inspection (400 hrs)', category: 'Labor', laborHours: 32, laborRate: 0, partsCost: 1900, partsMarkup: 1.2, applicableModelId: 'ac-cj4' },
  { id: 'svc-cj4-phase3', description: 'CJ4 Phase 3 Inspection (600 hrs)', category: 'Labor', laborHours: 30, laborRate: 0, partsCost: 1800, partsMarkup: 1.2, applicableModelId: 'ac-cj4' },
  { id: 'svc-cj4-phase4', description: 'CJ4 Phase 4 Inspection (800 hrs)', category: 'Labor', laborHours: 38, laborRate: 0, partsCost: 2200, partsMarkup: 1.2, applicableModelId: 'ac-cj4' },
  { id: 'svc-cj4-12mo', description: 'CJ4 12-Month Inspection', category: 'Labor', laborHours: 22, laborRate: 0, partsCost: 1000, partsMarkup: 1.2, applicableModelId: 'ac-cj4' },
  { id: 'svc-cj4-24mo', description: 'CJ4 24-Month Inspection', category: 'Labor', laborHours: 55, laborRate: 0, partsCost: 3200, partsMarkup: 1.2, applicableModelId: 'ac-cj4' },
  { id: 'svc-cj4-landing-gear', description: 'CJ4 Landing Gear Overhaul (10yr/12000 cycles)', category: 'Service', laborHours: 140, laborRate: 0, partsCost: 58000, partsMarkup: 1.08, applicableModelId: 'ac-cj4' },
  { id: 'svc-cj4-hsi', description: 'CJ4 FJ44-4A HSI (3500 hrs)', category: 'Service', laborHours: 48, laborRate: 0, partsCost: 165000, partsMarkup: 1.05, applicableModelId: 'ac-cj4' },

  // ============================================================================
  // CITATION EXCEL (560XL) SPECIFIC
  // ============================================================================
  { id: 'svc-xl-phase1', description: 'Excel Phase 1 Inspection (200 hrs)', category: 'Labor', laborHours: 35, laborRate: 0, partsCost: 2000, partsMarkup: 1.2, applicableModelId: 'ac-c560xl' },
  { id: 'svc-xl-phase2', description: 'Excel Phase 2 Inspection (400 hrs)', category: 'Labor', laborHours: 40, laborRate: 0, partsCost: 2400, partsMarkup: 1.2, applicableModelId: 'ac-c560xl' },
  { id: 'svc-xl-phase3', description: 'Excel Phase 3 Inspection (600 hrs)', category: 'Labor', laborHours: 38, laborRate: 0, partsCost: 2200, partsMarkup: 1.2, applicableModelId: 'ac-c560xl' },
  { id: 'svc-xl-phase4', description: 'Excel Phase 4 Inspection (800 hrs)', category: 'Labor', laborHours: 48, laborRate: 0, partsCost: 2800, partsMarkup: 1.2, applicableModelId: 'ac-c560xl' },
  { id: 'svc-xl-12mo', description: 'Excel 12-Month Inspection', category: 'Labor', laborHours: 28, laborRate: 0, partsCost: 1400, partsMarkup: 1.2, applicableModelId: 'ac-c560xl' },
  { id: 'svc-xl-24mo', description: 'Excel 24-Month Inspection', category: 'Labor', laborHours: 65, laborRate: 0, partsCost: 4500, partsMarkup: 1.2, applicableModelId: 'ac-c560xl' },
  { id: 'svc-xl-landing-gear', description: 'Excel Landing Gear Overhaul (12yr)', category: 'Service', laborHours: 160, laborRate: 0, partsCost: 72000, partsMarkup: 1.08, applicableModelId: 'ac-c560xl' },
  { id: 'svc-xl-hsi', description: 'Excel PW545A HSI (4000 hrs)', category: 'Service', laborHours: 55, laborRate: 0, partsCost: 185000, partsMarkup: 1.05, applicableModelId: 'ac-c560xl' },

  // ============================================================================
  // CITATION XLS+ (560XLS) SPECIFIC
  // ============================================================================
  { id: 'svc-xls-phase1', description: 'XLS+ Phase 1 Inspection (200 hrs)', category: 'Labor', laborHours: 36, laborRate: 0, partsCost: 2200, partsMarkup: 1.2, applicableModelId: 'ac-c560xls' },
  { id: 'svc-xls-phase2', description: 'XLS+ Phase 2 Inspection (400 hrs)', category: 'Labor', laborHours: 42, laborRate: 0, partsCost: 2600, partsMarkup: 1.2, applicableModelId: 'ac-c560xls' },
  { id: 'svc-xls-phase3', description: 'XLS+ Phase 3 Inspection (600 hrs)', category: 'Labor', laborHours: 40, laborRate: 0, partsCost: 2400, partsMarkup: 1.2, applicableModelId: 'ac-c560xls' },
  { id: 'svc-xls-phase4', description: 'XLS+ Phase 4 Inspection (800 hrs)', category: 'Labor', laborHours: 50, laborRate: 0, partsCost: 3000, partsMarkup: 1.2, applicableModelId: 'ac-c560xls' },
  { id: 'svc-xls-12mo', description: 'XLS+ 12-Month Inspection', category: 'Labor', laborHours: 30, laborRate: 0, partsCost: 1600, partsMarkup: 1.2, applicableModelId: 'ac-c560xls' },
  { id: 'svc-xls-24mo', description: 'XLS+ 24-Month Inspection', category: 'Labor', laborHours: 70, laborRate: 0, partsCost: 5000, partsMarkup: 1.2, applicableModelId: 'ac-c560xls' },
  { id: 'svc-xls-landing-gear', description: 'XLS+ Landing Gear Overhaul (12yr)', category: 'Service', laborHours: 165, laborRate: 0, partsCost: 78000, partsMarkup: 1.08, applicableModelId: 'ac-c560xls' },
  { id: 'svc-xls-hsi', description: 'XLS+ PW545C HSI (4000 hrs)', category: 'Service', laborHours: 58, laborRate: 0, partsCost: 195000, partsMarkup: 1.05, applicableModelId: 'ac-c560xls' },

  // ============================================================================
  // CITATION X (750) SPECIFIC
  // ============================================================================
  { id: 'svc-cx-phase1', description: 'Citation X Phase 1 Inspection (300 hrs)', category: 'Labor', laborHours: 45, laborRate: 0, partsCost: 3200, partsMarkup: 1.2, applicableModelId: 'ac-c750' },
  { id: 'svc-cx-phase2', description: 'Citation X Phase 2 Inspection (600 hrs)', category: 'Labor', laborHours: 52, laborRate: 0, partsCost: 3800, partsMarkup: 1.2, applicableModelId: 'ac-c750' },
  { id: 'svc-cx-phase3', description: 'Citation X Phase 3 Inspection (900 hrs)', category: 'Labor', laborHours: 48, laborRate: 0, partsCost: 3500, partsMarkup: 1.2, applicableModelId: 'ac-c750' },
  { id: 'svc-cx-phase4', description: 'Citation X Phase 4 Inspection (1200 hrs)', category: 'Labor', laborHours: 60, laborRate: 0, partsCost: 4200, partsMarkup: 1.2, applicableModelId: 'ac-c750' },
  { id: 'svc-cx-12mo', description: 'Citation X 12-Month Inspection', category: 'Labor', laborHours: 35, laborRate: 0, partsCost: 2200, partsMarkup: 1.2, applicableModelId: 'ac-c750' },
  { id: 'svc-cx-24mo', description: 'Citation X 24-Month Inspection', category: 'Labor', laborHours: 85, laborRate: 0, partsCost: 6500, partsMarkup: 1.2, applicableModelId: 'ac-c750' },
  { id: 'svc-cx-landing-gear', description: 'Citation X Landing Gear Overhaul (12yr)', category: 'Service', laborHours: 200, laborRate: 0, partsCost: 125000, partsMarkup: 1.08, applicableModelId: 'ac-c750' },
  { id: 'svc-cx-hsi', description: 'Citation X AE3007C HSI (4500 hrs)', category: 'Service', laborHours: 80, laborRate: 0, partsCost: 285000, partsMarkup: 1.05, applicableModelId: 'ac-c750' },

  // ============================================================================
  // GULFSTREAM G450 SPECIFIC
  // ============================================================================
  { id: 'svc-g450-12mo', description: 'G450 12-Month Inspection', category: 'Labor', laborHours: 80, laborRate: 0, partsCost: 8500, partsMarkup: 1.15, applicableModelId: 'ac-g450' },
  { id: 'svc-g450-24mo', description: 'G450 24-Month Inspection', category: 'Labor', laborHours: 180, laborRate: 0, partsCost: 22000, partsMarkup: 1.15, applicableModelId: 'ac-g450' },
  { id: 'svc-g450-48mo', description: 'G450 48-Month Inspection', category: 'Labor', laborHours: 320, laborRate: 0, partsCost: 45000, partsMarkup: 1.12, applicableModelId: 'ac-g450' },
  { id: 'svc-g450-96mo', description: 'G450 96-Month Inspection', category: 'Labor', laborHours: 550, laborRate: 0, partsCost: 85000, partsMarkup: 1.10, applicableModelId: 'ac-g450' },
  { id: 'svc-g450-landing-gear', description: 'G450 Landing Gear Overhaul (12yr)', category: 'Service', laborHours: 280, laborRate: 0, partsCost: 185000, partsMarkup: 1.08, applicableModelId: 'ac-g450' },
  { id: 'svc-g450-apu', description: 'G450 APU Overhaul (RE220)', category: 'Service', laborHours: 60, laborRate: 0, partsCost: 125000, partsMarkup: 1.06, applicableModelId: 'ac-g450' },
  { id: 'svc-g450-hsi', description: 'G450 Tay 611-8C HSI (5000 hrs)', category: 'Service', laborHours: 120, laborRate: 0, partsCost: 425000, partsMarkup: 1.05, applicableModelId: 'ac-g450' },

  // ============================================================================
  // GULFSTREAM G550 SPECIFIC
  // ============================================================================
  { id: 'svc-g550-12mo', description: 'G550 12-Month Inspection', category: 'Labor', laborHours: 85, laborRate: 0, partsCost: 9500, partsMarkup: 1.15, applicableModelId: 'ac-g550' },
  { id: 'svc-g550-24mo', description: 'G550 24-Month Inspection', category: 'Labor', laborHours: 195, laborRate: 0, partsCost: 25000, partsMarkup: 1.15, applicableModelId: 'ac-g550' },
  { id: 'svc-g550-48mo', description: 'G550 48-Month Inspection', category: 'Labor', laborHours: 350, laborRate: 0, partsCost: 52000, partsMarkup: 1.12, applicableModelId: 'ac-g550' },
  { id: 'svc-g550-96mo', description: 'G550 96-Month Inspection', category: 'Labor', laborHours: 600, laborRate: 0, partsCost: 95000, partsMarkup: 1.10, applicableModelId: 'ac-g550' },
  { id: 'svc-g550-landing-gear', description: 'G550 Landing Gear Overhaul (12yr)', category: 'Service', laborHours: 300, laborRate: 0, partsCost: 210000, partsMarkup: 1.08, applicableModelId: 'ac-g550' },
  { id: 'svc-g550-apu', description: 'G550 APU Overhaul (RE220)', category: 'Service', laborHours: 65, laborRate: 0, partsCost: 135000, partsMarkup: 1.06, applicableModelId: 'ac-g550' },
  { id: 'svc-g550-hsi', description: 'G550 BR710 HSI (5000 hrs)', category: 'Service', laborHours: 140, laborRate: 0, partsCost: 485000, partsMarkup: 1.05, applicableModelId: 'ac-g550' },

  // ============================================================================
  // GULFSTREAM G650 SPECIFIC
  // ============================================================================
  { id: 'svc-g650-12mo', description: 'G650 12-Month Inspection', category: 'Labor', laborHours: 95, laborRate: 0, partsCost: 12000, partsMarkup: 1.15, applicableModelId: 'ac-g650' },
  { id: 'svc-g650-24mo', description: 'G650 24-Month Inspection', category: 'Labor', laborHours: 220, laborRate: 0, partsCost: 32000, partsMarkup: 1.15, applicableModelId: 'ac-g650' },
  { id: 'svc-g650-48mo', description: 'G650 48-Month Inspection', category: 'Labor', laborHours: 400, laborRate: 0, partsCost: 65000, partsMarkup: 1.12, applicableModelId: 'ac-g650' },
  { id: 'svc-g650-96mo', description: 'G650 96-Month Inspection', category: 'Labor', laborHours: 700, laborRate: 0, partsCost: 120000, partsMarkup: 1.10, applicableModelId: 'ac-g650' },
  { id: 'svc-g650-landing-gear', description: 'G650 Landing Gear Overhaul (12yr)', category: 'Service', laborHours: 350, laborRate: 0, partsCost: 285000, partsMarkup: 1.08, applicableModelId: 'ac-g650' },
  { id: 'svc-g650-apu', description: 'G650 APU Overhaul (RE220)', category: 'Service', laborHours: 70, laborRate: 0, partsCost: 155000, partsMarkup: 1.06, applicableModelId: 'ac-g650' },
  { id: 'svc-g650-hsi', description: 'G650 BR725 HSI (5000 hrs)', category: 'Service', laborHours: 160, laborRate: 0, partsCost: 565000, partsMarkup: 1.05, applicableModelId: 'ac-g650' },

  // ============================================================================
  // EMBRAER PHENOM 100 SPECIFIC (MSG-3 Based)
  // ============================================================================
  { id: 'svc-e100-100hr', description: 'Phenom 100 100-Hour Inspection', category: 'Labor', laborHours: 12, laborRate: 0, partsCost: 600, partsMarkup: 1.2, applicableModelId: 'ac-phenom100' },
  { id: 'svc-e100-200hr', description: 'Phenom 100 200-Hour Inspection', category: 'Labor', laborHours: 20, laborRate: 0, partsCost: 1100, partsMarkup: 1.2, applicableModelId: 'ac-phenom100' },
  { id: 'svc-e100-12mo', description: 'Phenom 100 12-Month Inspection', category: 'Labor', laborHours: 28, laborRate: 0, partsCost: 1500, partsMarkup: 1.2, applicableModelId: 'ac-phenom100' },
  { id: 'svc-e100-24mo', description: 'Phenom 100 24-Month Inspection', category: 'Labor', laborHours: 55, laborRate: 0, partsCost: 3200, partsMarkup: 1.2, applicableModelId: 'ac-phenom100' },
  { id: 'svc-e100-48mo', description: 'Phenom 100 48-Month Inspection', category: 'Labor', laborHours: 90, laborRate: 0, partsCost: 6500, partsMarkup: 1.15, applicableModelId: 'ac-phenom100' },
  { id: 'svc-e100-landing-gear', description: 'Phenom 100 Landing Gear Overhaul (10yr)', category: 'Service', laborHours: 100, laborRate: 0, partsCost: 38000, partsMarkup: 1.08, applicableModelId: 'ac-phenom100' },
  { id: 'svc-e100-hsi', description: 'Phenom 100 PW617F HSI (3600 hrs)', category: 'Service', laborHours: 35, laborRate: 0, partsCost: 95000, partsMarkup: 1.05, applicableModelId: 'ac-phenom100' },

  // ============================================================================
  // EMBRAER PHENOM 300 SPECIFIC (MSG-3 Based)
  // ============================================================================
  { id: 'svc-e300-100hr', description: 'Phenom 300 100-Hour Inspection', category: 'Labor', laborHours: 14, laborRate: 0, partsCost: 750, partsMarkup: 1.2, applicableModelId: 'ac-phenom300' },
  { id: 'svc-e300-200hr', description: 'Phenom 300 200-Hour Inspection', category: 'Labor', laborHours: 24, laborRate: 0, partsCost: 1400, partsMarkup: 1.2, applicableModelId: 'ac-phenom300' },
  { id: 'svc-e300-12mo', description: 'Phenom 300 12-Month Inspection', category: 'Labor', laborHours: 35, laborRate: 0, partsCost: 2000, partsMarkup: 1.2, applicableModelId: 'ac-phenom300' },
  { id: 'svc-e300-24mo', description: 'Phenom 300 24-Month Inspection', category: 'Labor', laborHours: 70, laborRate: 0, partsCost: 4500, partsMarkup: 1.2, applicableModelId: 'ac-phenom300' },
  { id: 'svc-e300-48mo', description: 'Phenom 300 48-Month Inspection', category: 'Labor', laborHours: 120, laborRate: 0, partsCost: 9500, partsMarkup: 1.15, applicableModelId: 'ac-phenom300' },
  { id: 'svc-e300-landing-gear', description: 'Phenom 300 Landing Gear Overhaul (10yr)', category: 'Service', laborHours: 120, laborRate: 0, partsCost: 52000, partsMarkup: 1.08, applicableModelId: 'ac-phenom300' },
  { id: 'svc-e300-hsi', description: 'Phenom 300 PW535E HSI (3600 hrs)', category: 'Service', laborHours: 45, laborRate: 0, partsCost: 145000, partsMarkup: 1.05, applicableModelId: 'ac-phenom300' },

  // ============================================================================
  // PILATUS PC-24 SPECIFIC
  // ============================================================================
  { id: 'svc-pc24-100hr', description: 'PC-24 100-Hour Inspection', category: 'Labor', laborHours: 16, laborRate: 0, partsCost: 900, partsMarkup: 1.2, applicableModelId: 'ac-pc24' },
  { id: 'svc-pc24-200hr', description: 'PC-24 200-Hour Inspection', category: 'Labor', laborHours: 28, laborRate: 0, partsCost: 1600, partsMarkup: 1.2, applicableModelId: 'ac-pc24' },
  { id: 'svc-pc24-12mo', description: 'PC-24 12-Month Inspection', category: 'Labor', laborHours: 40, laborRate: 0, partsCost: 2400, partsMarkup: 1.2, applicableModelId: 'ac-pc24' },
  { id: 'svc-pc24-24mo', description: 'PC-24 24-Month Inspection', category: 'Labor', laborHours: 80, laborRate: 0, partsCost: 5500, partsMarkup: 1.2, applicableModelId: 'ac-pc24' },
  { id: 'svc-pc24-48mo', description: 'PC-24 48-Month Inspection', category: 'Labor', laborHours: 140, laborRate: 0, partsCost: 12000, partsMarkup: 1.15, applicableModelId: 'ac-pc24' },
  { id: 'svc-pc24-landing-gear', description: 'PC-24 Landing Gear Overhaul (12yr)', category: 'Service', laborHours: 130, laborRate: 0, partsCost: 65000, partsMarkup: 1.08, applicableModelId: 'ac-pc24' },
  { id: 'svc-pc24-hsi', description: 'PC-24 FJ44-4A HSI (3500 hrs)', category: 'Service', laborHours: 50, laborRate: 0, partsCost: 175000, partsMarkup: 1.05, applicableModelId: 'ac-pc24' },

  // ============================================================================
  // PILATUS PC-12 NGX SPECIFIC (PT6A-67P Turboprop)
  // ============================================================================
  { id: 'svc-pc12-100hr', description: 'PC-12 NGX 100-Hour Inspection', category: 'Labor', laborHours: 16, laborRate: 0, partsCost: 1200, partsMarkup: 1.2, applicableModelId: 'ac-pc12' },
  { id: 'svc-pc12-200hr', description: 'PC-12 NGX 200-Hour Inspection', category: 'Labor', laborHours: 28, laborRate: 0, partsCost: 2000, partsMarkup: 1.2, applicableModelId: 'ac-pc12' },
  { id: 'svc-pc12-300hr', description: 'PC-12 NGX 300-Hour Inspection', category: 'Labor', laborHours: 22, laborRate: 0, partsCost: 1600, partsMarkup: 1.2, applicableModelId: 'ac-pc12' },
  { id: 'svc-pc12-600hr', description: 'PC-12 NGX 600-Hour Inspection', category: 'Labor', laborHours: 45, laborRate: 0, partsCost: 3500, partsMarkup: 1.2, applicableModelId: 'ac-pc12' },
  { id: 'svc-pc12-12mo', description: 'PC-12 NGX 12-Month Inspection', category: 'Labor', laborHours: 35, laborRate: 0, partsCost: 2800, partsMarkup: 1.2, applicableModelId: 'ac-pc12' },
  { id: 'svc-pc12-24mo', description: 'PC-12 NGX 24-Month Inspection', category: 'Labor', laborHours: 75, laborRate: 0, partsCost: 5800, partsMarkup: 1.2, applicableModelId: 'ac-pc12' },
  { id: 'svc-pc12-prop-oh', description: 'PC-12 NGX Prop Overhaul (1500 hrs/5yr)', category: 'Service', laborHours: 24, laborRate: 0, partsCost: 42000, partsMarkup: 1.08, applicableModelId: 'ac-pc12' },
  { id: 'svc-pc12-landing-gear', description: 'PC-12 NGX Landing Gear Overhaul (12yr)', category: 'Service', laborHours: 85, laborRate: 0, partsCost: 48000, partsMarkup: 1.08, applicableModelId: 'ac-pc12' },
  { id: 'svc-pc12-hsi', description: 'PC-12 NGX PT6A-67P HSI (3600 hrs)', category: 'Service', laborHours: 40, laborRate: 0, partsCost: 185000, partsMarkup: 1.05, applicableModelId: 'ac-pc12' },
  { id: 'svc-pc12-hot-section', description: 'PC-12 NGX Hot Section Inspection', category: 'Service', laborHours: 32, laborRate: 0, partsCost: 65000, partsMarkup: 1.06, applicableModelId: 'ac-pc12' },

  // ============================================================================
  // TBM 900 SPECIFIC (PT6A-66D Turboprop)
  // ============================================================================
  { id: 'svc-tbm900-100hr', description: 'TBM 900 100-Hour Inspection', category: 'Labor', laborHours: 12, laborRate: 0, partsCost: 600, partsMarkup: 1.2, applicableModelId: 'ac-tbm900' },
  { id: 'svc-tbm900-200hr', description: 'TBM 900 200-Hour Inspection', category: 'Labor', laborHours: 20, laborRate: 0, partsCost: 1200, partsMarkup: 1.2, applicableModelId: 'ac-tbm900' },
  { id: 'svc-tbm900-annual', description: 'TBM 900 Annual Inspection', category: 'Labor', laborHours: 45, laborRate: 0, partsCost: 3500, partsMarkup: 1.2, applicableModelId: 'ac-tbm900' },
  { id: 'svc-tbm900-prop', description: 'TBM 900 Prop Overhaul (2000 hrs)', category: 'Service', laborHours: 20, laborRate: 0, partsCost: 35000, partsMarkup: 1.08, applicableModelId: 'ac-tbm900' },
  { id: 'svc-tbm900-hsi', description: 'TBM 900 PT6A-66D HSI (3600 hrs)', category: 'Service', laborHours: 35, laborRate: 0, partsCost: 150000, partsMarkup: 1.05, applicableModelId: 'ac-tbm900' },

  // ============================================================================
  // TBM 960 SPECIFIC (PT6E-66XT Turboprop)
  // ============================================================================
  { id: 'svc-tbm960-100hr', description: 'TBM 960 100-Hour Inspection', category: 'Labor', laborHours: 14, laborRate: 0, partsCost: 700, partsMarkup: 1.2, applicableModelId: 'ac-tbm960' },
  { id: 'svc-tbm960-200hr', description: 'TBM 960 200-Hour Inspection', category: 'Labor', laborHours: 24, laborRate: 0, partsCost: 1400, partsMarkup: 1.2, applicableModelId: 'ac-tbm960' },
  { id: 'svc-tbm960-annual', description: 'TBM 960 Annual Inspection', category: 'Labor', laborHours: 50, laborRate: 0, partsCost: 4000, partsMarkup: 1.2, applicableModelId: 'ac-tbm960' },
  { id: 'svc-tbm960-prop', description: 'TBM 960 Prop Overhaul (2000 hrs)', category: 'Service', laborHours: 22, laborRate: 0, partsCost: 38000, partsMarkup: 1.08, applicableModelId: 'ac-tbm960' },
  { id: 'svc-tbm960-hsi', description: 'TBM 960 PT6E-66XT HSI (4000 hrs)', category: 'Service', laborHours: 40, laborRate: 0, partsCost: 175000, partsMarkup: 1.05, applicableModelId: 'ac-tbm960' },

  // ============================================================================
  // KING AIR 350 SPECIFIC (PT6A-60A Turboprop)
  // ============================================================================
  { id: 'svc-ka350-phase1', description: 'King Air 350 Phase 1 (200 hrs)', category: 'Labor', laborHours: 40, laborRate: 0, partsCost: 2500, partsMarkup: 1.2, applicableModelId: 'ac-kingair350' },
  { id: 'svc-ka350-phase2', description: 'King Air 350 Phase 2 (400 hrs)', category: 'Labor', laborHours: 50, laborRate: 0, partsCost: 3500, partsMarkup: 1.2, applicableModelId: 'ac-kingair350' },
  { id: 'svc-ka350-phase3', description: 'King Air 350 Phase 3 (600 hrs)', category: 'Labor', laborHours: 45, laborRate: 0, partsCost: 3000, partsMarkup: 1.2, applicableModelId: 'ac-kingair350' },
  { id: 'svc-ka350-phase4', description: 'King Air 350 Phase 4 (800 hrs)', category: 'Labor', laborHours: 60, laborRate: 0, partsCost: 5000, partsMarkup: 1.2, applicableModelId: 'ac-kingair350' },
  { id: 'svc-ka350-annual', description: 'King Air 350 Annual Inspection', category: 'Labor', laborHours: 80, laborRate: 0, partsCost: 8500, partsMarkup: 1.2, applicableModelId: 'ac-kingair350' },
  { id: 'svc-ka350-prop', description: 'King Air 350 Prop Overhaul (per prop)', category: 'Service', laborHours: 18, laborRate: 0, partsCost: 28000, partsMarkup: 1.08, applicableModelId: 'ac-kingair350' },
  { id: 'svc-ka350-hsi', description: 'King Air 350 PT6A-60A HSI (3600 hrs)', category: 'Service', laborHours: 45, laborRate: 0, partsCost: 165000, partsMarkup: 1.05, applicableModelId: 'ac-kingair350' },

  // ============================================================================
  // KING AIR 250 SPECIFIC (PT6A-52 Turboprop)
  // ============================================================================
  { id: 'svc-ka250-phase1', description: 'King Air 250 Phase 1 (200 hrs)', category: 'Labor', laborHours: 35, laborRate: 0, partsCost: 2200, partsMarkup: 1.2, applicableModelId: 'ac-kingair250' },
  { id: 'svc-ka250-phase2', description: 'King Air 250 Phase 2 (400 hrs)', category: 'Labor', laborHours: 42, laborRate: 0, partsCost: 3000, partsMarkup: 1.2, applicableModelId: 'ac-kingair250' },
  { id: 'svc-ka250-annual', description: 'King Air 250 Annual Inspection', category: 'Labor', laborHours: 65, laborRate: 0, partsCost: 6500, partsMarkup: 1.2, applicableModelId: 'ac-kingair250' },
  { id: 'svc-ka250-prop', description: 'King Air 250 Prop Overhaul (per prop)', category: 'Service', laborHours: 16, laborRate: 0, partsCost: 25000, partsMarkup: 1.08, applicableModelId: 'ac-kingair250' },
  { id: 'svc-ka250-hsi', description: 'King Air 250 PT6A-52 HSI (3600 hrs)', category: 'Service', laborHours: 40, laborRate: 0, partsCost: 145000, partsMarkup: 1.05, applicableModelId: 'ac-kingair250' },

  // ============================================================================
  // KING AIR C90 SPECIFIC (PT6A-135A Turboprop)
  // ============================================================================
  { id: 'svc-ka90-100hr', description: 'King Air C90 100-Hour Inspection', category: 'Labor', laborHours: 18, laborRate: 0, partsCost: 1000, partsMarkup: 1.2, applicableModelId: 'ac-kingair90' },
  { id: 'svc-ka90-annual', description: 'King Air C90 Annual Inspection', category: 'Labor', laborHours: 55, laborRate: 0, partsCost: 5000, partsMarkup: 1.2, applicableModelId: 'ac-kingair90' },
  { id: 'svc-ka90-prop', description: 'King Air C90 Prop Overhaul (per prop)', category: 'Service', laborHours: 14, laborRate: 0, partsCost: 22000, partsMarkup: 1.08, applicableModelId: 'ac-kingair90' },
  { id: 'svc-ka90-hsi', description: 'King Air C90 PT6A-135A HSI (3600 hrs)', category: 'Service', laborHours: 35, laborRate: 0, partsCost: 125000, partsMarkup: 1.05, applicableModelId: 'ac-kingair90' },
];

// ============================================================================
// MARKUP TIERS
// ============================================================================
export const DEFAULT_MARKUP_TIERS: MarkupTier[] = [
  { maxLimit: 500, markup: 1.30 },
  { maxLimit: 2500, markup: 1.20 },
  { maxLimit: 10000, markup: 1.12 },
  { maxLimit: 999999999, markup: 1.08 },
];

// ============================================================================
// 10 QUOTES (Unscheduled Jobs in Backlog) - Light Jets & Turboprops
// ============================================================================
export const INITIAL_BACKLOG: Job[] = [
  // Quote 1: CJ2+ Phase 1-4 Combined (110 hrs)
  {
    id: 'quote-001',
    customer: 'N525AB',
    aircraftType: 'ac-cj2',
    description: 'CJ2 Phases 1-4 Combined (800 hr)',
    estimatedHours: 110,
    revenue: 14850,
    partsRevenue: 7200,
    color: 'bg-slate-500',
    deadlineDays: 14,
    requiredHangarSize: 'Medium',
    isAOG: false,
    notes: 'Customer wants all phases done together. TTAF 2,847 hrs.',
    quoteLines: [
      { id: 'ql-001-1', description: 'CJ2 Phase 1 Inspection (200 hrs)', category: 'Labor', laborHours: 24, laborRate: 175, partsCost: 1200, partsMarkup: 1.2 },
      { id: 'ql-001-2', description: 'CJ2 Phase 2 Inspection (400 hrs)', category: 'Labor', laborHours: 28, laborRate: 175, partsCost: 1500, partsMarkup: 1.2 },
      { id: 'ql-001-3', description: 'CJ2 Phase 3 Inspection (600 hrs)', category: 'Labor', laborHours: 26, laborRate: 175, partsCost: 1400, partsMarkup: 1.2 },
      { id: 'ql-001-4', description: 'CJ2 Phase 4 Inspection (800 hrs)', category: 'Labor', laborHours: 32, laborRate: 175, partsCost: 1800, partsMarkup: 1.2 },
      { id: 'ql-001-5', description: 'Consumable Materials Fee', category: 'Service', laborHours: 0, laborRate: 0, partsCost: 450, partsMarkup: 1.0 },
    ]
  },

  // Quote 2: CJ3 24-Month + Landing Gear
  {
    id: 'quote-002',
    customer: 'N723PJ',
    aircraftType: 'ac-cj3',
    description: 'CJ3 24-Month + Landing Gear OH',
    estimatedHours: 180,
    revenue: 24300,
    partsRevenue: 59280,
    color: 'bg-rose-600',
    deadlineDays: 21,
    requiredHangarSize: 'Medium',
    isAOG: false,
    notes: 'Landing gear due at 12 years. Gear going to Hawker Pacific.',
    quoteLines: [
      { id: 'ql-002-1', description: 'CJ3 24-Month Inspection', category: 'Labor', laborHours: 50, laborRate: 175, partsCost: 2800, partsMarkup: 1.2 },
      { id: 'ql-002-2', description: 'CJ3 Landing Gear Overhaul (10yr/12000 cycles)', category: 'Service', laborHours: 130, laborRate: 175, partsCost: 52000, partsMarkup: 1.08 },
      { id: 'ql-002-3', description: 'Consumable Materials Fee', category: 'Service', laborHours: 0, laborRate: 0, partsCost: 680, partsMarkup: 1.0 },
    ]
  },

  // Quote 3: G550 96-Month Major
  {
    id: 'quote-003',
    customer: 'N550GS',
    aircraftType: 'ac-g550',
    description: 'G550 96-Month Major Inspection',
    estimatedHours: 600,
    revenue: 81000,
    partsRevenue: 104500,
    color: 'bg-slate-500',
    deadlineDays: 45,
    requiredHangarSize: 'Large',
    isAOG: false,
    notes: 'Full 8-year inspection. Customer wants paint quote as add-on.',
    quoteLines: [
      { id: 'ql-003-1', description: 'G550 96-Month Inspection', category: 'Labor', laborHours: 600, laborRate: 175, partsCost: 95000, partsMarkup: 1.10 },
      { id: 'ql-003-2', description: 'Consumable Materials Fee', category: 'Service', laborHours: 0, laborRate: 0, partsCost: 2400, partsMarkup: 1.0 },
    ]
  },

  // Quote 4: Phenom 300 12-Month + Detailing
  {
    id: 'quote-004',
    customer: 'N300EM',
    aircraftType: 'ac-phenom300',
    description: 'Phenom 300 12-Month + Full Detail',
    estimatedHours: 47,
    revenue: 6345,
    partsRevenue: 3250,
    color: 'bg-amber-500',
    deadlineDays: 7,
    requiredHangarSize: 'Medium',
    isAOG: false,
    notes: 'Regular customer. Wants aircraft detailed for upcoming charter.',
    quoteLines: [
      { id: 'ql-004-1', description: 'Phenom 300 12-Month Inspection', category: 'Labor', laborHours: 35, laborRate: 175, partsCost: 2000, partsMarkup: 1.2 },
      { id: 'ql-004-2', description: 'Full Detail (Complete Interior/Exterior)', category: 'Service', laborHours: 12, laborRate: 175, partsCost: 500, partsMarkup: 1.3 },
      { id: 'ql-004-3', description: 'Consumable Materials Fee', category: 'Service', laborHours: 0, laborRate: 0, partsCost: 175, partsMarkup: 1.0 },
    ]
  },

  // Quote 5: Citation XLS+ Phase 2 + HSI
  {
    id: 'quote-005',
    customer: 'N560XP',
    aircraftType: 'ac-cj4',
    description: 'XLS+ Phase 2 + Engine HSI (Both)',
    estimatedHours: 158,
    revenue: 21330,
    partsRevenue: 424600,
    color: 'bg-slate-500',
    deadlineDays: 30,
    requiredHangarSize: 'Medium',
    isAOG: false,
    notes: 'Both engines at HSI interval. Sending to StandardAero.',
    quoteLines: [
      { id: 'ql-005-1', description: 'XLS+ Phase 2 Inspection (400 hrs)', category: 'Labor', laborHours: 42, laborRate: 175, partsCost: 2600, partsMarkup: 1.2 },
      { id: 'ql-005-2', description: 'XLS+ PW545C HSI (4000 hrs) - Left Engine', category: 'Service', laborHours: 58, laborRate: 175, partsCost: 195000, partsMarkup: 1.05 },
      { id: 'ql-005-3', description: 'XLS+ PW545C HSI (4000 hrs) - Right Engine', category: 'Service', laborHours: 58, laborRate: 175, partsCost: 195000, partsMarkup: 1.05 },
      { id: 'ql-005-4', description: 'Consumable Materials Fee', category: 'Service', laborHours: 0, laborRate: 0, partsCost: 850, partsMarkup: 1.0 },
    ]
  },

  // Quote 6: CJ4 AOG - Hydraulic Pump Failure
  {
    id: 'quote-006',
    customer: 'N525PH',
    aircraftType: 'ac-cj4',
    description: 'AOG - Hydraulic Pump Replacement',
    estimatedHours: 18,
    revenue: 2430,
    partsRevenue: 15120,
    color: 'bg-rose-600',
    deadlineDays: 2,
    requiredHangarSize: 'Medium',
    isAOG: true,
    notes: 'AOG in Denver. Customer stranded with passengers. Pump overnighted from Textron.',
    quoteLines: [
      { id: 'ql-006-1', description: 'Hydraulic System Pump R&R', category: 'Part', laborHours: 12, laborRate: 175, partsCost: 12500, partsMarkup: 1.15 },
      { id: 'ql-006-2', description: 'Hydraulic System Operational Test', category: 'Labor', laborHours: 4, laborRate: 175, partsCost: 450, partsMarkup: 1.2 },
      { id: 'ql-006-3', description: 'AOG Premium (After Hours)', category: 'Service', laborHours: 2, laborRate: 175, partsCost: 500, partsMarkup: 1.0 },
    ]
  },

  // Quote 7: G450 48-Month
  {
    id: 'quote-007',
    customer: 'N450GJ',
    aircraftType: 'ac-g450',
    description: 'G450 48-Month Inspection',
    estimatedHours: 320,
    revenue: 43200,
    partsRevenue: 51400,
    color: 'bg-amber-500',
    deadlineDays: 28,
    requiredHangarSize: 'Large',
    isAOG: false,
    notes: 'Aircraft arriving from Teterboro. Need to coordinate with flight dept.',
    quoteLines: [
      { id: 'ql-007-1', description: 'G450 48-Month Inspection', category: 'Labor', laborHours: 320, laborRate: 175, partsCost: 45000, partsMarkup: 1.12 },
      { id: 'ql-007-2', description: 'Full Detail (Complete Interior/Exterior)', category: 'Service', laborHours: 0, laborRate: 0, partsCost: 850, partsMarkup: 1.3 },
      { id: 'ql-007-3', description: 'Consumable Materials Fee', category: 'Service', laborHours: 0, laborRate: 0, partsCost: 1280, partsMarkup: 1.0 },
    ]
  },

  // Quote 8: Phenom 100 24-Month + Tire Change
  {
    id: 'quote-008',
    customer: 'N100PE',
    aircraftType: 'ac-phenom100',
    description: 'Phenom 100 24-Month + Tires',
    estimatedHours: 61,
    revenue: 8235,
    partsRevenue: 7700,
    color: 'bg-slate-500',
    deadlineDays: 10,
    requiredHangarSize: 'Medium',
    isAOG: false,
    notes: 'All 4 mains and nose tires due. Michelin Air tires.',
    quoteLines: [
      { id: 'ql-008-1', description: 'Phenom 100 24-Month Inspection', category: 'Labor', laborHours: 55, laborRate: 175, partsCost: 3200, partsMarkup: 1.2 },
      { id: 'ql-008-2', description: 'Tire Change (per tire)', category: 'Part', laborHours: 1.5, laborRate: 175, partsCost: 850, partsMarkup: 1.15 },
      { id: 'ql-008-3', description: 'Tire Change (per tire)', category: 'Part', laborHours: 1.5, laborRate: 175, partsCost: 850, partsMarkup: 1.15 },
      { id: 'ql-008-4', description: 'Tire Change (per tire)', category: 'Part', laborHours: 1.5, laborRate: 175, partsCost: 850, partsMarkup: 1.15 },
      { id: 'ql-008-5', description: 'Tire Change (per tire)', category: 'Part', laborHours: 1.5, laborRate: 175, partsCost: 850, partsMarkup: 1.15 },
      { id: 'ql-008-6', description: 'Consumable Materials Fee', category: 'Service', laborHours: 0, laborRate: 0, partsCost: 220, partsMarkup: 1.0 },
    ]
  },

  // Quote 9: Citation X 24-Month
  {
    id: 'quote-009',
    customer: 'N750CX',
    aircraftType: 'ac-c750',
    description: 'Citation X 24-Month Inspection',
    estimatedHours: 85,
    revenue: 11475,
    partsRevenue: 7150,
    color: 'bg-slate-500',
    deadlineDays: 14,
    requiredHangarSize: 'Large',
    isAOG: false,
    notes: 'Fastest civilian aircraft in fleet. Customer very particular about schedule.',
    quoteLines: [
      { id: 'ql-009-1', description: 'Citation X 24-Month Inspection', category: 'Labor', laborHours: 85, laborRate: 175, partsCost: 6500, partsMarkup: 1.2 },
      { id: 'ql-009-2', description: 'Consumable Materials Fee', category: 'Service', laborHours: 0, laborRate: 0, partsCost: 340, partsMarkup: 1.0 },
    ]
  },

  // Quote 10: PC-24 48-Month + Avionics Update
  {
    id: 'quote-010',
    customer: 'N24PC',
    aircraftType: 'ac-pc24',
    description: 'PC-24 48-Month + G5000 Update',
    estimatedHours: 180,
    revenue: 24300,
    partsRevenue: 38000,
    color: 'bg-amber-500',
    deadlineDays: 21,
    requiredHangarSize: 'Medium',
    isAOG: false,
    notes: 'Customer wants latest Garmin software load. Check SB compliance.',
    quoteLines: [
      { id: 'ql-010-1', description: 'PC-24 48-Month Inspection', category: 'Labor', laborHours: 140, laborRate: 175, partsCost: 12000, partsMarkup: 1.15 },
      { id: 'ql-010-2', description: 'Garmin G5000 Software Update', category: 'Labor', laborHours: 40, laborRate: 175, partsCost: 18500, partsMarkup: 1.12 },
      { id: 'ql-010-3', description: 'Consumable Materials Fee', category: 'Service', laborHours: 0, laborRate: 0, partsCost: 720, partsMarkup: 1.0 },
    ]
  },

  // Quote 11: G650 12-Month + Interior Refurb
  {
    id: 'quote-011',
    customer: 'N650GX',
    aircraftType: 'ac-g650',
    description: 'G650 12-Month + Leather Refurb',
    estimatedHours: 140,
    revenue: 18900,
    partsRevenue: 22750,
    color: 'bg-slate-500',
    deadlineDays: 18,
    requiredHangarSize: 'Large',
    isAOG: false,
    notes: 'VIP owner. Leather showing wear on forward seats. Schedule around owner travel.',
    quoteLines: [
      { id: 'ql-011-1', description: 'G650 12-Month Inspection', category: 'Labor', laborHours: 95, laborRate: 175, partsCost: 12000, partsMarkup: 1.15 },
      { id: 'ql-011-2', description: 'Leather Seat Refurbishment (4 seats)', category: 'Service', laborHours: 35, laborRate: 175, partsCost: 6500, partsMarkup: 1.25 },
      { id: 'ql-011-3', description: 'Leather Treatment Package', category: 'Service', laborHours: 4, laborRate: 175, partsCost: 350, partsMarkup: 1.25 },
      { id: 'ql-011-4', description: 'Full Detail (Complete Interior/Exterior)', category: 'Service', laborHours: 6, laborRate: 175, partsCost: 750, partsMarkup: 1.3 },
    ]
  },

  // Quote 12: Citation Excel Phase 1-2
  {
    id: 'quote-012',
    customer: 'N560EX',
    aircraftType: 'ac-cj3',
    description: 'Excel Phase 1 & 2 Combined',
    estimatedHours: 75,
    revenue: 10125,
    partsRevenue: 5520,
    color: 'bg-slate-500',
    deadlineDays: 12,
    requiredHangarSize: 'Medium',
    isAOG: false,
    notes: 'Fleet aircraft - NetJets fractional. Need to minimize downtime.',
    quoteLines: [
      { id: 'ql-012-1', description: 'Excel Phase 1 Inspection (200 hrs)', category: 'Labor', laborHours: 35, laborRate: 175, partsCost: 2000, partsMarkup: 1.2 },
      { id: 'ql-012-2', description: 'Excel Phase 2 Inspection (400 hrs)', category: 'Labor', laborHours: 40, laborRate: 175, partsCost: 2400, partsMarkup: 1.2 },
      { id: 'ql-012-3', description: 'Consumable Materials Fee', category: 'Service', laborHours: 0, laborRate: 0, partsCost: 300, partsMarkup: 1.0 },
    ]
  },

  // Quote 13: CJ3 Pre-Purchase Inspection
  {
    id: 'quote-013',
    customer: 'N813PP',
    aircraftType: 'ac-cj3',
    description: 'CJ3 Pre-Purchase Inspection',
    estimatedHours: 45,
    revenue: 6075,
    partsRevenue: 660,
    color: 'bg-rose-600',
    deadlineDays: 5,
    requiredHangarSize: 'Medium',
    isAOG: false,
    notes: 'Buyer from Texas. Seller nervous about sale falling through. Priority.',
    quoteLines: [
      { id: 'ql-013-1', description: 'Pre-Purchase Evaluation', category: 'Labor', laborHours: 35, laborRate: 175, partsCost: 500, partsMarkup: 1.2 },
      { id: 'ql-013-2', description: 'Engine Borescope Inspection (Both)', category: 'Labor', laborHours: 6, laborRate: 175, partsCost: 0, partsMarkup: 1.0 },
      { id: 'ql-013-3', description: 'Records Research & Documentation', category: 'Labor', laborHours: 4, laborRate: 175, partsCost: 50, partsMarkup: 1.2 },
    ]
  },

  // Quote 14: Phenom 300 Landing Gear OH
  {
    id: 'quote-014',
    customer: 'N300LG',
    aircraftType: 'ac-phenom300',
    description: 'Phenom 300 Landing Gear Overhaul',
    estimatedHours: 120,
    revenue: 16200,
    partsRevenue: 56880,
    color: 'bg-slate-500',
    deadlineDays: 25,
    requiredHangarSize: 'Medium',
    isAOG: false,
    notes: 'Gear hitting 10-year limit. Coordinate with APPH for gear exchange.',
    quoteLines: [
      { id: 'ql-014-1', description: 'Phenom 300 Landing Gear Overhaul (10yr)', category: 'Service', laborHours: 120, laborRate: 175, partsCost: 52000, partsMarkup: 1.08 },
      { id: 'ql-014-2', description: 'Consumable Materials Fee', category: 'Service', laborHours: 0, laborRate: 0, partsCost: 480, partsMarkup: 1.0 },
    ]
  },

  // Quote 15: G550 APU Overhaul + 24-Month
  {
    id: 'quote-015',
    customer: 'N555GA',
    aircraftType: 'ac-g550',
    description: 'G550 24-Month + APU Overhaul',
    estimatedHours: 260,
    revenue: 35100,
    partsRevenue: 173150,
    color: 'bg-amber-500',
    deadlineDays: 35,
    requiredHangarSize: 'Large',
    isAOG: false,
    notes: 'APU approaching TBO. Customer approved exchange unit from Honeywell.',
    quoteLines: [
      { id: 'ql-015-1', description: 'G550 24-Month Inspection', category: 'Labor', laborHours: 195, laborRate: 175, partsCost: 25000, partsMarkup: 1.15 },
      { id: 'ql-015-2', description: 'G550 APU Overhaul (RE220)', category: 'Service', laborHours: 65, laborRate: 175, partsCost: 135000, partsMarkup: 1.06 },
      { id: 'ql-015-3', description: 'Consumable Materials Fee', category: 'Service', laborHours: 0, laborRate: 0, partsCost: 1040, partsMarkup: 1.0 },
    ]
  },
];

// ============================================================================
// PROJECT STAGES
// ============================================================================
export const INITIAL_PROJECT_STAGES: ProjectStage[] = [
  { id: 'stage-planning', label: 'Planning', color: 'bg-slate-500', description: 'Quote Dev & Review (No Commitment)' },
  { id: 'stage-authorized', label: 'Authorized', color: 'bg-rose-600', description: 'WO Signed / Deposit Paid' },
  { id: 'stage-prep', label: 'Prep Complete', color: 'bg-amber-500', description: 'Parts Ordered / Team Assigned' },
  { id: 'stage-wip', label: 'WIP', color: 'bg-violet-600', description: 'Work In Progress' },
  { id: 'stage-rts', label: 'RTS / Billing', color: 'bg-cyan-500', description: 'Aircraft RTS / Billing Pending' },
  { id: 'stage-complete', label: 'Complete', color: 'bg-emerald-600', description: 'Paid / Released' },
  { id: 'stage-warranty', label: 'Warranty', color: 'bg-indigo-500', description: 'Warranty Service' },
];

// ============================================================================
// EXPENSES (Monthly Operating Costs) - $130K/month total
// ============================================================================
export const INITIAL_EXPENSES: ExpenseItem[] = [
  // === FACILITY - $45,000/month ===
  { id: 'exp-hangar-rent', category: 'Facility', name: 'Hangar Rent', monthlyCost: 45000 },

  // === SHARED SERVICES - $85,000/month ===
  // Management
  { id: 'exp-chief-inspector', category: 'Personnel', name: 'Chief Inspector', monthlyCost: 12000 },
  { id: 'exp-dom', category: 'Personnel', name: 'Director of Maintenance', monthlyCost: 15000 },
  { id: 'exp-accountable-mgr', category: 'Personnel', name: 'Accountable Manager', monthlyCost: 15000 },
  // Departments
  { id: 'exp-hr', category: 'Personnel', name: 'HR Department', monthlyCost: 15000 },
  { id: 'exp-marketing', category: 'Marketing', name: 'Marketing', monthlyCost: 8000 },
  { id: 'exp-sales', category: 'Admin', name: 'Sales', monthlyCost: 12000 },
  { id: 'exp-admin', category: 'Admin', name: 'Administrative/Other', monthlyCost: 8000 },
];

// ============================================================================
// UI CONSTANTS
// ============================================================================
export const TAILWIND_COLORS = [
  'bg-slate-500', 'bg-gray-500', 'bg-zinc-500', 'bg-neutral-500', 'bg-stone-500',
  'bg-red-500', 'bg-orange-500', 'bg-amber-500', 'bg-yellow-500', 'bg-lime-500',
  'bg-green-500', 'bg-emerald-500', 'bg-teal-500', 'bg-cyan-500', 'bg-sky-500',
  'bg-blue-500', 'bg-indigo-500', 'bg-violet-500', 'bg-purple-500', 'bg-fuchsia-500',
  'bg-pink-500', 'bg-rose-500'
];

export const INITIAL_CURSORS: ProgressCursor[] = [
  { id: 'cursor-4wk', label: '4 Weeks Out', dayOffset: 28, color: 'bg-emerald-500', enabled: true },
  { id: 'cursor-2wk', label: '2 Weeks Out', dayOffset: 14, color: 'bg-amber-500', enabled: true },
  { id: 'cursor-1wk', label: '1 Week Out', dayOffset: 7, color: 'bg-orange-500', enabled: false },
  { id: 'cursor-3d-ago', label: '3 Days Ago', dayOffset: -3, color: 'bg-blue-500', enabled: false },
  { id: 'cursor-2wk-ago', label: '2 Weeks Ago', dayOffset: -14, color: 'bg-purple-500', enabled: false },
];

// ============================================================================
// INITIAL SCHEDULE - 1 Year of Scheduled Maintenance for 10 Regular Customers
// Day Index Reference: Jan 1, 2025 = Day 366 (2024 is leap year)
// HEAVY MONTHS: May (486), June (517), July (547), November (670), December (700)
// ============================================================================
export const INITIAL_SCHEDULE: ScheduledJob[] = [
  // ============================================================================
  // 90% CAPACITY SCHEDULE - December 2, 2025 to February 28, 2026
  // Total Target: ~4,600 hours across 30 jobs
  // Day 701 = Dec 2, 2025 | Day 791 = Feb 28, 2026
  // ============================================================================

  // === WEEK 1 (Dec 2-6): 4 jobs starting ===
  {
    id: 'sched-001',
    customer: 'N90GTX',
    aircraftType: 'ac-kingair90',
    description: 'King Air C90GTx 1200hr + Engine HSI',
    estimatedHours: 400,
    revenue: 70000,
    partsRevenue: 42000,
    color: 'bg-amber-600',
    deadlineDays: 35,
    requiredHangarSize: 'Medium',
    isAOG: false,
    notes: 'Major engine hot section - Extended downtime',
    startDate: 701, // Dec 2, 2025
    hangarId: 'hangar-large',
    progress: 0,
    status: 'Scheduled',
    stageId: 'stage-planning'
  },
  {
    id: 'sched-002',
    customer: 'N350KA',
    aircraftType: 'ac-kingair350',
    description: 'King Air 350i Phase 1-4 + Props Overhaul',
    estimatedHours: 350,
    revenue: 61250,
    partsRevenue: 35000,
    color: 'bg-emerald-600',
    deadlineDays: 30,
    requiredHangarSize: 'Large',
    isAOG: false,
    notes: 'Complete phase inspection cycle + prop overhaul',
    startDate: 701, // Dec 2, 2025
    hangarId: 'hangar-large',
    progress: 0,
    status: 'Scheduled',
    stageId: 'stage-planning'
  },
  {
    id: 'sched-003',
    customer: 'N12NGX',
    aircraftType: 'ac-pc12',
    description: 'PC-12 NGX 600hr + Avionics Upgrade',
    estimatedHours: 200,
    revenue: 35000,
    partsRevenue: 28000,
    color: 'bg-violet-600',
    deadlineDays: 22,
    requiredHangarSize: 'Medium',
    isAOG: false,
    notes: 'Major inspection with G1000 NXi upgrade',
    startDate: 703, // Dec 4, 2025
    hangarId: 'hangar-small',
    progress: 0,
    status: 'Scheduled',
    stageId: 'stage-planning'
  },
  {
    id: 'sched-004',
    customer: 'N960DA',
    aircraftType: 'ac-tbm960',
    description: 'TBM 960 Annual + Interior Refurb',
    estimatedHours: 180,
    revenue: 31500,
    partsRevenue: 22000,
    color: 'bg-teal-600',
    deadlineDays: 20,
    requiredHangarSize: 'Medium',
    isAOG: false,
    notes: 'Annual inspection with full interior refresh',
    startDate: 705, // Dec 6, 2025
    hangarId: 'hangar-small',
    progress: 0,
    status: 'Scheduled',
    stageId: 'stage-planning'
  },

  // === WEEK 2 (Dec 8-12): 3 jobs starting ===
  {
    id: 'sched-005',
    customer: 'N525AB',
    aircraftType: 'ac-cj2',
    description: 'CJ2+ Phase 1-4 Combined Inspection',
    estimatedHours: 150,
    revenue: 26250,
    partsRevenue: 18000,
    color: 'bg-blue-600',
    deadlineDays: 18,
    requiredHangarSize: 'Medium',
    isAOG: false,
    notes: 'Full phase cycle - high utilization aircraft',
    startDate: 708, // Dec 9, 2025
    hangarId: 'hangar-small',
    progress: 0,
    status: 'Scheduled',
    stageId: 'stage-planning'
  },
  {
    id: 'sched-006',
    customer: 'N100EV',
    aircraftType: 'ac-phenom100',
    description: 'Phenom 100EV 24-Month + Landing Gear',
    estimatedHours: 120,
    revenue: 21000,
    partsRevenue: 15000,
    color: 'bg-purple-600',
    deadlineDays: 14,
    requiredHangarSize: 'Medium',
    isAOG: false,
    notes: '24-month with gear overhaul',
    startDate: 710, // Dec 11, 2025
    hangarId: 'hangar-small',
    progress: 0,
    status: 'Scheduled',
    stageId: 'stage-planning'
  },
  {
    id: 'sched-007',
    customer: 'N900TB',
    aircraftType: 'ac-tbm900',
    description: 'TBM 900 Annual + Hot Section',
    estimatedHours: 200,
    revenue: 35000,
    partsRevenue: 32000,
    color: 'bg-rose-600',
    deadlineDays: 24,
    requiredHangarSize: 'Medium',
    isAOG: false,
    notes: 'Annual with engine hot section inspection',
    startDate: 712, // Dec 13, 2025
    hangarId: 'hangar-large',
    progress: 0,
    status: 'Scheduled',
    stageId: 'stage-planning'
  },

  // === WEEK 3 (Dec 15-19): 3 jobs starting ===
  {
    id: 'sched-008',
    customer: 'N420HJ',
    aircraftType: 'ac-hondajet',
    description: 'HondaJet Elite 200hr + Paint Touch-up',
    estimatedHours: 100,
    revenue: 17500,
    partsRevenue: 8500,
    color: 'bg-cyan-600',
    deadlineDays: 12,
    requiredHangarSize: 'Medium',
    isAOG: false,
    notes: '200-hour with cosmetic paint work',
    startDate: 715, // Dec 16, 2025
    hangarId: 'hangar-small',
    progress: 0,
    status: 'Scheduled',
    stageId: 'stage-planning'
  },
  {
    id: 'sched-009',
    customer: 'N250BE',
    aircraftType: 'ac-kingair250',
    description: 'King Air 250 Annual + Interior',
    estimatedHours: 300,
    revenue: 52500,
    partsRevenue: 28000,
    color: 'bg-amber-600',
    deadlineDays: 28,
    requiredHangarSize: 'Large',
    isAOG: false,
    notes: 'Annual inspection with full interior refurbishment',
    startDate: 717, // Dec 18, 2025
    hangarId: 'hangar-large',
    progress: 0,
    status: 'Scheduled',
    stageId: 'stage-planning'
  },
  {
    id: 'sched-010',
    customer: 'N24PIL',
    aircraftType: 'ac-pc24',
    description: 'PC-24 Phase 1-2 + WiFi Install',
    estimatedHours: 130,
    revenue: 22750,
    partsRevenue: 18000,
    color: 'bg-orange-600',
    deadlineDays: 16,
    requiredHangarSize: 'Medium',
    isAOG: false,
    notes: 'Phase inspections with Gogo AVANCE install',
    startDate: 719, // Dec 20, 2025
    hangarId: 'hangar-small',
    progress: 0,
    status: 'Scheduled',
    stageId: 'stage-planning'
  },

  // === WEEK 4-5 (Dec 22-Jan 2): 2 jobs starting (holiday period) ===
  {
    id: 'sched-011',
    customer: 'N101CJ',
    aircraftType: 'ac-cj1',
    description: 'CJ1+ Phase 2 + Gear Service',
    estimatedHours: 80,
    revenue: 14000,
    partsRevenue: 9500,
    color: 'bg-indigo-600',
    deadlineDays: 10,
    requiredHangarSize: 'Medium',
    isAOG: false,
    notes: 'Phase 2 with gear inspection',
    startDate: 722, // Dec 23, 2025
    hangarId: 'hangar-small',
    progress: 0,
    status: 'Scheduled',
    stageId: 'stage-planning'
  },
  {
    id: 'sched-012',
    customer: 'N300EM',
    aircraftType: 'ac-phenom300',
    description: 'Phenom 300E Phase 1-2 Inspection',
    estimatedHours: 110,
    revenue: 19250,
    partsRevenue: 12000,
    color: 'bg-teal-600',
    deadlineDays: 14,
    requiredHangarSize: 'Medium',
    isAOG: false,
    notes: 'Phase inspections - corporate flight dept',
    startDate: 729, // Dec 30, 2025
    hangarId: 'hangar-large',
    progress: 0,
    status: 'Scheduled',
    stageId: 'stage-planning'
  },

  // === WEEK 6 (Jan 5-9): 3 jobs starting ===
  {
    id: 'sched-013',
    customer: 'N208EX',
    aircraftType: 'ac-caravan',
    description: 'Grand Caravan EX Annual + Floats Service',
    estimatedHours: 160,
    revenue: 28000,
    partsRevenue: 18000,
    color: 'bg-emerald-600',
    deadlineDays: 20,
    requiredHangarSize: 'Large',
    isAOG: false,
    notes: 'Annual with amphibious float inspection',
    startDate: 736, // Jan 6, 2026
    hangarId: 'hangar-large',
    progress: 0,
    status: 'Scheduled',
    stageId: 'stage-planning'
  },
  {
    id: 'sched-014',
    customer: 'N441CQ',
    aircraftType: 'ac-conquest',
    description: 'Conquest II Phase Inspection + Props',
    estimatedHours: 240,
    revenue: 42000,
    partsRevenue: 22000,
    color: 'bg-violet-600',
    deadlineDays: 22,
    requiredHangarSize: 'Large',
    isAOG: false,
    notes: 'Phase inspection with prop overhaul',
    startDate: 738, // Jan 8, 2026
    hangarId: 'hangar-large',
    progress: 0,
    status: 'Scheduled',
    stageId: 'stage-planning'
  },
  {
    id: 'sched-015',
    customer: 'N525CL',
    aircraftType: 'ac-cj4',
    description: 'CJ4 Gen 2 24-Month Heavy',
    estimatedHours: 150,
    revenue: 26250,
    partsRevenue: 16000,
    color: 'bg-blue-600',
    deadlineDays: 18,
    requiredHangarSize: 'Medium',
    isAOG: false,
    notes: '24-month major inspection',
    startDate: 740, // Jan 10, 2026
    hangarId: 'hangar-small',
    progress: 0,
    status: 'Scheduled',
    stageId: 'stage-planning'
  },

  // === WEEK 7 (Jan 12-16): 3 jobs starting ===
  {
    id: 'sched-016',
    customer: 'N900TX',
    aircraftType: 'ac-tbm900',
    description: 'TBM 900 200hr + Avionics Update',
    estimatedHours: 75,
    revenue: 13125,
    partsRevenue: 8000,
    color: 'bg-rose-600',
    deadlineDays: 10,
    requiredHangarSize: 'Medium',
    isAOG: false,
    notes: '200-hour with G3000 software update',
    startDate: 743, // Jan 13, 2026
    hangarId: 'hangar-small',
    progress: 0,
    status: 'Scheduled',
    stageId: 'stage-planning'
  },
  {
    id: 'sched-017',
    customer: 'N350FL',
    aircraftType: 'ac-kingair350',
    description: 'King Air 350i Annual Inspection',
    estimatedHours: 120,
    revenue: 21000,
    partsRevenue: 14000,
    color: 'bg-amber-600',
    deadlineDays: 15,
    requiredHangarSize: 'Large',
    isAOG: false,
    notes: 'Annual - charter operator',
    startDate: 745, // Jan 15, 2026
    hangarId: 'hangar-large',
    progress: 0,
    status: 'Scheduled',
    stageId: 'stage-planning'
  },
  {
    id: 'sched-018',
    customer: 'N55EP',
    aircraftType: 'ac-phenom300',
    description: 'Phenom 300E 12-Month + Gear',
    estimatedHours: 90,
    revenue: 15750,
    partsRevenue: 11000,
    color: 'bg-teal-600',
    deadlineDays: 12,
    requiredHangarSize: 'Medium',
    isAOG: false,
    notes: '12-month with main gear service',
    startDate: 747, // Jan 17, 2026
    hangarId: 'hangar-small',
    progress: 0,
    status: 'Scheduled',
    stageId: 'stage-planning'
  },

  // === WEEK 8 (Jan 19-23): 3 jobs starting ===
  {
    id: 'sched-019',
    customer: 'N12PC',
    aircraftType: 'ac-pc12',
    description: 'PC-12 NGX 300hr Inspection',
    estimatedHours: 60,
    revenue: 10500,
    partsRevenue: 6000,
    color: 'bg-violet-600',
    deadlineDays: 8,
    requiredHangarSize: 'Medium',
    isAOG: false,
    notes: '300-hour phase inspection',
    startDate: 750, // Jan 20, 2026
    hangarId: 'hangar-small',
    progress: 0,
    status: 'Scheduled',
    stageId: 'stage-planning'
  },
  {
    id: 'sched-020',
    customer: 'N525RA',
    aircraftType: 'ac-premier',
    description: 'Premier IA 24-Month + Paint',
    estimatedHours: 200,
    revenue: 35000,
    partsRevenue: 24000,
    color: 'bg-cyan-600',
    deadlineDays: 26,
    requiredHangarSize: 'Medium',
    isAOG: false,
    notes: '24-month with full exterior repaint',
    startDate: 752, // Jan 22, 2026
    hangarId: 'hangar-large',
    progress: 0,
    status: 'Scheduled',
    stageId: 'stage-planning'
  },
  {
    id: 'sched-021',
    customer: 'N90KA',
    aircraftType: 'ac-kingair90',
    description: 'King Air C90GTx Phase Inspection',
    estimatedHours: 100,
    revenue: 17500,
    partsRevenue: 10000,
    color: 'bg-amber-600',
    deadlineDays: 12,
    requiredHangarSize: 'Medium',
    isAOG: false,
    notes: 'Phase inspection - owner operated',
    startDate: 754, // Jan 24, 2026
    hangarId: 'hangar-small',
    progress: 0,
    status: 'Scheduled',
    stageId: 'stage-planning'
  },

  // === WEEK 9 (Jan 26-30): 3 jobs starting ===
  {
    id: 'sched-022',
    customer: 'N960TB',
    aircraftType: 'ac-tbm960',
    description: 'TBM 960 100hr + Oxygen Service',
    estimatedHours: 45,
    revenue: 7875,
    partsRevenue: 4500,
    color: 'bg-rose-600',
    deadlineDays: 6,
    requiredHangarSize: 'Small',
    isAOG: false,
    notes: '100-hour with oxygen system service',
    startDate: 757, // Jan 27, 2026
    hangarId: 'hangar-small',
    progress: 0,
    status: 'Scheduled',
    stageId: 'stage-planning'
  },
  {
    id: 'sched-023',
    customer: 'N24RM',
    aircraftType: 'ac-pc24',
    description: 'PC-24 Annual + Landing Gear OH',
    estimatedHours: 240,
    revenue: 42000,
    partsRevenue: 25000,
    color: 'bg-orange-600',
    deadlineDays: 22,
    requiredHangarSize: 'Large',
    isAOG: false,
    notes: 'Annual with landing gear overhaul',
    startDate: 759, // Jan 29, 2026
    hangarId: 'hangar-large',
    progress: 0,
    status: 'Scheduled',
    stageId: 'stage-planning'
  },
  {
    id: 'sched-024',
    customer: 'N525CJ',
    aircraftType: 'ac-cj3',
    description: 'CJ3+ Phase 3 Inspection',
    estimatedHours: 70,
    revenue: 12250,
    partsRevenue: 7500,
    color: 'bg-blue-600',
    deadlineDays: 9,
    requiredHangarSize: 'Medium',
    isAOG: false,
    notes: 'Phase 3 - 600hr interval',
    startDate: 761, // Jan 31, 2026
    hangarId: 'hangar-small',
    progress: 0,
    status: 'Scheduled',
    stageId: 'stage-planning'
  },

  // === WEEK 10 (Feb 2-6): 3 jobs starting ===
  {
    id: 'sched-025',
    customer: 'N420HE',
    aircraftType: 'ac-hondajet',
    description: 'HondaJet Elite S 12-Month',
    estimatedHours: 85,
    revenue: 14875,
    partsRevenue: 9000,
    color: 'bg-cyan-600',
    deadlineDays: 11,
    requiredHangarSize: 'Medium',
    isAOG: false,
    notes: '12-month annual inspection',
    startDate: 764, // Feb 3, 2026
    hangarId: 'hangar-small',
    progress: 0,
    status: 'Scheduled',
    stageId: 'stage-planning'
  },
  {
    id: 'sched-026',
    customer: 'N350HV',
    aircraftType: 'ac-kingair350',
    description: 'King Air 350i Phase 1-2 + Winglets',
    estimatedHours: 280,
    revenue: 49000,
    partsRevenue: 45000,
    color: 'bg-emerald-600',
    deadlineDays: 25,
    requiredHangarSize: 'Large',
    isAOG: false,
    notes: 'Phase inspections with winglet installation',
    startDate: 766, // Feb 5, 2026
    hangarId: 'hangar-large',
    progress: 0,
    status: 'Scheduled',
    stageId: 'stage-planning'
  },
  {
    id: 'sched-027',
    customer: 'N100PA',
    aircraftType: 'ac-phenom100',
    description: 'Phenom 100EV 100hr + Brake Service',
    estimatedHours: 40,
    revenue: 7000,
    partsRevenue: 4800,
    color: 'bg-purple-600',
    deadlineDays: 5,
    requiredHangarSize: 'Small',
    isAOG: false,
    notes: '100-hour with brake overhaul',
    startDate: 768, // Feb 7, 2026
    hangarId: 'hangar-small',
    progress: 0,
    status: 'Scheduled',
    stageId: 'stage-planning'
  },

  // === WEEK 11 (Feb 9-13): 2 jobs starting ===
  {
    id: 'sched-028',
    customer: 'N208CA',
    aircraftType: 'ac-caravan',
    description: 'Grand Caravan 100hr + Cargo Pod',
    estimatedHours: 55,
    revenue: 9625,
    partsRevenue: 6000,
    color: 'bg-emerald-600',
    deadlineDays: 7,
    requiredHangarSize: 'Medium',
    isAOG: false,
    notes: '100-hour with cargo pod inspection',
    startDate: 771, // Feb 10, 2026
    hangarId: 'hangar-small',
    progress: 0,
    status: 'Scheduled',
    stageId: 'stage-planning'
  },
  {
    id: 'sched-029',
    customer: 'N525M2',
    aircraftType: 'ac-m2',
    description: 'Citation M2 12-Month + Generator',
    estimatedHours: 75,
    revenue: 13125,
    partsRevenue: 8500,
    color: 'bg-indigo-600',
    deadlineDays: 10,
    requiredHangarSize: 'Medium',
    isAOG: false,
    notes: '12-month with generator replacement',
    startDate: 775, // Feb 14, 2026
    hangarId: 'hangar-small',
    progress: 0,
    status: 'Scheduled',
    stageId: 'stage-planning'
  },

  // === WEEK 12 (Feb 16-20): 2 jobs starting ===
  {
    id: 'sched-030',
    customer: 'N12NGX2',
    aircraftType: 'ac-pc12',
    description: 'PC-12 NGX Annual + Prop Governor',
    estimatedHours: 180,
    revenue: 31500,
    partsRevenue: 16000,
    color: 'bg-violet-600',
    deadlineDays: 18,
    requiredHangarSize: 'Large',
    isAOG: false,
    notes: 'Annual with prop governor overhaul',
    startDate: 778, // Feb 17, 2026
    hangarId: 'hangar-large',
    progress: 0,
    status: 'Scheduled',
    stageId: 'stage-planning'
  },
];

// Total scheduled hours: ~4,585 (90% of ~5,096 capacity)
// Updated job hours:
// - sched-001: 400 hrs (King Air C90GTx engine HSI)
// - sched-002: 350 hrs (King Air 350i full phase + props)
// - sched-009: 300 hrs (King Air 250 annual + interior)
// - sched-014: 240 hrs (Conquest II phase + props)
// - sched-023: 240 hrs (PC-24 annual + gear OH)
// - sched-026: 280 hrs (King Air 350i phases + winglets)
// - sched-030: 180 hrs (PC-12 annual + prop governor)
// Total: ~4,585 hours across 30 jobs = 90% utilization

// ============================================================================
// PROJECT STAGE PRESETS - Common workflow stage configurations
// ============================================================================

export interface StagePreset {
  id: string;
  name: string;
  description: string;
  stages: Omit<ProjectStage, 'id'>[];
}

export const STAGE_PRESETS: StagePreset[] = [
  {
    id: 'preset-mro-standard',
    name: 'Standard MRO Workflow',
    description: 'Classic aviation MRO workflow with inspection, work, and return phases',
    stages: [
      { label: 'Induction', description: 'Aircraft arrival, paperwork, initial inspection', color: 'bg-blue-500' },
      { label: 'Inspection', description: 'Detailed inspection and discrepancy documentation', color: 'bg-cyan-500' },
      { label: 'Work In Progress', description: 'Active maintenance and repairs', color: 'bg-violet-500' },
      { label: 'Parts Hold', description: 'Awaiting parts delivery', color: 'bg-amber-500' },
      { label: 'QA Review', description: 'Quality assurance and inspector sign-off', color: 'bg-indigo-500' },
      { label: 'Return to Service', description: 'Final checks and aircraft release', color: 'bg-emerald-500' },
    ]
  },
  {
    id: 'preset-quick-turn',
    name: 'Quick Turn / Line Maintenance',
    description: 'Simplified workflow for quick turnaround jobs',
    stages: [
      { label: 'Check-In', description: 'Aircraft arrival and task review', color: 'bg-blue-500' },
      { label: 'In Work', description: 'Active service being performed', color: 'bg-violet-500' },
      { label: 'Complete', description: 'Work finished, ready for release', color: 'bg-emerald-500' },
    ]
  },
  {
    id: 'preset-heavy-maintenance',
    name: 'Heavy Maintenance / Major Inspection',
    description: 'Detailed workflow for major inspections and heavy checks',
    stages: [
      { label: 'Planning', description: 'Work package preparation and scheduling', color: 'bg-slate-500' },
      { label: 'Induction', description: 'Aircraft arrival, panels open, access prep', color: 'bg-blue-500' },
      { label: 'Phase Inspection', description: 'Scheduled inspection tasks', color: 'bg-cyan-500' },
      { label: 'Discrepancy Review', description: 'Findings review and customer approval', color: 'bg-amber-500' },
      { label: 'Corrective Action', description: 'Repair and rectification work', color: 'bg-violet-500' },
      { label: 'Parts/Outsource', description: 'Waiting on parts or external repairs', color: 'bg-orange-500' },
      { label: 'Reassembly', description: 'Closing panels and final assembly', color: 'bg-indigo-500' },
      { label: 'Functional Test', description: 'Systems testing and ground runs', color: 'bg-teal-500' },
      { label: 'QA/IA Sign-off', description: 'Inspector approval and documentation', color: 'bg-purple-500' },
      { label: 'Release', description: 'Airworthiness release and delivery', color: 'bg-emerald-500' },
    ]
  },
  {
    id: 'preset-avionics',
    name: 'Avionics Installation',
    description: 'Workflow for avionics upgrades and installations',
    stages: [
      { label: 'Survey', description: 'Pre-installation assessment', color: 'bg-slate-500' },
      { label: 'Removal', description: 'Old equipment removal', color: 'bg-blue-500' },
      { label: 'Installation', description: 'New equipment installation', color: 'bg-violet-500' },
      { label: 'Wiring', description: 'Wire routing and connections', color: 'bg-cyan-500' },
      { label: 'Configuration', description: 'Software setup and programming', color: 'bg-indigo-500' },
      { label: 'Testing', description: 'Functional and flight testing', color: 'bg-amber-500' },
      { label: 'Documentation', description: 'Weight & balance, 337 forms', color: 'bg-purple-500' },
      { label: 'Complete', description: 'Ready for customer pickup', color: 'bg-emerald-500' },
    ]
  },
  {
    id: 'preset-paint-interior',
    name: 'Paint & Interior',
    description: 'Workflow for paint jobs and interior refurbishment',
    stages: [
      { label: 'Strip', description: 'Paint stripping and prep', color: 'bg-slate-500' },
      { label: 'Repair', description: 'Surface repair and filling', color: 'bg-blue-500' },
      { label: 'Prime', description: 'Primer application', color: 'bg-cyan-500' },
      { label: 'Paint', description: 'Base coat and striping', color: 'bg-violet-500' },
      { label: 'Clear Coat', description: 'Final clear coat application', color: 'bg-indigo-500' },
      { label: 'Interior', description: 'Interior installation/refurb', color: 'bg-amber-500' },
      { label: 'Detail', description: 'Final detailing and touch-up', color: 'bg-teal-500' },
      { label: 'Complete', description: 'Ready for delivery', color: 'bg-emerald-500' },
    ]
  },
  {
    id: 'preset-simple',
    name: 'Simple 3-Stage',
    description: 'Basic workflow for simple tracking',
    stages: [
      { label: 'Pending', description: 'Not yet started', color: 'bg-slate-500' },
      { label: 'In Progress', description: 'Work underway', color: 'bg-violet-500' },
      { label: 'Complete', description: 'Finished', color: 'bg-emerald-500' },
    ]
  },
];

// ============================================================================
// TIMELINE CURSOR PRESETS - Common progress marker configurations
// ============================================================================

export interface CursorPreset {
  id: string;
  name: string;
  description: string;
  cursors: Omit<ProgressCursor, 'id'>[];
}

export const CURSOR_PRESETS: CursorPreset[] = [
  {
    id: 'preset-planning-horizons',
    name: 'Planning Horizons',
    description: 'Standard planning windows for scheduling visibility',
    cursors: [
      { label: '1 Week', dayOffset: 7, color: 'bg-emerald-500', enabled: true },
      { label: '2 Weeks', dayOffset: 14, color: 'bg-cyan-500', enabled: true },
      { label: '30 Days', dayOffset: 30, color: 'bg-amber-500', enabled: true },
      { label: '60 Days', dayOffset: 60, color: 'bg-orange-500', enabled: true },
      { label: '90 Days', dayOffset: 90, color: 'bg-rose-500', enabled: true },
    ]
  },
  {
    id: 'preset-weekly-milestones',
    name: 'Weekly Milestones',
    description: 'Week-by-week tracking markers',
    cursors: [
      { label: 'Week 1', dayOffset: 7, color: 'bg-blue-500', enabled: true },
      { label: 'Week 2', dayOffset: 14, color: 'bg-cyan-500', enabled: true },
      { label: 'Week 3', dayOffset: 21, color: 'bg-teal-500', enabled: true },
      { label: 'Week 4', dayOffset: 28, color: 'bg-emerald-500', enabled: true },
    ]
  },
  {
    id: 'preset-parts-lead-times',
    name: 'Parts Lead Times',
    description: 'Common parts ordering lead time markers',
    cursors: [
      { label: 'Stock Parts (3d)', dayOffset: 3, color: 'bg-emerald-500', enabled: true },
      { label: 'Standard (7d)', dayOffset: 7, color: 'bg-cyan-500', enabled: true },
      { label: 'Special Order (14d)', dayOffset: 14, color: 'bg-amber-500', enabled: true },
      { label: 'Overhaul (30d)', dayOffset: 30, color: 'bg-orange-500', enabled: true },
      { label: 'Factory (60d)', dayOffset: 60, color: 'bg-rose-500', enabled: true },
    ]
  },
  {
    id: 'preset-customer-deadlines',
    name: 'Customer Deadline Alerts',
    description: 'Warning markers for approaching deadlines',
    cursors: [
      { label: 'Due Tomorrow', dayOffset: 1, color: 'bg-rose-600', enabled: true },
      { label: '3 Days Out', dayOffset: 3, color: 'bg-orange-500', enabled: true },
      { label: '1 Week Out', dayOffset: 7, color: 'bg-amber-500', enabled: true },
      { label: '2 Weeks Out', dayOffset: 14, color: 'bg-cyan-500', enabled: true },
    ]
  },
  {
    id: 'preset-quarterly',
    name: 'Quarterly Planning',
    description: 'Quarterly business planning horizons',
    cursors: [
      { label: 'End of Month', dayOffset: 30, color: 'bg-blue-500', enabled: true },
      { label: 'End of Quarter', dayOffset: 90, color: 'bg-violet-500', enabled: true },
      { label: '6 Months', dayOffset: 180, color: 'bg-amber-500', enabled: true },
      { label: '1 Year', dayOffset: 365, color: 'bg-rose-500', enabled: true },
    ]
  },
  {
    id: 'preset-minimal',
    name: 'Minimal',
    description: 'Just the essentials',
    cursors: [
      { label: '2 Weeks', dayOffset: 14, color: 'bg-cyan-500', enabled: true },
      { label: '30 Days', dayOffset: 30, color: 'bg-amber-500', enabled: true },
    ]
  },
];
