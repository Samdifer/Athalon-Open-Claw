/**
 * Utility functions for the application
 */

/**
 * Generate a UUID v4 string
 * Uses the native crypto.randomUUID() API available in modern browsers
 */
export function generateUUID(): string {
  return crypto.randomUUID();
}
