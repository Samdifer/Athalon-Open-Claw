# 🔧 Registration Fix - Quick Start

## The Problem
You were getting these errors when trying to register:
```
Error: new row violates row-level security policy for table "organizations"
Error: new row violates row-level security policy for table "profiles"
401 Unauthorized
```

## The Solution (2 Steps)

### Step 1: Run SQL in Supabase (1 minute)

1. Go to https://supabase.com/dashboard
2. Select your project: `kmjjymsbwjfkwhcgrdfr`
3. Click **SQL Editor** in left sidebar
4. Click **New Query**
5. Copy the ENTIRE contents of: `supabase/COMPLETE-SETUP.sql`
6. Paste into the SQL editor
7. Click **Run** (or press Cmd/Ctrl + Enter)
8. Wait for "Success" message

**What this does:** Creates a database trigger that automatically creates organizations and profiles when users sign up, bypassing RLS restrictions.

### Step 2: Test Registration (30 seconds)

1. Open http://localhost:3001
2. Click **Register** or **Create Account**
3. Fill in:
   - Name: Test User
   - Email: your-email@example.com
   - Password: test123456
4. Click **Get Started**
5. **Success!** You should see "Check Your Email" (no errors)

### Step 3: Verify Data Shows Up

After verifying your email and logging in, you should see:

✅ **10 Technicians:**
- Mike Rodriguez (Lead, 80%)
- Sarah Chen (Senior, 75%)
- Carlos Martinez (Senior, 70%)
- Jim Barnes (Junior, 65%)
- Kevin Taylor (Junior, 60%)
- Alex Davis (Lead, 80%)
- Tom Harris (Senior, 75%)
- Marcus Johnson (Junior, 65%)
- Tyler Smith (Junior, 60%)
- Jenny Lin (Apprentice, 50%)

✅ **4 Hangars:**
- Hangar 1 - Heavy Jets
- Hangar 2 - Midsize Bay
- Hangar 3 - Light Jets
- Ramp - Quick Turn

✅ **10 Jobs:**
- N125GX - Gulfstream ($120k)
- N780QS - Global ($165k)
- N47CJ - Citation ($18k)
- N892ER - Embraer AOG ($8.5k)
- N456FA - Falcon ($285k)
- N234KA - King Air ($28k)
- N678HC - Honda Jet ($32k)
- N912GU - Gulfstream ($95k)
- N345CX - Citation ($15k)
- N789FX - Falcon AOG ($22k)

## Optional: Skip Email Verification (Dev Only)

To test faster without email verification:

1. Supabase Dashboard → **Authentication** → **Settings**
2. Scroll to **Email Auth**
3. **Disable** "Enable email confirmations"
4. Save

Now you can register and login immediately! ⚠️ Re-enable before production.

## Troubleshooting

**Still getting 401 errors?**
- Make sure you ran the COMPLETE-SETUP.sql file
- Check for errors in the Supabase SQL Editor output
- Try refreshing the page

**No data after login?**
- Open browser console (F12)
- Look for: "Initializing with defaults..." logs
- Try http://localhost:3000/force-reinit.html

**Need more help?**
- See detailed guide: `supabase/APPLY-FIX.md`
- Check troubleshooting: `TROUBLESHOOT.md`

## What Changed

**Before:**
```typescript
// ❌ Client code tried to create org + profile manually
// Blocked by RLS policies
await supabase.from('organizations').insert({...});
await supabase.from('profiles').insert({...});
```

**After:**
```typescript
// ✅ Just create auth user
// Trigger auto-creates org + profile with elevated privileges
await supabase.auth.signUp({email, password});
```

## Files Modified

1. ✅ `contexts/AuthContext.tsx` - Removed manual org/profile creation
2. ✅ `supabase/COMPLETE-SETUP.sql` - Full schema + trigger (run this)
3. ✅ `supabase/schema-fixed.sql` - Just the fix (if you already have schema)

---

**That's it!** Registration should work now. Test it and let me know if you see any errors.
