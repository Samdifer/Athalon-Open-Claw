# CLAUDE.md - AeroManager 145

## Project Overview

AeroManager 145 is a tactical aviation maintenance management simulation built as a React SPA. Users plan schedules, manage hangar capacity, assign personnel, create quotes, and balance finances against strict deadlines and efficiency penalties.

## Tech Stack

- **Frontend**: React 19.2 + TypeScript 5.8
- **Build Tool**: Vite 6.2
- **Styling**: Tailwind CSS 4.x (CDN-loaded)
- **Icons**: Lucide React
- **Charts**: Recharts 3.4
- **Storage**: IndexedDB (game state) + localStorage (auth/users)
- **No Backend**: Client-side only application

## Project Structure

```
scheduler/
├── App.tsx                 # Main dashboard component (~1900 LOC), state management, routing
├── index.tsx               # React entry point
├── index.html              # HTML shell with Tailwind CDN and global styles
├── types.ts                # All TypeScript interfaces (GameState, Job, Personnel, etc.)
├── constants.ts            # Initial data, config values (SHOP_RATE, TOTAL_DAYS, etc.)
├── persistence.ts          # IndexedDB wrapper (saveGame, loadGame)
├── vite.config.ts          # Vite configuration
├── tsconfig.json           # TypeScript configuration
│
├── components/             # React components (23 files, ~10k LOC total)
│   ├── GanttBoard.tsx          # Timeline visualization, drag-drop scheduling
│   ├── QuoteBuilder.tsx        # Job quoting with line items
│   ├── PersonnelManager.tsx    # Staff, teams, shifts, roles
│   ├── ConfigurationPanel.tsx  # Hangars, aircraft, workflow stages
│   ├── FinancialPanel.tsx      # Shop rate, overhead, expenses, markup
│   ├── BacklogPanel.tsx        # Unscheduled job cards
│   ├── AnalyticsPanel.tsx      # KPI metrics dashboard
│   ├── DailyFinancialTracker.tsx # Daily P&L aligned with timeline
│   ├── CapacityForecaster.tsx  # Labor capacity by team/role
│   ├── JobDetailsModal.tsx     # View/edit job details
│   ├── OnboardingTour.tsx      # Step-by-step tutorial
│   ├── RosterPanel.tsx         # Personnel roster display
│   ├── LandingPage.tsx         # Public marketing page
│   ├── auth/                   # LoginPage, RegisterPage, ChangePasswordModal
│   └── admin/                  # UserManagement
│
└── contexts/
    └── AuthContext.tsx     # Authentication state management
```

## Development Commands

```bash
npm run dev      # Start dev server on port 3000
npm run build    # Production build to /dist
npm run preview  # Preview production build
```

## Architecture Patterns

### State Management
- **GameState** is the single source of truth, passed down as props from App.tsx
- Unidirectional data flow: Parent → Children via props
- State updates: `setGameState(prev => ({ ...prev, ...changes }))`
- History tracking: `history` and `future` stacks for undo/redo
- Auto-save: 2-second debounce to IndexedDB

### Component Pattern
Components receive `gameState` and callback props:
```typescript
interface ComponentProps {
  gameState: GameState;
  onClose: () => void;
  onUpdate?: (data: Partial<GameState>) => void;
  isOpen?: boolean;
  isPoppedOut?: boolean;
}
```

### Authentication
- Supabase Auth with email/password
- User roles: Admin, Manager, Technician
- Platform roles: super_admin, support_admin, billing_admin
- Session managed via Supabase
- Profiles created automatically via database trigger on signup

## Key Domain Concepts

### Timeline System
- `dayIndex`: Days since START_YEAR (2024) = 0
- `TOTAL_DAYS`: 1461 (2024-2027, includes leap year)
- Helper functions: `getDateForDay()`, `getDateStr()`, `getDayIndex()`

### Job Scheduling
- **Job**: Unscheduled work item with customer, aircraft, hours, revenue, deadline
- **ScheduledJob**: Extends Job with startDate, hangarId, progress, status
- `nonWorkDays`: Array of day offsets where no work occurs
- `dailyEffort`: Map of day offset to effort allocation (0.0-1.0)

### Financial Model
- `shopRate`: Hourly billing rate (default $125)
- `overheadDaily`: Fixed daily operating cost
- `partMarkups`: Tiered pricing (30%/<$500, 15%/<$2500, 5%/else)
- `financialHistory`: Daily P&L log entries

### Personnel System
- **Personnel**: Individual staff with role, team, efficiency override
- **Team**: Group assigned to a shift and base
- **Shift**: Work schedule (days, hours, breaks, meetings)
- **Role**: Job title with efficiency multiplier and hourly cost

## Code Conventions

### Naming
- **Files**: PascalCase for components (`GanttBoard.tsx`)
- **Variables/Functions**: camelCase (`handleZoom`, `selectedJob`)
- **Constants**: SCREAMING_SNAKE_CASE (`SHOP_RATE`, `TOTAL_DAYS`)
- **Types/Interfaces**: PascalCase (`GameState`, `ScheduledJob`)

### Boolean/Handler Prefixes
- `is`, `has` for booleans: `isAOG`, `isPoppedOut`, `hasChanges`
- `on` for event props: `onClose`, `onUpdate`, `onDragStart`
- `handle` for internal handlers: `handleZoom`, `handleUndo`

### Styling
- 100% Tailwind utility classes (no CSS files)
- Dark theme: `slate-950` background, `slate-300` text
- Color coding for status: violet (WIP), rose (AOG/Authorized), emerald (Complete), cyan (RTS)
- Glassmorphism effect with backdrop blur

### TypeScript
- All interfaces defined in `types.ts`
- Props interfaces defined at top of each component file
- Strict type checking enabled

## Important Constants (constants.ts)

```typescript
SHOP_RATE = 125              // $/hour billing rate
MONTHLY_OVERHEAD = 135000    // Monthly operating cost
DAILY_OVERHEAD = 4500        // Per-day overhead
HOURLY_COST_AVG = 58         // Average staff cost/hour

START_YEAR = 2024
TIMELINE_YEARS = 4           // 2024-2027
TOTAL_DAYS = 1461            // 4 years with leap day

DEFAULT_CELL_WIDTH = 40      // Pixels per day in Gantt
ZOOM_LEVELS = [2, 4, 8, 14, 24, 40, 60, 90, 130, 180, 240]

HIRING_COST = 2500
FIRING_COST = 1000
```

## Data Persistence

### IndexedDB (persistence.ts)
- Database: `AeroManagerDB`
- Store: `saves`
- Functions: `initDB()`, `saveGame(id, data)`, `loadGame(id)`
- Default save ID: `'default_company_profile'`

### localStorage Keys
- `AM_IMPERSONATION_SESSION`: Platform admin impersonation session data

## Testing

**No test framework is currently configured.** Consider adding:
- Vitest for unit tests (integrates well with Vite)
- React Testing Library for component tests

## Common Development Tasks

### Adding a New Component
1. Create file in `components/` with PascalCase naming
2. Define Props interface at top of file
3. Export default function component
4. Import and use in App.tsx or parent component

### Adding a New Type
1. Add interface to `types.ts`
2. Add initial data to `constants.ts` if needed
3. Add to `GameState` interface if it's persistent state

### Modifying Financial Calculations
Key locations:
- `App.tsx`: Daily tick processing, income/expense calculations
- `AnalyticsPanel.tsx`: KPI calculations (useMemo blocks)
- `DailyFinancialTracker.tsx`: Daily P&L grid
- `FinancialPanel.tsx`: Configuration UI

### Working with the Gantt Timeline
- `GanttBoard.tsx`: Main visualization (~1400 LOC)
- Day calculations use `dayIndex` (0-based from START_YEAR)
- Zoom controlled by `cellWidth` (pixels per day)
- Drag-drop scheduling updates `schedule` array in GameState

## Path Aliases

TypeScript/Vite configured with `@/` alias mapping to project root:
```typescript
import { Job } from '@/types';
import { SHOP_RATE } from '@/constants';
```

## Environment Variables

- `GEMINI_API_KEY`: Prepared but not actively used in code
- Set in `.env.local` file if needed

## Git Workflow

Current branch structure follows Claude-generated naming:
- Feature branches: `claude/claude-md-*`
- Main development follows conventional commits:
  - `feat:` for new features
  - `fix:` for bug fixes
  - `refactor:` for code improvements
