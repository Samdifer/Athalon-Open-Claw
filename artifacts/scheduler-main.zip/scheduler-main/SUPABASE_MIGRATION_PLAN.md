# AeroManager 145 - SaaS Migration Plan

## Executive Summary

**Goal:** Transform AeroManager 145 from a client-only demo into a production multi-tenant SaaS application.

**Business Model:** Flat rate per company (organization), unlimited user seats.

**Target Market:** Aviation maintenance facilities (MROs).

**Domain:** mro-ai.com

---

## Business Decisions (Confirmed)

| Decision | Choice | Notes |
|----------|--------|-------|
| **Domain** | mro-ai.com | Owned, needs DNS migration to Vercel |
| **Pricing Model** | Flat rate per organization | Unlimited users per org |
| **Trial Period** | 14 days | Free access before payment required |
| **Authentication** | Google Sign-In + Email/Password | Both options available |
| **Email Verification** | Required | Users must verify before accessing app |

---

## Technology Stack Decisions

| Layer | Technology | Why |
|-------|------------|-----|
| **Frontend** | React 19 + TypeScript | Already built, keep as-is |
| **Backend/Database** | Supabase (PostgreSQL) | Best for relational data, great docs, Claude Code friendly |
| **Authentication** | Supabase Auth | Integrated with database, secure, handles email/OAuth |
| **Hosting** | Vercel | Easiest deployment, auto-deploys from GitHub, free tier |
| **Payments** | Stripe (post-MVP) | Industry standard, great Supabase integration |
| **IDE** | VS Code | Free, industry standard, excellent Claude Code integration |
| **Version Control** | GitHub | Already in use, connects to Vercel |

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                      YOUR CUSTOMERS                              │
│                   (Aviation Companies)                           │
│                                                                  │
│   Company A          Company B          Company C                │
│   (Org 1)            (Org 2)            (Org 3)                  │
│   - 5 users          - 12 users         - 3 users               │
│   - unlimited        - unlimited        - unlimited             │
└──────────────────────────┬──────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────────┐
│                     CUSTOM DOMAIN                                │
│                      mro-ai.com                                  │
│              (DNS pointed to Vercel)                             │
└──────────────────────────┬──────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────────┐
│                        VERCEL                                    │
│                  (Frontend Hosting)                              │
│                                                                  │
│  • Hosts React application (static files)                        │
│  • Global CDN (fast everywhere)                                  │
│  • Auto-deploys when you push to GitHub                          │
│  • SSL certificate included                                      │
│  • Preview URLs for testing changes                              │
│                                                                  │
│  Cost: $0/month (free tier) → $20/month (pro)                   │
└──────────────────────────┬──────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────────┐
│                       SUPABASE                                   │
│              (Database + Auth + Backend)                         │
│                                                                  │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐  │
│  │   PostgreSQL    │  │   Supabase      │  │   Row Level     │  │
│  │   Database      │  │   Auth          │  │   Security      │  │
│  │                 │  │                 │  │                 │  │
│  │  24 tables      │  │  Google OAuth   │  │  Org isolation  │  │
│  │  All your data  │  │  Email/pass     │  │  Auto-enforced  │  │
│  │  Relational     │  │  Email verify ✓ │  │  Can't bypass   │  │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘  │
│                                                                  │
│  Cost: $0/month (free) → $25/month (pro)                        │
└──────────────────────────┬──────────────────────────────────────┘
                           │
                           ▼ (Post-MVP)
┌─────────────────────────────────────────────────────────────────┐
│                        STRIPE                                    │
│                  (Payment Processing)                            │
│                                                                  │
│  • Subscription billing (monthly/annual)                         │
│  • Customer portal (update payment, cancel)                      │
│  • Webhooks sync status to Supabase                              │
│  • Invoices and receipts automatic                               │
│                                                                  │
│  Cost: 2.9% + 30¢ per transaction (no monthly fee)              │
└─────────────────────────────────────────────────────────────────┘
```

---

## Development Workflow

### Your Daily Process (Using VS Code + Claude Code)

```
┌─────────────────────────────────────────────────────────────────┐
│                        VS CODE                                   │
│                                                                  │
│  ┌──────────────┬───────────────────────────────────────────┐   │
│  │   EXPLORER   │              EDITOR                        │   │
│  │              │                                            │   │
│  │  📁 scheduler│   View files that Claude Code changes     │   │
│  │   ├─ components                                          │   │
│  │   ├─ lib     │   See syntax highlighting                 │   │
│  │   ├─ services│   Review code changes                     │   │
│  │   └─ ...     │                                            │   │
│  │              │                                            │   │
│  │  SOURCE CTRL │                                            │   │
│  │  (Git panel) │                                            │   │
│  │  See changes │                                            │   │
│  │  Commit/push │                                            │   │
│  ├──────────────┴───────────────────────────────────────────┤   │
│  │                      TERMINAL                             │   │
│  │                                                           │   │
│  │  $ claude                                                 │   │
│  │  > Add a new field for aircraft serial number             │   │
│  │  > Fix the bug where jobs don't save                      │   │
│  │  > Deploy to production                                   │   │
│  │                                                           │   │
│  │  (Claude Code runs here - you type requests in English)   │   │
│  └───────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
                           │
                           │ git push
                           ▼
┌─────────────────────────────────────────────────────────────────┐
│                        GITHUB                                    │
│                   (Code Repository)                              │
│                                                                  │
│  Stores all your code, tracks history                            │
└──────────────────────────┬──────────────────────────────────────┘
                           │
                           │ automatic trigger
                           ▼
┌─────────────────────────────────────────────────────────────────┐
│                        VERCEL                                    │
│                  (Auto-Deployment)                               │
│                                                                  │
│  Sees new code → Builds → Deploys → Live in ~60 seconds         │
└─────────────────────────────────────────────────────────────────┘
```

### Typical Change Workflow

1. **Open VS Code** → Open terminal (Ctrl+`)
2. **Start Claude Code** → Type `claude`
3. **Describe what you want** → "Add a notes field to the job form"
4. **Review changes** → See files update in VS Code
5. **Test locally** → `npm run dev` → check localhost:3000
6. **Commit & push** → Claude Code can do this, or use Git panel
7. **Auto-deploys** → Vercel builds and deploys automatically
8. **Done** → Changes live on your domain

---

## Monthly Cost Projection

### Development Phase
| Service | Cost |
|---------|------|
| Supabase | $0 (free tier) |
| Vercel | $0 (free tier) |
| Domain | ~$1/month ($12/year) |
| Claude Code | (your existing subscription) |
| **Total** | **~$1/month** |

### Launch Phase (1-20 customers)
| Service | Cost |
|---------|------|
| Supabase Pro | $25/month |
| Vercel | $0 (free tier likely sufficient) |
| Domain | ~$1/month |
| Stripe | 2.9% + 30¢ per charge |
| **Total** | **~$26/month + Stripe fees** |

### Growth Phase (20-100 customers)
| Service | Cost |
|---------|------|
| Supabase Pro | $25-50/month |
| Vercel Pro | $20/month (if needed) |
| Domain | ~$1/month |
| Stripe | 2.9% + 30¢ per charge |
| **Total** | **~$50-75/month + Stripe fees** |

### Revenue Example
At $200/month per customer with 50 customers:
- **Revenue:** $10,000/month
- **Infrastructure:** ~$50/month
- **Stripe fees:** ~$300/month (3%)
- **Net margin on infrastructure:** 96.5%

---

## Database Schema Design

### Multi-Tenancy Model

Every customer (aviation company) is an "Organization". Every piece of data belongs to exactly one organization. Row Level Security ensures Company A can never see Company B's data - this is enforced at the database level, not in application code.

```
Organization (your customer's company)
├── Users (unlimited per org, flat pricing)
├── Bases (physical locations)
│   └── Hangars
├── Aircraft Models
├── Personnel
│   ├── Roles
│   ├── Teams
│   └── Shifts
├── Jobs (backlog)
│   └── Quote Line Items
├── Scheduled Jobs
│   ├── Daily Efforts
│   └── Non-Work Days
├── Financial Data
│   ├── Expense Items
│   ├── Capex Items
│   └── Financial Log
└── Configuration
    ├── Standard Services
    ├── Markup Tiers
    ├── Project Stages
    ├── Holidays
    └── Settings
```

### Entity Relationship Diagram

```
organizations (tenant root)
    │
    ├── profiles (users belonging to org)
    │
    ├── bases (locations)
    │       └── hangars
    │
    ├── aircraft_models
    │
    ├── roles
    │
    ├── shifts
    │
    ├── teams
    │       └── personnel
    │
    ├── jobs (backlog)
    │       └── quote_line_items
    │
    ├── scheduled_jobs
    │       └── daily_efforts
    │       └── non_work_days
    │
    ├── standard_services
    │
    ├── expense_items
    │       └── expense_overrides
    │
    ├── capex_items
    │
    ├── holidays
    │
    ├── project_stages
    │
    ├── markup_tiers (parts & services)
    │
    ├── progress_cursors
    │
    ├── financial_log_entries
    │
    └── organization_settings (simulation config)
```

---

## Table Definitions

### 1. organizations
```sql
CREATE TABLE organizations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    slug TEXT UNIQUE NOT NULL,  -- URL-friendly identifier
    subscription_status TEXT DEFAULT 'trial',  -- trial, active, cancelled, past_due
    subscription_tier TEXT DEFAULT 'standard',
    trial_ends_at TIMESTAMPTZ DEFAULT (NOW() + INTERVAL '14 days'),  -- 14-day trial
    stripe_customer_id TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);
```

### 2. profiles (extends Supabase auth.users)
```sql
CREATE TABLE profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
    email TEXT NOT NULL,
    full_name TEXT,
    role TEXT DEFAULT 'member',  -- owner, admin, manager, technician, viewer
    avatar_url TEXT,
    auth_provider TEXT,  -- 'email' or 'google'
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);
-- Note: Email verification status is tracked in auth.users by Supabase
```

### 3. bases
```sql
CREATE TABLE bases (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
    name TEXT NOT NULL,
    location TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);
```

### 4. hangars
```sql
CREATE TABLE hangars (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
    base_id UUID REFERENCES bases(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    size TEXT CHECK (size IN ('Small', 'Medium', 'Large')),
    supported_types TEXT[],  -- Array of aircraft_model IDs
    created_at TIMESTAMPTZ DEFAULT NOW()
);
```

### 5. aircraft_models
```sql
CREATE TABLE aircraft_models (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
    code TEXT NOT NULL,  -- e.g., 'GULF', 'CIT'
    name TEXT NOT NULL,  -- e.g., 'Gulfstream G-IV/V'
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(organization_id, code)
);
```

### 6. roles
```sql
CREATE TABLE roles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
    name TEXT NOT NULL,
    base_efficiency DECIMAL(3,2) DEFAULT 1.0,
    hourly_cost DECIMAL(10,2) NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);
```

### 7. shifts
```sql
CREATE TABLE shifts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
    name TEXT NOT NULL,
    days INTEGER[] NOT NULL,  -- 0=Sun, 1=Mon, etc.
    start_hour INTEGER NOT NULL,
    duration DECIMAL(4,2) NOT NULL,
    break_count INTEGER DEFAULT 0,
    break_duration INTEGER DEFAULT 0,  -- minutes
    meeting_duration INTEGER DEFAULT 0,  -- minutes
    created_at TIMESTAMPTZ DEFAULT NOW()
);
```

### 8. teams
```sql
CREATE TABLE teams (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
    name TEXT NOT NULL,
    color TEXT,  -- Tailwind class
    shift_id UUID REFERENCES shifts(id),
    base_id UUID REFERENCES bases(id),
    created_at TIMESTAMPTZ DEFAULT NOW()
);
```

### 9. personnel
```sql
CREATE TABLE personnel (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
    name TEXT NOT NULL,
    role_id UUID REFERENCES roles(id),
    team_id UUID REFERENCES teams(id),
    base_id UUID REFERENCES bases(id),
    efficiency_override DECIMAL(3,2),
    created_at TIMESTAMPTZ DEFAULT NOW()
);
```

### 10. jobs (backlog - unscheduled)
```sql
CREATE TABLE jobs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
    customer TEXT NOT NULL,  -- Tail number or customer name
    aircraft_type TEXT NOT NULL,  -- References aircraft_models.code
    description TEXT NOT NULL,
    estimated_hours DECIMAL(10,2) NOT NULL,
    revenue DECIMAL(12,2) NOT NULL,
    parts_revenue DECIMAL(12,2) DEFAULT 0,
    color TEXT DEFAULT 'bg-slate-500',
    deadline_days INTEGER NOT NULL,
    required_hangar_size TEXT CHECK (required_hangar_size IN ('Small', 'Medium', 'Large')),
    is_aog BOOLEAN DEFAULT FALSE,
    arrival_day INTEGER,
    notes TEXT,
    is_deleted BOOLEAN DEFAULT FALSE,  -- Soft delete for graveyard
    deleted_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);
```

### 11. quote_line_items
```sql
CREATE TABLE quote_line_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    job_id UUID REFERENCES jobs(id) ON DELETE CASCADE NOT NULL,
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
    description TEXT NOT NULL,
    category TEXT CHECK (category IN ('Labor', 'Part', 'Service')),
    labor_hours DECIMAL(10,2) DEFAULT 0,
    labor_rate DECIMAL(10,2) DEFAULT 0,
    parts_cost DECIMAL(12,2) DEFAULT 0,
    parts_markup DECIMAL(4,2) DEFAULT 1.0,
    fixed_price DECIMAL(12,2),
    sort_order INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);
```

### 12. scheduled_jobs
```sql
CREATE TABLE scheduled_jobs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
    job_id UUID REFERENCES jobs(id) ON DELETE CASCADE NOT NULL,
    hangar_id UUID REFERENCES hangars(id),
    start_date INTEGER NOT NULL,  -- Day index
    end_date INTEGER,
    progress DECIMAL(10,2) DEFAULT 0,
    status TEXT DEFAULT 'Scheduled' CHECK (status IN ('Scheduled', 'In Progress', 'Completed', 'Late')),
    payment_received BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);
```

### 13. scheduled_job_non_work_days
```sql
CREATE TABLE scheduled_job_non_work_days (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    scheduled_job_id UUID REFERENCES scheduled_jobs(id) ON DELETE CASCADE NOT NULL,
    day_offset INTEGER NOT NULL,  -- Offset from start_date
    UNIQUE(scheduled_job_id, day_offset)
);
```

### 14. scheduled_job_daily_efforts
```sql
CREATE TABLE scheduled_job_daily_efforts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    scheduled_job_id UUID REFERENCES scheduled_jobs(id) ON DELETE CASCADE NOT NULL,
    day_offset INTEGER NOT NULL,
    effort DECIMAL(4,2) NOT NULL,  -- 0.0 to 1.0
    UNIQUE(scheduled_job_id, day_offset)
);
```

### 15. standard_services
```sql
CREATE TABLE standard_services (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
    description TEXT NOT NULL,
    category TEXT CHECK (category IN ('Labor', 'Part', 'Service')),
    labor_hours DECIMAL(10,2) DEFAULT 0,
    labor_rate DECIMAL(10,2) DEFAULT 0,
    parts_cost DECIMAL(12,2) DEFAULT 0,
    parts_markup DECIMAL(4,2) DEFAULT 1.0,
    applicable_model_id UUID REFERENCES aircraft_models(id),  -- NULL = all aircraft
    created_at TIMESTAMPTZ DEFAULT NOW()
);
```

### 16. expense_items
```sql
CREATE TABLE expense_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
    category TEXT CHECK (category IN ('Facility', 'Admin', 'IT', 'Marketing', 'Personnel', 'Other')),
    name TEXT NOT NULL,
    monthly_cost DECIMAL(12,2) NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);
```

### 17. expense_overrides
```sql
CREATE TABLE expense_overrides (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    expense_item_id UUID REFERENCES expense_items(id) ON DELETE CASCADE NOT NULL,
    year_month TEXT NOT NULL,  -- Format: 'YYYY-M' e.g., '2025-0' for Jan
    override_amount DECIMAL(12,2) NOT NULL,
    UNIQUE(expense_item_id, year_month)
);
```

### 18. capex_items
```sql
CREATE TABLE capex_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
    name TEXT NOT NULL,
    cost DECIMAL(12,2) NOT NULL,
    planned_day INTEGER NOT NULL,
    amortize BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);
```

### 19. markup_tiers
```sql
CREATE TABLE markup_tiers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
    tier_type TEXT CHECK (tier_type IN ('parts', 'services')) NOT NULL,
    max_limit DECIMAL(12,2) NOT NULL,
    markup DECIMAL(4,2) NOT NULL,  -- e.g., 1.30 for 30%
    sort_order INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);
```

### 20. holidays
```sql
CREATE TABLE holidays (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
    name TEXT NOT NULL,
    date DATE NOT NULL,
    day_index INTEGER NOT NULL,
    enabled BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);
```

### 21. project_stages
```sql
CREATE TABLE project_stages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
    label TEXT NOT NULL,
    color TEXT NOT NULL,
    description TEXT,
    sort_order INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);
```

### 22. progress_cursors
```sql
CREATE TABLE progress_cursors (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
    label TEXT NOT NULL,
    day_offset INTEGER NOT NULL,
    color TEXT NOT NULL,
    enabled BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);
```

### 23. financial_log_entries
```sql
CREATE TABLE financial_log_entries (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
    day INTEGER NOT NULL,
    income DECIMAL(12,2) DEFAULT 0,
    spend DECIMAL(12,2) DEFAULT 0,
    profit DECIMAL(12,2) DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(organization_id, day)
);
```

### 24. organization_settings
```sql
CREATE TABLE organization_settings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL UNIQUE,

    -- Simulation State
    current_day INTEGER DEFAULT 0,
    cash DECIMAL(14,2) DEFAULT 500000,
    efficiency DECIMAL(4,2) DEFAULT 1.0,
    paused BOOLEAN DEFAULT TRUE,
    speed INTEGER DEFAULT 1,

    -- Financial Config
    shop_rate DECIMAL(10,2) DEFAULT 125,
    overhead_daily DECIMAL(12,2) DEFAULT 4500,

    -- UI State (can be per-user later, but org-level for now)
    ui_state JSONB DEFAULT '{}',

    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);
```

---

## Row Level Security (RLS) Policies

### Core Pattern
Every table with `organization_id` gets these policies:

```sql
-- Enable RLS
ALTER TABLE [table_name] ENABLE ROW LEVEL SECURITY;

-- Users can only see their organization's data
CREATE POLICY "Users can view own org data" ON [table_name]
    FOR SELECT USING (
        organization_id IN (
            SELECT organization_id FROM profiles WHERE id = auth.uid()
        )
    );

-- Users can insert into their organization
CREATE POLICY "Users can insert own org data" ON [table_name]
    FOR INSERT WITH CHECK (
        organization_id IN (
            SELECT organization_id FROM profiles WHERE id = auth.uid()
        )
    );

-- Users can update their organization's data
CREATE POLICY "Users can update own org data" ON [table_name]
    FOR UPDATE USING (
        organization_id IN (
            SELECT organization_id FROM profiles WHERE id = auth.uid()
        )
    );

-- Users can delete their organization's data
CREATE POLICY "Users can delete own org data" ON [table_name]
    FOR DELETE USING (
        organization_id IN (
            SELECT organization_id FROM profiles WHERE id = auth.uid()
        )
    );
```

### Special Policies

#### profiles table
```sql
-- Users can read profiles in their organization
CREATE POLICY "Users can view org profiles" ON profiles
    FOR SELECT USING (
        organization_id IN (
            SELECT organization_id FROM profiles WHERE id = auth.uid()
        )
    );

-- Users can update their own profile
CREATE POLICY "Users can update own profile" ON profiles
    FOR UPDATE USING (id = auth.uid());
```

#### organizations table
```sql
-- Users can view their own organization
CREATE POLICY "Users can view own org" ON organizations
    FOR SELECT USING (
        id IN (SELECT organization_id FROM profiles WHERE id = auth.uid())
    );

-- Only owners can update organization
CREATE POLICY "Owners can update org" ON organizations
    FOR UPDATE USING (
        id IN (
            SELECT organization_id FROM profiles
            WHERE id = auth.uid() AND role = 'owner'
        )
    );
```

---

## Implementation Phases

### Phase 1: Supabase Project Setup
**Estimated Time:** 1-2 hours
**Status:** Not Started

**What happens:**
1. You create a Supabase account (free)
2. Create a new project
3. Share the credentials with Claude Code
4. Claude Code sets up environment variables

**Checklist:**
- [ ] Create Supabase account at supabase.com
- [ ] Create new project (name: aeromanager-production)
- [ ] Select region (US East recommended for US customers)
- [ ] Wait for project to provision (~2 minutes)
- [ ] Copy Project URL from Settings → API
- [ ] Copy anon/public key from Settings → API
- [ ] Share credentials with Claude Code

**Deliverables:**
- Supabase project created
- `.env.local` file with credentials

---

### Phase 2: Database Schema Creation
**Estimated Time:** 2-4 hours
**Status:** Not Started

**What happens:**
- Claude Code creates all 24 tables
- Sets up relationships between tables
- Enables Row Level Security
- Creates security policies

**Checklist:**
- [ ] Create all tables via Supabase SQL editor
- [ ] Set up foreign key relationships
- [ ] Enable RLS on all tables
- [ ] Create RLS policies for each table
- [ ] Create indexes for common queries
- [ ] Test with sample data in Supabase dashboard

**Deliverables:**
- All 24 tables created
- RLS policies active
- Test organization with sample data

---

### Phase 3: Supabase Client Integration
**Estimated Time:** 2-3 hours
**Status:** Not Started

**What happens:**
- Install Supabase JavaScript library
- Create client configuration file
- Generate TypeScript types from database

**Checklist:**
- [ ] Install `@supabase/supabase-js` package
- [ ] Create `lib/supabase.ts` client configuration
- [ ] Generate TypeScript types from database schema
- [ ] Set up Supabase auth helpers

**Deliverables:**
- Supabase client configured
- Type-safe database access ready

---

### Phase 4: Authentication Migration
**Estimated Time:** 4-6 hours
**Status:** Not Started

**What happens:**
- Replace fake localStorage auth with real Supabase Auth
- Update login/register pages
- Set up organization creation for new users

**Checklist:**
- [ ] Replace `AuthContext.tsx` with Supabase auth
- [ ] Update `LoginPage.tsx` for Supabase
- [ ] Update `RegisterPage.tsx` for Supabase
- [ ] Update `ChangePasswordModal.tsx`
- [ ] Implement organization creation on first signup
- [ ] Handle user invitation flow
- [ ] Test login/logout/register flows

**Deliverables:**
- Working authentication with Supabase
- New users automatically create organization
- Organization members can be invited

---

### Phase 5: Data Layer Migration
**Estimated Time:** 8-12 hours
**Status:** Not Started

**What happens:**
- Create service files for each data type
- Replace IndexedDB with Supabase queries
- Update main app to load from cloud

**Checklist:**
- [ ] Create data service layer (`services/` directory)
- [ ] Implement CRUD operations for each entity
- [ ] Replace IndexedDB calls with Supabase queries
- [ ] Migrate `persistence.ts` functions
- [ ] Update `App.tsx` to load from Supabase
- [ ] Implement optimistic updates for good UX
- [ ] Add loading and error states
- [ ] Test all features with cloud data

**Deliverables:**
- All data operations using Supabase
- IndexedDB code removed
- Error handling throughout

---

### Phase 6: User Management Enhancement
**Estimated Time:** 3-4 hours
**Status:** Not Started

**What happens:**
- Update admin user management for Supabase
- Add email invitations
- Implement role-based permissions

**Checklist:**
- [ ] Update `UserManagement.tsx` for Supabase
- [ ] Implement user invitation via email
- [ ] Add role-based permissions (owner/admin/manager/technician/viewer)
- [ ] Organization settings management

**Deliverables:**
- Full user management through UI
- Role-based access control working

---

### Phase 7: Vercel Deployment + Domain Setup
**Estimated Time:** 2-3 hours
**Status:** Not Started

**What happens:**
- Connect GitHub to Vercel
- Configure environment variables
- Deploy application
- Configure mro-ai.com domain

**Checklist:**
- [ ] Create Vercel account
- [ ] Import GitHub repository
- [ ] Add environment variables (Supabase URL, keys)
- [ ] Deploy to Vercel (get temporary .vercel.app URL)
- [ ] Test production deployment on temporary URL
- [ ] Add mro-ai.com as custom domain in Vercel
- [ ] Update DNS records at your domain registrar:
  - Add A record pointing to Vercel's IP (76.76.21.21)
  - Or add CNAME record pointing to cname.vercel-dns.com
- [ ] Wait for DNS propagation (can take up to 48 hours, usually ~30 min)
- [ ] Verify SSL certificate is active (automatic)
- [ ] Test https://mro-ai.com works correctly

**DNS Migration Notes:**
```
Current: mro-ai.com (wherever it's hosted now)
Target:  mro-ai.com → Vercel → Your React App

Records to add at your registrar:
Type    Name    Value
A       @       76.76.21.21
CNAME   www     cname.vercel-dns.com
```

**Deliverables:**
- Application live at https://mro-ai.com
- SSL certificate active (automatic with Vercel)
- Auto-deploys on every push to main

---

### Phase 8: Production Hardening
**Estimated Time:** 2-4 hours
**Status:** Not Started

**What happens:**
- Security review
- Performance optimization
- Error monitoring setup

**Checklist:**
- [ ] Security audit of RLS policies
- [ ] Enable Supabase email templates
- [ ] Set up error monitoring (optional: Sentry)
- [ ] Performance testing
- [ ] Set up Supabase billing alerts

**Deliverables:**
- Production-ready SaaS application

---

### Phase 9: Stripe Integration (Post-MVP)
**Estimated Time:** 4-6 hours
**Status:** Not Started

**What happens:**
- Set up Stripe subscription billing
- Create checkout flow
- Handle subscription webhooks

**Checklist:**
- [ ] Create Stripe account
- [ ] Create subscription product and prices
- [ ] Implement checkout flow
- [ ] Handle webhooks for subscription status
- [ ] Add billing portal link
- [ ] Test trial → paid conversion

**Deliverables:**
- Subscription billing working
- Customers can pay for the service

---

### Phase 10: Real-time Sync (Optional Enhancement)
**Estimated Time:** 4-6 hours
**Status:** Not Started

**What happens:**
- Enable real-time updates across users
- Multiple people can work simultaneously

**Checklist:**
- [ ] Enable Supabase Realtime for key tables
- [ ] Implement subscription handlers
- [ ] Handle concurrent edits
- [ ] Add presence indicators (who's online)

**Deliverables:**
- Multi-user real-time collaboration

---

## File Structure After Migration

```
scheduler/
├── lib/
│   ├── supabase.ts              # Supabase client initialization
│   └── database.types.ts        # Auto-generated TypeScript types
│
├── services/
│   ├── auth.service.ts          # Authentication operations
│   ├── organization.service.ts  # Organization CRUD
│   ├── jobs.service.ts          # Jobs and quotes
│   ├── personnel.service.ts     # Personnel, teams, roles, shifts
│   ├── hangars.service.ts       # Bases and hangars
│   ├── financial.service.ts     # Expenses, capex, financial log
│   └── settings.service.ts      # Organization settings
│
├── hooks/
│   ├── useAuth.ts               # Auth state hook
│   ├── useOrganization.ts       # Organization data hook
│   └── useGameState.ts          # Game state sync hook
│
├── contexts/
│   └── AuthContext.tsx          # Updated for Supabase
│
├── components/                   # Existing components (updated)
│   └── ...
│
├── App.tsx                       # Main app (updated for Supabase)
├── types.ts                      # TypeScript types (kept for reference)
├── constants.ts                  # Default values for new orgs
│
├── .env.local                    # Environment variables (not in git)
├── package.json                  # Updated with new dependencies
└── ...
```

---

## Environment Variables

```bash
# .env.local (create this file - it's gitignored)

# Supabase (required)
VITE_SUPABASE_URL=https://[your-project-id].supabase.co
VITE_SUPABASE_ANON_KEY=[your-anon-key]

# Stripe (post-MVP)
VITE_STRIPE_PUBLISHABLE_KEY=[your-stripe-publishable-key]
```

**Note:** The anon key is safe to expose in frontend code. It only allows access that RLS policies permit.

---

## Technical Decisions Log

| Decision | Choice | Rationale |
|----------|--------|-----------|
| Backend | Supabase (PostgreSQL) | Best for relational data, great docs, Claude Code friendly |
| Hosting | Vercel | Easiest deployment, auto-deploys, free tier |
| Domain | mro-ai.com | Owned domain, professional branding |
| IDE | VS Code | Free, industry standard, excellent terminal |
| Auth | Supabase Auth | Integrated solution, simplifies architecture |
| Auth Methods | Google OAuth + Email/Password | User choice, Google for convenience |
| Email Verification | Required | Security best practice |
| Trial Period | 14 days | Industry standard for SaaS |
| Multi-tenancy | Row Level Security | Database-level isolation, most secure |
| Tenant ID | organization_id (UUID) | Every table linked to organization |
| Pricing | Flat rate per org | Simplifies DB design, no seat counting |
| User roles | owner/admin/manager/technician/viewer | Flexible permissions |
| Payments | Stripe (post-MVP) | Industry standard, great Supabase integration |
| Offline | Deferred | Adds significant complexity |
| Real-time | Deferred | Nice-to-have, not critical for launch |

---

## Risk Mitigation

| Risk | Impact | Mitigation |
|------|--------|------------|
| Data loss during migration | High | Keep IndexedDB backup, validate before removing |
| Auth failures | High | Proper error handling, clear error messages |
| Supabase outage | Medium | Users notified, data safe, wait for recovery |
| Performance issues | Medium | Use indexes, implement pagination |
| Cost overruns | Low | Set up billing alerts, monitor usage |
| Security breach | High | RLS policies, regular audits, no secrets in code |

---

## Success Criteria

### MVP Ready When:
- [ ] Users can sign up and create organization
- [ ] Users can invite team members
- [ ] All existing features work with cloud data
- [ ] Data persists across sessions/devices
- [ ] Multiple users can access same organization
- [ ] Role-based permissions enforced
- [ ] Deployed and accessible via URL

### Post-MVP Goals:
- [ ] Stripe billing operational
- [ ] 10+ paying customers
- [ ] <100ms average API response time
- [ ] 99.9% uptime
- [ ] mro-ai.com live and working

---

## Reference Links

**Supabase:**
- [Supabase Documentation](https://supabase.com/docs)
- [Supabase Auth Guide](https://supabase.com/docs/guides/auth)
- [Row Level Security](https://supabase.com/docs/guides/auth/row-level-security)
- [Supabase + React](https://supabase.com/docs/guides/getting-started/quickstarts/reactjs)

**Vercel:**
- [Vercel Documentation](https://vercel.com/docs)
- [Deploy React App](https://vercel.com/guides/deploying-react-with-vercel)

**Stripe (for later):**
- [Stripe + Supabase Template](https://github.com/vercel/nextjs-subscription-payments)

**VS Code:**
- [VS Code Download](https://code.visualstudio.com)
- [VS Code Terminal](https://code.visualstudio.com/docs/terminal/basics)

---

## Open Questions

### Resolved Decisions:
1. ~~**Social login?**~~ → **Google Sign-In + Email/Password** (both available)
2. ~~**Trial period?**~~ → **14 days** free before payment required
3. ~~**Email verification?**~~ → **Required** before accessing app
4. ~~**Domain name?**~~ → **mro-ai.com** (owned, needs DNS migration)

### Remaining Questions:
- None currently - all major decisions resolved!

---

## Changelog

| Version | Date | Changes |
|---------|------|---------|
| 1.0 | Initial | Database schema, phases |
| 2.0 | - | Added tech stack decisions, architecture diagrams, VS Code workflow, Vercel hosting, cost projections |
| 3.0 | Current | Added business decisions: Google Sign-In, 14-day trial, email verification required, mro-ai.com domain with DNS migration instructions |

---

*This document serves as the single source of truth for the AeroManager SaaS migration. Claude Code should reference this document before making architectural decisions.*
