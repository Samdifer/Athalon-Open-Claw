

export interface AircraftModel {
  id: string;
  name: string;
  manufacturer: string;
  // Size removed; compatibility is now determined by Hangar.supportedTypes explicitly
}

export interface QuoteLineItem {
  id: string;
  description: string; // "Squawk" or Service Name
  category?: 'Labor' | 'Part' | 'Service'; // New category for markup logic
  laborHours: number;
  laborRate: number; // Hourly rate for this specific line
  partsCost: number; // Estimated parts/service cost to the shop
  partsMarkup: number; // % markup on parts (e.g. 1.15 for 15%)
  fixedPrice?: number; // If set, overrides calculated T&M
}

export interface StandardService extends QuoteLineItem {
  applicableModelId?: string; // If undefined/null, it applies to ALL aircraft (Common). Otherwise, specific ID.
}

export interface Job {
  id: string;
  customer: string; // e.g., "N77NZ"
  aircraftType: string; // Matches AircraftModel.id
  description: string; // e.g., "Starlink Installation"
  estimatedHours: number;
  revenue: number;
  color: string;
  deadlineDays: number; // Days from start to finish before penalties
  requiredHangarSize: 'Small' | 'Medium' | 'Large';
  isAOG: boolean; // Aircraft on Ground (High priority)
  arrivalDay?: number; // Day the aircraft arrives/becomes available in backlog
  
  // New Quoting Data
  quoteLines?: QuoteLineItem[];
  partsRevenue?: number; // Total parts revenue charged to customer

  // Notes
  notes?: string;

  // Project Stage
  stageId?: string; // Reference to ProjectStage.id
}

export type PaymentStatus = 'pending' | 'invoiced' | 'paid' | 'overdue';

export interface ScheduledJob extends Job {
  startDate: number; // Day index (0-365)
  hangarId: string;
  progress: number; // 0 to estimatedHours
  status: 'Scheduled' | 'In Progress' | 'Completed' | 'Late';
  endDate?: number; // Day index when completed
  paymentReceived?: boolean; // Has the revenue been collected? (deprecated, use paymentStatus)
  paymentStatus?: PaymentStatus; // Payment tracking status
  paymentDueDate?: number; // Day index when payment is due (completion + paymentTerms)
  invoicedDate?: number; // Day index when invoice was sent
  paidDate?: number; // Day index when payment was received
  nonWorkDays?: number[]; // Array of day offsets (0-indexed from startDate) where no work is performed
  dailyEffort?: Record<number, number>; // Map of day offset to effort (0.0 to 1.0). Defaults to 1.0.
}

export interface Hangar {
  id: string;
  name: string;
  size: 'Small' | 'Medium' | 'Large';
  supportedTypes: string[]; // Array of AircraftModel IDs
  baseId: string; // Reference to Base
}

// --- New Personnel Management Types ---

export interface Base {
  id: string;
  name: string;
  location: string;
}

export interface Shift {
  id: string;
  name: string;
  days: number[]; // 0=Sun, 1=Mon, ..., 6=Sat
  startHour: number; // 0-23
  duration: number; // hours (Total time taken in day)
  breakCount?: number; // Number of breaks
  breakDuration?: number; // Duration per break in minutes
  meetingDuration?: number; // Duration of daily meeting/handover in minutes
}

export interface Role {
  id: string;
  name: string;
  baseEfficiency: number; // 1.0 = Standard, 1.2 = Fast, 0.8 = Slow
  hourlyRate: number; // Base hourly rate before burden
  burdenMultiplier: number; // Default 1.35, multiplied by hourlyRate to get fully burdened cost
  hourlyCost: number; // Fully burdened hourly cost (hourlyRate * burdenMultiplier)
}

export interface RolePackage {
  id: string;
  name: string;
  description: string;
  roles: Omit<Role, 'id'>[]; // Roles without IDs (they'll be generated on import)
}

export interface AircraftPackage {
  id: string;
  name: string;
  description: string;
  isBuiltIn: boolean;
  aircraft: Omit<AircraftModel, 'id'>[]; // Aircraft without IDs (generated on import)
}

export interface FacilityPackageHangar {
  name: string;
  size: 'Small' | 'Medium' | 'Large';
  supportedTypes: string[];
  baseIndex: number; // References index in bases array
}

export interface FacilityPackage {
  id: string;
  name: string;
  description: string;
  bases: Omit<Base, 'id'>[];
  hangars: FacilityPackageHangar[];
}

export interface AircraftConflict {
  incoming: Omit<AircraftModel, 'id'>;
  existing: AircraftModel;
  resolution: 'overwrite' | 'skip' | 'keep_both' | null;
}

export interface Team {
  id: string;
  name: string;
  color: string; // Tailwind class or hex
  shiftId: string; // Reference to Shift
  baseId?: string; // Reference to Base
}

export interface Personnel {
  id: string;
  name: string;
  roleId: string;
  teamId: string | null; // If null, maybe floater or unassigned
  baseId?: string; // Reference to Base (Location)
  efficiencyOverride?: number; // If defined, overrides Role baseEfficiency
}

// --- Financial Planning Types ---

export interface ExpenseItem {
  id: string;
  category: 'Facility' | 'Admin' | 'IT' | 'Marketing' | 'Personnel' | 'Other';
  name: string;
  monthlyCost: number;
  // Map of "YYYY-M" (e.g., "2025-0" for Jan 2025) to overridden value.
  overrides?: Record<string, number>; 
}

export interface CapexItem {
  id: string;
  name: string;
  cost: number;
  plannedDay: number; // Day index when it hits
  amortize: boolean; // If true, cost/12 is added to monthly overhead
}

export interface MarkupTier {
  maxLimit: number; // The upper bound of this tier (e.g. 500)
  markup: number; // The multiplier (e.g. 1.30 for 30%)
}

export interface Holiday {
  id: string;
  name: string;
  date: string; // YYYY-MM-DD
  dayIndex: number;
  enabled: boolean;
}

// --------------------------------------

export interface ProjectStage {
  id: string;
  label: string;
  color: string; // Tailwind class
  description: string;
}

export interface GameEvent {
  id: string;
  title: string;
  description: string;
  impact: 'efficiency' | 'financial' | 'schedule';
  choices: {
    label: string;
    action: (state: GameState) => Partial<GameState>;
  }[];
}

export interface FinancialLogEntry {
  day: number;
  income: number; // Accrued based on shop rate * hours worked
  spend: number; // Labor cost * hours worked + overhead
  profit: number;
}

export interface GameNotification {
  id: string;
  message: string;
  timestamp: number;
}

export interface UIState {
  backlogOpen: boolean;
  analyticsOpen: boolean; // Bottom KPI panel
  pnlOpen: boolean;
  capacityOpen: boolean;
  rosterOpen: boolean;
  cellWidth: number;
  layoutDims: {
    backlogWidth: number;
    rosterWidth: number;
    capacityHeight: number;
    pnlHeight: number;
    analyticsHeight: number;
  };
  popouts: {
    analytics: boolean;
    backlog: boolean;
    pnl: boolean;
    cashflow: boolean;
    capacity: boolean;
    roster: boolean;
    graveyard?: boolean;
    projectList?: boolean;
    unifiedCapacity?: boolean;
  };
  scenarioStart?: number;
  scenarioEnd?: number;
  selectedBaseId: string;
  
  // Tutorial State
  tutorialActive: boolean;
  tutorialStep: number;

  // Onboarding completion tracking
  onboardingCompleted: boolean;
  onboardingCompletedAt?: number;
  completedSections: string[];
}

export interface ProgressCursor {
  id: string;
  label: string;
  dayOffset: number; // Relative to Today. Positive = Future, Negative = Past
  color: string; // Tailwind bg class
  enabled: boolean;
}

export interface GameState {
  day: number;
  cash: number;
  efficiency: number; // Global shop modifier (morale/events)
  paused: boolean;
  speed: number;
  
  // Configurable Data
  hangars: Hangar[];
  aircraftModels: AircraftModel[];
  customAircraftPackages: AircraftPackage[]; // User-created aircraft packages
  shopRate: number; // Global hourly rate
  standardServices: StandardService[]; // Registry of service templates
  projectStages: ProjectStage[]; // Configurable Workflow Stages

  // Financial Config
  partMarkups: MarkupTier[];
  serviceMarkups: MarkupTier[];
  paymentTerms: 7 | 15 | 30 | 45 | 60; // Days until payment received after job completion

  backlog: Job[];
  schedule: ScheduledJob[];
  graveyard: Job[]; // Deleted jobs
  
  // New Personnel Data
  bases: Base[]; // Locations
  personnel: Personnel[];
  teams: Team[];
  shifts: Shift[]; // Registry of Shifts
  roles: Role[];
  holidays: Holiday[];

  overheadDaily: number;
  capacityBufferPercent: number; // 0-50, warning threshold (15 = warn at 85% capacity)

  // New Financial Data
  expenseItems: ExpenseItem[];
  capexItems: CapexItem[];
  
  // Timeline Cursors
  cursors: ProgressCursor[];

  events: GameEvent[];
  activeEvent: GameEvent | null;
  notifications: GameNotification[];
  
  financialHistory: FinancialLogEntry[];
  
  // Persistent UI Preferences
  uiState: UIState;
}

export const MONTH_NAMES = [
  "Jan", "Feb", "Mar", "Apr", "May", "Jun",
  "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
];

// --- User Management & Auth Types ---

export type SystemRole = 'Admin' | 'Manager' | 'Technician';
export type PlatformRole = 'super_admin' | 'support_admin' | 'billing_admin';
export type SubscriptionStatus = 'trial' | 'active' | 'cancelled' | 'past_due';

export interface User {
  id: string;
  email: string;
  name: string;
  role: SystemRole;
  status: 'Active' | 'Invited' | 'Inactive';
  lastLogin?: number;
  avatar?: string;
  // Platform admin fields
  isPlatformAdmin?: boolean;
  platformRole?: PlatformRole;
  organizationId?: string;
}

// --- Platform Admin Types ---

export interface Organization {
  id: string;
  name: string;
  slug: string;
  subscriptionStatus: SubscriptionStatus;
  subscriptionTier: string;
  trialEndsAt: string | null;
  stripeCustomerId: string | null;
  gracePeriodUsed: boolean;
  gracePeriodEndsAt: string | null;
  createdAt: string;
  updatedAt: string;
  // Computed fields (from joins)
  userCount?: number;
  ownerEmail?: string;
  ownerName?: string;
}

export interface PlatformAdminInvite {
  id: string;
  email: string;
  role: PlatformRole;
  invitedBy: string | null;
  token: string;
  expiresAt: string;
  acceptedAt: string | null;
  createdAt: string;
}

export interface PlatformAuditLog {
  id: string;
  adminId: string | null;
  action: string;
  targetType: 'organization' | 'user' | 'subscription' | 'platform_admin' | null;
  targetId: string | null;
  details: Record<string, any>;
  ipAddress: string | null;
  createdAt: string;
}

export interface ImpersonationSession {
  adminId: string;
  adminEmail: string;
  targetUserId: string;
  targetUserEmail: string;
  targetOrgId: string;
  targetOrgName: string;
  startedAt: number;
  expiresAt: number; // 1 hour from start
}

export interface PlatformMetrics {
  totalOrganizations: number;
  activeOrganizations: number;
  trialOrganizations: number;
  cancelledOrganizations: number;
  pastDueOrganizations: number;
  totalUsers: number;
  signupsLast7Days: number;
  signupsLast30Days: number;
  trialsExpiringIn7Days: number;
  mrr: number; // Monthly Recurring Revenue
  arr: number; // Annual Recurring Revenue
}

export interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  login: (email: string, pass: string) => Promise<void>;
  register: (email: string, pass: string, name: string) => Promise<void>;
  logout: () => void;
  isLoading: boolean;

  // Admin Management
  allUsers: User[];
  updateUser: (id: string, updates: Partial<User>) => Promise<void>;
  deleteUser: (id: string) => Promise<void>;
  inviteUser: (email: string, name: string, role: SystemRole) => Promise<void>;
  changePassword: (currentPass: string, newPass: string) => Promise<void>;

  // Platform Admin
  isPlatformAdmin: boolean;
  platformRole: PlatformRole | null;

  // Impersonation
  impersonationSession: ImpersonationSession | null;
  startImpersonation: (targetUserId: string) => Promise<void>;
  endImpersonation: () => Promise<void>;

  // Email Verification
  emailVerificationPending: boolean;
  resendVerificationEmail: (email: string) => Promise<void>;
}

// Invitation for user invites
export interface Invitation {
  id: string;
  organizationId: string;
  email: string;
  role: 'admin' | 'manager' | 'technician' | 'viewer';
  invitedBy: string | null;
  token: string;
  expiresAt: string;
  acceptedAt: string | null;
  createdAt: string;
}