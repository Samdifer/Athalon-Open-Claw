/**
 * Delta-Based State Management for Undo/Redo
 *
 * Instead of storing full state snapshots (500KB-2MB each),
 * we store only the changes (deltas) between states.
 *
 * Expected memory reduction: ~95% (25-100MB → 1-5MB for 50 history entries)
 */

import { GameState } from '../types';

// Keys to track for undo/redo (excludes UI state and transient data)
const TRACKABLE_KEYS: (keyof GameState)[] = [
  'day',
  'cash',
  'efficiency',
  'paused',
  'speed',
  'hangars',
  'aircraftModels',
  'customAircraftPackages',
  'shopRate',
  'standardServices',
  'projectStages',
  'partMarkups',
  'serviceMarkups',
  'paymentTerms',
  'backlog',
  'schedule',
  'graveyard',
  'bases',
  'personnel',
  'teams',
  'shifts',
  'roles',
  'holidays',
  'overheadDaily',
  'capacityBufferPercent',
  'expenseItems',
  'capexItems',
  'cursors',
  'events',
  'activeEvent',
  'notifications',
  // Note: financialHistory excluded - append-only, grows large
  // Note: uiState excluded - UI preferences shouldn't be undoable
];

// Keys that are expensive to compare deeply (arrays of objects)
const DEEP_COMPARE_KEYS: Set<keyof GameState> = new Set([
  'hangars',
  'aircraftModels',
  'customAircraftPackages',
  'standardServices',
  'projectStages',
  'partMarkups',
  'serviceMarkups',
  'backlog',
  'schedule',
  'graveyard',
  'bases',
  'personnel',
  'teams',
  'shifts',
  'roles',
  'holidays',
  'expenseItems',
  'capexItems',
  'cursors',
  'events',
  'notifications',
]);

export interface StateDelta {
  desc: string;
  changes: {
    key: keyof GameState;
    previousValue: unknown;
  }[];
}

/**
 * Fast shallow comparison for primitives, deep JSON comparison for objects/arrays
 */
function valuesEqual(a: unknown, b: unknown, key: keyof GameState): boolean {
  // Primitive comparison
  if (a === b) return true;

  // For arrays/objects, use JSON comparison (effective for our data structures)
  if (DEEP_COMPARE_KEYS.has(key)) {
    return JSON.stringify(a) === JSON.stringify(b);
  }

  return false;
}

/**
 * Calculate the delta between previous and next state
 * Returns only the keys that changed and their previous values
 */
export function calculateDelta(
  prevState: GameState,
  nextState: GameState,
  desc: string
): StateDelta {
  const changes: StateDelta['changes'] = [];

  for (const key of TRACKABLE_KEYS) {
    const prevValue = prevState[key];
    const nextValue = nextState[key];

    if (!valuesEqual(prevValue, nextValue, key)) {
      // Store a deep copy of the previous value
      changes.push({
        key,
        previousValue: DEEP_COMPARE_KEYS.has(key)
          ? JSON.parse(JSON.stringify(prevValue))
          : prevValue,
      });
    }
  }

  return { desc, changes };
}

/**
 * Apply a delta to restore the previous state
 * Returns a new state object with the changes reverted
 */
export function applyDelta(
  currentState: GameState,
  delta: StateDelta
): GameState {
  const newState = { ...currentState };

  for (const change of delta.changes) {
    // Deep copy for objects/arrays, direct assignment for primitives
    (newState as Record<string, unknown>)[change.key] =
      DEEP_COMPARE_KEYS.has(change.key)
        ? JSON.parse(JSON.stringify(change.previousValue))
        : change.previousValue;
  }

  return newState;
}

/**
 * Create a forward delta from a reverse delta
 * Used when moving an undo entry to the redo stack
 */
export function createForwardDelta(
  currentState: GameState,
  reverseDelta: StateDelta
): StateDelta {
  const changes: StateDelta['changes'] = [];

  for (const change of reverseDelta.changes) {
    const currentValue = currentState[change.key];
    changes.push({
      key: change.key,
      previousValue: DEEP_COMPARE_KEYS.has(change.key)
        ? JSON.parse(JSON.stringify(currentValue))
        : currentValue,
    });
  }

  return { desc: reverseDelta.desc, changes };
}

/**
 * Estimate the memory size of a delta (for debugging/monitoring)
 */
export function estimateDeltaSize(delta: StateDelta): number {
  return JSON.stringify(delta).length;
}

/**
 * Check if a delta is empty (no actual changes)
 */
export function isDeltaEmpty(delta: StateDelta): boolean {
  return delta.changes.length === 0;
}
